$(document).ready(function(){
	//$("#list-thongke").hide();
	//$("#list-quanly").hide();
	//$("#list-thongbao").hide();
	$("#title-thongke").click(function(){
	//	$("#list-thongke").toggle();
	});
	$("#title-quanly").click(function(){
	//	$("#list-quanly").toggle();
	});		
	$("#title-thongbao").click(function(){
	//	$("#list-thongbao").toggle();
	});						   
})