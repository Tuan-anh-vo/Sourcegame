<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-10 20:50:03 --> Config Class Initialized
INFO - 2016-11-10 20:50:03 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:50:04 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:50:04 --> Utf8 Class Initialized
INFO - 2016-11-10 20:50:04 --> URI Class Initialized
DEBUG - 2016-11-10 20:50:04 --> No URI present. Default controller set.
INFO - 2016-11-10 20:50:04 --> Router Class Initialized
INFO - 2016-11-10 20:50:04 --> Output Class Initialized
INFO - 2016-11-10 20:50:04 --> Security Class Initialized
DEBUG - 2016-11-10 20:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:50:04 --> Input Class Initialized
INFO - 2016-11-10 20:50:04 --> Language Class Initialized
INFO - 2016-11-10 20:50:04 --> Language Class Initialized
INFO - 2016-11-10 20:50:04 --> Config Class Initialized
INFO - 2016-11-10 20:50:04 --> Loader Class Initialized
INFO - 2016-11-10 20:50:04 --> Helper loaded: common_helper
INFO - 2016-11-10 20:50:04 --> Helper loaded: url_helper
INFO - 2016-11-10 20:50:04 --> Database Driver Class Initialized
ERROR - 2016-11-10 20:50:04 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\do_long\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2016-11-10 20:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:50:04 --> Parser Class Initialized
INFO - 2016-11-10 20:50:04 --> Controller Class Initialized
DEBUG - 2016-11-10 20:50:04 --> Home MX_Controller Initialized
INFO - 2016-11-10 20:50:05 --> Model Class Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 20:50:05 --> Model Class Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 20:50:05 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 20:50:05 --> Model Class Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 20:50:05 --> Model Class Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 20:50:05 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 20:50:05 --> Model Class Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 20:50:05 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 20:50:05 --> Model Class Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 20:50:05 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 20:50:05 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 20:50:05 --> Final output sent to browser
DEBUG - 2016-11-10 20:50:05 --> Total execution time: 1.8490
INFO - 2016-11-10 20:53:12 --> Config Class Initialized
INFO - 2016-11-10 20:53:12 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:53:12 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:53:12 --> Utf8 Class Initialized
INFO - 2016-11-10 20:53:12 --> URI Class Initialized
DEBUG - 2016-11-10 20:53:12 --> No URI present. Default controller set.
INFO - 2016-11-10 20:53:12 --> Router Class Initialized
INFO - 2016-11-10 20:53:12 --> Output Class Initialized
INFO - 2016-11-10 20:53:12 --> Security Class Initialized
DEBUG - 2016-11-10 20:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:53:12 --> Input Class Initialized
INFO - 2016-11-10 20:53:12 --> Language Class Initialized
INFO - 2016-11-10 20:53:12 --> Language Class Initialized
INFO - 2016-11-10 20:53:12 --> Config Class Initialized
INFO - 2016-11-10 20:53:12 --> Loader Class Initialized
INFO - 2016-11-10 20:53:12 --> Helper loaded: common_helper
INFO - 2016-11-10 20:53:12 --> Helper loaded: url_helper
INFO - 2016-11-10 20:53:12 --> Database Driver Class Initialized
ERROR - 2016-11-10 20:53:12 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\do_long\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2016-11-10 20:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:53:12 --> Parser Class Initialized
INFO - 2016-11-10 20:53:12 --> Controller Class Initialized
DEBUG - 2016-11-10 20:53:12 --> Home MX_Controller Initialized
INFO - 2016-11-10 20:53:12 --> Model Class Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 20:53:12 --> Model Class Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 20:53:12 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 20:53:12 --> Model Class Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 20:53:12 --> Model Class Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 20:53:12 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 20:53:12 --> Model Class Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 20:53:12 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 20:53:12 --> Model Class Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 20:53:12 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 20:53:12 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 20:53:12 --> Final output sent to browser
DEBUG - 2016-11-10 20:53:12 --> Total execution time: 0.2688
INFO - 2016-11-10 20:57:56 --> Config Class Initialized
INFO - 2016-11-10 20:57:56 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:57:56 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:57:56 --> Utf8 Class Initialized
INFO - 2016-11-10 20:57:56 --> URI Class Initialized
DEBUG - 2016-11-10 20:57:56 --> No URI present. Default controller set.
INFO - 2016-11-10 20:57:56 --> Router Class Initialized
INFO - 2016-11-10 20:57:56 --> Output Class Initialized
INFO - 2016-11-10 20:57:56 --> Security Class Initialized
DEBUG - 2016-11-10 20:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:57:56 --> Input Class Initialized
INFO - 2016-11-10 20:57:56 --> Language Class Initialized
INFO - 2016-11-10 20:57:56 --> Language Class Initialized
INFO - 2016-11-10 20:57:56 --> Config Class Initialized
INFO - 2016-11-10 20:57:56 --> Loader Class Initialized
INFO - 2016-11-10 20:57:56 --> Helper loaded: common_helper
INFO - 2016-11-10 20:57:56 --> Helper loaded: url_helper
INFO - 2016-11-10 20:57:56 --> Database Driver Class Initialized
ERROR - 2016-11-10 20:57:56 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\do_long\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2016-11-10 20:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:57:56 --> Parser Class Initialized
INFO - 2016-11-10 20:57:56 --> Controller Class Initialized
DEBUG - 2016-11-10 20:57:56 --> Home MX_Controller Initialized
INFO - 2016-11-10 20:57:56 --> Model Class Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 20:57:56 --> Model Class Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 20:57:56 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 20:57:56 --> Model Class Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 20:57:56 --> Model Class Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 20:57:56 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 20:57:56 --> Model Class Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 20:57:56 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 20:57:56 --> Model Class Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 20:57:56 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 20:57:56 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 20:57:56 --> Final output sent to browser
DEBUG - 2016-11-10 20:57:56 --> Total execution time: 0.3135
INFO - 2016-11-10 20:58:28 --> Config Class Initialized
INFO - 2016-11-10 20:58:28 --> Hooks Class Initialized
DEBUG - 2016-11-10 20:58:28 --> UTF-8 Support Enabled
INFO - 2016-11-10 20:58:28 --> Utf8 Class Initialized
INFO - 2016-11-10 20:58:28 --> URI Class Initialized
DEBUG - 2016-11-10 20:58:28 --> No URI present. Default controller set.
INFO - 2016-11-10 20:58:28 --> Router Class Initialized
INFO - 2016-11-10 20:58:28 --> Output Class Initialized
INFO - 2016-11-10 20:58:28 --> Security Class Initialized
DEBUG - 2016-11-10 20:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 20:58:28 --> Input Class Initialized
INFO - 2016-11-10 20:58:28 --> Language Class Initialized
INFO - 2016-11-10 20:58:28 --> Language Class Initialized
INFO - 2016-11-10 20:58:28 --> Config Class Initialized
INFO - 2016-11-10 20:58:28 --> Loader Class Initialized
INFO - 2016-11-10 20:58:28 --> Helper loaded: common_helper
INFO - 2016-11-10 20:58:28 --> Helper loaded: url_helper
INFO - 2016-11-10 20:58:28 --> Database Driver Class Initialized
ERROR - 2016-11-10 20:58:28 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\do_long\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2016-11-10 20:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 20:58:28 --> Parser Class Initialized
INFO - 2016-11-10 20:58:28 --> Controller Class Initialized
DEBUG - 2016-11-10 20:58:28 --> Home MX_Controller Initialized
INFO - 2016-11-10 20:58:28 --> Model Class Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 20:58:28 --> Model Class Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 20:58:28 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 20:58:28 --> Model Class Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 20:58:28 --> Model Class Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 20:58:28 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 20:58:28 --> Model Class Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 20:58:28 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 20:58:28 --> Model Class Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 20:58:28 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 20:58:28 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 20:58:28 --> Final output sent to browser
DEBUG - 2016-11-10 20:58:28 --> Total execution time: 0.1507
INFO - 2016-11-10 21:11:32 --> Config Class Initialized
INFO - 2016-11-10 21:11:32 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:11:32 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:11:32 --> Utf8 Class Initialized
INFO - 2016-11-10 21:11:32 --> URI Class Initialized
DEBUG - 2016-11-10 21:11:32 --> No URI present. Default controller set.
INFO - 2016-11-10 21:11:32 --> Router Class Initialized
INFO - 2016-11-10 21:11:32 --> Output Class Initialized
INFO - 2016-11-10 21:11:32 --> Security Class Initialized
DEBUG - 2016-11-10 21:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:11:32 --> Input Class Initialized
INFO - 2016-11-10 21:11:32 --> Language Class Initialized
INFO - 2016-11-10 21:11:32 --> Language Class Initialized
INFO - 2016-11-10 21:11:32 --> Config Class Initialized
INFO - 2016-11-10 21:11:32 --> Loader Class Initialized
INFO - 2016-11-10 21:11:32 --> Helper loaded: common_helper
INFO - 2016-11-10 21:11:32 --> Helper loaded: url_helper
INFO - 2016-11-10 21:11:32 --> Database Driver Class Initialized
INFO - 2016-11-10 21:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:11:32 --> Parser Class Initialized
INFO - 2016-11-10 21:11:32 --> Controller Class Initialized
DEBUG - 2016-11-10 21:11:32 --> Home MX_Controller Initialized
INFO - 2016-11-10 21:11:32 --> Model Class Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 21:11:32 --> Model Class Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 21:11:32 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 21:11:32 --> Model Class Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 21:11:32 --> Model Class Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 21:11:32 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 21:11:32 --> Model Class Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 21:11:32 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 21:11:32 --> Model Class Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 21:11:32 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 21:11:32 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 21:11:32 --> Final output sent to browser
DEBUG - 2016-11-10 21:11:32 --> Total execution time: 0.7341
INFO - 2016-11-10 21:12:40 --> Config Class Initialized
INFO - 2016-11-10 21:12:40 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:12:40 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:12:40 --> Utf8 Class Initialized
INFO - 2016-11-10 21:12:40 --> URI Class Initialized
DEBUG - 2016-11-10 21:12:40 --> No URI present. Default controller set.
INFO - 2016-11-10 21:12:40 --> Router Class Initialized
INFO - 2016-11-10 21:12:40 --> Output Class Initialized
INFO - 2016-11-10 21:12:40 --> Security Class Initialized
DEBUG - 2016-11-10 21:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:12:40 --> Input Class Initialized
INFO - 2016-11-10 21:12:40 --> Language Class Initialized
INFO - 2016-11-10 21:12:40 --> Language Class Initialized
INFO - 2016-11-10 21:12:40 --> Config Class Initialized
INFO - 2016-11-10 21:12:40 --> Loader Class Initialized
INFO - 2016-11-10 21:12:40 --> Helper loaded: common_helper
INFO - 2016-11-10 21:12:40 --> Helper loaded: url_helper
INFO - 2016-11-10 21:12:40 --> Database Driver Class Initialized
INFO - 2016-11-10 21:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:12:40 --> Parser Class Initialized
INFO - 2016-11-10 21:12:40 --> Controller Class Initialized
DEBUG - 2016-11-10 21:12:40 --> Home MX_Controller Initialized
INFO - 2016-11-10 21:12:40 --> Model Class Initialized
DEBUG - 2016-11-10 21:12:40 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 21:12:40 --> Model Class Initialized
DEBUG - 2016-11-10 21:12:40 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 21:12:40 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 21:12:40 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 21:12:40 --> Model Class Initialized
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 21:12:41 --> Model Class Initialized
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 21:12:41 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 21:12:41 --> Model Class Initialized
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 21:12:41 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 21:12:41 --> Model Class Initialized
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 21:12:41 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 21:12:41 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 21:12:41 --> Final output sent to browser
DEBUG - 2016-11-10 21:12:41 --> Total execution time: 0.2187
INFO - 2016-11-10 21:14:14 --> Config Class Initialized
INFO - 2016-11-10 21:14:14 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:14:14 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:14:14 --> Utf8 Class Initialized
INFO - 2016-11-10 21:14:14 --> URI Class Initialized
DEBUG - 2016-11-10 21:14:14 --> No URI present. Default controller set.
INFO - 2016-11-10 21:14:14 --> Router Class Initialized
INFO - 2016-11-10 21:14:14 --> Output Class Initialized
INFO - 2016-11-10 21:14:14 --> Security Class Initialized
DEBUG - 2016-11-10 21:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:14:14 --> Input Class Initialized
INFO - 2016-11-10 21:14:14 --> Language Class Initialized
INFO - 2016-11-10 21:14:14 --> Language Class Initialized
INFO - 2016-11-10 21:14:14 --> Config Class Initialized
INFO - 2016-11-10 21:14:14 --> Loader Class Initialized
INFO - 2016-11-10 21:14:14 --> Helper loaded: common_helper
INFO - 2016-11-10 21:14:14 --> Helper loaded: url_helper
INFO - 2016-11-10 21:14:14 --> Database Driver Class Initialized
INFO - 2016-11-10 21:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:14:14 --> Parser Class Initialized
INFO - 2016-11-10 21:14:14 --> Controller Class Initialized
DEBUG - 2016-11-10 21:14:14 --> Home MX_Controller Initialized
INFO - 2016-11-10 21:14:14 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 21:14:14 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 21:14:14 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 21:14:14 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 21:14:14 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 21:14:14 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 21:14:14 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 21:14:14 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 21:14:14 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 21:14:14 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 21:14:14 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 21:14:14 --> Final output sent to browser
DEBUG - 2016-11-10 21:14:14 --> Total execution time: 0.1813
INFO - 2016-11-10 21:14:17 --> Config Class Initialized
INFO - 2016-11-10 21:14:17 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:14:17 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:14:17 --> Utf8 Class Initialized
INFO - 2016-11-10 21:14:17 --> URI Class Initialized
DEBUG - 2016-11-10 21:14:17 --> No URI present. Default controller set.
INFO - 2016-11-10 21:14:17 --> Router Class Initialized
INFO - 2016-11-10 21:14:17 --> Output Class Initialized
INFO - 2016-11-10 21:14:17 --> Security Class Initialized
DEBUG - 2016-11-10 21:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:14:17 --> Input Class Initialized
INFO - 2016-11-10 21:14:17 --> Language Class Initialized
INFO - 2016-11-10 21:14:17 --> Language Class Initialized
INFO - 2016-11-10 21:14:17 --> Config Class Initialized
INFO - 2016-11-10 21:14:17 --> Loader Class Initialized
INFO - 2016-11-10 21:14:17 --> Helper loaded: common_helper
INFO - 2016-11-10 21:14:17 --> Helper loaded: url_helper
INFO - 2016-11-10 21:14:17 --> Database Driver Class Initialized
INFO - 2016-11-10 21:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:14:17 --> Parser Class Initialized
INFO - 2016-11-10 21:14:17 --> Controller Class Initialized
DEBUG - 2016-11-10 21:14:17 --> Home MX_Controller Initialized
INFO - 2016-11-10 21:14:17 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 21:14:17 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 21:14:17 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 21:14:17 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 21:14:17 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 21:14:17 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 21:14:17 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 21:14:17 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 21:14:17 --> Model Class Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 21:14:17 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 21:14:17 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 21:14:17 --> Final output sent to browser
DEBUG - 2016-11-10 21:14:17 --> Total execution time: 0.1713
INFO - 2016-11-10 21:15:49 --> Config Class Initialized
INFO - 2016-11-10 21:15:49 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:15:49 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:15:49 --> Utf8 Class Initialized
INFO - 2016-11-10 21:15:49 --> URI Class Initialized
DEBUG - 2016-11-10 21:15:49 --> No URI present. Default controller set.
INFO - 2016-11-10 21:15:49 --> Router Class Initialized
INFO - 2016-11-10 21:15:49 --> Output Class Initialized
INFO - 2016-11-10 21:15:49 --> Security Class Initialized
DEBUG - 2016-11-10 21:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:15:49 --> Input Class Initialized
INFO - 2016-11-10 21:15:49 --> Language Class Initialized
INFO - 2016-11-10 21:15:49 --> Language Class Initialized
INFO - 2016-11-10 21:15:49 --> Config Class Initialized
INFO - 2016-11-10 21:15:49 --> Loader Class Initialized
INFO - 2016-11-10 21:15:49 --> Helper loaded: common_helper
INFO - 2016-11-10 21:15:49 --> Helper loaded: url_helper
INFO - 2016-11-10 21:15:49 --> Database Driver Class Initialized
INFO - 2016-11-10 21:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:15:49 --> Parser Class Initialized
INFO - 2016-11-10 21:15:49 --> Controller Class Initialized
DEBUG - 2016-11-10 21:15:49 --> Home MX_Controller Initialized
INFO - 2016-11-10 21:15:49 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 21:15:49 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:49 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 21:15:49 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 21:15:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 21:15:49 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:15:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:15:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 21:15:49 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:49 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 21:15:49 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 21:15:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 21:15:49 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:15:50 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 21:15:50 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 21:15:50 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 21:15:50 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:50 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 21:15:50 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 21:15:50 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 21:15:50 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:15:50 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 21:15:50 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 21:15:50 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 21:15:50 --> Final output sent to browser
DEBUG - 2016-11-10 21:15:50 --> Total execution time: 0.5895
INFO - 2016-11-10 21:15:58 --> Config Class Initialized
INFO - 2016-11-10 21:15:58 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:15:58 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:15:58 --> Utf8 Class Initialized
INFO - 2016-11-10 21:15:58 --> URI Class Initialized
DEBUG - 2016-11-10 21:15:58 --> No URI present. Default controller set.
INFO - 2016-11-10 21:15:58 --> Router Class Initialized
INFO - 2016-11-10 21:15:58 --> Output Class Initialized
INFO - 2016-11-10 21:15:58 --> Security Class Initialized
DEBUG - 2016-11-10 21:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:15:58 --> Input Class Initialized
INFO - 2016-11-10 21:15:58 --> Language Class Initialized
INFO - 2016-11-10 21:15:58 --> Language Class Initialized
INFO - 2016-11-10 21:15:58 --> Config Class Initialized
INFO - 2016-11-10 21:15:58 --> Loader Class Initialized
INFO - 2016-11-10 21:15:58 --> Helper loaded: common_helper
INFO - 2016-11-10 21:15:58 --> Helper loaded: url_helper
INFO - 2016-11-10 21:15:59 --> Database Driver Class Initialized
INFO - 2016-11-10 21:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:15:59 --> Parser Class Initialized
INFO - 2016-11-10 21:15:59 --> Controller Class Initialized
DEBUG - 2016-11-10 21:15:59 --> Home MX_Controller Initialized
INFO - 2016-11-10 21:15:59 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 21:15:59 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 21:15:59 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 21:15:59 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 21:15:59 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 21:15:59 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 21:15:59 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 21:15:59 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 21:15:59 --> Model Class Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 21:15:59 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 21:15:59 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 21:15:59 --> Final output sent to browser
DEBUG - 2016-11-10 21:15:59 --> Total execution time: 0.2026
ERROR - 2016-11-10 21:23:32 --> Severity: Notice --> Use of undefined constant do_long - assumed 'do_long' C:\xampp\htdocs\do_long\application\config\config.php 20
ERROR - 2016-11-10 21:23:32 --> Severity: Warning --> Division by zero C:\xampp\htdocs\do_long\application\config\config.php 20
INFO - 2016-11-10 21:23:32 --> Config Class Initialized
INFO - 2016-11-10 21:23:32 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:23:32 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:23:32 --> Utf8 Class Initialized
INFO - 2016-11-10 21:23:32 --> URI Class Initialized
DEBUG - 2016-11-10 21:23:32 --> No URI present. Default controller set.
INFO - 2016-11-10 21:23:32 --> Router Class Initialized
INFO - 2016-11-10 21:23:32 --> Output Class Initialized
INFO - 2016-11-10 21:23:32 --> Security Class Initialized
DEBUG - 2016-11-10 21:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:23:32 --> Input Class Initialized
INFO - 2016-11-10 21:23:32 --> Language Class Initialized
INFO - 2016-11-10 21:23:32 --> Language Class Initialized
INFO - 2016-11-10 21:23:32 --> Config Class Initialized
INFO - 2016-11-10 21:23:32 --> Loader Class Initialized
INFO - 2016-11-10 21:23:32 --> Helper loaded: common_helper
INFO - 2016-11-10 21:23:32 --> Helper loaded: url_helper
INFO - 2016-11-10 21:23:32 --> Database Driver Class Initialized
INFO - 2016-11-10 21:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:23:33 --> Parser Class Initialized
INFO - 2016-11-10 21:23:33 --> Controller Class Initialized
DEBUG - 2016-11-10 21:23:33 --> Home MX_Controller Initialized
INFO - 2016-11-10 21:23:33 --> Model Class Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 21:23:33 --> Model Class Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 21:23:33 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 21:23:33 --> Model Class Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 21:23:33 --> Model Class Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 21:23:33 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 21:23:33 --> Model Class Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 21:23:33 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 21:23:33 --> Model Class Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 21:23:33 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 21:23:33 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 21:23:33 --> Final output sent to browser
DEBUG - 2016-11-10 21:23:33 --> Total execution time: 0.1889
INFO - 2016-11-10 21:24:15 --> Config Class Initialized
INFO - 2016-11-10 21:24:15 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:24:15 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:24:15 --> Utf8 Class Initialized
INFO - 2016-11-10 21:24:15 --> URI Class Initialized
DEBUG - 2016-11-10 21:24:15 --> No URI present. Default controller set.
INFO - 2016-11-10 21:24:15 --> Router Class Initialized
INFO - 2016-11-10 21:24:15 --> Output Class Initialized
INFO - 2016-11-10 21:24:15 --> Security Class Initialized
DEBUG - 2016-11-10 21:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:24:15 --> Input Class Initialized
INFO - 2016-11-10 21:24:15 --> Language Class Initialized
INFO - 2016-11-10 21:24:15 --> Language Class Initialized
INFO - 2016-11-10 21:24:15 --> Config Class Initialized
INFO - 2016-11-10 21:24:15 --> Loader Class Initialized
INFO - 2016-11-10 21:24:15 --> Helper loaded: common_helper
INFO - 2016-11-10 21:24:15 --> Helper loaded: url_helper
INFO - 2016-11-10 21:24:15 --> Database Driver Class Initialized
INFO - 2016-11-10 21:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:24:15 --> Parser Class Initialized
INFO - 2016-11-10 21:24:15 --> Controller Class Initialized
DEBUG - 2016-11-10 21:24:15 --> Home MX_Controller Initialized
INFO - 2016-11-10 21:24:15 --> Model Class Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 21:24:15 --> Model Class Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 21:24:15 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 21:24:15 --> Model Class Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 21:24:15 --> Model Class Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 21:24:15 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 21:24:15 --> Model Class Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 21:24:15 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 21:24:15 --> Model Class Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 21:24:15 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 21:24:15 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 21:24:15 --> Final output sent to browser
DEBUG - 2016-11-10 21:24:15 --> Total execution time: 0.2028
ERROR - 2016-11-10 21:26:43 --> Severity: Notice --> Use of undefined constant do_long - assumed 'do_long' C:\xampp\htdocs\do_long\application\config\config.php 20
INFO - 2016-11-10 21:26:44 --> Config Class Initialized
INFO - 2016-11-10 21:26:44 --> Hooks Class Initialized
DEBUG - 2016-11-10 21:26:44 --> UTF-8 Support Enabled
INFO - 2016-11-10 21:26:44 --> Utf8 Class Initialized
INFO - 2016-11-10 21:26:44 --> URI Class Initialized
DEBUG - 2016-11-10 21:26:44 --> No URI present. Default controller set.
INFO - 2016-11-10 21:26:44 --> Router Class Initialized
INFO - 2016-11-10 21:26:44 --> Output Class Initialized
INFO - 2016-11-10 21:26:44 --> Security Class Initialized
DEBUG - 2016-11-10 21:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 21:26:44 --> Input Class Initialized
INFO - 2016-11-10 21:26:44 --> Language Class Initialized
INFO - 2016-11-10 21:26:44 --> Language Class Initialized
INFO - 2016-11-10 21:26:44 --> Config Class Initialized
INFO - 2016-11-10 21:26:44 --> Loader Class Initialized
INFO - 2016-11-10 21:26:44 --> Helper loaded: common_helper
INFO - 2016-11-10 21:26:44 --> Helper loaded: url_helper
INFO - 2016-11-10 21:26:44 --> Database Driver Class Initialized
INFO - 2016-11-10 21:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 21:26:44 --> Parser Class Initialized
INFO - 2016-11-10 21:26:44 --> Controller Class Initialized
DEBUG - 2016-11-10 21:26:44 --> Home MX_Controller Initialized
INFO - 2016-11-10 21:26:44 --> Model Class Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 21:26:44 --> Model Class Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 21:26:44 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 21:26:44 --> Model Class Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 21:26:44 --> Model Class Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 21:26:44 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 21:26:44 --> Model Class Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 21:26:44 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 21:26:44 --> Model Class Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 21:26:44 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 21:26:44 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 21:26:44 --> Final output sent to browser
DEBUG - 2016-11-10 21:26:44 --> Total execution time: 0.6029
INFO - 2016-11-10 22:33:44 --> Config Class Initialized
INFO - 2016-11-10 22:33:44 --> Hooks Class Initialized
DEBUG - 2016-11-10 22:33:44 --> UTF-8 Support Enabled
INFO - 2016-11-10 22:33:44 --> Utf8 Class Initialized
INFO - 2016-11-10 22:33:44 --> URI Class Initialized
DEBUG - 2016-11-10 22:33:44 --> No URI present. Default controller set.
INFO - 2016-11-10 22:33:44 --> Router Class Initialized
INFO - 2016-11-10 22:33:44 --> Output Class Initialized
INFO - 2016-11-10 22:33:44 --> Security Class Initialized
DEBUG - 2016-11-10 22:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 22:33:44 --> Input Class Initialized
INFO - 2016-11-10 22:33:44 --> Language Class Initialized
INFO - 2016-11-10 22:33:44 --> Language Class Initialized
INFO - 2016-11-10 22:33:44 --> Config Class Initialized
INFO - 2016-11-10 22:33:44 --> Loader Class Initialized
INFO - 2016-11-10 22:33:44 --> Helper loaded: common_helper
INFO - 2016-11-10 22:33:44 --> Helper loaded: url_helper
INFO - 2016-11-10 22:33:44 --> Database Driver Class Initialized
INFO - 2016-11-10 22:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 22:33:44 --> Parser Class Initialized
INFO - 2016-11-10 22:33:44 --> Controller Class Initialized
DEBUG - 2016-11-10 22:33:44 --> Home MX_Controller Initialized
INFO - 2016-11-10 22:33:44 --> Model Class Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 22:33:44 --> Model Class Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 22:33:44 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 22:33:44 --> Model Class Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 22:33:44 --> Model Class Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 22:33:44 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 22:33:44 --> Model Class Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 22:33:44 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 22:33:44 --> Model Class Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 22:33:44 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 22:33:44 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 22:33:44 --> Final output sent to browser
DEBUG - 2016-11-10 22:33:44 --> Total execution time: 0.2086
INFO - 2016-11-10 22:35:08 --> Config Class Initialized
INFO - 2016-11-10 22:35:08 --> Hooks Class Initialized
DEBUG - 2016-11-10 22:35:08 --> UTF-8 Support Enabled
INFO - 2016-11-10 22:35:08 --> Utf8 Class Initialized
INFO - 2016-11-10 22:35:08 --> URI Class Initialized
DEBUG - 2016-11-10 22:35:08 --> No URI present. Default controller set.
INFO - 2016-11-10 22:35:08 --> Router Class Initialized
INFO - 2016-11-10 22:35:08 --> Output Class Initialized
INFO - 2016-11-10 22:35:08 --> Security Class Initialized
DEBUG - 2016-11-10 22:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 22:35:08 --> Input Class Initialized
INFO - 2016-11-10 22:35:08 --> Language Class Initialized
INFO - 2016-11-10 22:35:08 --> Language Class Initialized
INFO - 2016-11-10 22:35:08 --> Config Class Initialized
INFO - 2016-11-10 22:35:08 --> Loader Class Initialized
INFO - 2016-11-10 22:35:08 --> Helper loaded: common_helper
INFO - 2016-11-10 22:35:08 --> Helper loaded: url_helper
INFO - 2016-11-10 22:35:08 --> Database Driver Class Initialized
INFO - 2016-11-10 22:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 22:35:08 --> Parser Class Initialized
INFO - 2016-11-10 22:35:08 --> Controller Class Initialized
DEBUG - 2016-11-10 22:35:08 --> Home MX_Controller Initialized
INFO - 2016-11-10 22:35:08 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 22:35:08 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 22:35:08 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 22:35:08 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 22:35:08 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 22:35:08 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 22:35:08 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 22:35:08 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 22:35:08 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 22:35:08 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 22:35:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 22:35:08 --> Final output sent to browser
DEBUG - 2016-11-10 22:35:08 --> Total execution time: 0.1917
INFO - 2016-11-10 22:35:42 --> Config Class Initialized
INFO - 2016-11-10 22:35:42 --> Hooks Class Initialized
DEBUG - 2016-11-10 22:35:42 --> UTF-8 Support Enabled
INFO - 2016-11-10 22:35:42 --> Utf8 Class Initialized
INFO - 2016-11-10 22:35:42 --> URI Class Initialized
DEBUG - 2016-11-10 22:35:42 --> No URI present. Default controller set.
INFO - 2016-11-10 22:35:42 --> Router Class Initialized
INFO - 2016-11-10 22:35:42 --> Output Class Initialized
INFO - 2016-11-10 22:35:42 --> Security Class Initialized
DEBUG - 2016-11-10 22:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 22:35:42 --> Input Class Initialized
INFO - 2016-11-10 22:35:42 --> Language Class Initialized
INFO - 2016-11-10 22:35:42 --> Language Class Initialized
INFO - 2016-11-10 22:35:42 --> Config Class Initialized
INFO - 2016-11-10 22:35:42 --> Loader Class Initialized
INFO - 2016-11-10 22:35:42 --> Helper loaded: common_helper
INFO - 2016-11-10 22:35:42 --> Helper loaded: url_helper
INFO - 2016-11-10 22:35:42 --> Database Driver Class Initialized
INFO - 2016-11-10 22:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 22:35:42 --> Parser Class Initialized
INFO - 2016-11-10 22:35:42 --> Controller Class Initialized
DEBUG - 2016-11-10 22:35:42 --> Home MX_Controller Initialized
INFO - 2016-11-10 22:35:42 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 22:35:42 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 22:35:42 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 22:35:42 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 22:35:42 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 22:35:42 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 22:35:42 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 22:35:42 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 22:35:42 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 22:35:42 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 22:35:42 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 22:35:42 --> Final output sent to browser
DEBUG - 2016-11-10 22:35:42 --> Total execution time: 0.2040
INFO - 2016-11-10 22:35:46 --> Config Class Initialized
INFO - 2016-11-10 22:35:46 --> Hooks Class Initialized
DEBUG - 2016-11-10 22:35:46 --> UTF-8 Support Enabled
INFO - 2016-11-10 22:35:46 --> Utf8 Class Initialized
INFO - 2016-11-10 22:35:46 --> URI Class Initialized
DEBUG - 2016-11-10 22:35:46 --> No URI present. Default controller set.
INFO - 2016-11-10 22:35:46 --> Router Class Initialized
INFO - 2016-11-10 22:35:46 --> Output Class Initialized
INFO - 2016-11-10 22:35:46 --> Security Class Initialized
DEBUG - 2016-11-10 22:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 22:35:46 --> Input Class Initialized
INFO - 2016-11-10 22:35:46 --> Language Class Initialized
INFO - 2016-11-10 22:35:46 --> Language Class Initialized
INFO - 2016-11-10 22:35:46 --> Config Class Initialized
INFO - 2016-11-10 22:35:46 --> Loader Class Initialized
INFO - 2016-11-10 22:35:46 --> Helper loaded: common_helper
INFO - 2016-11-10 22:35:46 --> Helper loaded: url_helper
INFO - 2016-11-10 22:35:46 --> Database Driver Class Initialized
INFO - 2016-11-10 22:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 22:35:46 --> Parser Class Initialized
INFO - 2016-11-10 22:35:46 --> Controller Class Initialized
DEBUG - 2016-11-10 22:35:46 --> Home MX_Controller Initialized
INFO - 2016-11-10 22:35:46 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 22:35:46 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 22:35:46 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 22:35:46 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 22:35:46 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 22:35:46 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 22:35:46 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 22:35:46 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 22:35:46 --> Model Class Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 22:35:46 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 22:35:46 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 22:35:46 --> Final output sent to browser
DEBUG - 2016-11-10 22:35:46 --> Total execution time: 0.1741
INFO - 2016-11-10 22:36:10 --> Config Class Initialized
INFO - 2016-11-10 22:36:10 --> Hooks Class Initialized
DEBUG - 2016-11-10 22:36:10 --> UTF-8 Support Enabled
INFO - 2016-11-10 22:36:10 --> Utf8 Class Initialized
INFO - 2016-11-10 22:36:10 --> URI Class Initialized
DEBUG - 2016-11-10 22:36:10 --> No URI present. Default controller set.
INFO - 2016-11-10 22:36:10 --> Router Class Initialized
INFO - 2016-11-10 22:36:10 --> Output Class Initialized
INFO - 2016-11-10 22:36:10 --> Security Class Initialized
DEBUG - 2016-11-10 22:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 22:36:10 --> Input Class Initialized
INFO - 2016-11-10 22:36:10 --> Language Class Initialized
INFO - 2016-11-10 22:36:10 --> Language Class Initialized
INFO - 2016-11-10 22:36:10 --> Config Class Initialized
INFO - 2016-11-10 22:36:10 --> Loader Class Initialized
INFO - 2016-11-10 22:36:10 --> Helper loaded: common_helper
INFO - 2016-11-10 22:36:10 --> Helper loaded: url_helper
INFO - 2016-11-10 22:36:10 --> Database Driver Class Initialized
INFO - 2016-11-10 22:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 22:36:10 --> Parser Class Initialized
INFO - 2016-11-10 22:36:10 --> Controller Class Initialized
DEBUG - 2016-11-10 22:36:10 --> Home MX_Controller Initialized
INFO - 2016-11-10 22:36:10 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 22:36:10 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 22:36:10 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 22:36:10 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 22:36:10 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 22:36:10 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 22:36:10 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 22:36:10 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 22:36:10 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 22:36:10 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 22:36:10 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 22:36:10 --> Final output sent to browser
DEBUG - 2016-11-10 22:36:10 --> Total execution time: 0.2859
INFO - 2016-11-10 22:36:14 --> Config Class Initialized
INFO - 2016-11-10 22:36:14 --> Hooks Class Initialized
DEBUG - 2016-11-10 22:36:14 --> UTF-8 Support Enabled
INFO - 2016-11-10 22:36:14 --> Utf8 Class Initialized
INFO - 2016-11-10 22:36:14 --> URI Class Initialized
DEBUG - 2016-11-10 22:36:14 --> No URI present. Default controller set.
INFO - 2016-11-10 22:36:14 --> Router Class Initialized
INFO - 2016-11-10 22:36:14 --> Output Class Initialized
INFO - 2016-11-10 22:36:14 --> Security Class Initialized
DEBUG - 2016-11-10 22:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 22:36:14 --> Input Class Initialized
INFO - 2016-11-10 22:36:14 --> Language Class Initialized
INFO - 2016-11-10 22:36:14 --> Language Class Initialized
INFO - 2016-11-10 22:36:14 --> Config Class Initialized
INFO - 2016-11-10 22:36:14 --> Loader Class Initialized
INFO - 2016-11-10 22:36:14 --> Helper loaded: common_helper
INFO - 2016-11-10 22:36:14 --> Helper loaded: url_helper
INFO - 2016-11-10 22:36:14 --> Database Driver Class Initialized
INFO - 2016-11-10 22:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 22:36:14 --> Parser Class Initialized
INFO - 2016-11-10 22:36:14 --> Controller Class Initialized
DEBUG - 2016-11-10 22:36:14 --> Home MX_Controller Initialized
INFO - 2016-11-10 22:36:14 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 22:36:14 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 22:36:14 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 22:36:14 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 22:36:14 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 22:36:14 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 22:36:14 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 22:36:14 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 22:36:14 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 22:36:14 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 22:36:14 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 22:36:14 --> Final output sent to browser
DEBUG - 2016-11-10 22:36:14 --> Total execution time: 0.1948
INFO - 2016-11-10 22:36:26 --> Config Class Initialized
INFO - 2016-11-10 22:36:26 --> Hooks Class Initialized
DEBUG - 2016-11-10 22:36:26 --> UTF-8 Support Enabled
INFO - 2016-11-10 22:36:26 --> Utf8 Class Initialized
INFO - 2016-11-10 22:36:26 --> URI Class Initialized
DEBUG - 2016-11-10 22:36:26 --> No URI present. Default controller set.
INFO - 2016-11-10 22:36:26 --> Router Class Initialized
INFO - 2016-11-10 22:36:26 --> Output Class Initialized
INFO - 2016-11-10 22:36:26 --> Security Class Initialized
DEBUG - 2016-11-10 22:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-10 22:36:26 --> Input Class Initialized
INFO - 2016-11-10 22:36:26 --> Language Class Initialized
INFO - 2016-11-10 22:36:26 --> Language Class Initialized
INFO - 2016-11-10 22:36:26 --> Config Class Initialized
INFO - 2016-11-10 22:36:26 --> Loader Class Initialized
INFO - 2016-11-10 22:36:26 --> Helper loaded: common_helper
INFO - 2016-11-10 22:36:26 --> Helper loaded: url_helper
INFO - 2016-11-10 22:36:26 --> Database Driver Class Initialized
INFO - 2016-11-10 22:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-10 22:36:26 --> Parser Class Initialized
INFO - 2016-11-10 22:36:26 --> Controller Class Initialized
DEBUG - 2016-11-10 22:36:26 --> Home MX_Controller Initialized
INFO - 2016-11-10 22:36:26 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-10 22:36:26 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-10 22:36:26 --> Content MX_Controller Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-10 22:36:26 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-10 22:36:26 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-10 22:36:26 --> Slider MX_Controller Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-10 22:36:26 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-10 22:36:26 --> Servers MX_Controller Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-10 22:36:26 --> Model Class Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-10 22:36:26 --> Banner MX_Controller Initialized
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-10 22:36:26 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-10 22:36:26 --> Final output sent to browser
DEBUG - 2016-11-10 22:36:26 --> Total execution time: 0.2224
