<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-06 05:55:01 --> Config Class Initialized
INFO - 2017-04-06 05:55:01 --> Hooks Class Initialized
DEBUG - 2017-04-06 05:55:01 --> UTF-8 Support Enabled
INFO - 2017-04-06 05:55:01 --> Utf8 Class Initialized
INFO - 2017-04-06 05:55:01 --> URI Class Initialized
DEBUG - 2017-04-06 05:55:01 --> No URI present. Default controller set.
INFO - 2017-04-06 05:55:01 --> Router Class Initialized
INFO - 2017-04-06 05:55:02 --> Output Class Initialized
INFO - 2017-04-06 05:55:02 --> Security Class Initialized
DEBUG - 2017-04-06 05:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-06 05:55:02 --> Input Class Initialized
INFO - 2017-04-06 05:55:02 --> Language Class Initialized
INFO - 2017-04-06 05:55:02 --> Language Class Initialized
INFO - 2017-04-06 05:55:02 --> Config Class Initialized
INFO - 2017-04-06 05:55:02 --> Loader Class Initialized
INFO - 2017-04-06 05:55:02 --> Helper loaded: common_helper
INFO - 2017-04-06 05:55:02 --> Helper loaded: url_helper
INFO - 2017-04-06 05:55:03 --> Database Driver Class Initialized
INFO - 2017-04-06 05:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-06 05:55:03 --> Parser Class Initialized
INFO - 2017-04-06 05:55:03 --> Controller Class Initialized
DEBUG - 2017-04-06 05:55:03 --> Home MX_Controller Initialized
INFO - 2017-04-06 05:55:03 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:03 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/home/models/Home_model.php
INFO - 2017-04-06 05:55:03 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:03 --> File loaded: C:\xampp\htdocs\game1\game\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2017-04-06 05:55:03 --> Content MX_Controller Initialized
DEBUG - 2017-04-06 05:55:03 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2017-04-06 05:55:03 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:03 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/content/views/FRONTEND/index.php
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/home/views/FRONTEND/index.php
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/date_server/models/Date_server_model.php
INFO - 2017-04-06 05:55:04 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2017-04-06 05:55:04 --> Slider MX_Controller Initialized
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/slider/models/Slider_model.php
INFO - 2017-04-06 05:55:04 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2017-04-06 05:55:04 --> Servers MX_Controller Initialized
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/servers/models/Servers_model.php
INFO - 2017-04-06 05:55:04 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2017-04-06 05:55:04 --> Banner MX_Controller Initialized
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\views\FRONTEND/popup/account.php
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\views\FRONTEND/modules/tracking.php
DEBUG - 2017-04-06 05:55:04 --> File loaded: C:\xampp\htdocs\game1\game\application\views\FRONTEND/template.php
INFO - 2017-04-06 05:55:04 --> Final output sent to browser
DEBUG - 2017-04-06 05:55:04 --> Total execution time: 3.4716
INFO - 2017-04-06 05:55:34 --> Config Class Initialized
INFO - 2017-04-06 05:55:34 --> Hooks Class Initialized
DEBUG - 2017-04-06 05:55:34 --> UTF-8 Support Enabled
INFO - 2017-04-06 05:55:34 --> Utf8 Class Initialized
INFO - 2017-04-06 05:55:34 --> URI Class Initialized
DEBUG - 2017-04-06 05:55:34 --> No URI present. Default controller set.
INFO - 2017-04-06 05:55:34 --> Router Class Initialized
INFO - 2017-04-06 05:55:34 --> Output Class Initialized
INFO - 2017-04-06 05:55:34 --> Security Class Initialized
DEBUG - 2017-04-06 05:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-06 05:55:34 --> Input Class Initialized
INFO - 2017-04-06 05:55:34 --> Language Class Initialized
INFO - 2017-04-06 05:55:34 --> Language Class Initialized
INFO - 2017-04-06 05:55:34 --> Config Class Initialized
INFO - 2017-04-06 05:55:34 --> Loader Class Initialized
INFO - 2017-04-06 05:55:34 --> Helper loaded: common_helper
INFO - 2017-04-06 05:55:34 --> Helper loaded: url_helper
INFO - 2017-04-06 05:55:34 --> Database Driver Class Initialized
INFO - 2017-04-06 05:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-06 05:55:34 --> Parser Class Initialized
INFO - 2017-04-06 05:55:34 --> Controller Class Initialized
DEBUG - 2017-04-06 05:55:34 --> Home MX_Controller Initialized
INFO - 2017-04-06 05:55:34 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:34 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/home/models/Home_model.php
INFO - 2017-04-06 05:55:34 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:34 --> File loaded: C:\xampp\htdocs\game1\game\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2017-04-06 05:55:34 --> Content MX_Controller Initialized
DEBUG - 2017-04-06 05:55:34 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2017-04-06 05:55:34 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:34 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/content/views/FRONTEND/index.php
DEBUG - 2017-04-06 05:55:34 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/home/views/FRONTEND/index.php
DEBUG - 2017-04-06 05:55:34 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/date_server/models/Date_server_model.php
INFO - 2017-04-06 05:55:34 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:34 --> File loaded: C:\xampp\htdocs\game1\game\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2017-04-06 05:55:34 --> Slider MX_Controller Initialized
DEBUG - 2017-04-06 05:55:34 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/slider/models/Slider_model.php
INFO - 2017-04-06 05:55:35 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:35 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2017-04-06 05:55:35 --> File loaded: C:\xampp\htdocs\game1\game\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2017-04-06 05:55:35 --> Servers MX_Controller Initialized
DEBUG - 2017-04-06 05:55:35 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/servers/models/Servers_model.php
INFO - 2017-04-06 05:55:35 --> Model Class Initialized
DEBUG - 2017-04-06 05:55:35 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2017-04-06 05:55:35 --> File loaded: C:\xampp\htdocs\game1\game\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2017-04-06 05:55:35 --> Banner MX_Controller Initialized
DEBUG - 2017-04-06 05:55:35 --> File loaded: C:\xampp\htdocs\game1\game\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2017-04-06 05:55:35 --> File loaded: C:\xampp\htdocs\game1\game\application\views\FRONTEND/popup/account.php
DEBUG - 2017-04-06 05:55:35 --> File loaded: C:\xampp\htdocs\game1\game\application\views\FRONTEND/modules/tracking.php
DEBUG - 2017-04-06 05:55:35 --> File loaded: C:\xampp\htdocs\game1\game\application\views\FRONTEND/template.php
INFO - 2017-04-06 05:55:35 --> Final output sent to browser
DEBUG - 2017-04-06 05:55:35 --> Total execution time: 0.6093
