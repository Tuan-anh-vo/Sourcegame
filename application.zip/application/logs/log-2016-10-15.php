<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-15 00:20:07 --> Config Class Initialized
INFO - 2016-10-15 00:20:07 --> Hooks Class Initialized
DEBUG - 2016-10-15 00:20:08 --> UTF-8 Support Enabled
INFO - 2016-10-15 00:20:08 --> Utf8 Class Initialized
INFO - 2016-10-15 00:20:08 --> URI Class Initialized
INFO - 2016-10-15 00:20:08 --> Router Class Initialized
INFO - 2016-10-15 00:20:08 --> Output Class Initialized
INFO - 2016-10-15 00:20:08 --> Security Class Initialized
DEBUG - 2016-10-15 00:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 00:20:08 --> Input Class Initialized
INFO - 2016-10-15 00:20:08 --> Language Class Initialized
INFO - 2016-10-15 00:20:08 --> Language Class Initialized
INFO - 2016-10-15 00:20:08 --> Config Class Initialized
INFO - 2016-10-15 00:20:08 --> Loader Class Initialized
INFO - 2016-10-15 00:20:08 --> Helper loaded: common_helper
INFO - 2016-10-15 00:20:08 --> Helper loaded: url_helper
INFO - 2016-10-15 00:20:08 --> Database Driver Class Initialized
INFO - 2016-10-15 00:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 00:20:08 --> Parser Class Initialized
INFO - 2016-10-15 00:20:08 --> Controller Class Initialized
DEBUG - 2016-10-15 00:20:08 --> Admincp MX_Controller Initialized
INFO - 2016-10-15 00:20:08 --> Config Class Initialized
INFO - 2016-10-15 00:20:08 --> Hooks Class Initialized
DEBUG - 2016-10-15 00:20:08 --> UTF-8 Support Enabled
INFO - 2016-10-15 00:20:08 --> Utf8 Class Initialized
INFO - 2016-10-15 00:20:08 --> URI Class Initialized
INFO - 2016-10-15 00:20:08 --> Router Class Initialized
INFO - 2016-10-15 00:20:08 --> Output Class Initialized
INFO - 2016-10-15 00:20:08 --> Security Class Initialized
DEBUG - 2016-10-15 00:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 00:20:08 --> Input Class Initialized
INFO - 2016-10-15 00:20:08 --> Language Class Initialized
INFO - 2016-10-15 00:20:08 --> Language Class Initialized
INFO - 2016-10-15 00:20:08 --> Config Class Initialized
INFO - 2016-10-15 00:20:08 --> Loader Class Initialized
INFO - 2016-10-15 00:20:08 --> Helper loaded: common_helper
INFO - 2016-10-15 00:20:08 --> Helper loaded: url_helper
INFO - 2016-10-15 00:20:08 --> Database Driver Class Initialized
INFO - 2016-10-15 00:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 00:20:08 --> Parser Class Initialized
INFO - 2016-10-15 00:20:08 --> Controller Class Initialized
DEBUG - 2016-10-15 00:20:08 --> Admincp MX_Controller Initialized
INFO - 2016-10-15 00:20:08 --> Model Class Initialized
DEBUG - 2016-10-15 00:20:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-15 00:20:08 --> Model Class Initialized
DEBUG - 2016-10-15 00:20:08 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-15 00:20:08 --> Final output sent to browser
DEBUG - 2016-10-15 00:20:08 --> Total execution time: 0.0325
INFO - 2016-10-15 01:55:05 --> Config Class Initialized
INFO - 2016-10-15 01:55:05 --> Hooks Class Initialized
DEBUG - 2016-10-15 01:55:05 --> UTF-8 Support Enabled
INFO - 2016-10-15 01:55:05 --> Utf8 Class Initialized
INFO - 2016-10-15 01:55:05 --> URI Class Initialized
INFO - 2016-10-15 01:55:05 --> Router Class Initialized
INFO - 2016-10-15 01:55:05 --> Output Class Initialized
INFO - 2016-10-15 01:55:05 --> Security Class Initialized
DEBUG - 2016-10-15 01:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 01:55:05 --> Input Class Initialized
INFO - 2016-10-15 01:55:05 --> Language Class Initialized
ERROR - 2016-10-15 01:55:05 --> 404 Page Not Found: /index
INFO - 2016-10-15 01:55:06 --> Config Class Initialized
INFO - 2016-10-15 01:55:06 --> Hooks Class Initialized
DEBUG - 2016-10-15 01:55:06 --> UTF-8 Support Enabled
INFO - 2016-10-15 01:55:06 --> Utf8 Class Initialized
INFO - 2016-10-15 01:55:06 --> URI Class Initialized
INFO - 2016-10-15 01:55:06 --> Router Class Initialized
INFO - 2016-10-15 01:55:06 --> Output Class Initialized
INFO - 2016-10-15 01:55:06 --> Security Class Initialized
DEBUG - 2016-10-15 01:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 01:55:06 --> Input Class Initialized
INFO - 2016-10-15 01:55:06 --> Language Class Initialized
ERROR - 2016-10-15 01:55:06 --> 404 Page Not Found: /index
INFO - 2016-10-15 04:28:09 --> Config Class Initialized
INFO - 2016-10-15 04:28:09 --> Hooks Class Initialized
DEBUG - 2016-10-15 04:28:09 --> UTF-8 Support Enabled
INFO - 2016-10-15 04:28:09 --> Utf8 Class Initialized
INFO - 2016-10-15 04:28:09 --> URI Class Initialized
DEBUG - 2016-10-15 04:28:09 --> No URI present. Default controller set.
INFO - 2016-10-15 04:28:09 --> Router Class Initialized
INFO - 2016-10-15 04:28:09 --> Output Class Initialized
INFO - 2016-10-15 04:28:09 --> Security Class Initialized
DEBUG - 2016-10-15 04:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 04:28:09 --> Input Class Initialized
INFO - 2016-10-15 04:28:09 --> Language Class Initialized
INFO - 2016-10-15 04:28:09 --> Language Class Initialized
INFO - 2016-10-15 04:28:09 --> Config Class Initialized
INFO - 2016-10-15 04:28:09 --> Loader Class Initialized
INFO - 2016-10-15 04:28:09 --> Helper loaded: common_helper
INFO - 2016-10-15 04:28:09 --> Helper loaded: url_helper
INFO - 2016-10-15 04:28:09 --> Database Driver Class Initialized
INFO - 2016-10-15 04:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 04:28:09 --> Parser Class Initialized
INFO - 2016-10-15 04:28:09 --> Controller Class Initialized
DEBUG - 2016-10-15 04:28:09 --> Home MX_Controller Initialized
INFO - 2016-10-15 04:28:09 --> Model Class Initialized
DEBUG - 2016-10-15 04:28:10 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 04:28:10 --> Model Class Initialized
ERROR - 2016-10-15 04:28:10 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 04:28:10 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 04:28:10 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 04:28:10 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-15 04:28:10 --> Final output sent to browser
DEBUG - 2016-10-15 04:28:10 --> Total execution time: 0.9117
INFO - 2016-10-15 05:22:42 --> Config Class Initialized
INFO - 2016-10-15 05:22:42 --> Hooks Class Initialized
DEBUG - 2016-10-15 05:22:42 --> UTF-8 Support Enabled
INFO - 2016-10-15 05:22:42 --> Utf8 Class Initialized
INFO - 2016-10-15 05:22:42 --> URI Class Initialized
DEBUG - 2016-10-15 05:22:42 --> No URI present. Default controller set.
INFO - 2016-10-15 05:22:42 --> Router Class Initialized
INFO - 2016-10-15 05:22:42 --> Output Class Initialized
INFO - 2016-10-15 05:22:42 --> Security Class Initialized
DEBUG - 2016-10-15 05:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 05:22:42 --> Input Class Initialized
INFO - 2016-10-15 05:22:42 --> Language Class Initialized
INFO - 2016-10-15 05:22:42 --> Language Class Initialized
INFO - 2016-10-15 05:22:42 --> Config Class Initialized
INFO - 2016-10-15 05:22:42 --> Loader Class Initialized
INFO - 2016-10-15 05:22:42 --> Helper loaded: common_helper
INFO - 2016-10-15 05:22:42 --> Helper loaded: url_helper
INFO - 2016-10-15 05:22:42 --> Database Driver Class Initialized
INFO - 2016-10-15 05:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 05:22:42 --> Parser Class Initialized
INFO - 2016-10-15 05:22:42 --> Controller Class Initialized
DEBUG - 2016-10-15 05:22:42 --> Home MX_Controller Initialized
INFO - 2016-10-15 05:22:42 --> Model Class Initialized
DEBUG - 2016-10-15 05:22:42 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 05:22:42 --> Model Class Initialized
ERROR - 2016-10-15 05:22:42 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 05:22:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 05:22:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 05:22:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-15 05:22:42 --> Final output sent to browser
DEBUG - 2016-10-15 05:22:42 --> Total execution time: 0.0470
INFO - 2016-10-15 07:18:13 --> Config Class Initialized
INFO - 2016-10-15 07:18:13 --> Hooks Class Initialized
DEBUG - 2016-10-15 07:18:13 --> UTF-8 Support Enabled
INFO - 2016-10-15 07:18:13 --> Utf8 Class Initialized
INFO - 2016-10-15 07:18:13 --> URI Class Initialized
DEBUG - 2016-10-15 07:18:13 --> No URI present. Default controller set.
INFO - 2016-10-15 07:18:13 --> Router Class Initialized
INFO - 2016-10-15 07:18:13 --> Output Class Initialized
INFO - 2016-10-15 07:18:13 --> Security Class Initialized
DEBUG - 2016-10-15 07:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 07:18:13 --> Input Class Initialized
INFO - 2016-10-15 07:18:13 --> Language Class Initialized
INFO - 2016-10-15 07:18:13 --> Language Class Initialized
INFO - 2016-10-15 07:18:13 --> Config Class Initialized
INFO - 2016-10-15 07:18:13 --> Loader Class Initialized
INFO - 2016-10-15 07:18:13 --> Helper loaded: common_helper
INFO - 2016-10-15 07:18:13 --> Helper loaded: url_helper
INFO - 2016-10-15 07:18:13 --> Database Driver Class Initialized
INFO - 2016-10-15 07:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 07:18:13 --> Parser Class Initialized
INFO - 2016-10-15 07:18:13 --> Controller Class Initialized
DEBUG - 2016-10-15 07:18:13 --> Home MX_Controller Initialized
INFO - 2016-10-15 07:18:13 --> Model Class Initialized
DEBUG - 2016-10-15 07:18:13 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 07:18:13 --> Model Class Initialized
ERROR - 2016-10-15 07:18:13 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 07:18:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 07:18:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 07:18:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-15 07:18:13 --> Final output sent to browser
DEBUG - 2016-10-15 07:18:13 --> Total execution time: 0.0580
INFO - 2016-10-15 07:27:25 --> Config Class Initialized
INFO - 2016-10-15 07:27:25 --> Hooks Class Initialized
DEBUG - 2016-10-15 07:27:25 --> UTF-8 Support Enabled
INFO - 2016-10-15 07:27:25 --> Utf8 Class Initialized
INFO - 2016-10-15 07:27:25 --> URI Class Initialized
DEBUG - 2016-10-15 07:27:25 --> No URI present. Default controller set.
INFO - 2016-10-15 07:27:25 --> Router Class Initialized
INFO - 2016-10-15 07:27:25 --> Output Class Initialized
INFO - 2016-10-15 07:27:25 --> Security Class Initialized
DEBUG - 2016-10-15 07:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 07:27:25 --> Input Class Initialized
INFO - 2016-10-15 07:27:25 --> Language Class Initialized
INFO - 2016-10-15 07:27:25 --> Language Class Initialized
INFO - 2016-10-15 07:27:25 --> Config Class Initialized
INFO - 2016-10-15 07:27:25 --> Loader Class Initialized
INFO - 2016-10-15 07:27:25 --> Helper loaded: common_helper
INFO - 2016-10-15 07:27:25 --> Helper loaded: url_helper
INFO - 2016-10-15 07:27:25 --> Database Driver Class Initialized
INFO - 2016-10-15 07:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 07:27:25 --> Parser Class Initialized
INFO - 2016-10-15 07:27:25 --> Controller Class Initialized
DEBUG - 2016-10-15 07:27:25 --> Home MX_Controller Initialized
INFO - 2016-10-15 07:27:25 --> Model Class Initialized
DEBUG - 2016-10-15 07:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 07:27:25 --> Model Class Initialized
ERROR - 2016-10-15 07:27:25 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 07:27:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 07:27:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 07:27:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-15 07:27:25 --> Final output sent to browser
DEBUG - 2016-10-15 07:27:25 --> Total execution time: 0.0452
INFO - 2016-10-15 07:27:30 --> Config Class Initialized
INFO - 2016-10-15 07:27:30 --> Hooks Class Initialized
DEBUG - 2016-10-15 07:27:30 --> UTF-8 Support Enabled
INFO - 2016-10-15 07:27:30 --> Utf8 Class Initialized
INFO - 2016-10-15 07:27:30 --> URI Class Initialized
INFO - 2016-10-15 07:27:30 --> Router Class Initialized
INFO - 2016-10-15 07:27:30 --> Output Class Initialized
INFO - 2016-10-15 07:27:30 --> Security Class Initialized
DEBUG - 2016-10-15 07:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 07:27:30 --> Input Class Initialized
INFO - 2016-10-15 07:27:30 --> Language Class Initialized
INFO - 2016-10-15 07:27:30 --> Language Class Initialized
INFO - 2016-10-15 07:27:30 --> Config Class Initialized
INFO - 2016-10-15 07:27:30 --> Loader Class Initialized
INFO - 2016-10-15 07:27:30 --> Helper loaded: common_helper
INFO - 2016-10-15 07:27:30 --> Helper loaded: url_helper
INFO - 2016-10-15 07:27:30 --> Database Driver Class Initialized
INFO - 2016-10-15 07:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 07:27:30 --> Parser Class Initialized
INFO - 2016-10-15 07:27:30 --> Controller Class Initialized
DEBUG - 2016-10-15 07:27:30 --> Home MX_Controller Initialized
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-15 07:27:30 --> Content MX_Controller Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-15 07:27:30 --> Slider MX_Controller Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
INFO - 2016-10-15 07:27:30 --> Config Class Initialized
INFO - 2016-10-15 07:27:30 --> Hooks Class Initialized
DEBUG - 2016-10-15 07:27:30 --> UTF-8 Support Enabled
INFO - 2016-10-15 07:27:30 --> Utf8 Class Initialized
INFO - 2016-10-15 07:27:30 --> URI Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
INFO - 2016-10-15 07:27:30 --> Router Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-15 07:27:30 --> Servers MX_Controller Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
INFO - 2016-10-15 07:27:30 --> Output Class Initialized
INFO - 2016-10-15 07:27:30 --> Security Class Initialized
DEBUG - 2016-10-15 07:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 07:27:30 --> Input Class Initialized
INFO - 2016-10-15 07:27:30 --> Language Class Initialized
INFO - 2016-10-15 07:27:30 --> Language Class Initialized
INFO - 2016-10-15 07:27:30 --> Config Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-15 07:27:30 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-15 07:27:30 --> Final output sent to browser
DEBUG - 2016-10-15 07:27:30 --> Total execution time: 0.1419
INFO - 2016-10-15 07:27:30 --> Loader Class Initialized
INFO - 2016-10-15 07:27:30 --> Helper loaded: common_helper
INFO - 2016-10-15 07:27:30 --> Helper loaded: url_helper
INFO - 2016-10-15 07:27:30 --> Database Driver Class Initialized
INFO - 2016-10-15 07:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 07:27:30 --> Parser Class Initialized
INFO - 2016-10-15 07:27:30 --> Controller Class Initialized
DEBUG - 2016-10-15 07:27:30 --> Home MX_Controller Initialized
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-15 07:27:30 --> Content MX_Controller Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-15 07:27:30 --> Slider MX_Controller Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-15 07:27:30 --> Servers MX_Controller Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-15 07:27:30 --> Model Class Initialized
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-15 07:27:30 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 07:27:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-15 07:27:30 --> Final output sent to browser
DEBUG - 2016-10-15 07:27:30 --> Total execution time: 0.1004
INFO - 2016-10-15 07:27:30 --> Config Class Initialized
INFO - 2016-10-15 07:27:30 --> Hooks Class Initialized
DEBUG - 2016-10-15 07:27:30 --> UTF-8 Support Enabled
INFO - 2016-10-15 07:27:30 --> Utf8 Class Initialized
INFO - 2016-10-15 07:27:30 --> URI Class Initialized
INFO - 2016-10-15 07:27:30 --> Router Class Initialized
INFO - 2016-10-15 07:27:30 --> Output Class Initialized
INFO - 2016-10-15 07:27:30 --> Security Class Initialized
DEBUG - 2016-10-15 07:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 07:27:30 --> Input Class Initialized
INFO - 2016-10-15 07:27:30 --> Language Class Initialized
ERROR - 2016-10-15 07:27:30 --> 404 Page Not Found: /index
INFO - 2016-10-15 07:48:56 --> Config Class Initialized
INFO - 2016-10-15 07:48:56 --> Hooks Class Initialized
DEBUG - 2016-10-15 07:48:56 --> UTF-8 Support Enabled
INFO - 2016-10-15 07:48:56 --> Utf8 Class Initialized
INFO - 2016-10-15 07:48:56 --> URI Class Initialized
INFO - 2016-10-15 07:48:56 --> Router Class Initialized
INFO - 2016-10-15 07:48:56 --> Output Class Initialized
INFO - 2016-10-15 07:48:56 --> Security Class Initialized
DEBUG - 2016-10-15 07:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 07:48:56 --> Input Class Initialized
INFO - 2016-10-15 07:48:56 --> Language Class Initialized
ERROR - 2016-10-15 07:48:56 --> 404 Page Not Found: /index
INFO - 2016-10-15 07:48:57 --> Config Class Initialized
INFO - 2016-10-15 07:48:57 --> Hooks Class Initialized
DEBUG - 2016-10-15 07:48:57 --> UTF-8 Support Enabled
INFO - 2016-10-15 07:48:57 --> Utf8 Class Initialized
INFO - 2016-10-15 07:48:57 --> URI Class Initialized
DEBUG - 2016-10-15 07:48:57 --> No URI present. Default controller set.
INFO - 2016-10-15 07:48:57 --> Router Class Initialized
INFO - 2016-10-15 07:48:57 --> Output Class Initialized
INFO - 2016-10-15 07:48:57 --> Security Class Initialized
DEBUG - 2016-10-15 07:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 07:48:57 --> Input Class Initialized
INFO - 2016-10-15 07:48:57 --> Language Class Initialized
INFO - 2016-10-15 07:48:57 --> Language Class Initialized
INFO - 2016-10-15 07:48:57 --> Config Class Initialized
INFO - 2016-10-15 07:48:57 --> Loader Class Initialized
INFO - 2016-10-15 07:48:57 --> Helper loaded: common_helper
INFO - 2016-10-15 07:48:57 --> Helper loaded: url_helper
INFO - 2016-10-15 07:48:57 --> Database Driver Class Initialized
INFO - 2016-10-15 07:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 07:48:57 --> Parser Class Initialized
INFO - 2016-10-15 07:48:57 --> Controller Class Initialized
DEBUG - 2016-10-15 07:48:57 --> Home MX_Controller Initialized
INFO - 2016-10-15 07:48:57 --> Model Class Initialized
DEBUG - 2016-10-15 07:48:57 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 07:48:57 --> Model Class Initialized
ERROR - 2016-10-15 07:48:57 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 07:48:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 07:48:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 07:48:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-15 07:48:57 --> Final output sent to browser
DEBUG - 2016-10-15 07:48:57 --> Total execution time: 0.0414
INFO - 2016-10-15 07:59:11 --> Config Class Initialized
INFO - 2016-10-15 07:59:11 --> Hooks Class Initialized
DEBUG - 2016-10-15 07:59:11 --> UTF-8 Support Enabled
INFO - 2016-10-15 07:59:11 --> Utf8 Class Initialized
INFO - 2016-10-15 07:59:11 --> URI Class Initialized
INFO - 2016-10-15 07:59:11 --> Router Class Initialized
INFO - 2016-10-15 07:59:11 --> Output Class Initialized
INFO - 2016-10-15 07:59:11 --> Security Class Initialized
DEBUG - 2016-10-15 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 07:59:11 --> Input Class Initialized
INFO - 2016-10-15 07:59:11 --> Language Class Initialized
ERROR - 2016-10-15 07:59:11 --> 404 Page Not Found: /index
INFO - 2016-10-15 07:59:12 --> Config Class Initialized
INFO - 2016-10-15 07:59:12 --> Hooks Class Initialized
DEBUG - 2016-10-15 07:59:12 --> UTF-8 Support Enabled
INFO - 2016-10-15 07:59:12 --> Utf8 Class Initialized
INFO - 2016-10-15 07:59:12 --> URI Class Initialized
DEBUG - 2016-10-15 07:59:12 --> No URI present. Default controller set.
INFO - 2016-10-15 07:59:12 --> Router Class Initialized
INFO - 2016-10-15 07:59:12 --> Output Class Initialized
INFO - 2016-10-15 07:59:12 --> Security Class Initialized
DEBUG - 2016-10-15 07:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 07:59:12 --> Input Class Initialized
INFO - 2016-10-15 07:59:12 --> Language Class Initialized
INFO - 2016-10-15 07:59:12 --> Language Class Initialized
INFO - 2016-10-15 07:59:12 --> Config Class Initialized
INFO - 2016-10-15 07:59:12 --> Loader Class Initialized
INFO - 2016-10-15 07:59:12 --> Helper loaded: common_helper
INFO - 2016-10-15 07:59:12 --> Helper loaded: url_helper
INFO - 2016-10-15 07:59:12 --> Database Driver Class Initialized
INFO - 2016-10-15 07:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 07:59:12 --> Parser Class Initialized
INFO - 2016-10-15 07:59:12 --> Controller Class Initialized
DEBUG - 2016-10-15 07:59:12 --> Home MX_Controller Initialized
INFO - 2016-10-15 07:59:12 --> Model Class Initialized
DEBUG - 2016-10-15 07:59:12 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 07:59:12 --> Model Class Initialized
ERROR - 2016-10-15 07:59:12 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 07:59:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 07:59:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 07:59:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-15 07:59:12 --> Final output sent to browser
DEBUG - 2016-10-15 07:59:12 --> Total execution time: 0.0664
INFO - 2016-10-15 09:04:57 --> Config Class Initialized
INFO - 2016-10-15 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-15 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-15 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-15 09:04:57 --> URI Class Initialized
DEBUG - 2016-10-15 09:04:57 --> No URI present. Default controller set.
INFO - 2016-10-15 09:04:57 --> Router Class Initialized
INFO - 2016-10-15 09:04:57 --> Output Class Initialized
INFO - 2016-10-15 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-15 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 09:04:57 --> Input Class Initialized
INFO - 2016-10-15 09:04:57 --> Language Class Initialized
INFO - 2016-10-15 09:04:57 --> Language Class Initialized
INFO - 2016-10-15 09:04:57 --> Config Class Initialized
INFO - 2016-10-15 09:04:57 --> Loader Class Initialized
INFO - 2016-10-15 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-15 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-15 09:04:57 --> Database Driver Class Initialized
INFO - 2016-10-15 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 09:04:57 --> Parser Class Initialized
INFO - 2016-10-15 09:04:57 --> Controller Class Initialized
DEBUG - 2016-10-15 09:04:57 --> Home MX_Controller Initialized
INFO - 2016-10-15 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-15 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 09:04:57 --> Model Class Initialized
ERROR - 2016-10-15 09:04:57 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 09:04:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 09:04:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 09:04:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-15 09:04:57 --> Final output sent to browser
DEBUG - 2016-10-15 09:04:57 --> Total execution time: 0.0450
INFO - 2016-10-15 20:18:47 --> Config Class Initialized
INFO - 2016-10-15 20:18:47 --> Hooks Class Initialized
DEBUG - 2016-10-15 20:18:47 --> UTF-8 Support Enabled
INFO - 2016-10-15 20:18:47 --> Utf8 Class Initialized
INFO - 2016-10-15 20:18:47 --> URI Class Initialized
DEBUG - 2016-10-15 20:18:47 --> No URI present. Default controller set.
INFO - 2016-10-15 20:18:47 --> Router Class Initialized
INFO - 2016-10-15 20:18:47 --> Output Class Initialized
INFO - 2016-10-15 20:18:47 --> Security Class Initialized
DEBUG - 2016-10-15 20:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 20:18:47 --> Input Class Initialized
INFO - 2016-10-15 20:18:47 --> Language Class Initialized
INFO - 2016-10-15 20:18:47 --> Language Class Initialized
INFO - 2016-10-15 20:18:47 --> Config Class Initialized
INFO - 2016-10-15 20:18:47 --> Loader Class Initialized
INFO - 2016-10-15 20:18:47 --> Helper loaded: common_helper
INFO - 2016-10-15 20:18:47 --> Helper loaded: url_helper
INFO - 2016-10-15 20:18:47 --> Database Driver Class Initialized
INFO - 2016-10-15 20:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-15 20:18:47 --> Parser Class Initialized
INFO - 2016-10-15 20:18:47 --> Controller Class Initialized
DEBUG - 2016-10-15 20:18:47 --> Home MX_Controller Initialized
INFO - 2016-10-15 20:18:47 --> Model Class Initialized
DEBUG - 2016-10-15 20:18:47 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-15 20:18:47 --> Model Class Initialized
ERROR - 2016-10-15 20:18:47 --> Module controller failed to run: banner/index
DEBUG - 2016-10-15 20:18:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-15 20:18:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-15 20:18:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-15 20:18:47 --> Final output sent to browser
DEBUG - 2016-10-15 20:18:47 --> Total execution time: 0.0616
INFO - 2016-10-15 20:18:56 --> Config Class Initialized
INFO - 2016-10-15 20:18:56 --> Hooks Class Initialized
DEBUG - 2016-10-15 20:18:56 --> UTF-8 Support Enabled
INFO - 2016-10-15 20:18:56 --> Utf8 Class Initialized
INFO - 2016-10-15 20:18:56 --> URI Class Initialized
INFO - 2016-10-15 20:18:56 --> Router Class Initialized
INFO - 2016-10-15 20:18:56 --> Output Class Initialized
INFO - 2016-10-15 20:18:56 --> Security Class Initialized
DEBUG - 2016-10-15 20:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-15 20:18:56 --> Input Class Initialized
INFO - 2016-10-15 20:18:56 --> Language Class Initialized
ERROR - 2016-10-15 20:18:56 --> 404 Page Not Found: /index
