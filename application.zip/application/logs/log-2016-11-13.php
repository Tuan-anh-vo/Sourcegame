<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-13 00:06:09 --> Config Class Initialized
INFO - 2016-11-13 00:06:09 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:06:09 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:06:09 --> Utf8 Class Initialized
INFO - 2016-11-13 00:06:09 --> URI Class Initialized
DEBUG - 2016-11-13 00:06:09 --> No URI present. Default controller set.
INFO - 2016-11-13 00:06:09 --> Router Class Initialized
INFO - 2016-11-13 00:06:09 --> Output Class Initialized
INFO - 2016-11-13 00:06:09 --> Security Class Initialized
DEBUG - 2016-11-13 00:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:06:09 --> Input Class Initialized
INFO - 2016-11-13 00:06:09 --> Language Class Initialized
INFO - 2016-11-13 00:06:09 --> Language Class Initialized
INFO - 2016-11-13 00:06:09 --> Config Class Initialized
INFO - 2016-11-13 00:06:09 --> Loader Class Initialized
INFO - 2016-11-13 00:06:09 --> Helper loaded: common_helper
INFO - 2016-11-13 00:06:09 --> Helper loaded: url_helper
INFO - 2016-11-13 00:06:09 --> Database Driver Class Initialized
INFO - 2016-11-13 00:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:06:09 --> Parser Class Initialized
INFO - 2016-11-13 00:06:09 --> Controller Class Initialized
DEBUG - 2016-11-13 00:06:09 --> Home MX_Controller Initialized
INFO - 2016-11-13 00:06:09 --> Model Class Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-13 00:06:09 --> Model Class Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-13 00:06:09 --> Content MX_Controller Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-13 00:06:09 --> Model Class Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-13 00:06:09 --> Model Class Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-13 00:06:09 --> Slider MX_Controller Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-13 00:06:09 --> Model Class Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-13 00:06:09 --> Servers MX_Controller Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-13 00:06:09 --> Model Class Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-13 00:06:09 --> Banner MX_Controller Initialized
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-13 00:06:09 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-13 00:06:09 --> Final output sent to browser
DEBUG - 2016-11-13 00:06:09 --> Total execution time: 0.1788
INFO - 2016-11-13 00:10:11 --> Config Class Initialized
INFO - 2016-11-13 00:10:11 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:10:11 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:10:11 --> Utf8 Class Initialized
INFO - 2016-11-13 00:10:11 --> URI Class Initialized
DEBUG - 2016-11-13 00:10:11 --> No URI present. Default controller set.
INFO - 2016-11-13 00:10:11 --> Router Class Initialized
INFO - 2016-11-13 00:10:11 --> Output Class Initialized
INFO - 2016-11-13 00:10:11 --> Security Class Initialized
DEBUG - 2016-11-13 00:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:10:11 --> Input Class Initialized
INFO - 2016-11-13 00:10:11 --> Language Class Initialized
INFO - 2016-11-13 00:10:11 --> Language Class Initialized
INFO - 2016-11-13 00:10:11 --> Config Class Initialized
INFO - 2016-11-13 00:10:11 --> Loader Class Initialized
INFO - 2016-11-13 00:10:11 --> Helper loaded: common_helper
INFO - 2016-11-13 00:10:11 --> Helper loaded: url_helper
INFO - 2016-11-13 00:10:11 --> Database Driver Class Initialized
INFO - 2016-11-13 00:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:10:11 --> Parser Class Initialized
INFO - 2016-11-13 00:10:11 --> Controller Class Initialized
DEBUG - 2016-11-13 00:10:11 --> Home MX_Controller Initialized
INFO - 2016-11-13 00:10:11 --> Model Class Initialized
DEBUG - 2016-11-13 00:10:11 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-13 00:10:11 --> Model Class Initialized
DEBUG - 2016-11-13 00:10:11 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-13 00:10:11 --> Content MX_Controller Initialized
DEBUG - 2016-11-13 00:10:11 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-13 00:10:11 --> Model Class Initialized
DEBUG - 2016-11-13 00:10:11 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:10:11 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:10:11 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-13 00:10:11 --> Model Class Initialized
DEBUG - 2016-11-13 00:10:11 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-13 00:10:11 --> Slider MX_Controller Initialized
DEBUG - 2016-11-13 00:10:11 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-13 00:10:11 --> Model Class Initialized
DEBUG - 2016-11-13 00:10:11 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:10:12 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-13 00:10:12 --> Servers MX_Controller Initialized
DEBUG - 2016-11-13 00:10:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-13 00:10:12 --> Model Class Initialized
DEBUG - 2016-11-13 00:10:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-13 00:10:12 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-13 00:10:12 --> Banner MX_Controller Initialized
DEBUG - 2016-11-13 00:10:12 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:10:12 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-13 00:10:12 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-13 00:10:12 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-13 00:10:12 --> Final output sent to browser
DEBUG - 2016-11-13 00:10:12 --> Total execution time: 0.7947
INFO - 2016-11-13 00:16:18 --> Config Class Initialized
INFO - 2016-11-13 00:16:18 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:16:18 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:16:18 --> Utf8 Class Initialized
INFO - 2016-11-13 00:16:19 --> URI Class Initialized
DEBUG - 2016-11-13 00:16:19 --> No URI present. Default controller set.
INFO - 2016-11-13 00:16:19 --> Router Class Initialized
INFO - 2016-11-13 00:16:19 --> Output Class Initialized
INFO - 2016-11-13 00:16:19 --> Security Class Initialized
DEBUG - 2016-11-13 00:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:16:19 --> Input Class Initialized
INFO - 2016-11-13 00:16:19 --> Language Class Initialized
INFO - 2016-11-13 00:16:19 --> Language Class Initialized
INFO - 2016-11-13 00:16:19 --> Config Class Initialized
INFO - 2016-11-13 00:16:19 --> Loader Class Initialized
INFO - 2016-11-13 00:16:19 --> Helper loaded: common_helper
INFO - 2016-11-13 00:16:19 --> Helper loaded: url_helper
INFO - 2016-11-13 00:16:19 --> Database Driver Class Initialized
INFO - 2016-11-13 00:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:16:19 --> Parser Class Initialized
INFO - 2016-11-13 00:16:19 --> Controller Class Initialized
DEBUG - 2016-11-13 00:16:19 --> Home MX_Controller Initialized
INFO - 2016-11-13 00:16:19 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-13 00:16:19 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-13 00:16:19 --> Content MX_Controller Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-13 00:16:19 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-13 00:16:19 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-13 00:16:19 --> Slider MX_Controller Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-13 00:16:19 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-13 00:16:19 --> Servers MX_Controller Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-13 00:16:19 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-13 00:16:19 --> Banner MX_Controller Initialized
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-13 00:16:19 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-13 00:16:19 --> Final output sent to browser
DEBUG - 2016-11-13 00:16:19 --> Total execution time: 0.7064
INFO - 2016-11-13 00:16:42 --> Config Class Initialized
INFO - 2016-11-13 00:16:42 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:16:42 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:16:42 --> Utf8 Class Initialized
INFO - 2016-11-13 00:16:42 --> URI Class Initialized
DEBUG - 2016-11-13 00:16:42 --> No URI present. Default controller set.
INFO - 2016-11-13 00:16:42 --> Router Class Initialized
INFO - 2016-11-13 00:16:42 --> Output Class Initialized
INFO - 2016-11-13 00:16:42 --> Security Class Initialized
DEBUG - 2016-11-13 00:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:16:42 --> Input Class Initialized
INFO - 2016-11-13 00:16:42 --> Language Class Initialized
INFO - 2016-11-13 00:16:42 --> Language Class Initialized
INFO - 2016-11-13 00:16:42 --> Config Class Initialized
INFO - 2016-11-13 00:16:42 --> Loader Class Initialized
INFO - 2016-11-13 00:16:42 --> Helper loaded: common_helper
INFO - 2016-11-13 00:16:42 --> Helper loaded: url_helper
INFO - 2016-11-13 00:16:42 --> Database Driver Class Initialized
INFO - 2016-11-13 00:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:16:42 --> Parser Class Initialized
INFO - 2016-11-13 00:16:42 --> Controller Class Initialized
DEBUG - 2016-11-13 00:16:42 --> Home MX_Controller Initialized
INFO - 2016-11-13 00:16:42 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-13 00:16:42 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-13 00:16:42 --> Content MX_Controller Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-13 00:16:42 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-13 00:16:42 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-13 00:16:42 --> Slider MX_Controller Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-13 00:16:42 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-13 00:16:42 --> Servers MX_Controller Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-13 00:16:42 --> Model Class Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-13 00:16:42 --> Banner MX_Controller Initialized
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-13 00:16:42 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-13 00:16:42 --> Final output sent to browser
DEBUG - 2016-11-13 00:16:42 --> Total execution time: 0.2720
INFO - 2016-11-13 00:21:00 --> Config Class Initialized
INFO - 2016-11-13 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:21:00 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:21:00 --> Utf8 Class Initialized
INFO - 2016-11-13 00:21:00 --> URI Class Initialized
DEBUG - 2016-11-13 00:21:00 --> No URI present. Default controller set.
INFO - 2016-11-13 00:21:00 --> Router Class Initialized
INFO - 2016-11-13 00:21:00 --> Output Class Initialized
INFO - 2016-11-13 00:21:00 --> Security Class Initialized
DEBUG - 2016-11-13 00:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:21:00 --> Input Class Initialized
INFO - 2016-11-13 00:21:00 --> Language Class Initialized
INFO - 2016-11-13 00:21:00 --> Language Class Initialized
INFO - 2016-11-13 00:21:00 --> Config Class Initialized
INFO - 2016-11-13 00:21:00 --> Loader Class Initialized
INFO - 2016-11-13 00:21:00 --> Helper loaded: common_helper
INFO - 2016-11-13 00:21:00 --> Helper loaded: url_helper
INFO - 2016-11-13 00:21:00 --> Database Driver Class Initialized
INFO - 2016-11-13 00:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:21:00 --> Parser Class Initialized
INFO - 2016-11-13 00:21:00 --> Controller Class Initialized
DEBUG - 2016-11-13 00:21:00 --> Home MX_Controller Initialized
INFO - 2016-11-13 00:21:00 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-13 00:21:00 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-13 00:21:00 --> Content MX_Controller Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-13 00:21:00 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-13 00:21:00 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-13 00:21:00 --> Slider MX_Controller Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-13 00:21:00 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-13 00:21:00 --> Servers MX_Controller Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-13 00:21:00 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-13 00:21:00 --> Banner MX_Controller Initialized
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-13 00:21:00 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-13 00:21:00 --> Final output sent to browser
DEBUG - 2016-11-13 00:21:00 --> Total execution time: 0.2475
INFO - 2016-11-13 00:21:24 --> Config Class Initialized
INFO - 2016-11-13 00:21:24 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:21:24 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:21:24 --> Utf8 Class Initialized
INFO - 2016-11-13 00:21:24 --> URI Class Initialized
DEBUG - 2016-11-13 00:21:24 --> No URI present. Default controller set.
INFO - 2016-11-13 00:21:24 --> Router Class Initialized
INFO - 2016-11-13 00:21:24 --> Output Class Initialized
INFO - 2016-11-13 00:21:24 --> Security Class Initialized
DEBUG - 2016-11-13 00:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:21:24 --> Input Class Initialized
INFO - 2016-11-13 00:21:24 --> Language Class Initialized
INFO - 2016-11-13 00:21:24 --> Language Class Initialized
INFO - 2016-11-13 00:21:24 --> Config Class Initialized
INFO - 2016-11-13 00:21:24 --> Loader Class Initialized
INFO - 2016-11-13 00:21:24 --> Helper loaded: common_helper
INFO - 2016-11-13 00:21:24 --> Helper loaded: url_helper
INFO - 2016-11-13 00:21:24 --> Database Driver Class Initialized
INFO - 2016-11-13 00:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:21:25 --> Parser Class Initialized
INFO - 2016-11-13 00:21:25 --> Controller Class Initialized
DEBUG - 2016-11-13 00:21:25 --> Home MX_Controller Initialized
INFO - 2016-11-13 00:21:25 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-13 00:21:25 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-13 00:21:25 --> Content MX_Controller Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-13 00:21:25 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-13 00:21:25 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-13 00:21:25 --> Slider MX_Controller Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-13 00:21:25 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-13 00:21:25 --> Servers MX_Controller Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-13 00:21:25 --> Model Class Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-13 00:21:25 --> Banner MX_Controller Initialized
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-13 00:21:25 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-13 00:21:25 --> Final output sent to browser
DEBUG - 2016-11-13 00:21:25 --> Total execution time: 0.1494
INFO - 2016-11-13 00:41:53 --> Config Class Initialized
INFO - 2016-11-13 00:41:53 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:41:53 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:41:53 --> Utf8 Class Initialized
INFO - 2016-11-13 00:41:53 --> URI Class Initialized
DEBUG - 2016-11-13 00:41:53 --> No URI present. Default controller set.
INFO - 2016-11-13 00:41:53 --> Router Class Initialized
INFO - 2016-11-13 00:41:53 --> Output Class Initialized
INFO - 2016-11-13 00:41:53 --> Security Class Initialized
DEBUG - 2016-11-13 00:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:41:53 --> Input Class Initialized
INFO - 2016-11-13 00:41:53 --> Language Class Initialized
INFO - 2016-11-13 00:41:53 --> Language Class Initialized
INFO - 2016-11-13 00:41:53 --> Config Class Initialized
INFO - 2016-11-13 00:41:53 --> Loader Class Initialized
INFO - 2016-11-13 00:41:53 --> Helper loaded: common_helper
INFO - 2016-11-13 00:41:53 --> Helper loaded: url_helper
INFO - 2016-11-13 00:41:53 --> Database Driver Class Initialized
INFO - 2016-11-13 00:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:41:53 --> Parser Class Initialized
INFO - 2016-11-13 00:41:53 --> Controller Class Initialized
DEBUG - 2016-11-13 00:41:53 --> Home MX_Controller Initialized
INFO - 2016-11-13 00:41:53 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-13 00:41:53 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-13 00:41:53 --> Content MX_Controller Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-13 00:41:53 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-13 00:41:53 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-13 00:41:53 --> Slider MX_Controller Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-13 00:41:53 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-13 00:41:53 --> Servers MX_Controller Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-13 00:41:53 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-13 00:41:53 --> Banner MX_Controller Initialized
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-13 00:41:53 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-13 00:41:53 --> Final output sent to browser
DEBUG - 2016-11-13 00:41:53 --> Total execution time: 0.1760
INFO - 2016-11-13 00:41:55 --> Config Class Initialized
INFO - 2016-11-13 00:41:55 --> Hooks Class Initialized
DEBUG - 2016-11-13 00:41:55 --> UTF-8 Support Enabled
INFO - 2016-11-13 00:41:55 --> Utf8 Class Initialized
INFO - 2016-11-13 00:41:55 --> URI Class Initialized
DEBUG - 2016-11-13 00:41:55 --> No URI present. Default controller set.
INFO - 2016-11-13 00:41:55 --> Router Class Initialized
INFO - 2016-11-13 00:41:55 --> Output Class Initialized
INFO - 2016-11-13 00:41:55 --> Security Class Initialized
DEBUG - 2016-11-13 00:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-13 00:41:55 --> Input Class Initialized
INFO - 2016-11-13 00:41:55 --> Language Class Initialized
INFO - 2016-11-13 00:41:56 --> Language Class Initialized
INFO - 2016-11-13 00:41:56 --> Config Class Initialized
INFO - 2016-11-13 00:41:56 --> Loader Class Initialized
INFO - 2016-11-13 00:41:56 --> Helper loaded: common_helper
INFO - 2016-11-13 00:41:56 --> Helper loaded: url_helper
INFO - 2016-11-13 00:41:56 --> Database Driver Class Initialized
INFO - 2016-11-13 00:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-13 00:41:56 --> Parser Class Initialized
INFO - 2016-11-13 00:41:56 --> Controller Class Initialized
DEBUG - 2016-11-13 00:41:56 --> Home MX_Controller Initialized
INFO - 2016-11-13 00:41:56 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-13 00:41:56 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-13 00:41:56 --> Content MX_Controller Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-13 00:41:56 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-13 00:41:56 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-13 00:41:56 --> Slider MX_Controller Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-13 00:41:56 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-13 00:41:56 --> Servers MX_Controller Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-13 00:41:56 --> Model Class Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-13 00:41:56 --> Banner MX_Controller Initialized
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-13 00:41:56 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-13 00:41:56 --> Final output sent to browser
DEBUG - 2016-11-13 00:41:56 --> Total execution time: 0.1905
