<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-10 00:18:54 --> Config Class Initialized
INFO - 2016-10-10 00:18:54 --> Hooks Class Initialized
DEBUG - 2016-10-10 00:18:54 --> UTF-8 Support Enabled
INFO - 2016-10-10 00:18:54 --> Utf8 Class Initialized
INFO - 2016-10-10 00:18:54 --> URI Class Initialized
INFO - 2016-10-10 00:18:54 --> Router Class Initialized
INFO - 2016-10-10 00:18:54 --> Output Class Initialized
INFO - 2016-10-10 00:18:54 --> Security Class Initialized
DEBUG - 2016-10-10 00:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 00:18:54 --> Input Class Initialized
INFO - 2016-10-10 00:18:54 --> Language Class Initialized
INFO - 2016-10-10 00:18:54 --> Language Class Initialized
INFO - 2016-10-10 00:18:54 --> Config Class Initialized
INFO - 2016-10-10 00:18:54 --> Loader Class Initialized
INFO - 2016-10-10 00:18:54 --> Helper loaded: common_helper
INFO - 2016-10-10 00:18:54 --> Helper loaded: url_helper
INFO - 2016-10-10 00:18:54 --> Database Driver Class Initialized
INFO - 2016-10-10 00:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 00:18:54 --> Parser Class Initialized
INFO - 2016-10-10 00:18:54 --> Controller Class Initialized
DEBUG - 2016-10-10 00:18:54 --> Content MX_Controller Initialized
INFO - 2016-10-10 00:18:54 --> Model Class Initialized
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 00:18:54 --> Model Class Initialized
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 00:18:54 --> Model Class Initialized
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 00:18:54 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 00:18:54 --> Model Class Initialized
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 00:18:54 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 00:18:54 --> Model Class Initialized
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 00:18:54 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 00:18:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 00:18:54 --> Final output sent to browser
DEBUG - 2016-10-10 00:18:54 --> Total execution time: 0.0569
INFO - 2016-10-10 00:36:42 --> Config Class Initialized
INFO - 2016-10-10 00:36:42 --> Hooks Class Initialized
DEBUG - 2016-10-10 00:36:42 --> UTF-8 Support Enabled
INFO - 2016-10-10 00:36:42 --> Utf8 Class Initialized
INFO - 2016-10-10 00:36:42 --> URI Class Initialized
INFO - 2016-10-10 00:36:42 --> Router Class Initialized
INFO - 2016-10-10 00:36:42 --> Output Class Initialized
INFO - 2016-10-10 00:36:42 --> Security Class Initialized
DEBUG - 2016-10-10 00:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 00:36:42 --> Input Class Initialized
INFO - 2016-10-10 00:36:42 --> Language Class Initialized
INFO - 2016-10-10 00:36:42 --> Language Class Initialized
INFO - 2016-10-10 00:36:42 --> Config Class Initialized
INFO - 2016-10-10 00:36:42 --> Loader Class Initialized
INFO - 2016-10-10 00:36:42 --> Helper loaded: common_helper
INFO - 2016-10-10 00:36:42 --> Helper loaded: url_helper
INFO - 2016-10-10 00:36:42 --> Database Driver Class Initialized
INFO - 2016-10-10 00:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 00:36:42 --> Parser Class Initialized
INFO - 2016-10-10 00:36:42 --> Controller Class Initialized
DEBUG - 2016-10-10 00:36:42 --> Content MX_Controller Initialized
INFO - 2016-10-10 00:36:42 --> Model Class Initialized
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 00:36:42 --> Model Class Initialized
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 00:36:42 --> Model Class Initialized
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 00:36:42 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 00:36:42 --> Model Class Initialized
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 00:36:42 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 00:36:42 --> Model Class Initialized
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 00:36:42 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 00:36:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 00:36:42 --> Final output sent to browser
DEBUG - 2016-10-10 00:36:42 --> Total execution time: 0.0670
INFO - 2016-10-10 01:34:41 --> Config Class Initialized
INFO - 2016-10-10 01:34:41 --> Hooks Class Initialized
DEBUG - 2016-10-10 01:34:41 --> UTF-8 Support Enabled
INFO - 2016-10-10 01:34:41 --> Utf8 Class Initialized
INFO - 2016-10-10 01:34:41 --> URI Class Initialized
INFO - 2016-10-10 01:34:41 --> Router Class Initialized
INFO - 2016-10-10 01:34:41 --> Output Class Initialized
INFO - 2016-10-10 01:34:41 --> Security Class Initialized
DEBUG - 2016-10-10 01:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 01:34:41 --> Input Class Initialized
INFO - 2016-10-10 01:34:41 --> Language Class Initialized
INFO - 2016-10-10 01:34:41 --> Language Class Initialized
INFO - 2016-10-10 01:34:41 --> Config Class Initialized
INFO - 2016-10-10 01:34:41 --> Loader Class Initialized
INFO - 2016-10-10 01:34:41 --> Helper loaded: common_helper
INFO - 2016-10-10 01:34:41 --> Helper loaded: url_helper
INFO - 2016-10-10 01:34:41 --> Database Driver Class Initialized
INFO - 2016-10-10 01:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 01:34:41 --> Parser Class Initialized
INFO - 2016-10-10 01:34:41 --> Controller Class Initialized
DEBUG - 2016-10-10 01:34:41 --> Content MX_Controller Initialized
INFO - 2016-10-10 01:34:41 --> Model Class Initialized
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 01:34:41 --> Model Class Initialized
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 01:34:41 --> Model Class Initialized
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 01:34:41 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 01:34:41 --> Model Class Initialized
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 01:34:41 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 01:34:41 --> Model Class Initialized
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 01:34:41 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 01:34:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 01:34:41 --> Final output sent to browser
DEBUG - 2016-10-10 01:34:41 --> Total execution time: 0.0572
INFO - 2016-10-10 01:48:07 --> Config Class Initialized
INFO - 2016-10-10 01:48:07 --> Hooks Class Initialized
DEBUG - 2016-10-10 01:48:07 --> UTF-8 Support Enabled
INFO - 2016-10-10 01:48:07 --> Utf8 Class Initialized
INFO - 2016-10-10 01:48:07 --> URI Class Initialized
INFO - 2016-10-10 01:48:07 --> Router Class Initialized
INFO - 2016-10-10 01:48:07 --> Output Class Initialized
INFO - 2016-10-10 01:48:07 --> Security Class Initialized
DEBUG - 2016-10-10 01:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 01:48:07 --> Input Class Initialized
INFO - 2016-10-10 01:48:08 --> Language Class Initialized
INFO - 2016-10-10 01:48:08 --> Language Class Initialized
INFO - 2016-10-10 01:48:08 --> Config Class Initialized
INFO - 2016-10-10 01:48:08 --> Loader Class Initialized
INFO - 2016-10-10 01:48:08 --> Helper loaded: common_helper
INFO - 2016-10-10 01:48:08 --> Helper loaded: url_helper
INFO - 2016-10-10 01:48:08 --> Database Driver Class Initialized
INFO - 2016-10-10 01:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 01:48:08 --> Parser Class Initialized
INFO - 2016-10-10 01:48:08 --> Controller Class Initialized
DEBUG - 2016-10-10 01:48:08 --> Content MX_Controller Initialized
INFO - 2016-10-10 01:48:08 --> Model Class Initialized
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 01:48:08 --> Model Class Initialized
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 01:48:08 --> Model Class Initialized
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 01:48:08 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 01:48:08 --> Model Class Initialized
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 01:48:08 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 01:48:08 --> Model Class Initialized
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 01:48:08 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 01:48:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 01:48:08 --> Final output sent to browser
DEBUG - 2016-10-10 01:48:08 --> Total execution time: 0.9327
INFO - 2016-10-10 02:50:28 --> Config Class Initialized
INFO - 2016-10-10 02:50:28 --> Hooks Class Initialized
DEBUG - 2016-10-10 02:50:28 --> UTF-8 Support Enabled
INFO - 2016-10-10 02:50:28 --> Utf8 Class Initialized
INFO - 2016-10-10 02:50:28 --> URI Class Initialized
INFO - 2016-10-10 02:50:28 --> Router Class Initialized
INFO - 2016-10-10 02:50:28 --> Output Class Initialized
INFO - 2016-10-10 02:50:28 --> Security Class Initialized
DEBUG - 2016-10-10 02:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 02:50:28 --> Input Class Initialized
INFO - 2016-10-10 02:50:28 --> Language Class Initialized
INFO - 2016-10-10 02:50:28 --> Language Class Initialized
INFO - 2016-10-10 02:50:28 --> Config Class Initialized
INFO - 2016-10-10 02:50:28 --> Loader Class Initialized
INFO - 2016-10-10 02:50:28 --> Helper loaded: common_helper
INFO - 2016-10-10 02:50:28 --> Helper loaded: url_helper
INFO - 2016-10-10 02:50:28 --> Database Driver Class Initialized
INFO - 2016-10-10 02:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 02:50:28 --> Parser Class Initialized
INFO - 2016-10-10 02:50:28 --> Controller Class Initialized
DEBUG - 2016-10-10 02:50:28 --> Content MX_Controller Initialized
INFO - 2016-10-10 02:50:28 --> Model Class Initialized
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 02:50:29 --> Model Class Initialized
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 02:50:29 --> Model Class Initialized
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 02:50:29 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 02:50:29 --> Model Class Initialized
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 02:50:29 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 02:50:29 --> Model Class Initialized
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 02:50:29 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 02:50:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 02:50:29 --> Final output sent to browser
DEBUG - 2016-10-10 02:50:29 --> Total execution time: 0.1933
INFO - 2016-10-10 02:59:31 --> Config Class Initialized
INFO - 2016-10-10 02:59:31 --> Hooks Class Initialized
DEBUG - 2016-10-10 02:59:31 --> UTF-8 Support Enabled
INFO - 2016-10-10 02:59:31 --> Utf8 Class Initialized
INFO - 2016-10-10 02:59:31 --> URI Class Initialized
INFO - 2016-10-10 02:59:31 --> Router Class Initialized
INFO - 2016-10-10 02:59:31 --> Output Class Initialized
INFO - 2016-10-10 02:59:31 --> Security Class Initialized
DEBUG - 2016-10-10 02:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 02:59:31 --> Input Class Initialized
INFO - 2016-10-10 02:59:31 --> Language Class Initialized
INFO - 2016-10-10 02:59:31 --> Language Class Initialized
INFO - 2016-10-10 02:59:31 --> Config Class Initialized
INFO - 2016-10-10 02:59:31 --> Loader Class Initialized
INFO - 2016-10-10 02:59:31 --> Helper loaded: common_helper
INFO - 2016-10-10 02:59:31 --> Helper loaded: url_helper
INFO - 2016-10-10 02:59:31 --> Database Driver Class Initialized
INFO - 2016-10-10 02:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 02:59:31 --> Parser Class Initialized
INFO - 2016-10-10 02:59:31 --> Controller Class Initialized
DEBUG - 2016-10-10 02:59:31 --> Content MX_Controller Initialized
INFO - 2016-10-10 02:59:31 --> Model Class Initialized
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 02:59:31 --> Model Class Initialized
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 02:59:31 --> Model Class Initialized
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 02:59:31 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 02:59:31 --> Model Class Initialized
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 02:59:31 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 02:59:31 --> Model Class Initialized
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 02:59:31 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 02:59:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 02:59:31 --> Final output sent to browser
DEBUG - 2016-10-10 02:59:31 --> Total execution time: 0.0575
INFO - 2016-10-10 03:04:36 --> Config Class Initialized
INFO - 2016-10-10 03:04:36 --> Hooks Class Initialized
DEBUG - 2016-10-10 03:04:36 --> UTF-8 Support Enabled
INFO - 2016-10-10 03:04:36 --> Utf8 Class Initialized
INFO - 2016-10-10 03:04:36 --> URI Class Initialized
DEBUG - 2016-10-10 03:04:36 --> No URI present. Default controller set.
INFO - 2016-10-10 03:04:36 --> Router Class Initialized
INFO - 2016-10-10 03:04:36 --> Output Class Initialized
INFO - 2016-10-10 03:04:36 --> Security Class Initialized
DEBUG - 2016-10-10 03:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 03:04:36 --> Input Class Initialized
INFO - 2016-10-10 03:04:36 --> Language Class Initialized
INFO - 2016-10-10 03:04:36 --> Language Class Initialized
INFO - 2016-10-10 03:04:36 --> Config Class Initialized
INFO - 2016-10-10 03:04:36 --> Loader Class Initialized
INFO - 2016-10-10 03:04:36 --> Helper loaded: common_helper
INFO - 2016-10-10 03:04:36 --> Helper loaded: url_helper
INFO - 2016-10-10 03:04:36 --> Database Driver Class Initialized
INFO - 2016-10-10 03:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 03:04:36 --> Parser Class Initialized
INFO - 2016-10-10 03:04:36 --> Controller Class Initialized
DEBUG - 2016-10-10 03:04:36 --> Home MX_Controller Initialized
INFO - 2016-10-10 03:04:36 --> Model Class Initialized
DEBUG - 2016-10-10 03:04:36 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 03:04:36 --> Model Class Initialized
ERROR - 2016-10-10 03:04:36 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 03:04:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 03:04:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 03:04:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 03:04:36 --> Final output sent to browser
DEBUG - 2016-10-10 03:04:36 --> Total execution time: 0.1734
INFO - 2016-10-10 04:06:23 --> Config Class Initialized
INFO - 2016-10-10 04:06:23 --> Hooks Class Initialized
DEBUG - 2016-10-10 04:06:23 --> UTF-8 Support Enabled
INFO - 2016-10-10 04:06:23 --> Utf8 Class Initialized
INFO - 2016-10-10 04:06:23 --> URI Class Initialized
INFO - 2016-10-10 04:06:23 --> Router Class Initialized
INFO - 2016-10-10 04:06:23 --> Output Class Initialized
INFO - 2016-10-10 04:06:23 --> Security Class Initialized
DEBUG - 2016-10-10 04:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 04:06:23 --> Input Class Initialized
INFO - 2016-10-10 04:06:23 --> Language Class Initialized
INFO - 2016-10-10 04:06:23 --> Language Class Initialized
INFO - 2016-10-10 04:06:23 --> Config Class Initialized
INFO - 2016-10-10 04:06:23 --> Loader Class Initialized
INFO - 2016-10-10 04:06:23 --> Helper loaded: common_helper
INFO - 2016-10-10 04:06:23 --> Helper loaded: url_helper
INFO - 2016-10-10 04:06:23 --> Database Driver Class Initialized
INFO - 2016-10-10 04:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 04:06:23 --> Parser Class Initialized
INFO - 2016-10-10 04:06:23 --> Controller Class Initialized
DEBUG - 2016-10-10 04:06:23 --> Content MX_Controller Initialized
INFO - 2016-10-10 04:06:23 --> Model Class Initialized
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 04:06:23 --> Model Class Initialized
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 04:06:23 --> Model Class Initialized
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 04:06:23 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 04:06:23 --> Model Class Initialized
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 04:06:23 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 04:06:23 --> Model Class Initialized
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 04:06:23 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 04:06:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 04:06:23 --> Final output sent to browser
DEBUG - 2016-10-10 04:06:23 --> Total execution time: 0.0575
INFO - 2016-10-10 04:10:41 --> Config Class Initialized
INFO - 2016-10-10 04:10:41 --> Hooks Class Initialized
DEBUG - 2016-10-10 04:10:41 --> UTF-8 Support Enabled
INFO - 2016-10-10 04:10:41 --> Utf8 Class Initialized
INFO - 2016-10-10 04:10:41 --> URI Class Initialized
INFO - 2016-10-10 04:10:41 --> Router Class Initialized
INFO - 2016-10-10 04:10:41 --> Output Class Initialized
INFO - 2016-10-10 04:10:41 --> Security Class Initialized
DEBUG - 2016-10-10 04:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 04:10:41 --> Input Class Initialized
INFO - 2016-10-10 04:10:41 --> Language Class Initialized
INFO - 2016-10-10 04:10:41 --> Language Class Initialized
INFO - 2016-10-10 04:10:41 --> Config Class Initialized
INFO - 2016-10-10 04:10:41 --> Loader Class Initialized
INFO - 2016-10-10 04:10:41 --> Helper loaded: common_helper
INFO - 2016-10-10 04:10:41 --> Helper loaded: url_helper
INFO - 2016-10-10 04:10:41 --> Database Driver Class Initialized
INFO - 2016-10-10 04:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 04:10:41 --> Parser Class Initialized
INFO - 2016-10-10 04:10:41 --> Controller Class Initialized
DEBUG - 2016-10-10 04:10:41 --> Content MX_Controller Initialized
INFO - 2016-10-10 04:10:41 --> Model Class Initialized
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 04:10:41 --> Model Class Initialized
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 04:10:41 --> Model Class Initialized
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 04:10:41 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 04:10:41 --> Model Class Initialized
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 04:10:41 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 04:10:41 --> Model Class Initialized
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 04:10:41 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 04:10:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 04:10:41 --> Final output sent to browser
DEBUG - 2016-10-10 04:10:41 --> Total execution time: 0.0553
INFO - 2016-10-10 05:08:05 --> Config Class Initialized
INFO - 2016-10-10 05:08:05 --> Hooks Class Initialized
DEBUG - 2016-10-10 05:08:05 --> UTF-8 Support Enabled
INFO - 2016-10-10 05:08:05 --> Utf8 Class Initialized
INFO - 2016-10-10 05:08:05 --> URI Class Initialized
INFO - 2016-10-10 05:08:05 --> Router Class Initialized
INFO - 2016-10-10 05:08:05 --> Output Class Initialized
INFO - 2016-10-10 05:08:05 --> Security Class Initialized
DEBUG - 2016-10-10 05:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 05:08:05 --> Input Class Initialized
INFO - 2016-10-10 05:08:05 --> Language Class Initialized
INFO - 2016-10-10 05:08:05 --> Language Class Initialized
INFO - 2016-10-10 05:08:05 --> Config Class Initialized
INFO - 2016-10-10 05:08:05 --> Loader Class Initialized
INFO - 2016-10-10 05:08:05 --> Helper loaded: common_helper
INFO - 2016-10-10 05:08:05 --> Helper loaded: url_helper
INFO - 2016-10-10 05:08:05 --> Database Driver Class Initialized
INFO - 2016-10-10 05:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 05:08:05 --> Parser Class Initialized
INFO - 2016-10-10 05:08:05 --> Controller Class Initialized
DEBUG - 2016-10-10 05:08:05 --> Popup MX_Controller Initialized
INFO - 2016-10-10 05:08:05 --> Model Class Initialized
DEBUG - 2016-10-10 05:08:05 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-10 05:08:05 --> Model Class Initialized
DEBUG - 2016-10-10 05:08:05 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-10 05:08:05 --> Final output sent to browser
DEBUG - 2016-10-10 05:08:05 --> Total execution time: 0.0414
INFO - 2016-10-10 05:21:20 --> Config Class Initialized
INFO - 2016-10-10 05:21:20 --> Hooks Class Initialized
DEBUG - 2016-10-10 05:21:20 --> UTF-8 Support Enabled
INFO - 2016-10-10 05:21:20 --> Utf8 Class Initialized
INFO - 2016-10-10 05:21:20 --> URI Class Initialized
INFO - 2016-10-10 05:21:20 --> Router Class Initialized
INFO - 2016-10-10 05:21:20 --> Output Class Initialized
INFO - 2016-10-10 05:21:20 --> Security Class Initialized
DEBUG - 2016-10-10 05:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 05:21:20 --> Input Class Initialized
INFO - 2016-10-10 05:21:20 --> Language Class Initialized
INFO - 2016-10-10 05:21:20 --> Language Class Initialized
INFO - 2016-10-10 05:21:20 --> Config Class Initialized
INFO - 2016-10-10 05:21:20 --> Loader Class Initialized
INFO - 2016-10-10 05:21:20 --> Helper loaded: common_helper
INFO - 2016-10-10 05:21:20 --> Helper loaded: url_helper
INFO - 2016-10-10 05:21:20 --> Database Driver Class Initialized
INFO - 2016-10-10 05:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 05:21:20 --> Parser Class Initialized
INFO - 2016-10-10 05:21:20 --> Controller Class Initialized
DEBUG - 2016-10-10 05:21:20 --> Content MX_Controller Initialized
INFO - 2016-10-10 05:21:20 --> Model Class Initialized
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 05:21:20 --> Model Class Initialized
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 05:21:20 --> Model Class Initialized
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 05:21:20 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 05:21:20 --> Model Class Initialized
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 05:21:20 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 05:21:20 --> Model Class Initialized
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 05:21:20 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 05:21:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 05:21:20 --> Final output sent to browser
DEBUG - 2016-10-10 05:21:20 --> Total execution time: 0.0605
INFO - 2016-10-10 06:33:00 --> Config Class Initialized
INFO - 2016-10-10 06:33:00 --> Hooks Class Initialized
DEBUG - 2016-10-10 06:33:00 --> UTF-8 Support Enabled
INFO - 2016-10-10 06:33:00 --> Utf8 Class Initialized
INFO - 2016-10-10 06:33:00 --> URI Class Initialized
INFO - 2016-10-10 06:33:00 --> Router Class Initialized
INFO - 2016-10-10 06:33:00 --> Output Class Initialized
INFO - 2016-10-10 06:33:00 --> Security Class Initialized
DEBUG - 2016-10-10 06:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 06:33:00 --> Input Class Initialized
INFO - 2016-10-10 06:33:00 --> Language Class Initialized
ERROR - 2016-10-10 06:33:00 --> 404 Page Not Found: /index
INFO - 2016-10-10 06:33:00 --> Config Class Initialized
INFO - 2016-10-10 06:33:00 --> Hooks Class Initialized
DEBUG - 2016-10-10 06:33:00 --> UTF-8 Support Enabled
INFO - 2016-10-10 06:33:00 --> Utf8 Class Initialized
INFO - 2016-10-10 06:33:00 --> URI Class Initialized
INFO - 2016-10-10 06:33:00 --> Router Class Initialized
INFO - 2016-10-10 06:33:00 --> Output Class Initialized
INFO - 2016-10-10 06:33:00 --> Security Class Initialized
DEBUG - 2016-10-10 06:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 06:33:00 --> Input Class Initialized
INFO - 2016-10-10 06:33:00 --> Language Class Initialized
INFO - 2016-10-10 06:33:00 --> Language Class Initialized
INFO - 2016-10-10 06:33:00 --> Config Class Initialized
INFO - 2016-10-10 06:33:00 --> Loader Class Initialized
INFO - 2016-10-10 06:33:00 --> Helper loaded: common_helper
INFO - 2016-10-10 06:33:00 --> Helper loaded: url_helper
INFO - 2016-10-10 06:33:00 --> Database Driver Class Initialized
INFO - 2016-10-10 06:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 06:33:00 --> Parser Class Initialized
INFO - 2016-10-10 06:33:00 --> Controller Class Initialized
DEBUG - 2016-10-10 06:33:00 --> Content MX_Controller Initialized
INFO - 2016-10-10 06:33:00 --> Model Class Initialized
DEBUG - 2016-10-10 06:33:00 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 06:33:00 --> Model Class Initialized
DEBUG - 2016-10-10 06:33:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 06:33:00 --> Model Class Initialized
DEBUG - 2016-10-10 06:33:00 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 06:33:00 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 06:33:00 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 06:33:00 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 06:33:00 --> Model Class Initialized
DEBUG - 2016-10-10 06:33:00 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 06:33:00 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 06:33:00 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 06:33:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 06:33:00 --> Model Class Initialized
DEBUG - 2016-10-10 06:33:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 06:33:01 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 06:33:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 06:33:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 06:33:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 06:33:01 --> Final output sent to browser
DEBUG - 2016-10-10 06:33:01 --> Total execution time: 0.0700
INFO - 2016-10-10 07:45:00 --> Config Class Initialized
INFO - 2016-10-10 07:45:00 --> Hooks Class Initialized
DEBUG - 2016-10-10 07:45:00 --> UTF-8 Support Enabled
INFO - 2016-10-10 07:45:00 --> Utf8 Class Initialized
INFO - 2016-10-10 07:45:00 --> URI Class Initialized
INFO - 2016-10-10 07:45:00 --> Router Class Initialized
INFO - 2016-10-10 07:45:00 --> Output Class Initialized
INFO - 2016-10-10 07:45:00 --> Security Class Initialized
DEBUG - 2016-10-10 07:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 07:45:00 --> Input Class Initialized
INFO - 2016-10-10 07:45:00 --> Language Class Initialized
ERROR - 2016-10-10 07:45:00 --> 404 Page Not Found: /index
INFO - 2016-10-10 07:45:01 --> Config Class Initialized
INFO - 2016-10-10 07:45:01 --> Hooks Class Initialized
DEBUG - 2016-10-10 07:45:01 --> UTF-8 Support Enabled
INFO - 2016-10-10 07:45:01 --> Utf8 Class Initialized
INFO - 2016-10-10 07:45:01 --> URI Class Initialized
INFO - 2016-10-10 07:45:01 --> Router Class Initialized
INFO - 2016-10-10 07:45:01 --> Output Class Initialized
INFO - 2016-10-10 07:45:01 --> Security Class Initialized
DEBUG - 2016-10-10 07:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 07:45:01 --> Input Class Initialized
INFO - 2016-10-10 07:45:01 --> Language Class Initialized
INFO - 2016-10-10 07:45:01 --> Language Class Initialized
INFO - 2016-10-10 07:45:01 --> Config Class Initialized
INFO - 2016-10-10 07:45:01 --> Loader Class Initialized
INFO - 2016-10-10 07:45:01 --> Helper loaded: common_helper
INFO - 2016-10-10 07:45:01 --> Helper loaded: url_helper
INFO - 2016-10-10 07:45:01 --> Database Driver Class Initialized
INFO - 2016-10-10 07:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 07:45:01 --> Parser Class Initialized
INFO - 2016-10-10 07:45:01 --> Controller Class Initialized
DEBUG - 2016-10-10 07:45:01 --> Content MX_Controller Initialized
INFO - 2016-10-10 07:45:01 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 07:45:01 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 07:45:01 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 07:45:01 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 07:45:01 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 07:45:01 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 07:45:01 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 07:45:01 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 07:45:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 07:45:01 --> Final output sent to browser
DEBUG - 2016-10-10 07:45:01 --> Total execution time: 0.0754
INFO - 2016-10-10 07:45:20 --> Config Class Initialized
INFO - 2016-10-10 07:45:20 --> Hooks Class Initialized
DEBUG - 2016-10-10 07:45:20 --> UTF-8 Support Enabled
INFO - 2016-10-10 07:45:20 --> Utf8 Class Initialized
INFO - 2016-10-10 07:45:20 --> URI Class Initialized
INFO - 2016-10-10 07:45:20 --> Router Class Initialized
INFO - 2016-10-10 07:45:20 --> Output Class Initialized
INFO - 2016-10-10 07:45:20 --> Security Class Initialized
DEBUG - 2016-10-10 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 07:45:20 --> Input Class Initialized
INFO - 2016-10-10 07:45:20 --> Language Class Initialized
INFO - 2016-10-10 07:45:20 --> Language Class Initialized
INFO - 2016-10-10 07:45:20 --> Config Class Initialized
INFO - 2016-10-10 07:45:20 --> Loader Class Initialized
INFO - 2016-10-10 07:45:20 --> Helper loaded: common_helper
INFO - 2016-10-10 07:45:20 --> Helper loaded: url_helper
INFO - 2016-10-10 07:45:20 --> Database Driver Class Initialized
INFO - 2016-10-10 07:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 07:45:20 --> Parser Class Initialized
INFO - 2016-10-10 07:45:20 --> Controller Class Initialized
DEBUG - 2016-10-10 07:45:20 --> Content MX_Controller Initialized
INFO - 2016-10-10 07:45:20 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 07:45:20 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 07:45:20 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 07:45:20 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 07:45:20 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 07:45:20 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 07:45:20 --> Model Class Initialized
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 07:45:20 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 07:45:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 07:45:20 --> Final output sent to browser
DEBUG - 2016-10-10 07:45:20 --> Total execution time: 0.0564
INFO - 2016-10-10 08:10:48 --> Config Class Initialized
INFO - 2016-10-10 08:10:48 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:10:48 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:10:48 --> Utf8 Class Initialized
INFO - 2016-10-10 08:10:48 --> URI Class Initialized
DEBUG - 2016-10-10 08:10:48 --> No URI present. Default controller set.
INFO - 2016-10-10 08:10:48 --> Router Class Initialized
INFO - 2016-10-10 08:10:48 --> Output Class Initialized
INFO - 2016-10-10 08:10:48 --> Security Class Initialized
DEBUG - 2016-10-10 08:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:10:48 --> Input Class Initialized
INFO - 2016-10-10 08:10:48 --> Language Class Initialized
INFO - 2016-10-10 08:10:48 --> Language Class Initialized
INFO - 2016-10-10 08:10:48 --> Config Class Initialized
INFO - 2016-10-10 08:10:48 --> Loader Class Initialized
INFO - 2016-10-10 08:10:48 --> Helper loaded: common_helper
INFO - 2016-10-10 08:10:48 --> Helper loaded: url_helper
INFO - 2016-10-10 08:10:48 --> Database Driver Class Initialized
INFO - 2016-10-10 08:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:10:48 --> Parser Class Initialized
INFO - 2016-10-10 08:10:48 --> Controller Class Initialized
DEBUG - 2016-10-10 08:10:48 --> Home MX_Controller Initialized
INFO - 2016-10-10 08:10:48 --> Model Class Initialized
DEBUG - 2016-10-10 08:10:48 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 08:10:48 --> Model Class Initialized
ERROR - 2016-10-10 08:10:48 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 08:10:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 08:10:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 08:10:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 08:10:48 --> Final output sent to browser
DEBUG - 2016-10-10 08:10:48 --> Total execution time: 0.0442
INFO - 2016-10-10 08:10:51 --> Config Class Initialized
INFO - 2016-10-10 08:10:51 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:10:51 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:10:51 --> Utf8 Class Initialized
INFO - 2016-10-10 08:10:51 --> URI Class Initialized
INFO - 2016-10-10 08:10:51 --> Router Class Initialized
INFO - 2016-10-10 08:10:51 --> Output Class Initialized
INFO - 2016-10-10 08:10:51 --> Security Class Initialized
DEBUG - 2016-10-10 08:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:10:51 --> Input Class Initialized
INFO - 2016-10-10 08:10:51 --> Language Class Initialized
INFO - 2016-10-10 08:10:51 --> Language Class Initialized
INFO - 2016-10-10 08:10:51 --> Config Class Initialized
INFO - 2016-10-10 08:10:51 --> Loader Class Initialized
INFO - 2016-10-10 08:10:51 --> Helper loaded: common_helper
INFO - 2016-10-10 08:10:51 --> Helper loaded: url_helper
INFO - 2016-10-10 08:10:51 --> Database Driver Class Initialized
INFO - 2016-10-10 08:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:10:51 --> Parser Class Initialized
INFO - 2016-10-10 08:10:51 --> Controller Class Initialized
DEBUG - 2016-10-10 08:10:51 --> Popup MX_Controller Initialized
INFO - 2016-10-10 08:10:51 --> Model Class Initialized
DEBUG - 2016-10-10 08:10:51 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-10 08:10:51 --> Model Class Initialized
DEBUG - 2016-10-10 08:10:51 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-10 08:10:51 --> Final output sent to browser
DEBUG - 2016-10-10 08:10:51 --> Total execution time: 0.0368
INFO - 2016-10-10 08:31:41 --> Config Class Initialized
INFO - 2016-10-10 08:31:41 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:31:41 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:31:41 --> Utf8 Class Initialized
INFO - 2016-10-10 08:31:41 --> URI Class Initialized
INFO - 2016-10-10 08:31:41 --> Router Class Initialized
INFO - 2016-10-10 08:31:41 --> Output Class Initialized
INFO - 2016-10-10 08:31:41 --> Security Class Initialized
DEBUG - 2016-10-10 08:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:31:41 --> Input Class Initialized
INFO - 2016-10-10 08:31:41 --> Language Class Initialized
INFO - 2016-10-10 08:31:41 --> Language Class Initialized
INFO - 2016-10-10 08:31:41 --> Config Class Initialized
INFO - 2016-10-10 08:31:41 --> Loader Class Initialized
INFO - 2016-10-10 08:31:41 --> Helper loaded: common_helper
INFO - 2016-10-10 08:31:41 --> Helper loaded: url_helper
INFO - 2016-10-10 08:31:41 --> Database Driver Class Initialized
INFO - 2016-10-10 08:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:31:41 --> Parser Class Initialized
INFO - 2016-10-10 08:31:41 --> Controller Class Initialized
DEBUG - 2016-10-10 08:31:41 --> Admincp MX_Controller Initialized
INFO - 2016-10-10 08:31:41 --> Config Class Initialized
INFO - 2016-10-10 08:31:41 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:31:41 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:31:41 --> Utf8 Class Initialized
INFO - 2016-10-10 08:31:41 --> URI Class Initialized
INFO - 2016-10-10 08:31:41 --> Router Class Initialized
INFO - 2016-10-10 08:31:41 --> Output Class Initialized
INFO - 2016-10-10 08:31:41 --> Security Class Initialized
DEBUG - 2016-10-10 08:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:31:41 --> Input Class Initialized
INFO - 2016-10-10 08:31:41 --> Language Class Initialized
INFO - 2016-10-10 08:31:41 --> Language Class Initialized
INFO - 2016-10-10 08:31:41 --> Config Class Initialized
INFO - 2016-10-10 08:31:41 --> Loader Class Initialized
INFO - 2016-10-10 08:31:41 --> Helper loaded: common_helper
INFO - 2016-10-10 08:31:41 --> Helper loaded: url_helper
INFO - 2016-10-10 08:31:41 --> Database Driver Class Initialized
INFO - 2016-10-10 08:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:31:41 --> Parser Class Initialized
INFO - 2016-10-10 08:31:41 --> Controller Class Initialized
DEBUG - 2016-10-10 08:31:41 --> Admincp MX_Controller Initialized
INFO - 2016-10-10 08:31:41 --> Model Class Initialized
DEBUG - 2016-10-10 08:31:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 08:31:41 --> Model Class Initialized
DEBUG - 2016-10-10 08:31:41 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-10 08:31:41 --> Final output sent to browser
DEBUG - 2016-10-10 08:31:41 --> Total execution time: 0.0324
INFO - 2016-10-10 08:31:53 --> Config Class Initialized
INFO - 2016-10-10 08:31:53 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:31:53 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:31:53 --> Utf8 Class Initialized
INFO - 2016-10-10 08:31:53 --> URI Class Initialized
INFO - 2016-10-10 08:31:53 --> Router Class Initialized
INFO - 2016-10-10 08:31:53 --> Output Class Initialized
INFO - 2016-10-10 08:31:53 --> Security Class Initialized
DEBUG - 2016-10-10 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:31:53 --> Input Class Initialized
INFO - 2016-10-10 08:31:53 --> Language Class Initialized
INFO - 2016-10-10 08:31:53 --> Language Class Initialized
INFO - 2016-10-10 08:31:53 --> Config Class Initialized
INFO - 2016-10-10 08:31:53 --> Loader Class Initialized
INFO - 2016-10-10 08:31:53 --> Helper loaded: common_helper
INFO - 2016-10-10 08:31:53 --> Helper loaded: url_helper
INFO - 2016-10-10 08:31:53 --> Database Driver Class Initialized
INFO - 2016-10-10 08:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:31:53 --> Parser Class Initialized
INFO - 2016-10-10 08:31:53 --> Controller Class Initialized
DEBUG - 2016-10-10 08:31:53 --> Admincp MX_Controller Initialized
INFO - 2016-10-10 08:31:53 --> Model Class Initialized
DEBUG - 2016-10-10 08:31:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 08:31:53 --> Model Class Initialized
INFO - 2016-10-10 08:31:53 --> Final output sent to browser
DEBUG - 2016-10-10 08:31:53 --> Total execution time: 0.0431
INFO - 2016-10-10 08:31:53 --> Config Class Initialized
INFO - 2016-10-10 08:31:53 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:31:53 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:31:53 --> Utf8 Class Initialized
INFO - 2016-10-10 08:31:53 --> URI Class Initialized
INFO - 2016-10-10 08:31:53 --> Router Class Initialized
INFO - 2016-10-10 08:31:53 --> Output Class Initialized
INFO - 2016-10-10 08:31:53 --> Security Class Initialized
DEBUG - 2016-10-10 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:31:53 --> Input Class Initialized
INFO - 2016-10-10 08:31:53 --> Language Class Initialized
INFO - 2016-10-10 08:31:53 --> Language Class Initialized
INFO - 2016-10-10 08:31:53 --> Config Class Initialized
INFO - 2016-10-10 08:31:53 --> Loader Class Initialized
INFO - 2016-10-10 08:31:53 --> Helper loaded: common_helper
INFO - 2016-10-10 08:31:53 --> Helper loaded: url_helper
INFO - 2016-10-10 08:31:53 --> Database Driver Class Initialized
INFO - 2016-10-10 08:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:31:53 --> Parser Class Initialized
INFO - 2016-10-10 08:31:53 --> Controller Class Initialized
DEBUG - 2016-10-10 08:31:53 --> Admincp MX_Controller Initialized
INFO - 2016-10-10 08:31:53 --> Model Class Initialized
DEBUG - 2016-10-10 08:31:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 08:31:53 --> Model Class Initialized
DEBUG - 2016-10-10 08:31:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-10 08:31:53 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 08:31:53 --> Model Class Initialized
DEBUG - 2016-10-10 08:31:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 08:31:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 08:31:53 --> Model Class Initialized
DEBUG - 2016-10-10 08:31:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 08:31:53 --> Model Class Initialized
DEBUG - 2016-10-10 08:31:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 08:31:53 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 08:31:53 --> Final output sent to browser
DEBUG - 2016-10-10 08:31:53 --> Total execution time: 0.0481
INFO - 2016-10-10 08:31:55 --> Config Class Initialized
INFO - 2016-10-10 08:31:55 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:31:55 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:31:55 --> Utf8 Class Initialized
INFO - 2016-10-10 08:31:55 --> URI Class Initialized
INFO - 2016-10-10 08:31:55 --> Router Class Initialized
INFO - 2016-10-10 08:31:55 --> Output Class Initialized
INFO - 2016-10-10 08:31:55 --> Security Class Initialized
DEBUG - 2016-10-10 08:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:31:55 --> Input Class Initialized
INFO - 2016-10-10 08:31:55 --> Language Class Initialized
ERROR - 2016-10-10 08:31:55 --> 404 Page Not Found: /index
INFO - 2016-10-10 08:32:29 --> Config Class Initialized
INFO - 2016-10-10 08:32:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:32:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:32:29 --> Utf8 Class Initialized
INFO - 2016-10-10 08:32:29 --> URI Class Initialized
INFO - 2016-10-10 08:32:29 --> Router Class Initialized
INFO - 2016-10-10 08:32:29 --> Output Class Initialized
INFO - 2016-10-10 08:32:29 --> Security Class Initialized
DEBUG - 2016-10-10 08:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:32:29 --> Input Class Initialized
INFO - 2016-10-10 08:32:29 --> Language Class Initialized
INFO - 2016-10-10 08:32:29 --> Language Class Initialized
INFO - 2016-10-10 08:32:29 --> Config Class Initialized
INFO - 2016-10-10 08:32:29 --> Loader Class Initialized
INFO - 2016-10-10 08:32:29 --> Helper loaded: common_helper
INFO - 2016-10-10 08:32:29 --> Helper loaded: url_helper
INFO - 2016-10-10 08:32:29 --> Database Driver Class Initialized
INFO - 2016-10-10 08:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:32:29 --> Parser Class Initialized
INFO - 2016-10-10 08:32:29 --> Controller Class Initialized
DEBUG - 2016-10-10 08:32:29 --> Servers MX_Controller Initialized
INFO - 2016-10-10 08:32:29 --> Model Class Initialized
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 08:32:29 --> Model Class Initialized
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 08:32:29 --> Model Class Initialized
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 08:32:29 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 08:32:29 --> Model Class Initialized
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 08:32:29 --> Model Class Initialized
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 08:32:29 --> Final output sent to browser
DEBUG - 2016-10-10 08:32:29 --> Total execution time: 0.0528
INFO - 2016-10-10 08:32:29 --> Config Class Initialized
INFO - 2016-10-10 08:32:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:32:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:32:29 --> Utf8 Class Initialized
INFO - 2016-10-10 08:32:29 --> URI Class Initialized
INFO - 2016-10-10 08:32:29 --> Router Class Initialized
INFO - 2016-10-10 08:32:29 --> Output Class Initialized
INFO - 2016-10-10 08:32:29 --> Security Class Initialized
DEBUG - 2016-10-10 08:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:32:29 --> Input Class Initialized
INFO - 2016-10-10 08:32:29 --> Language Class Initialized
INFO - 2016-10-10 08:32:29 --> Language Class Initialized
INFO - 2016-10-10 08:32:29 --> Config Class Initialized
INFO - 2016-10-10 08:32:29 --> Loader Class Initialized
INFO - 2016-10-10 08:32:29 --> Helper loaded: common_helper
INFO - 2016-10-10 08:32:29 --> Helper loaded: url_helper
INFO - 2016-10-10 08:32:29 --> Database Driver Class Initialized
INFO - 2016-10-10 08:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:32:29 --> Parser Class Initialized
INFO - 2016-10-10 08:32:29 --> Controller Class Initialized
DEBUG - 2016-10-10 08:32:29 --> Servers MX_Controller Initialized
INFO - 2016-10-10 08:32:29 --> Model Class Initialized
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 08:32:29 --> Model Class Initialized
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 08:32:29 --> Model Class Initialized
DEBUG - 2016-10-10 08:32:29 --> Pagination Class Initialized
DEBUG - 2016-10-10 08:32:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-10 08:32:29 --> Final output sent to browser
DEBUG - 2016-10-10 08:32:29 --> Total execution time: 0.0689
INFO - 2016-10-10 08:32:29 --> Config Class Initialized
INFO - 2016-10-10 08:32:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:32:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:32:29 --> Utf8 Class Initialized
INFO - 2016-10-10 08:32:29 --> URI Class Initialized
INFO - 2016-10-10 08:32:29 --> Router Class Initialized
INFO - 2016-10-10 08:32:29 --> Output Class Initialized
INFO - 2016-10-10 08:32:29 --> Security Class Initialized
DEBUG - 2016-10-10 08:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:32:29 --> Input Class Initialized
INFO - 2016-10-10 08:32:29 --> Language Class Initialized
ERROR - 2016-10-10 08:32:29 --> 404 Page Not Found: /index
INFO - 2016-10-10 08:34:42 --> Config Class Initialized
INFO - 2016-10-10 08:34:42 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:34:42 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:34:42 --> Utf8 Class Initialized
INFO - 2016-10-10 08:34:42 --> URI Class Initialized
INFO - 2016-10-10 08:34:42 --> Router Class Initialized
INFO - 2016-10-10 08:34:42 --> Output Class Initialized
INFO - 2016-10-10 08:34:42 --> Security Class Initialized
DEBUG - 2016-10-10 08:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:34:42 --> Input Class Initialized
INFO - 2016-10-10 08:34:42 --> Language Class Initialized
INFO - 2016-10-10 08:34:42 --> Language Class Initialized
INFO - 2016-10-10 08:34:42 --> Config Class Initialized
INFO - 2016-10-10 08:34:42 --> Loader Class Initialized
INFO - 2016-10-10 08:34:42 --> Helper loaded: common_helper
INFO - 2016-10-10 08:34:42 --> Helper loaded: url_helper
INFO - 2016-10-10 08:34:42 --> Database Driver Class Initialized
INFO - 2016-10-10 08:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:34:42 --> Parser Class Initialized
INFO - 2016-10-10 08:34:42 --> Controller Class Initialized
DEBUG - 2016-10-10 08:34:42 --> Servers MX_Controller Initialized
INFO - 2016-10-10 08:34:42 --> Model Class Initialized
DEBUG - 2016-10-10 08:34:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 08:34:42 --> Model Class Initialized
DEBUG - 2016-10-10 08:34:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 08:34:42 --> Model Class Initialized
DEBUG - 2016-10-10 08:34:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 08:34:42 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 08:34:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 08:34:42 --> Model Class Initialized
DEBUG - 2016-10-10 08:34:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 08:34:42 --> Model Class Initialized
DEBUG - 2016-10-10 08:34:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-10 08:34:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 08:34:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 08:34:42 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 08:34:42 --> Final output sent to browser
DEBUG - 2016-10-10 08:34:42 --> Total execution time: 0.0656
INFO - 2016-10-10 08:55:03 --> Config Class Initialized
INFO - 2016-10-10 08:55:03 --> Hooks Class Initialized
DEBUG - 2016-10-10 08:55:03 --> UTF-8 Support Enabled
INFO - 2016-10-10 08:55:03 --> Utf8 Class Initialized
INFO - 2016-10-10 08:55:03 --> URI Class Initialized
INFO - 2016-10-10 08:55:03 --> Router Class Initialized
INFO - 2016-10-10 08:55:03 --> Output Class Initialized
INFO - 2016-10-10 08:55:03 --> Security Class Initialized
DEBUG - 2016-10-10 08:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 08:55:03 --> Input Class Initialized
INFO - 2016-10-10 08:55:03 --> Language Class Initialized
INFO - 2016-10-10 08:55:03 --> Language Class Initialized
INFO - 2016-10-10 08:55:03 --> Config Class Initialized
INFO - 2016-10-10 08:55:03 --> Loader Class Initialized
INFO - 2016-10-10 08:55:03 --> Helper loaded: common_helper
INFO - 2016-10-10 08:55:03 --> Helper loaded: url_helper
INFO - 2016-10-10 08:55:03 --> Database Driver Class Initialized
INFO - 2016-10-10 08:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 08:55:03 --> Parser Class Initialized
INFO - 2016-10-10 08:55:03 --> Controller Class Initialized
DEBUG - 2016-10-10 08:55:03 --> Content MX_Controller Initialized
INFO - 2016-10-10 08:55:03 --> Model Class Initialized
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 08:55:03 --> Model Class Initialized
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 08:55:03 --> Model Class Initialized
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 08:55:03 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 08:55:03 --> Model Class Initialized
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 08:55:03 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 08:55:03 --> Model Class Initialized
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 08:55:03 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 08:55:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 08:55:03 --> Final output sent to browser
DEBUG - 2016-10-10 08:55:03 --> Total execution time: 0.0568
INFO - 2016-10-10 10:27:00 --> Config Class Initialized
INFO - 2016-10-10 10:27:00 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:00 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:00 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:00 --> URI Class Initialized
INFO - 2016-10-10 10:27:00 --> Router Class Initialized
INFO - 2016-10-10 10:27:00 --> Output Class Initialized
INFO - 2016-10-10 10:27:00 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:00 --> Input Class Initialized
INFO - 2016-10-10 10:27:00 --> Language Class Initialized
INFO - 2016-10-10 10:27:00 --> Language Class Initialized
INFO - 2016-10-10 10:27:00 --> Config Class Initialized
INFO - 2016-10-10 10:27:00 --> Loader Class Initialized
INFO - 2016-10-10 10:27:00 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:00 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:01 --> Parser Class Initialized
INFO - 2016-10-10 10:27:01 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:01 --> Admincp MX_Controller Initialized
INFO - 2016-10-10 10:27:01 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:01 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-10 10:27:01 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:01 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:01 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:01 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:01 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:01 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:01 --> Total execution time: 0.0729
INFO - 2016-10-10 10:27:02 --> Config Class Initialized
INFO - 2016-10-10 10:27:02 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:02 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:02 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:02 --> URI Class Initialized
INFO - 2016-10-10 10:27:02 --> Router Class Initialized
INFO - 2016-10-10 10:27:02 --> Output Class Initialized
INFO - 2016-10-10 10:27:02 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:02 --> Input Class Initialized
INFO - 2016-10-10 10:27:02 --> Language Class Initialized
ERROR - 2016-10-10 10:27:02 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:27:05 --> Config Class Initialized
INFO - 2016-10-10 10:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:05 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:05 --> URI Class Initialized
INFO - 2016-10-10 10:27:05 --> Router Class Initialized
INFO - 2016-10-10 10:27:05 --> Output Class Initialized
INFO - 2016-10-10 10:27:05 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:05 --> Input Class Initialized
INFO - 2016-10-10 10:27:05 --> Language Class Initialized
ERROR - 2016-10-10 10:27:05 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:27:05 --> Config Class Initialized
INFO - 2016-10-10 10:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:05 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:05 --> URI Class Initialized
INFO - 2016-10-10 10:27:05 --> Router Class Initialized
INFO - 2016-10-10 10:27:05 --> Output Class Initialized
INFO - 2016-10-10 10:27:05 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:05 --> Input Class Initialized
INFO - 2016-10-10 10:27:05 --> Language Class Initialized
ERROR - 2016-10-10 10:27:05 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:27:07 --> Config Class Initialized
INFO - 2016-10-10 10:27:07 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:07 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:07 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:07 --> URI Class Initialized
INFO - 2016-10-10 10:27:07 --> Router Class Initialized
INFO - 2016-10-10 10:27:07 --> Output Class Initialized
INFO - 2016-10-10 10:27:07 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:07 --> Input Class Initialized
INFO - 2016-10-10 10:27:07 --> Language Class Initialized
INFO - 2016-10-10 10:27:07 --> Language Class Initialized
INFO - 2016-10-10 10:27:07 --> Config Class Initialized
INFO - 2016-10-10 10:27:07 --> Loader Class Initialized
INFO - 2016-10-10 10:27:07 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:07 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:07 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:07 --> Parser Class Initialized
INFO - 2016-10-10 10:27:07 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:07 --> Admincp MX_Controller Initialized
INFO - 2016-10-10 10:27:07 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:07 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-10 10:27:07 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:07 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:07 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:07 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:07 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:07 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:07 --> Total execution time: 0.0741
INFO - 2016-10-10 10:27:08 --> Config Class Initialized
INFO - 2016-10-10 10:27:08 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:08 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:08 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:08 --> URI Class Initialized
INFO - 2016-10-10 10:27:08 --> Router Class Initialized
INFO - 2016-10-10 10:27:08 --> Output Class Initialized
INFO - 2016-10-10 10:27:08 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:08 --> Input Class Initialized
INFO - 2016-10-10 10:27:08 --> Language Class Initialized
ERROR - 2016-10-10 10:27:08 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:27:09 --> Config Class Initialized
INFO - 2016-10-10 10:27:09 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:09 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:09 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:09 --> URI Class Initialized
INFO - 2016-10-10 10:27:09 --> Router Class Initialized
INFO - 2016-10-10 10:27:09 --> Output Class Initialized
INFO - 2016-10-10 10:27:09 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:09 --> Input Class Initialized
INFO - 2016-10-10 10:27:09 --> Language Class Initialized
INFO - 2016-10-10 10:27:09 --> Language Class Initialized
INFO - 2016-10-10 10:27:09 --> Config Class Initialized
INFO - 2016-10-10 10:27:09 --> Loader Class Initialized
INFO - 2016-10-10 10:27:09 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:09 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:09 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:09 --> Parser Class Initialized
INFO - 2016-10-10 10:27:09 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:09 --> Admincp MX_Controller Initialized
INFO - 2016-10-10 10:27:09 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:09 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-10 10:27:09 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:09 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:09 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:09 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:09 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:09 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:09 --> Total execution time: 0.0432
INFO - 2016-10-10 10:27:11 --> Config Class Initialized
INFO - 2016-10-10 10:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:11 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:11 --> URI Class Initialized
INFO - 2016-10-10 10:27:11 --> Router Class Initialized
INFO - 2016-10-10 10:27:11 --> Output Class Initialized
INFO - 2016-10-10 10:27:11 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:11 --> Input Class Initialized
INFO - 2016-10-10 10:27:11 --> Language Class Initialized
INFO - 2016-10-10 10:27:11 --> Language Class Initialized
INFO - 2016-10-10 10:27:11 --> Config Class Initialized
INFO - 2016-10-10 10:27:11 --> Loader Class Initialized
INFO - 2016-10-10 10:27:11 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:11 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:11 --> Parser Class Initialized
INFO - 2016-10-10 10:27:11 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:11 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:11 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:11 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:11 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:11 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:11 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:11 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:11 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/index.php
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:11 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:11 --> Total execution time: 0.0479
INFO - 2016-10-10 10:27:11 --> Config Class Initialized
INFO - 2016-10-10 10:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:11 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:11 --> URI Class Initialized
INFO - 2016-10-10 10:27:11 --> Router Class Initialized
INFO - 2016-10-10 10:27:11 --> Output Class Initialized
INFO - 2016-10-10 10:27:11 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:11 --> Input Class Initialized
INFO - 2016-10-10 10:27:11 --> Language Class Initialized
ERROR - 2016-10-10 10:27:11 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:27:11 --> Config Class Initialized
INFO - 2016-10-10 10:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:11 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:11 --> URI Class Initialized
INFO - 2016-10-10 10:27:11 --> Router Class Initialized
INFO - 2016-10-10 10:27:11 --> Output Class Initialized
INFO - 2016-10-10 10:27:11 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:11 --> Input Class Initialized
INFO - 2016-10-10 10:27:11 --> Language Class Initialized
INFO - 2016-10-10 10:27:11 --> Language Class Initialized
INFO - 2016-10-10 10:27:11 --> Config Class Initialized
INFO - 2016-10-10 10:27:11 --> Loader Class Initialized
INFO - 2016-10-10 10:27:11 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:11 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:11 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:11 --> Parser Class Initialized
INFO - 2016-10-10 10:27:11 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:11 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:11 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:11 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:11 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:11 --> Pagination Class Initialized
DEBUG - 2016-10-10 10:27:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/ajax_loadContent.php
INFO - 2016-10-10 10:27:12 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:12 --> Total execution time: 0.0597
INFO - 2016-10-10 10:27:14 --> Config Class Initialized
INFO - 2016-10-10 10:27:14 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:14 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:14 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:14 --> URI Class Initialized
INFO - 2016-10-10 10:27:14 --> Router Class Initialized
INFO - 2016-10-10 10:27:14 --> Output Class Initialized
INFO - 2016-10-10 10:27:14 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:14 --> Input Class Initialized
INFO - 2016-10-10 10:27:14 --> Language Class Initialized
INFO - 2016-10-10 10:27:14 --> Language Class Initialized
INFO - 2016-10-10 10:27:14 --> Config Class Initialized
INFO - 2016-10-10 10:27:14 --> Loader Class Initialized
INFO - 2016-10-10 10:27:14 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:14 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:14 --> Parser Class Initialized
INFO - 2016-10-10 10:27:14 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:14 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:14 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:14 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_account_groups/models/Admincp_account_groups_model.php
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/ajax_editContent.php
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:14 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:14 --> Total execution time: 0.0550
INFO - 2016-10-10 10:27:14 --> Config Class Initialized
INFO - 2016-10-10 10:27:14 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:14 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:14 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:14 --> URI Class Initialized
INFO - 2016-10-10 10:27:14 --> Router Class Initialized
INFO - 2016-10-10 10:27:14 --> Output Class Initialized
INFO - 2016-10-10 10:27:14 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:14 --> Input Class Initialized
INFO - 2016-10-10 10:27:14 --> Language Class Initialized
INFO - 2016-10-10 10:27:14 --> Language Class Initialized
INFO - 2016-10-10 10:27:14 --> Config Class Initialized
INFO - 2016-10-10 10:27:14 --> Loader Class Initialized
INFO - 2016-10-10 10:27:14 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:14 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:14 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:14 --> Parser Class Initialized
INFO - 2016-10-10 10:27:14 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:14 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_account_groups/models/Admincp_account_groups_model.php
INFO - 2016-10-10 10:27:14 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/ajax_permission.php
INFO - 2016-10-10 10:27:14 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:14 --> Total execution time: 0.0400
INFO - 2016-10-10 10:27:21 --> Config Class Initialized
INFO - 2016-10-10 10:27:21 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:21 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:21 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:21 --> URI Class Initialized
INFO - 2016-10-10 10:27:21 --> Router Class Initialized
INFO - 2016-10-10 10:27:21 --> Output Class Initialized
INFO - 2016-10-10 10:27:21 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:21 --> Input Class Initialized
INFO - 2016-10-10 10:27:21 --> Language Class Initialized
INFO - 2016-10-10 10:27:21 --> Language Class Initialized
INFO - 2016-10-10 10:27:21 --> Config Class Initialized
INFO - 2016-10-10 10:27:21 --> Loader Class Initialized
INFO - 2016-10-10 10:27:21 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:21 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:21 --> Parser Class Initialized
INFO - 2016-10-10 10:27:21 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:21 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:21 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:21 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/index.php
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:21 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:21 --> Total execution time: 0.0554
INFO - 2016-10-10 10:27:21 --> Config Class Initialized
INFO - 2016-10-10 10:27:21 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:21 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:21 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:21 --> URI Class Initialized
INFO - 2016-10-10 10:27:21 --> Router Class Initialized
INFO - 2016-10-10 10:27:21 --> Output Class Initialized
INFO - 2016-10-10 10:27:21 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:21 --> Input Class Initialized
INFO - 2016-10-10 10:27:21 --> Language Class Initialized
ERROR - 2016-10-10 10:27:21 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:27:21 --> Config Class Initialized
INFO - 2016-10-10 10:27:21 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:21 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:21 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:21 --> URI Class Initialized
INFO - 2016-10-10 10:27:21 --> Router Class Initialized
INFO - 2016-10-10 10:27:21 --> Output Class Initialized
INFO - 2016-10-10 10:27:21 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:21 --> Input Class Initialized
INFO - 2016-10-10 10:27:21 --> Language Class Initialized
INFO - 2016-10-10 10:27:21 --> Language Class Initialized
INFO - 2016-10-10 10:27:21 --> Config Class Initialized
INFO - 2016-10-10 10:27:21 --> Loader Class Initialized
INFO - 2016-10-10 10:27:21 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:21 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:21 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:21 --> Parser Class Initialized
INFO - 2016-10-10 10:27:21 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:21 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:21 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:21 --> Pagination Class Initialized
DEBUG - 2016-10-10 10:27:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/ajax_loadContent.php
INFO - 2016-10-10 10:27:21 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:21 --> Total execution time: 0.0514
INFO - 2016-10-10 10:27:22 --> Config Class Initialized
INFO - 2016-10-10 10:27:22 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:22 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:22 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:22 --> URI Class Initialized
INFO - 2016-10-10 10:27:22 --> Router Class Initialized
INFO - 2016-10-10 10:27:22 --> Output Class Initialized
INFO - 2016-10-10 10:27:22 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:22 --> Input Class Initialized
INFO - 2016-10-10 10:27:22 --> Language Class Initialized
INFO - 2016-10-10 10:27:22 --> Language Class Initialized
INFO - 2016-10-10 10:27:22 --> Config Class Initialized
INFO - 2016-10-10 10:27:22 --> Loader Class Initialized
INFO - 2016-10-10 10:27:22 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:22 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:22 --> Parser Class Initialized
INFO - 2016-10-10 10:27:22 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:22 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:22 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:22 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_account_groups/models/Admincp_account_groups_model.php
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/ajax_editContent.php
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:22 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:22 --> Total execution time: 0.0528
INFO - 2016-10-10 10:27:22 --> Config Class Initialized
INFO - 2016-10-10 10:27:22 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:22 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:22 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:22 --> URI Class Initialized
INFO - 2016-10-10 10:27:22 --> Router Class Initialized
INFO - 2016-10-10 10:27:22 --> Output Class Initialized
INFO - 2016-10-10 10:27:22 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:22 --> Input Class Initialized
INFO - 2016-10-10 10:27:22 --> Language Class Initialized
INFO - 2016-10-10 10:27:22 --> Language Class Initialized
INFO - 2016-10-10 10:27:22 --> Config Class Initialized
INFO - 2016-10-10 10:27:22 --> Loader Class Initialized
INFO - 2016-10-10 10:27:22 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:22 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:22 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:22 --> Parser Class Initialized
INFO - 2016-10-10 10:27:22 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:22 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_account_groups/models/Admincp_account_groups_model.php
INFO - 2016-10-10 10:27:22 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/ajax_permission.php
INFO - 2016-10-10 10:27:22 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:22 --> Total execution time: 0.0360
INFO - 2016-10-10 10:27:26 --> Config Class Initialized
INFO - 2016-10-10 10:27:26 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:26 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:26 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:26 --> URI Class Initialized
INFO - 2016-10-10 10:27:26 --> Router Class Initialized
INFO - 2016-10-10 10:27:26 --> Output Class Initialized
INFO - 2016-10-10 10:27:26 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:26 --> Input Class Initialized
INFO - 2016-10-10 10:27:26 --> Language Class Initialized
INFO - 2016-10-10 10:27:26 --> Language Class Initialized
INFO - 2016-10-10 10:27:26 --> Config Class Initialized
INFO - 2016-10-10 10:27:26 --> Loader Class Initialized
INFO - 2016-10-10 10:27:26 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:26 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:26 --> Parser Class Initialized
INFO - 2016-10-10 10:27:26 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:26 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:26 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:26 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:26 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:26 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:26 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:26 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:26 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/index.php
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:26 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:26 --> Total execution time: 0.0539
INFO - 2016-10-10 10:27:26 --> Config Class Initialized
INFO - 2016-10-10 10:27:26 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:26 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:26 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:26 --> URI Class Initialized
INFO - 2016-10-10 10:27:26 --> Router Class Initialized
INFO - 2016-10-10 10:27:26 --> Output Class Initialized
INFO - 2016-10-10 10:27:26 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:26 --> Input Class Initialized
INFO - 2016-10-10 10:27:26 --> Language Class Initialized
INFO - 2016-10-10 10:27:26 --> Language Class Initialized
INFO - 2016-10-10 10:27:26 --> Config Class Initialized
INFO - 2016-10-10 10:27:26 --> Loader Class Initialized
INFO - 2016-10-10 10:27:26 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:26 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:26 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:26 --> Parser Class Initialized
INFO - 2016-10-10 10:27:26 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:26 --> Admincp_accounts MX_Controller Initialized
INFO - 2016-10-10 10:27:26 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:26 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:26 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:26 --> Pagination Class Initialized
DEBUG - 2016-10-10 10:27:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/views/ajax_loadContent.php
INFO - 2016-10-10 10:27:26 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:26 --> Total execution time: 0.0582
INFO - 2016-10-10 10:27:31 --> Config Class Initialized
INFO - 2016-10-10 10:27:31 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:31 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:31 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:31 --> URI Class Initialized
INFO - 2016-10-10 10:27:31 --> Router Class Initialized
INFO - 2016-10-10 10:27:31 --> Output Class Initialized
INFO - 2016-10-10 10:27:31 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:31 --> Input Class Initialized
INFO - 2016-10-10 10:27:31 --> Language Class Initialized
INFO - 2016-10-10 10:27:31 --> Language Class Initialized
INFO - 2016-10-10 10:27:31 --> Config Class Initialized
INFO - 2016-10-10 10:27:31 --> Loader Class Initialized
INFO - 2016-10-10 10:27:31 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:31 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:31 --> Parser Class Initialized
INFO - 2016-10-10 10:27:31 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:31 --> Donate MX_Controller Initialized
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/donate/models/Donate_model.php
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:31 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
INFO - 2016-10-10 10:27:31 --> Helper loaded: form_helper
INFO - 2016-10-10 10:27:31 --> Form Validation Class Initialized
INFO - 2016-10-10 10:27:31 --> Config Class Initialized
INFO - 2016-10-10 10:27:31 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:31 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:31 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:31 --> URI Class Initialized
INFO - 2016-10-10 10:27:31 --> Router Class Initialized
INFO - 2016-10-10 10:27:31 --> Output Class Initialized
INFO - 2016-10-10 10:27:31 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:31 --> Input Class Initialized
INFO - 2016-10-10 10:27:31 --> Language Class Initialized
INFO - 2016-10-10 10:27:31 --> Language Class Initialized
INFO - 2016-10-10 10:27:31 --> Config Class Initialized
INFO - 2016-10-10 10:27:31 --> Loader Class Initialized
INFO - 2016-10-10 10:27:31 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:31 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:31 --> Parser Class Initialized
INFO - 2016-10-10 10:27:31 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:31 --> Donate MX_Controller Initialized
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/donate/models/Donate_model.php
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:31 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
INFO - 2016-10-10 10:27:31 --> Helper loaded: form_helper
INFO - 2016-10-10 10:27:31 --> Form Validation Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File already loaded: /home/dolongpk/public_html/application/modules/donate/models/Donate_model.php
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/donate/views/BACKEND/transaction.php
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:31 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:31 --> Total execution time: 0.0485
INFO - 2016-10-10 10:27:31 --> Config Class Initialized
INFO - 2016-10-10 10:27:31 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:31 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:31 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:31 --> URI Class Initialized
INFO - 2016-10-10 10:27:31 --> Router Class Initialized
INFO - 2016-10-10 10:27:31 --> Output Class Initialized
INFO - 2016-10-10 10:27:31 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:31 --> Input Class Initialized
INFO - 2016-10-10 10:27:31 --> Language Class Initialized
INFO - 2016-10-10 10:27:31 --> Language Class Initialized
INFO - 2016-10-10 10:27:31 --> Config Class Initialized
INFO - 2016-10-10 10:27:31 --> Loader Class Initialized
INFO - 2016-10-10 10:27:31 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:31 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:31 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:31 --> Parser Class Initialized
INFO - 2016-10-10 10:27:31 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:31 --> Donate MX_Controller Initialized
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/donate/models/Donate_model.php
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:31 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:31 --> Model Class Initialized
INFO - 2016-10-10 10:27:31 --> Helper loaded: form_helper
INFO - 2016-10-10 10:27:31 --> Form Validation Class Initialized
DEBUG - 2016-10-10 10:27:31 --> Pagination Class Initialized
DEBUG - 2016-10-10 10:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/donate/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-10 10:27:31 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:31 --> Total execution time: 0.0536
INFO - 2016-10-10 10:27:34 --> Config Class Initialized
INFO - 2016-10-10 10:27:34 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:34 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:34 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:34 --> URI Class Initialized
INFO - 2016-10-10 10:27:34 --> Router Class Initialized
INFO - 2016-10-10 10:27:34 --> Output Class Initialized
INFO - 2016-10-10 10:27:34 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:34 --> Input Class Initialized
INFO - 2016-10-10 10:27:34 --> Language Class Initialized
ERROR - 2016-10-10 10:27:34 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:27:35 --> Config Class Initialized
INFO - 2016-10-10 10:27:35 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:35 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:35 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:35 --> URI Class Initialized
INFO - 2016-10-10 10:27:35 --> Router Class Initialized
INFO - 2016-10-10 10:27:35 --> Output Class Initialized
INFO - 2016-10-10 10:27:35 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:35 --> Input Class Initialized
INFO - 2016-10-10 10:27:35 --> Language Class Initialized
INFO - 2016-10-10 10:27:35 --> Language Class Initialized
INFO - 2016-10-10 10:27:35 --> Config Class Initialized
INFO - 2016-10-10 10:27:35 --> Loader Class Initialized
INFO - 2016-10-10 10:27:35 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:35 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:35 --> Parser Class Initialized
INFO - 2016-10-10 10:27:35 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:35 --> Donate MX_Controller Initialized
INFO - 2016-10-10 10:27:35 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/donate/models/Donate_model.php
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:35 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:35 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:35 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:35 --> Model Class Initialized
INFO - 2016-10-10 10:27:35 --> Helper loaded: form_helper
INFO - 2016-10-10 10:27:35 --> Form Validation Class Initialized
DEBUG - 2016-10-10 10:27:35 --> File already loaded: /home/dolongpk/public_html/application/modules/donate/models/Donate_model.php
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/donate/views/BACKEND/transaction.php
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-10 10:27:35 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:35 --> Total execution time: 0.0523
INFO - 2016-10-10 10:27:35 --> Config Class Initialized
INFO - 2016-10-10 10:27:35 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:35 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:35 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:35 --> URI Class Initialized
INFO - 2016-10-10 10:27:35 --> Router Class Initialized
INFO - 2016-10-10 10:27:35 --> Output Class Initialized
INFO - 2016-10-10 10:27:35 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:35 --> Input Class Initialized
INFO - 2016-10-10 10:27:35 --> Language Class Initialized
INFO - 2016-10-10 10:27:35 --> Language Class Initialized
INFO - 2016-10-10 10:27:35 --> Config Class Initialized
INFO - 2016-10-10 10:27:35 --> Loader Class Initialized
INFO - 2016-10-10 10:27:35 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:35 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:35 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:35 --> Parser Class Initialized
INFO - 2016-10-10 10:27:35 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:35 --> Donate MX_Controller Initialized
INFO - 2016-10-10 10:27:35 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/donate/models/Donate_model.php
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:27:35 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 10:27:35 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-10 10:27:35 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-10 10:27:35 --> Model Class Initialized
INFO - 2016-10-10 10:27:35 --> Helper loaded: form_helper
INFO - 2016-10-10 10:27:35 --> Form Validation Class Initialized
DEBUG - 2016-10-10 10:27:35 --> Pagination Class Initialized
DEBUG - 2016-10-10 10:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/donate/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-10 10:27:35 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:35 --> Total execution time: 0.0450
INFO - 2016-10-10 10:27:38 --> Config Class Initialized
INFO - 2016-10-10 10:27:38 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:38 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:38 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:38 --> URI Class Initialized
DEBUG - 2016-10-10 10:27:38 --> No URI present. Default controller set.
INFO - 2016-10-10 10:27:38 --> Router Class Initialized
INFO - 2016-10-10 10:27:38 --> Output Class Initialized
INFO - 2016-10-10 10:27:38 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:38 --> Input Class Initialized
INFO - 2016-10-10 10:27:38 --> Language Class Initialized
INFO - 2016-10-10 10:27:38 --> Language Class Initialized
INFO - 2016-10-10 10:27:38 --> Config Class Initialized
INFO - 2016-10-10 10:27:38 --> Loader Class Initialized
INFO - 2016-10-10 10:27:38 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:38 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:38 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:38 --> Parser Class Initialized
INFO - 2016-10-10 10:27:38 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:38 --> Home MX_Controller Initialized
INFO - 2016-10-10 10:27:38 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:38 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 10:27:38 --> Model Class Initialized
ERROR - 2016-10-10 10:27:38 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 10:27:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 10:27:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 10:27:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 10:27:38 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:38 --> Total execution time: 0.0373
INFO - 2016-10-10 10:27:42 --> Config Class Initialized
INFO - 2016-10-10 10:27:42 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:27:42 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:27:42 --> Utf8 Class Initialized
INFO - 2016-10-10 10:27:42 --> URI Class Initialized
INFO - 2016-10-10 10:27:42 --> Router Class Initialized
INFO - 2016-10-10 10:27:42 --> Output Class Initialized
INFO - 2016-10-10 10:27:42 --> Security Class Initialized
DEBUG - 2016-10-10 10:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:27:42 --> Input Class Initialized
INFO - 2016-10-10 10:27:42 --> Language Class Initialized
INFO - 2016-10-10 10:27:42 --> Language Class Initialized
INFO - 2016-10-10 10:27:42 --> Config Class Initialized
INFO - 2016-10-10 10:27:42 --> Loader Class Initialized
INFO - 2016-10-10 10:27:42 --> Helper loaded: common_helper
INFO - 2016-10-10 10:27:42 --> Helper loaded: url_helper
INFO - 2016-10-10 10:27:42 --> Database Driver Class Initialized
INFO - 2016-10-10 10:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:27:42 --> Parser Class Initialized
INFO - 2016-10-10 10:27:42 --> Controller Class Initialized
DEBUG - 2016-10-10 10:27:42 --> Popup MX_Controller Initialized
INFO - 2016-10-10 10:27:42 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:42 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-10 10:27:42 --> Model Class Initialized
DEBUG - 2016-10-10 10:27:42 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-10 10:27:42 --> Final output sent to browser
DEBUG - 2016-10-10 10:27:42 --> Total execution time: 0.0316
INFO - 2016-10-10 10:42:53 --> Config Class Initialized
INFO - 2016-10-10 10:42:53 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:42:53 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:42:53 --> Utf8 Class Initialized
INFO - 2016-10-10 10:42:53 --> URI Class Initialized
INFO - 2016-10-10 10:42:53 --> Router Class Initialized
INFO - 2016-10-10 10:42:53 --> Output Class Initialized
INFO - 2016-10-10 10:42:53 --> Security Class Initialized
DEBUG - 2016-10-10 10:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:42:53 --> Input Class Initialized
INFO - 2016-10-10 10:42:53 --> Language Class Initialized
INFO - 2016-10-10 10:42:53 --> Language Class Initialized
INFO - 2016-10-10 10:42:53 --> Config Class Initialized
INFO - 2016-10-10 10:42:53 --> Loader Class Initialized
INFO - 2016-10-10 10:42:53 --> Helper loaded: common_helper
INFO - 2016-10-10 10:42:53 --> Helper loaded: url_helper
INFO - 2016-10-10 10:42:53 --> Database Driver Class Initialized
INFO - 2016-10-10 10:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:42:53 --> Parser Class Initialized
INFO - 2016-10-10 10:42:53 --> Controller Class Initialized
DEBUG - 2016-10-10 10:42:53 --> Home MX_Controller Initialized
INFO - 2016-10-10 10:42:53 --> Model Class Initialized
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 10:42:53 --> Model Class Initialized
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-10 10:42:53 --> Content MX_Controller Initialized
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:42:53 --> Model Class Initialized
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 10:42:53 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 10:42:53 --> Model Class Initialized
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 10:42:53 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 10:42:53 --> Model Class Initialized
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 10:42:53 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 10:42:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 10:42:53 --> Final output sent to browser
DEBUG - 2016-10-10 10:42:53 --> Total execution time: 0.0767
INFO - 2016-10-10 10:42:53 --> Config Class Initialized
INFO - 2016-10-10 10:42:53 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:42:53 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:42:53 --> Utf8 Class Initialized
INFO - 2016-10-10 10:42:53 --> URI Class Initialized
INFO - 2016-10-10 10:42:53 --> Router Class Initialized
INFO - 2016-10-10 10:42:53 --> Output Class Initialized
INFO - 2016-10-10 10:42:53 --> Security Class Initialized
DEBUG - 2016-10-10 10:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:42:53 --> Input Class Initialized
INFO - 2016-10-10 10:42:53 --> Language Class Initialized
ERROR - 2016-10-10 10:42:53 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:43:00 --> Config Class Initialized
INFO - 2016-10-10 10:43:00 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:43:00 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:43:00 --> Utf8 Class Initialized
INFO - 2016-10-10 10:43:00 --> URI Class Initialized
INFO - 2016-10-10 10:43:00 --> Router Class Initialized
INFO - 2016-10-10 10:43:00 --> Output Class Initialized
INFO - 2016-10-10 10:43:00 --> Security Class Initialized
DEBUG - 2016-10-10 10:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:43:00 --> Input Class Initialized
INFO - 2016-10-10 10:43:00 --> Language Class Initialized
INFO - 2016-10-10 10:43:00 --> Language Class Initialized
INFO - 2016-10-10 10:43:00 --> Config Class Initialized
INFO - 2016-10-10 10:43:00 --> Loader Class Initialized
INFO - 2016-10-10 10:43:00 --> Helper loaded: common_helper
INFO - 2016-10-10 10:43:00 --> Helper loaded: url_helper
INFO - 2016-10-10 10:43:00 --> Database Driver Class Initialized
INFO - 2016-10-10 10:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:43:00 --> Parser Class Initialized
INFO - 2016-10-10 10:43:00 --> Controller Class Initialized
DEBUG - 2016-10-10 10:43:00 --> Servers MX_Controller Initialized
INFO - 2016-10-10 10:43:00 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 10:43:00 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:43:00 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 10:43:00 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 10:43:00 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:43:00 --> File already loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 10:43:00 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 10:43:00 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 10:43:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 10:43:00 --> Final output sent to browser
DEBUG - 2016-10-10 10:43:00 --> Total execution time: 0.0669
INFO - 2016-10-10 10:43:00 --> Config Class Initialized
INFO - 2016-10-10 10:43:00 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:43:00 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:43:00 --> Utf8 Class Initialized
INFO - 2016-10-10 10:43:00 --> URI Class Initialized
INFO - 2016-10-10 10:43:00 --> Router Class Initialized
INFO - 2016-10-10 10:43:00 --> Output Class Initialized
INFO - 2016-10-10 10:43:00 --> Security Class Initialized
DEBUG - 2016-10-10 10:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:43:00 --> Input Class Initialized
INFO - 2016-10-10 10:43:00 --> Language Class Initialized
ERROR - 2016-10-10 10:43:00 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:43:00 --> Config Class Initialized
INFO - 2016-10-10 10:43:00 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:43:00 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:43:00 --> Utf8 Class Initialized
INFO - 2016-10-10 10:43:00 --> URI Class Initialized
INFO - 2016-10-10 10:43:00 --> Router Class Initialized
INFO - 2016-10-10 10:43:00 --> Output Class Initialized
INFO - 2016-10-10 10:43:00 --> Security Class Initialized
DEBUG - 2016-10-10 10:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:43:00 --> Input Class Initialized
INFO - 2016-10-10 10:43:00 --> Language Class Initialized
ERROR - 2016-10-10 10:43:00 --> 404 Page Not Found: /index
INFO - 2016-10-10 10:43:03 --> Config Class Initialized
INFO - 2016-10-10 10:43:03 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:43:03 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:43:03 --> Utf8 Class Initialized
INFO - 2016-10-10 10:43:03 --> URI Class Initialized
INFO - 2016-10-10 10:43:03 --> Router Class Initialized
INFO - 2016-10-10 10:43:03 --> Output Class Initialized
INFO - 2016-10-10 10:43:03 --> Security Class Initialized
DEBUG - 2016-10-10 10:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:43:03 --> Input Class Initialized
INFO - 2016-10-10 10:43:03 --> Language Class Initialized
INFO - 2016-10-10 10:43:03 --> Language Class Initialized
INFO - 2016-10-10 10:43:03 --> Config Class Initialized
INFO - 2016-10-10 10:43:03 --> Loader Class Initialized
INFO - 2016-10-10 10:43:03 --> Helper loaded: common_helper
INFO - 2016-10-10 10:43:03 --> Helper loaded: url_helper
INFO - 2016-10-10 10:43:03 --> Database Driver Class Initialized
INFO - 2016-10-10 10:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:43:03 --> Parser Class Initialized
INFO - 2016-10-10 10:43:03 --> Controller Class Initialized
DEBUG - 2016-10-10 10:43:03 --> Home MX_Controller Initialized
INFO - 2016-10-10 10:43:03 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 10:43:03 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-10 10:43:03 --> Content MX_Controller Initialized
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:43:03 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 10:43:03 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 10:43:03 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 10:43:03 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 10:43:03 --> Model Class Initialized
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 10:43:03 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 10:43:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 10:43:03 --> Final output sent to browser
DEBUG - 2016-10-10 10:43:03 --> Total execution time: 0.0623
INFO - 2016-10-10 10:49:40 --> Config Class Initialized
INFO - 2016-10-10 10:49:40 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:49:40 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:49:40 --> Utf8 Class Initialized
INFO - 2016-10-10 10:49:40 --> URI Class Initialized
INFO - 2016-10-10 10:49:40 --> Router Class Initialized
INFO - 2016-10-10 10:49:40 --> Output Class Initialized
INFO - 2016-10-10 10:49:40 --> Security Class Initialized
DEBUG - 2016-10-10 10:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:49:40 --> Input Class Initialized
INFO - 2016-10-10 10:49:40 --> Language Class Initialized
INFO - 2016-10-10 10:49:40 --> Language Class Initialized
INFO - 2016-10-10 10:49:40 --> Config Class Initialized
INFO - 2016-10-10 10:49:40 --> Loader Class Initialized
INFO - 2016-10-10 10:49:40 --> Helper loaded: common_helper
INFO - 2016-10-10 10:49:40 --> Helper loaded: url_helper
INFO - 2016-10-10 10:49:40 --> Database Driver Class Initialized
INFO - 2016-10-10 10:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 10:49:40 --> Parser Class Initialized
INFO - 2016-10-10 10:49:40 --> Controller Class Initialized
DEBUG - 2016-10-10 10:49:40 --> Home MX_Controller Initialized
INFO - 2016-10-10 10:49:40 --> Model Class Initialized
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 10:49:40 --> Model Class Initialized
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-10 10:49:40 --> Content MX_Controller Initialized
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 10:49:40 --> Model Class Initialized
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 10:49:40 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 10:49:40 --> Model Class Initialized
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 10:49:40 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 10:49:40 --> Model Class Initialized
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 10:49:40 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 10:49:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 10:49:40 --> Final output sent to browser
DEBUG - 2016-10-10 10:49:40 --> Total execution time: 0.0786
INFO - 2016-10-10 10:49:40 --> Config Class Initialized
INFO - 2016-10-10 10:49:40 --> Hooks Class Initialized
DEBUG - 2016-10-10 10:49:40 --> UTF-8 Support Enabled
INFO - 2016-10-10 10:49:40 --> Utf8 Class Initialized
INFO - 2016-10-10 10:49:40 --> URI Class Initialized
INFO - 2016-10-10 10:49:40 --> Router Class Initialized
INFO - 2016-10-10 10:49:40 --> Output Class Initialized
INFO - 2016-10-10 10:49:40 --> Security Class Initialized
DEBUG - 2016-10-10 10:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 10:49:40 --> Input Class Initialized
INFO - 2016-10-10 10:49:40 --> Language Class Initialized
ERROR - 2016-10-10 10:49:40 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:27:39 --> Config Class Initialized
INFO - 2016-10-10 11:27:39 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:27:39 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:27:39 --> Utf8 Class Initialized
INFO - 2016-10-10 11:27:39 --> URI Class Initialized
DEBUG - 2016-10-10 11:27:39 --> No URI present. Default controller set.
INFO - 2016-10-10 11:27:39 --> Router Class Initialized
INFO - 2016-10-10 11:27:39 --> Output Class Initialized
INFO - 2016-10-10 11:27:39 --> Security Class Initialized
DEBUG - 2016-10-10 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:27:39 --> Input Class Initialized
INFO - 2016-10-10 11:27:39 --> Language Class Initialized
INFO - 2016-10-10 11:27:39 --> Language Class Initialized
INFO - 2016-10-10 11:27:39 --> Config Class Initialized
INFO - 2016-10-10 11:27:39 --> Loader Class Initialized
INFO - 2016-10-10 11:27:39 --> Helper loaded: common_helper
INFO - 2016-10-10 11:27:39 --> Helper loaded: url_helper
INFO - 2016-10-10 11:27:39 --> Database Driver Class Initialized
INFO - 2016-10-10 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:27:39 --> Parser Class Initialized
INFO - 2016-10-10 11:27:39 --> Controller Class Initialized
DEBUG - 2016-10-10 11:27:39 --> Home MX_Controller Initialized
INFO - 2016-10-10 11:27:39 --> Model Class Initialized
DEBUG - 2016-10-10 11:27:39 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 11:27:39 --> Model Class Initialized
ERROR - 2016-10-10 11:27:39 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:27:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:27:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:27:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 11:27:39 --> Final output sent to browser
DEBUG - 2016-10-10 11:27:39 --> Total execution time: 0.0423
INFO - 2016-10-10 11:37:41 --> Config Class Initialized
INFO - 2016-10-10 11:37:41 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:37:41 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:37:41 --> Utf8 Class Initialized
INFO - 2016-10-10 11:37:41 --> URI Class Initialized
DEBUG - 2016-10-10 11:37:41 --> No URI present. Default controller set.
INFO - 2016-10-10 11:37:41 --> Router Class Initialized
INFO - 2016-10-10 11:37:41 --> Output Class Initialized
INFO - 2016-10-10 11:37:41 --> Security Class Initialized
DEBUG - 2016-10-10 11:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:37:41 --> Input Class Initialized
INFO - 2016-10-10 11:37:41 --> Language Class Initialized
INFO - 2016-10-10 11:37:41 --> Language Class Initialized
INFO - 2016-10-10 11:37:41 --> Config Class Initialized
INFO - 2016-10-10 11:37:41 --> Loader Class Initialized
INFO - 2016-10-10 11:37:41 --> Helper loaded: common_helper
INFO - 2016-10-10 11:37:41 --> Helper loaded: url_helper
INFO - 2016-10-10 11:37:41 --> Database Driver Class Initialized
INFO - 2016-10-10 11:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:37:41 --> Parser Class Initialized
INFO - 2016-10-10 11:37:41 --> Controller Class Initialized
DEBUG - 2016-10-10 11:37:41 --> Home MX_Controller Initialized
INFO - 2016-10-10 11:37:41 --> Model Class Initialized
DEBUG - 2016-10-10 11:37:41 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 11:37:41 --> Model Class Initialized
ERROR - 2016-10-10 11:37:41 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:37:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:37:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:37:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 11:37:41 --> Final output sent to browser
DEBUG - 2016-10-10 11:37:41 --> Total execution time: 0.0447
INFO - 2016-10-10 11:37:44 --> Config Class Initialized
INFO - 2016-10-10 11:37:44 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:37:44 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:37:44 --> Utf8 Class Initialized
INFO - 2016-10-10 11:37:44 --> URI Class Initialized
INFO - 2016-10-10 11:37:44 --> Router Class Initialized
INFO - 2016-10-10 11:37:44 --> Output Class Initialized
INFO - 2016-10-10 11:37:44 --> Security Class Initialized
DEBUG - 2016-10-10 11:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:37:44 --> Input Class Initialized
INFO - 2016-10-10 11:37:44 --> Language Class Initialized
INFO - 2016-10-10 11:37:44 --> Language Class Initialized
INFO - 2016-10-10 11:37:44 --> Config Class Initialized
INFO - 2016-10-10 11:37:44 --> Loader Class Initialized
INFO - 2016-10-10 11:37:44 --> Helper loaded: common_helper
INFO - 2016-10-10 11:37:44 --> Helper loaded: url_helper
INFO - 2016-10-10 11:37:44 --> Database Driver Class Initialized
INFO - 2016-10-10 11:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:37:44 --> Parser Class Initialized
INFO - 2016-10-10 11:37:44 --> Controller Class Initialized
DEBUG - 2016-10-10 11:37:44 --> Popup MX_Controller Initialized
INFO - 2016-10-10 11:37:44 --> Model Class Initialized
DEBUG - 2016-10-10 11:37:44 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-10 11:37:44 --> Model Class Initialized
DEBUG - 2016-10-10 11:37:44 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-10 11:37:44 --> Final output sent to browser
DEBUG - 2016-10-10 11:37:44 --> Total execution time: 0.0484
INFO - 2016-10-10 11:49:08 --> Config Class Initialized
INFO - 2016-10-10 11:49:08 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:49:08 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:49:08 --> Utf8 Class Initialized
INFO - 2016-10-10 11:49:08 --> URI Class Initialized
DEBUG - 2016-10-10 11:49:08 --> No URI present. Default controller set.
INFO - 2016-10-10 11:49:08 --> Router Class Initialized
INFO - 2016-10-10 11:49:08 --> Output Class Initialized
INFO - 2016-10-10 11:49:08 --> Security Class Initialized
DEBUG - 2016-10-10 11:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:49:08 --> Input Class Initialized
INFO - 2016-10-10 11:49:08 --> Language Class Initialized
INFO - 2016-10-10 11:49:08 --> Language Class Initialized
INFO - 2016-10-10 11:49:08 --> Config Class Initialized
INFO - 2016-10-10 11:49:08 --> Loader Class Initialized
INFO - 2016-10-10 11:49:08 --> Helper loaded: common_helper
INFO - 2016-10-10 11:49:08 --> Helper loaded: url_helper
INFO - 2016-10-10 11:49:08 --> Database Driver Class Initialized
INFO - 2016-10-10 11:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:49:08 --> Parser Class Initialized
INFO - 2016-10-10 11:49:08 --> Controller Class Initialized
DEBUG - 2016-10-10 11:49:08 --> Home MX_Controller Initialized
INFO - 2016-10-10 11:49:08 --> Model Class Initialized
DEBUG - 2016-10-10 11:49:08 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 11:49:08 --> Model Class Initialized
ERROR - 2016-10-10 11:49:08 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:49:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:49:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:49:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 11:49:08 --> Final output sent to browser
DEBUG - 2016-10-10 11:49:08 --> Total execution time: 0.0432
INFO - 2016-10-10 11:49:11 --> Config Class Initialized
INFO - 2016-10-10 11:49:11 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:49:11 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:49:11 --> Utf8 Class Initialized
INFO - 2016-10-10 11:49:11 --> URI Class Initialized
INFO - 2016-10-10 11:49:11 --> Router Class Initialized
INFO - 2016-10-10 11:49:11 --> Output Class Initialized
INFO - 2016-10-10 11:49:11 --> Security Class Initialized
DEBUG - 2016-10-10 11:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:49:11 --> Input Class Initialized
INFO - 2016-10-10 11:49:11 --> Language Class Initialized
INFO - 2016-10-10 11:49:11 --> Language Class Initialized
INFO - 2016-10-10 11:49:11 --> Config Class Initialized
INFO - 2016-10-10 11:49:11 --> Loader Class Initialized
INFO - 2016-10-10 11:49:11 --> Helper loaded: common_helper
INFO - 2016-10-10 11:49:11 --> Helper loaded: url_helper
INFO - 2016-10-10 11:49:11 --> Database Driver Class Initialized
INFO - 2016-10-10 11:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:49:11 --> Parser Class Initialized
INFO - 2016-10-10 11:49:11 --> Controller Class Initialized
DEBUG - 2016-10-10 11:49:11 --> Popup MX_Controller Initialized
INFO - 2016-10-10 11:49:11 --> Model Class Initialized
DEBUG - 2016-10-10 11:49:11 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-10 11:49:11 --> Model Class Initialized
DEBUG - 2016-10-10 11:49:11 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-10 11:49:11 --> Final output sent to browser
DEBUG - 2016-10-10 11:49:11 --> Total execution time: 0.0427
INFO - 2016-10-10 11:50:22 --> Config Class Initialized
INFO - 2016-10-10 11:50:22 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:50:22 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:50:22 --> Utf8 Class Initialized
INFO - 2016-10-10 11:50:22 --> URI Class Initialized
INFO - 2016-10-10 11:50:22 --> Router Class Initialized
INFO - 2016-10-10 11:50:22 --> Output Class Initialized
INFO - 2016-10-10 11:50:22 --> Security Class Initialized
DEBUG - 2016-10-10 11:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:50:22 --> Input Class Initialized
INFO - 2016-10-10 11:50:22 --> Language Class Initialized
INFO - 2016-10-10 11:50:22 --> Language Class Initialized
INFO - 2016-10-10 11:50:22 --> Config Class Initialized
INFO - 2016-10-10 11:50:22 --> Loader Class Initialized
INFO - 2016-10-10 11:50:22 --> Helper loaded: common_helper
INFO - 2016-10-10 11:50:22 --> Helper loaded: url_helper
INFO - 2016-10-10 11:50:22 --> Database Driver Class Initialized
INFO - 2016-10-10 11:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:50:22 --> Parser Class Initialized
INFO - 2016-10-10 11:50:22 --> Controller Class Initialized
DEBUG - 2016-10-10 11:50:22 --> Popup MX_Controller Initialized
INFO - 2016-10-10 11:50:22 --> Model Class Initialized
DEBUG - 2016-10-10 11:50:22 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-10 11:50:22 --> Model Class Initialized
DEBUG - 2016-10-10 11:50:22 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-10 11:50:22 --> Final output sent to browser
DEBUG - 2016-10-10 11:50:22 --> Total execution time: 0.0477
INFO - 2016-10-10 11:51:29 --> Config Class Initialized
INFO - 2016-10-10 11:51:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:51:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:51:29 --> Utf8 Class Initialized
INFO - 2016-10-10 11:51:29 --> URI Class Initialized
INFO - 2016-10-10 11:51:29 --> Router Class Initialized
INFO - 2016-10-10 11:51:29 --> Output Class Initialized
INFO - 2016-10-10 11:51:29 --> Security Class Initialized
DEBUG - 2016-10-10 11:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:51:29 --> Input Class Initialized
INFO - 2016-10-10 11:51:29 --> Language Class Initialized
ERROR - 2016-10-10 11:51:29 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:51:29 --> Config Class Initialized
INFO - 2016-10-10 11:51:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:51:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:51:29 --> Utf8 Class Initialized
INFO - 2016-10-10 11:51:29 --> URI Class Initialized
INFO - 2016-10-10 11:51:29 --> Router Class Initialized
INFO - 2016-10-10 11:51:29 --> Output Class Initialized
INFO - 2016-10-10 11:51:29 --> Security Class Initialized
DEBUG - 2016-10-10 11:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:51:29 --> Input Class Initialized
INFO - 2016-10-10 11:51:29 --> Language Class Initialized
ERROR - 2016-10-10 11:51:29 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:51:30 --> Config Class Initialized
INFO - 2016-10-10 11:51:30 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:51:30 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:51:30 --> Utf8 Class Initialized
INFO - 2016-10-10 11:51:30 --> URI Class Initialized
INFO - 2016-10-10 11:51:30 --> Router Class Initialized
INFO - 2016-10-10 11:51:30 --> Output Class Initialized
INFO - 2016-10-10 11:51:30 --> Security Class Initialized
DEBUG - 2016-10-10 11:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:51:30 --> Input Class Initialized
INFO - 2016-10-10 11:51:30 --> Language Class Initialized
ERROR - 2016-10-10 11:51:30 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:52:57 --> Config Class Initialized
INFO - 2016-10-10 11:52:57 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:52:57 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:52:57 --> Utf8 Class Initialized
INFO - 2016-10-10 11:52:57 --> URI Class Initialized
INFO - 2016-10-10 11:52:57 --> Router Class Initialized
INFO - 2016-10-10 11:52:57 --> Output Class Initialized
INFO - 2016-10-10 11:52:57 --> Security Class Initialized
DEBUG - 2016-10-10 11:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:52:57 --> Input Class Initialized
INFO - 2016-10-10 11:52:57 --> Language Class Initialized
INFO - 2016-10-10 11:52:57 --> Language Class Initialized
INFO - 2016-10-10 11:52:57 --> Config Class Initialized
INFO - 2016-10-10 11:52:57 --> Loader Class Initialized
INFO - 2016-10-10 11:52:57 --> Helper loaded: common_helper
INFO - 2016-10-10 11:52:57 --> Helper loaded: url_helper
INFO - 2016-10-10 11:52:57 --> Database Driver Class Initialized
INFO - 2016-10-10 11:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:52:57 --> Parser Class Initialized
INFO - 2016-10-10 11:52:57 --> Controller Class Initialized
DEBUG - 2016-10-10 11:52:57 --> Home MX_Controller Initialized
INFO - 2016-10-10 11:52:57 --> Model Class Initialized
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 11:52:57 --> Model Class Initialized
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-10 11:52:57 --> Content MX_Controller Initialized
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:52:57 --> Model Class Initialized
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 11:52:57 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 11:52:57 --> Model Class Initialized
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 11:52:57 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:52:57 --> Model Class Initialized
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 11:52:57 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:52:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 11:52:57 --> Final output sent to browser
DEBUG - 2016-10-10 11:52:57 --> Total execution time: 0.0582
INFO - 2016-10-10 11:52:57 --> Config Class Initialized
INFO - 2016-10-10 11:52:57 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:52:57 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:52:57 --> Utf8 Class Initialized
INFO - 2016-10-10 11:52:57 --> URI Class Initialized
INFO - 2016-10-10 11:52:57 --> Router Class Initialized
INFO - 2016-10-10 11:52:57 --> Output Class Initialized
INFO - 2016-10-10 11:52:57 --> Security Class Initialized
DEBUG - 2016-10-10 11:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:52:57 --> Input Class Initialized
INFO - 2016-10-10 11:52:57 --> Language Class Initialized
ERROR - 2016-10-10 11:52:57 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:55:21 --> Config Class Initialized
INFO - 2016-10-10 11:55:21 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:21 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:21 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:21 --> URI Class Initialized
INFO - 2016-10-10 11:55:21 --> Router Class Initialized
INFO - 2016-10-10 11:55:21 --> Output Class Initialized
INFO - 2016-10-10 11:55:21 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:21 --> Input Class Initialized
INFO - 2016-10-10 11:55:21 --> Language Class Initialized
INFO - 2016-10-10 11:55:21 --> Language Class Initialized
INFO - 2016-10-10 11:55:21 --> Config Class Initialized
INFO - 2016-10-10 11:55:21 --> Loader Class Initialized
INFO - 2016-10-10 11:55:21 --> Helper loaded: common_helper
INFO - 2016-10-10 11:55:21 --> Helper loaded: url_helper
INFO - 2016-10-10 11:55:21 --> Database Driver Class Initialized
INFO - 2016-10-10 11:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:55:21 --> Parser Class Initialized
INFO - 2016-10-10 11:55:21 --> Controller Class Initialized
DEBUG - 2016-10-10 11:55:21 --> User MX_Controller Initialized
INFO - 2016-10-10 11:55:21 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:21 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-10 11:55:21 --> Model Class Initialized
INFO - 2016-10-10 11:55:21 --> Helper loaded: cookie_helper
INFO - 2016-10-10 11:55:21 --> Helper loaded: form_helper
DEBUG - 2016-10-10 11:55:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 11:55:21 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:55:21 --> Model Class Initialized
INFO - 2016-10-10 11:55:21 --> Final output sent to browser
DEBUG - 2016-10-10 11:55:21 --> Total execution time: 0.0654
INFO - 2016-10-10 11:55:23 --> Config Class Initialized
INFO - 2016-10-10 11:55:23 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:23 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:23 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:23 --> URI Class Initialized
DEBUG - 2016-10-10 11:55:23 --> No URI present. Default controller set.
INFO - 2016-10-10 11:55:23 --> Router Class Initialized
INFO - 2016-10-10 11:55:23 --> Output Class Initialized
INFO - 2016-10-10 11:55:23 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:23 --> Input Class Initialized
INFO - 2016-10-10 11:55:23 --> Language Class Initialized
INFO - 2016-10-10 11:55:23 --> Language Class Initialized
INFO - 2016-10-10 11:55:23 --> Config Class Initialized
INFO - 2016-10-10 11:55:23 --> Loader Class Initialized
INFO - 2016-10-10 11:55:23 --> Helper loaded: common_helper
INFO - 2016-10-10 11:55:23 --> Helper loaded: url_helper
INFO - 2016-10-10 11:55:23 --> Database Driver Class Initialized
INFO - 2016-10-10 11:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:55:23 --> Parser Class Initialized
INFO - 2016-10-10 11:55:23 --> Controller Class Initialized
DEBUG - 2016-10-10 11:55:23 --> Home MX_Controller Initialized
INFO - 2016-10-10 11:55:23 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:23 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 11:55:23 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-10 11:55:23 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:55:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:55:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:55:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 11:55:23 --> Final output sent to browser
DEBUG - 2016-10-10 11:55:23 --> Total execution time: 0.0608
INFO - 2016-10-10 11:55:26 --> Config Class Initialized
INFO - 2016-10-10 11:55:26 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:26 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:26 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:26 --> URI Class Initialized
INFO - 2016-10-10 11:55:26 --> Router Class Initialized
INFO - 2016-10-10 11:55:26 --> Output Class Initialized
INFO - 2016-10-10 11:55:26 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:26 --> Input Class Initialized
INFO - 2016-10-10 11:55:26 --> Language Class Initialized
INFO - 2016-10-10 11:55:26 --> Language Class Initialized
INFO - 2016-10-10 11:55:26 --> Config Class Initialized
INFO - 2016-10-10 11:55:26 --> Loader Class Initialized
INFO - 2016-10-10 11:55:26 --> Helper loaded: common_helper
INFO - 2016-10-10 11:55:26 --> Helper loaded: url_helper
INFO - 2016-10-10 11:55:26 --> Database Driver Class Initialized
INFO - 2016-10-10 11:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:55:26 --> Parser Class Initialized
INFO - 2016-10-10 11:55:26 --> Controller Class Initialized
DEBUG - 2016-10-10 11:55:26 --> Popup MX_Controller Initialized
INFO - 2016-10-10 11:55:26 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:26 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-10 11:55:26 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:26 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-10 11:55:26 --> Final output sent to browser
DEBUG - 2016-10-10 11:55:26 --> Total execution time: 0.0599
INFO - 2016-10-10 11:55:29 --> Config Class Initialized
INFO - 2016-10-10 11:55:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:29 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:29 --> URI Class Initialized
INFO - 2016-10-10 11:55:29 --> Router Class Initialized
INFO - 2016-10-10 11:55:29 --> Output Class Initialized
INFO - 2016-10-10 11:55:29 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:29 --> Input Class Initialized
INFO - 2016-10-10 11:55:29 --> Language Class Initialized
INFO - 2016-10-10 11:55:29 --> Language Class Initialized
INFO - 2016-10-10 11:55:29 --> Config Class Initialized
INFO - 2016-10-10 11:55:29 --> Loader Class Initialized
INFO - 2016-10-10 11:55:29 --> Helper loaded: common_helper
INFO - 2016-10-10 11:55:29 --> Helper loaded: url_helper
INFO - 2016-10-10 11:55:29 --> Database Driver Class Initialized
INFO - 2016-10-10 11:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:55:29 --> Parser Class Initialized
INFO - 2016-10-10 11:55:29 --> Controller Class Initialized
DEBUG - 2016-10-10 11:55:29 --> Home MX_Controller Initialized
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-10 11:55:29 --> Content MX_Controller Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 11:55:29 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 11:55:29 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-10 11:55:29 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 11:55:29 --> Final output sent to browser
DEBUG - 2016-10-10 11:55:29 --> Total execution time: 0.0508
INFO - 2016-10-10 11:55:29 --> Config Class Initialized
INFO - 2016-10-10 11:55:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:29 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:29 --> URI Class Initialized
INFO - 2016-10-10 11:55:29 --> Router Class Initialized
INFO - 2016-10-10 11:55:29 --> Output Class Initialized
INFO - 2016-10-10 11:55:29 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:29 --> Input Class Initialized
INFO - 2016-10-10 11:55:29 --> Language Class Initialized
INFO - 2016-10-10 11:55:29 --> Language Class Initialized
INFO - 2016-10-10 11:55:29 --> Config Class Initialized
INFO - 2016-10-10 11:55:29 --> Loader Class Initialized
INFO - 2016-10-10 11:55:29 --> Helper loaded: common_helper
INFO - 2016-10-10 11:55:29 --> Helper loaded: url_helper
INFO - 2016-10-10 11:55:29 --> Database Driver Class Initialized
INFO - 2016-10-10 11:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:55:29 --> Parser Class Initialized
INFO - 2016-10-10 11:55:29 --> Controller Class Initialized
DEBUG - 2016-10-10 11:55:29 --> Home MX_Controller Initialized
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-10 11:55:29 --> Content MX_Controller Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 11:55:29 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 11:55:29 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:55:29 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-10 11:55:29 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:55:29 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 11:55:29 --> Final output sent to browser
DEBUG - 2016-10-10 11:55:29 --> Total execution time: 0.0487
INFO - 2016-10-10 11:55:29 --> Config Class Initialized
INFO - 2016-10-10 11:55:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:29 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:29 --> URI Class Initialized
INFO - 2016-10-10 11:55:29 --> Router Class Initialized
INFO - 2016-10-10 11:55:29 --> Output Class Initialized
INFO - 2016-10-10 11:55:29 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:29 --> Input Class Initialized
INFO - 2016-10-10 11:55:29 --> Language Class Initialized
ERROR - 2016-10-10 11:55:29 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:55:32 --> Config Class Initialized
INFO - 2016-10-10 11:55:32 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:32 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:32 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:32 --> URI Class Initialized
INFO - 2016-10-10 11:55:32 --> Router Class Initialized
INFO - 2016-10-10 11:55:32 --> Output Class Initialized
INFO - 2016-10-10 11:55:32 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:32 --> Input Class Initialized
INFO - 2016-10-10 11:55:32 --> Language Class Initialized
INFO - 2016-10-10 11:55:32 --> Language Class Initialized
INFO - 2016-10-10 11:55:32 --> Config Class Initialized
INFO - 2016-10-10 11:55:32 --> Loader Class Initialized
INFO - 2016-10-10 11:55:32 --> Helper loaded: common_helper
INFO - 2016-10-10 11:55:32 --> Helper loaded: url_helper
INFO - 2016-10-10 11:55:32 --> Database Driver Class Initialized
INFO - 2016-10-10 11:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:55:32 --> Parser Class Initialized
INFO - 2016-10-10 11:55:32 --> Controller Class Initialized
DEBUG - 2016-10-10 11:55:32 --> User MX_Controller Initialized
INFO - 2016-10-10 11:55:32 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-10 11:55:32 --> Model Class Initialized
INFO - 2016-10-10 11:55:32 --> Helper loaded: cookie_helper
INFO - 2016-10-10 11:55:32 --> Helper loaded: form_helper
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 11:55:32 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:55:32 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/manageaccount.php
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 11:55:32 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 11:55:32 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 11:55:32 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:55:32 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-10 11:55:32 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:55:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 11:55:32 --> Final output sent to browser
DEBUG - 2016-10-10 11:55:32 --> Total execution time: 0.0841
INFO - 2016-10-10 11:55:33 --> Config Class Initialized
INFO - 2016-10-10 11:55:33 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:33 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:33 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:33 --> URI Class Initialized
INFO - 2016-10-10 11:55:33 --> Router Class Initialized
INFO - 2016-10-10 11:55:33 --> Output Class Initialized
INFO - 2016-10-10 11:55:33 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:33 --> Input Class Initialized
INFO - 2016-10-10 11:55:33 --> Language Class Initialized
ERROR - 2016-10-10 11:55:33 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:55:33 --> Config Class Initialized
INFO - 2016-10-10 11:55:33 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:33 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:33 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:33 --> URI Class Initialized
INFO - 2016-10-10 11:55:33 --> Router Class Initialized
INFO - 2016-10-10 11:55:33 --> Output Class Initialized
INFO - 2016-10-10 11:55:33 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:33 --> Input Class Initialized
INFO - 2016-10-10 11:55:33 --> Language Class Initialized
ERROR - 2016-10-10 11:55:33 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:55:40 --> Config Class Initialized
INFO - 2016-10-10 11:55:40 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:40 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:40 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:40 --> URI Class Initialized
INFO - 2016-10-10 11:55:40 --> Router Class Initialized
INFO - 2016-10-10 11:55:40 --> Output Class Initialized
INFO - 2016-10-10 11:55:40 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:40 --> Input Class Initialized
INFO - 2016-10-10 11:55:40 --> Language Class Initialized
INFO - 2016-10-10 11:55:40 --> Language Class Initialized
INFO - 2016-10-10 11:55:40 --> Config Class Initialized
INFO - 2016-10-10 11:55:40 --> Loader Class Initialized
INFO - 2016-10-10 11:55:40 --> Helper loaded: common_helper
INFO - 2016-10-10 11:55:40 --> Helper loaded: url_helper
INFO - 2016-10-10 11:55:40 --> Database Driver Class Initialized
INFO - 2016-10-10 11:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:55:40 --> Parser Class Initialized
INFO - 2016-10-10 11:55:40 --> Controller Class Initialized
DEBUG - 2016-10-10 11:55:40 --> User MX_Controller Initialized
INFO - 2016-10-10 11:55:40 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-10 11:55:40 --> Model Class Initialized
INFO - 2016-10-10 11:55:40 --> Helper loaded: cookie_helper
INFO - 2016-10-10 11:55:40 --> Helper loaded: form_helper
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 11:55:40 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:55:40 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/change_password.php
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 11:55:40 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 11:55:40 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 11:55:40 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:55:40 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-10 11:55:40 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:55:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 11:55:40 --> Final output sent to browser
DEBUG - 2016-10-10 11:55:40 --> Total execution time: 0.0609
INFO - 2016-10-10 11:55:41 --> Config Class Initialized
INFO - 2016-10-10 11:55:41 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:41 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:41 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:41 --> URI Class Initialized
INFO - 2016-10-10 11:55:41 --> Router Class Initialized
INFO - 2016-10-10 11:55:41 --> Output Class Initialized
INFO - 2016-10-10 11:55:41 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:41 --> Input Class Initialized
INFO - 2016-10-10 11:55:41 --> Language Class Initialized
ERROR - 2016-10-10 11:55:41 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:55:41 --> Config Class Initialized
INFO - 2016-10-10 11:55:41 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:41 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:41 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:41 --> URI Class Initialized
INFO - 2016-10-10 11:55:41 --> Router Class Initialized
INFO - 2016-10-10 11:55:41 --> Output Class Initialized
INFO - 2016-10-10 11:55:41 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:41 --> Input Class Initialized
INFO - 2016-10-10 11:55:41 --> Language Class Initialized
ERROR - 2016-10-10 11:55:41 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:55:49 --> Config Class Initialized
INFO - 2016-10-10 11:55:49 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:49 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:49 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:49 --> URI Class Initialized
INFO - 2016-10-10 11:55:49 --> Router Class Initialized
INFO - 2016-10-10 11:55:49 --> Output Class Initialized
INFO - 2016-10-10 11:55:49 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:49 --> Input Class Initialized
INFO - 2016-10-10 11:55:49 --> Language Class Initialized
INFO - 2016-10-10 11:55:49 --> Language Class Initialized
INFO - 2016-10-10 11:55:49 --> Config Class Initialized
INFO - 2016-10-10 11:55:49 --> Loader Class Initialized
INFO - 2016-10-10 11:55:49 --> Helper loaded: common_helper
INFO - 2016-10-10 11:55:49 --> Helper loaded: url_helper
INFO - 2016-10-10 11:55:49 --> Database Driver Class Initialized
INFO - 2016-10-10 11:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:55:49 --> Parser Class Initialized
INFO - 2016-10-10 11:55:49 --> Controller Class Initialized
DEBUG - 2016-10-10 11:55:49 --> User MX_Controller Initialized
INFO - 2016-10-10 11:55:49 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:49 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-10 11:55:49 --> Model Class Initialized
INFO - 2016-10-10 11:55:49 --> Helper loaded: cookie_helper
INFO - 2016-10-10 11:55:49 --> Helper loaded: form_helper
DEBUG - 2016-10-10 11:55:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 11:55:49 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:55:49 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:49 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/change_password.php
DEBUG - 2016-10-10 11:55:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 11:55:49 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 11:55:49 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 11:55:49 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:49 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 11:55:49 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 11:55:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:55:50 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-10 11:55:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-10 11:55:50 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:55:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:55:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:55:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 11:55:50 --> Final output sent to browser
DEBUG - 2016-10-10 11:55:50 --> Total execution time: 0.0732
INFO - 2016-10-10 11:55:50 --> Config Class Initialized
INFO - 2016-10-10 11:55:50 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:50 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:50 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:50 --> URI Class Initialized
INFO - 2016-10-10 11:55:50 --> Router Class Initialized
INFO - 2016-10-10 11:55:50 --> Output Class Initialized
INFO - 2016-10-10 11:55:50 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:50 --> Input Class Initialized
INFO - 2016-10-10 11:55:50 --> Language Class Initialized
ERROR - 2016-10-10 11:55:50 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:55:50 --> Config Class Initialized
INFO - 2016-10-10 11:55:50 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:50 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:50 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:50 --> URI Class Initialized
INFO - 2016-10-10 11:55:50 --> Router Class Initialized
INFO - 2016-10-10 11:55:50 --> Output Class Initialized
INFO - 2016-10-10 11:55:50 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:50 --> Input Class Initialized
INFO - 2016-10-10 11:55:50 --> Language Class Initialized
ERROR - 2016-10-10 11:55:50 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:55:55 --> Config Class Initialized
INFO - 2016-10-10 11:55:55 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:55 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:55 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:55 --> URI Class Initialized
INFO - 2016-10-10 11:55:55 --> Router Class Initialized
INFO - 2016-10-10 11:55:55 --> Output Class Initialized
INFO - 2016-10-10 11:55:55 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:55 --> Input Class Initialized
INFO - 2016-10-10 11:55:55 --> Language Class Initialized
INFO - 2016-10-10 11:55:55 --> Language Class Initialized
INFO - 2016-10-10 11:55:55 --> Config Class Initialized
INFO - 2016-10-10 11:55:55 --> Loader Class Initialized
INFO - 2016-10-10 11:55:55 --> Helper loaded: common_helper
INFO - 2016-10-10 11:55:55 --> Helper loaded: url_helper
INFO - 2016-10-10 11:55:55 --> Database Driver Class Initialized
INFO - 2016-10-10 11:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:55:55 --> Parser Class Initialized
INFO - 2016-10-10 11:55:55 --> Controller Class Initialized
DEBUG - 2016-10-10 11:55:55 --> Home MX_Controller Initialized
INFO - 2016-10-10 11:55:55 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 11:55:55 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-10 11:55:55 --> Content MX_Controller Initialized
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:55:55 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 11:55:55 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 11:55:55 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 11:55:55 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:55:55 --> Model Class Initialized
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-10 11:55:55 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 11:55:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 11:55:55 --> Final output sent to browser
DEBUG - 2016-10-10 11:55:55 --> Total execution time: 0.0604
INFO - 2016-10-10 11:55:55 --> Config Class Initialized
INFO - 2016-10-10 11:55:55 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:55:55 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:55:55 --> Utf8 Class Initialized
INFO - 2016-10-10 11:55:55 --> URI Class Initialized
INFO - 2016-10-10 11:55:55 --> Router Class Initialized
INFO - 2016-10-10 11:55:55 --> Output Class Initialized
INFO - 2016-10-10 11:55:55 --> Security Class Initialized
DEBUG - 2016-10-10 11:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:55:55 --> Input Class Initialized
INFO - 2016-10-10 11:55:55 --> Language Class Initialized
ERROR - 2016-10-10 11:55:55 --> 404 Page Not Found: /index
INFO - 2016-10-10 11:56:23 --> Config Class Initialized
INFO - 2016-10-10 11:56:23 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:56:23 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:56:23 --> Utf8 Class Initialized
INFO - 2016-10-10 11:56:23 --> URI Class Initialized
INFO - 2016-10-10 11:56:23 --> Router Class Initialized
INFO - 2016-10-10 11:56:23 --> Output Class Initialized
INFO - 2016-10-10 11:56:23 --> Security Class Initialized
DEBUG - 2016-10-10 11:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:56:23 --> Input Class Initialized
INFO - 2016-10-10 11:56:23 --> Language Class Initialized
INFO - 2016-10-10 11:56:23 --> Language Class Initialized
INFO - 2016-10-10 11:56:23 --> Config Class Initialized
INFO - 2016-10-10 11:56:23 --> Loader Class Initialized
INFO - 2016-10-10 11:56:23 --> Helper loaded: common_helper
INFO - 2016-10-10 11:56:23 --> Helper loaded: url_helper
INFO - 2016-10-10 11:56:23 --> Database Driver Class Initialized
INFO - 2016-10-10 11:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:56:23 --> Parser Class Initialized
INFO - 2016-10-10 11:56:23 --> Controller Class Initialized
DEBUG - 2016-10-10 11:56:23 --> Servers MX_Controller Initialized
INFO - 2016-10-10 11:56:23 --> Model Class Initialized
DEBUG - 2016-10-10 11:56:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:56:23 --> Model Class Initialized
DEBUG - 2016-10-10 11:56:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:56:23 --> Model Class Initialized
DEBUG - 2016-10-10 11:56:23 --> File already loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:56:23 --> Model Class Initialized
INFO - 2016-10-10 11:56:23 --> Config Class Initialized
INFO - 2016-10-10 11:56:23 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:56:23 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:56:23 --> Utf8 Class Initialized
INFO - 2016-10-10 11:56:23 --> URI Class Initialized
INFO - 2016-10-10 11:56:23 --> Router Class Initialized
INFO - 2016-10-10 11:56:23 --> Output Class Initialized
INFO - 2016-10-10 11:56:23 --> Security Class Initialized
DEBUG - 2016-10-10 11:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:56:23 --> Input Class Initialized
INFO - 2016-10-10 11:56:23 --> Language Class Initialized
INFO - 2016-10-10 11:56:23 --> Language Class Initialized
INFO - 2016-10-10 11:56:23 --> Config Class Initialized
INFO - 2016-10-10 11:56:23 --> Loader Class Initialized
INFO - 2016-10-10 11:56:23 --> Helper loaded: common_helper
INFO - 2016-10-10 11:56:23 --> Helper loaded: url_helper
INFO - 2016-10-10 11:56:23 --> Database Driver Class Initialized
INFO - 2016-10-10 11:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 11:56:23 --> Parser Class Initialized
INFO - 2016-10-10 11:56:23 --> Controller Class Initialized
DEBUG - 2016-10-10 11:56:23 --> Servers MX_Controller Initialized
INFO - 2016-10-10 11:56:23 --> Model Class Initialized
DEBUG - 2016-10-10 11:56:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 11:56:23 --> Model Class Initialized
DEBUG - 2016-10-10 11:56:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 11:56:23 --> Model Class Initialized
INFO - 2016-10-10 11:56:54 --> Config Class Initialized
INFO - 2016-10-10 11:56:54 --> Hooks Class Initialized
DEBUG - 2016-10-10 11:56:54 --> UTF-8 Support Enabled
INFO - 2016-10-10 11:56:54 --> Utf8 Class Initialized
INFO - 2016-10-10 11:56:54 --> URI Class Initialized
INFO - 2016-10-10 11:56:54 --> Router Class Initialized
INFO - 2016-10-10 11:56:54 --> Output Class Initialized
INFO - 2016-10-10 11:56:54 --> Security Class Initialized
DEBUG - 2016-10-10 11:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 11:56:54 --> Input Class Initialized
INFO - 2016-10-10 11:56:54 --> Language Class Initialized
INFO - 2016-10-10 11:56:54 --> Language Class Initialized
INFO - 2016-10-10 11:56:54 --> Config Class Initialized
INFO - 2016-10-10 11:56:54 --> Loader Class Initialized
INFO - 2016-10-10 11:56:54 --> Helper loaded: common_helper
INFO - 2016-10-10 11:56:54 --> Helper loaded: url_helper
INFO - 2016-10-10 11:56:54 --> Database Driver Class Initialized
INFO - 2016-10-10 12:39:27 --> Config Class Initialized
INFO - 2016-10-10 12:39:27 --> Hooks Class Initialized
DEBUG - 2016-10-10 12:39:27 --> UTF-8 Support Enabled
INFO - 2016-10-10 12:39:27 --> Utf8 Class Initialized
INFO - 2016-10-10 12:39:27 --> URI Class Initialized
DEBUG - 2016-10-10 12:39:27 --> No URI present. Default controller set.
INFO - 2016-10-10 12:39:27 --> Router Class Initialized
INFO - 2016-10-10 12:39:27 --> Output Class Initialized
INFO - 2016-10-10 12:39:27 --> Security Class Initialized
DEBUG - 2016-10-10 12:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 12:39:27 --> Input Class Initialized
INFO - 2016-10-10 12:39:27 --> Language Class Initialized
INFO - 2016-10-10 12:39:27 --> Language Class Initialized
INFO - 2016-10-10 12:39:27 --> Config Class Initialized
INFO - 2016-10-10 12:39:27 --> Loader Class Initialized
INFO - 2016-10-10 12:39:27 --> Helper loaded: common_helper
INFO - 2016-10-10 12:39:27 --> Helper loaded: url_helper
INFO - 2016-10-10 12:39:27 --> Database Driver Class Initialized
INFO - 2016-10-10 12:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 12:39:27 --> Parser Class Initialized
INFO - 2016-10-10 12:39:27 --> Controller Class Initialized
DEBUG - 2016-10-10 12:39:27 --> Home MX_Controller Initialized
INFO - 2016-10-10 12:39:27 --> Model Class Initialized
DEBUG - 2016-10-10 12:39:27 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 12:39:27 --> Model Class Initialized
ERROR - 2016-10-10 12:39:27 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 12:39:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 12:39:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 12:39:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 12:39:27 --> Final output sent to browser
DEBUG - 2016-10-10 12:39:27 --> Total execution time: 0.0449
INFO - 2016-10-10 14:47:42 --> Config Class Initialized
INFO - 2016-10-10 14:47:42 --> Hooks Class Initialized
DEBUG - 2016-10-10 14:47:42 --> UTF-8 Support Enabled
INFO - 2016-10-10 14:47:42 --> Utf8 Class Initialized
INFO - 2016-10-10 14:47:42 --> URI Class Initialized
DEBUG - 2016-10-10 14:47:42 --> No URI present. Default controller set.
INFO - 2016-10-10 14:47:42 --> Router Class Initialized
INFO - 2016-10-10 14:47:42 --> Output Class Initialized
INFO - 2016-10-10 14:47:42 --> Security Class Initialized
DEBUG - 2016-10-10 14:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 14:47:42 --> Input Class Initialized
INFO - 2016-10-10 14:47:42 --> Language Class Initialized
INFO - 2016-10-10 14:47:42 --> Language Class Initialized
INFO - 2016-10-10 14:47:42 --> Config Class Initialized
INFO - 2016-10-10 14:47:42 --> Loader Class Initialized
INFO - 2016-10-10 14:47:42 --> Helper loaded: common_helper
INFO - 2016-10-10 14:47:42 --> Helper loaded: url_helper
INFO - 2016-10-10 14:47:42 --> Database Driver Class Initialized
INFO - 2016-10-10 14:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 14:47:42 --> Parser Class Initialized
INFO - 2016-10-10 14:47:42 --> Controller Class Initialized
DEBUG - 2016-10-10 14:47:42 --> Home MX_Controller Initialized
INFO - 2016-10-10 14:47:42 --> Model Class Initialized
DEBUG - 2016-10-10 14:47:42 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 14:47:42 --> Model Class Initialized
ERROR - 2016-10-10 14:47:42 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 14:47:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 14:47:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 14:47:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 14:47:42 --> Final output sent to browser
DEBUG - 2016-10-10 14:47:42 --> Total execution time: 0.0439
INFO - 2016-10-10 16:44:39 --> Config Class Initialized
INFO - 2016-10-10 16:44:39 --> Hooks Class Initialized
DEBUG - 2016-10-10 16:44:39 --> UTF-8 Support Enabled
INFO - 2016-10-10 16:44:39 --> Utf8 Class Initialized
INFO - 2016-10-10 16:44:39 --> URI Class Initialized
DEBUG - 2016-10-10 16:44:39 --> No URI present. Default controller set.
INFO - 2016-10-10 16:44:39 --> Router Class Initialized
INFO - 2016-10-10 16:44:39 --> Output Class Initialized
INFO - 2016-10-10 16:44:39 --> Security Class Initialized
DEBUG - 2016-10-10 16:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 16:44:39 --> Input Class Initialized
INFO - 2016-10-10 16:44:39 --> Language Class Initialized
INFO - 2016-10-10 16:44:39 --> Language Class Initialized
INFO - 2016-10-10 16:44:39 --> Config Class Initialized
INFO - 2016-10-10 16:44:39 --> Loader Class Initialized
INFO - 2016-10-10 16:44:39 --> Helper loaded: common_helper
INFO - 2016-10-10 16:44:39 --> Helper loaded: url_helper
INFO - 2016-10-10 16:44:39 --> Database Driver Class Initialized
INFO - 2016-10-10 16:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 16:44:39 --> Parser Class Initialized
INFO - 2016-10-10 16:44:39 --> Controller Class Initialized
DEBUG - 2016-10-10 16:44:39 --> Home MX_Controller Initialized
INFO - 2016-10-10 16:44:39 --> Model Class Initialized
DEBUG - 2016-10-10 16:44:39 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 16:44:39 --> Model Class Initialized
ERROR - 2016-10-10 16:44:39 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 16:44:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 16:44:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 16:44:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 16:44:39 --> Final output sent to browser
DEBUG - 2016-10-10 16:44:39 --> Total execution time: 0.0602
INFO - 2016-10-10 17:43:19 --> Config Class Initialized
INFO - 2016-10-10 17:43:19 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:43:19 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:43:19 --> Utf8 Class Initialized
INFO - 2016-10-10 17:43:19 --> URI Class Initialized
INFO - 2016-10-10 17:43:19 --> Router Class Initialized
INFO - 2016-10-10 17:43:19 --> Output Class Initialized
INFO - 2016-10-10 17:43:19 --> Security Class Initialized
DEBUG - 2016-10-10 17:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:43:19 --> Input Class Initialized
INFO - 2016-10-10 17:43:19 --> Language Class Initialized
INFO - 2016-10-10 17:43:19 --> Language Class Initialized
INFO - 2016-10-10 17:43:19 --> Config Class Initialized
INFO - 2016-10-10 17:43:19 --> Loader Class Initialized
INFO - 2016-10-10 17:43:19 --> Helper loaded: common_helper
INFO - 2016-10-10 17:43:19 --> Helper loaded: url_helper
INFO - 2016-10-10 17:43:19 --> Database Driver Class Initialized
INFO - 2016-10-10 17:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 17:43:19 --> Parser Class Initialized
INFO - 2016-10-10 17:43:19 --> Controller Class Initialized
DEBUG - 2016-10-10 17:43:19 --> Donate_report MX_Controller Initialized
INFO - 2016-10-10 17:43:19 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 17:43:19 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 17:43:19 --> Model Class Initialized
INFO - 2016-10-10 17:43:19 --> Helper loaded: form_helper
INFO - 2016-10-10 17:43:19 --> Form Validation Class Initialized
INFO - 2016-10-10 17:43:19 --> Config Class Initialized
INFO - 2016-10-10 17:43:19 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:43:19 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:43:19 --> Utf8 Class Initialized
INFO - 2016-10-10 17:43:19 --> URI Class Initialized
INFO - 2016-10-10 17:43:19 --> Router Class Initialized
INFO - 2016-10-10 17:43:19 --> Output Class Initialized
INFO - 2016-10-10 17:43:19 --> Security Class Initialized
DEBUG - 2016-10-10 17:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:43:19 --> Input Class Initialized
INFO - 2016-10-10 17:43:19 --> Language Class Initialized
INFO - 2016-10-10 17:43:19 --> Language Class Initialized
INFO - 2016-10-10 17:43:19 --> Config Class Initialized
INFO - 2016-10-10 17:43:19 --> Loader Class Initialized
INFO - 2016-10-10 17:43:19 --> Helper loaded: common_helper
INFO - 2016-10-10 17:43:19 --> Helper loaded: url_helper
INFO - 2016-10-10 17:43:19 --> Database Driver Class Initialized
INFO - 2016-10-10 17:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 17:43:19 --> Parser Class Initialized
INFO - 2016-10-10 17:43:19 --> Controller Class Initialized
DEBUG - 2016-10-10 17:43:19 --> Home MX_Controller Initialized
INFO - 2016-10-10 17:43:19 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 17:43:19 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-10 17:43:19 --> Content MX_Controller Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 17:43:19 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 17:43:19 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 17:43:19 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 17:43:19 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 17:43:19 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 17:43:19 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 17:43:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 17:43:19 --> Final output sent to browser
DEBUG - 2016-10-10 17:43:19 --> Total execution time: 0.0565
INFO - 2016-10-10 17:43:19 --> Config Class Initialized
INFO - 2016-10-10 17:43:19 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:43:19 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:43:19 --> Utf8 Class Initialized
INFO - 2016-10-10 17:43:19 --> URI Class Initialized
INFO - 2016-10-10 17:43:19 --> Router Class Initialized
INFO - 2016-10-10 17:43:19 --> Output Class Initialized
INFO - 2016-10-10 17:43:19 --> Security Class Initialized
DEBUG - 2016-10-10 17:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:43:19 --> Input Class Initialized
INFO - 2016-10-10 17:43:19 --> Language Class Initialized
ERROR - 2016-10-10 17:43:19 --> 404 Page Not Found: /index
INFO - 2016-10-10 17:43:30 --> Config Class Initialized
INFO - 2016-10-10 17:43:30 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:43:30 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:43:30 --> Utf8 Class Initialized
INFO - 2016-10-10 17:43:30 --> URI Class Initialized
INFO - 2016-10-10 17:43:30 --> Router Class Initialized
INFO - 2016-10-10 17:43:30 --> Output Class Initialized
INFO - 2016-10-10 17:43:30 --> Security Class Initialized
DEBUG - 2016-10-10 17:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:43:30 --> Input Class Initialized
INFO - 2016-10-10 17:43:30 --> Language Class Initialized
INFO - 2016-10-10 17:43:30 --> Language Class Initialized
INFO - 2016-10-10 17:43:30 --> Config Class Initialized
INFO - 2016-10-10 17:43:30 --> Loader Class Initialized
INFO - 2016-10-10 17:43:30 --> Helper loaded: common_helper
INFO - 2016-10-10 17:43:30 --> Helper loaded: url_helper
INFO - 2016-10-10 17:43:30 --> Database Driver Class Initialized
INFO - 2016-10-10 17:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 17:43:30 --> Parser Class Initialized
INFO - 2016-10-10 17:43:30 --> Controller Class Initialized
DEBUG - 2016-10-10 17:43:30 --> User MX_Controller Initialized
INFO - 2016-10-10 17:43:30 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:30 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-10 17:43:30 --> Model Class Initialized
INFO - 2016-10-10 17:43:30 --> Helper loaded: cookie_helper
INFO - 2016-10-10 17:43:30 --> Helper loaded: form_helper
DEBUG - 2016-10-10 17:43:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 17:43:30 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 17:43:30 --> Model Class Initialized
INFO - 2016-10-10 17:43:30 --> Final output sent to browser
DEBUG - 2016-10-10 17:43:30 --> Total execution time: 0.0474
INFO - 2016-10-10 17:43:32 --> Config Class Initialized
INFO - 2016-10-10 17:43:32 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:43:32 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:43:32 --> Utf8 Class Initialized
INFO - 2016-10-10 17:43:32 --> URI Class Initialized
DEBUG - 2016-10-10 17:43:32 --> No URI present. Default controller set.
INFO - 2016-10-10 17:43:32 --> Router Class Initialized
INFO - 2016-10-10 17:43:32 --> Output Class Initialized
INFO - 2016-10-10 17:43:32 --> Security Class Initialized
DEBUG - 2016-10-10 17:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:43:32 --> Input Class Initialized
INFO - 2016-10-10 17:43:32 --> Language Class Initialized
INFO - 2016-10-10 17:43:32 --> Language Class Initialized
INFO - 2016-10-10 17:43:32 --> Config Class Initialized
INFO - 2016-10-10 17:43:32 --> Loader Class Initialized
INFO - 2016-10-10 17:43:32 --> Helper loaded: common_helper
INFO - 2016-10-10 17:43:32 --> Helper loaded: url_helper
INFO - 2016-10-10 17:43:32 --> Database Driver Class Initialized
INFO - 2016-10-10 17:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 17:43:32 --> Parser Class Initialized
INFO - 2016-10-10 17:43:32 --> Controller Class Initialized
DEBUG - 2016-10-10 17:43:32 --> Home MX_Controller Initialized
INFO - 2016-10-10 17:43:32 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:32 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 17:43:32 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-10 17:43:32 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 17:43:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 17:43:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 17:43:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 17:43:32 --> Final output sent to browser
DEBUG - 2016-10-10 17:43:32 --> Total execution time: 0.0507
INFO - 2016-10-10 17:43:36 --> Config Class Initialized
INFO - 2016-10-10 17:43:36 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:43:36 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:43:36 --> Utf8 Class Initialized
INFO - 2016-10-10 17:43:36 --> URI Class Initialized
INFO - 2016-10-10 17:43:36 --> Router Class Initialized
INFO - 2016-10-10 17:43:36 --> Output Class Initialized
INFO - 2016-10-10 17:43:36 --> Security Class Initialized
DEBUG - 2016-10-10 17:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:43:36 --> Input Class Initialized
INFO - 2016-10-10 17:43:36 --> Language Class Initialized
INFO - 2016-10-10 17:43:36 --> Language Class Initialized
INFO - 2016-10-10 17:43:36 --> Config Class Initialized
INFO - 2016-10-10 17:43:36 --> Loader Class Initialized
INFO - 2016-10-10 17:43:36 --> Helper loaded: common_helper
INFO - 2016-10-10 17:43:36 --> Helper loaded: url_helper
INFO - 2016-10-10 17:43:36 --> Database Driver Class Initialized
INFO - 2016-10-10 17:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 17:43:36 --> Parser Class Initialized
INFO - 2016-10-10 17:43:36 --> Controller Class Initialized
DEBUG - 2016-10-10 17:43:36 --> Donate_report MX_Controller Initialized
INFO - 2016-10-10 17:43:36 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 17:43:36 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 17:43:36 --> Model Class Initialized
INFO - 2016-10-10 17:43:36 --> Helper loaded: form_helper
INFO - 2016-10-10 17:43:36 --> Form Validation Class Initialized
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/views/FRONTEND/pagedonate_new.php
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 17:43:36 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 17:43:36 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 17:43:36 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 17:43:36 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-10 17:43:36 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 17:43:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 17:43:36 --> Final output sent to browser
DEBUG - 2016-10-10 17:43:36 --> Total execution time: 0.0928
INFO - 2016-10-10 17:43:36 --> Config Class Initialized
INFO - 2016-10-10 17:43:36 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:43:36 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:43:36 --> Utf8 Class Initialized
INFO - 2016-10-10 17:43:36 --> URI Class Initialized
INFO - 2016-10-10 17:43:36 --> Router Class Initialized
INFO - 2016-10-10 17:43:36 --> Output Class Initialized
INFO - 2016-10-10 17:43:36 --> Security Class Initialized
DEBUG - 2016-10-10 17:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:43:36 --> Input Class Initialized
INFO - 2016-10-10 17:43:36 --> Language Class Initialized
ERROR - 2016-10-10 17:43:36 --> 404 Page Not Found: /index
INFO - 2016-10-10 17:43:36 --> Config Class Initialized
INFO - 2016-10-10 17:43:36 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:43:36 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:43:36 --> Utf8 Class Initialized
INFO - 2016-10-10 17:43:36 --> URI Class Initialized
INFO - 2016-10-10 17:43:36 --> Router Class Initialized
INFO - 2016-10-10 17:43:36 --> Output Class Initialized
INFO - 2016-10-10 17:43:36 --> Security Class Initialized
DEBUG - 2016-10-10 17:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:43:36 --> Input Class Initialized
INFO - 2016-10-10 17:43:36 --> Language Class Initialized
ERROR - 2016-10-10 17:43:36 --> 404 Page Not Found: /index
INFO - 2016-10-10 17:43:59 --> Config Class Initialized
INFO - 2016-10-10 17:43:59 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:43:59 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:43:59 --> Utf8 Class Initialized
INFO - 2016-10-10 17:43:59 --> URI Class Initialized
INFO - 2016-10-10 17:43:59 --> Router Class Initialized
INFO - 2016-10-10 17:43:59 --> Output Class Initialized
INFO - 2016-10-10 17:43:59 --> Security Class Initialized
DEBUG - 2016-10-10 17:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:43:59 --> Input Class Initialized
INFO - 2016-10-10 17:43:59 --> Language Class Initialized
INFO - 2016-10-10 17:43:59 --> Language Class Initialized
INFO - 2016-10-10 17:43:59 --> Config Class Initialized
INFO - 2016-10-10 17:43:59 --> Loader Class Initialized
INFO - 2016-10-10 17:43:59 --> Helper loaded: common_helper
INFO - 2016-10-10 17:43:59 --> Helper loaded: url_helper
INFO - 2016-10-10 17:43:59 --> Database Driver Class Initialized
INFO - 2016-10-10 17:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 17:43:59 --> Parser Class Initialized
INFO - 2016-10-10 17:43:59 --> Controller Class Initialized
DEBUG - 2016-10-10 17:43:59 --> Donate_report MX_Controller Initialized
INFO - 2016-10-10 17:43:59 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:59 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-10 17:43:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 17:43:59 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 17:43:59 --> Model Class Initialized
INFO - 2016-10-10 17:43:59 --> Helper loaded: form_helper
INFO - 2016-10-10 17:43:59 --> Form Validation Class Initialized
DEBUG - 2016-10-10 17:43:59 --> File loaded: /home/dolongpk/public_html/application/modules/donate_config/models/Donate_config_model.php
DEBUG - 2016-10-10 17:43:59 --> Config file loaded: /home/dolongpk/public_html/application/config/donate_config_setting.php
DEBUG - 2016-10-10 17:43:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 17:43:59 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:59 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-10 17:43:59 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:59 --> File loaded: /home/dolongpk/public_html/application/modules/mobile_card/models/Mobile_card_model.php
INFO - 2016-10-10 17:43:59 --> Model Class Initialized
DEBUG - 2016-10-10 17:43:59 --> Config file loaded: /home/dolongpk/public_html/application/config/mobile_card_config.php
INFO - 2016-10-10 17:43:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-10 17:44:03 --> Final output sent to browser
DEBUG - 2016-10-10 17:44:03 --> Total execution time: 4.5814
INFO - 2016-10-10 17:50:03 --> Config Class Initialized
INFO - 2016-10-10 17:50:03 --> Hooks Class Initialized
DEBUG - 2016-10-10 17:50:03 --> UTF-8 Support Enabled
INFO - 2016-10-10 17:50:03 --> Utf8 Class Initialized
INFO - 2016-10-10 17:50:03 --> URI Class Initialized
INFO - 2016-10-10 17:50:03 --> Router Class Initialized
INFO - 2016-10-10 17:50:03 --> Output Class Initialized
INFO - 2016-10-10 17:50:03 --> Security Class Initialized
DEBUG - 2016-10-10 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 17:50:03 --> Input Class Initialized
INFO - 2016-10-10 17:50:03 --> Language Class Initialized
INFO - 2016-10-10 17:50:03 --> Language Class Initialized
INFO - 2016-10-10 17:50:03 --> Config Class Initialized
INFO - 2016-10-10 17:50:03 --> Loader Class Initialized
INFO - 2016-10-10 17:50:03 --> Helper loaded: common_helper
INFO - 2016-10-10 17:50:03 --> Helper loaded: url_helper
INFO - 2016-10-10 17:50:03 --> Database Driver Class Initialized
INFO - 2016-10-10 17:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 17:50:03 --> Parser Class Initialized
INFO - 2016-10-10 17:50:03 --> Controller Class Initialized
DEBUG - 2016-10-10 17:50:03 --> Donate_report MX_Controller Initialized
INFO - 2016-10-10 17:50:03 --> Model Class Initialized
DEBUG - 2016-10-10 17:50:03 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-10 17:50:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 17:50:03 --> Model Class Initialized
DEBUG - 2016-10-10 17:50:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-10 17:50:03 --> Model Class Initialized
INFO - 2016-10-10 17:50:03 --> Helper loaded: form_helper
INFO - 2016-10-10 17:50:03 --> Form Validation Class Initialized
DEBUG - 2016-10-10 17:50:03 --> File loaded: /home/dolongpk/public_html/application/modules/donate_config/models/Donate_config_model.php
DEBUG - 2016-10-10 17:50:03 --> Config file loaded: /home/dolongpk/public_html/application/config/donate_config_setting.php
DEBUG - 2016-10-10 17:50:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 17:50:03 --> Model Class Initialized
DEBUG - 2016-10-10 17:50:03 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-10 17:50:03 --> Model Class Initialized
DEBUG - 2016-10-10 17:50:03 --> File loaded: /home/dolongpk/public_html/application/modules/mobile_card/models/Mobile_card_model.php
INFO - 2016-10-10 17:50:03 --> Model Class Initialized
DEBUG - 2016-10-10 17:50:03 --> Config file loaded: /home/dolongpk/public_html/application/config/mobile_card_config.php
INFO - 2016-10-10 17:50:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-10 17:50:03 --> Final output sent to browser
DEBUG - 2016-10-10 17:50:03 --> Total execution time: 0.6998
INFO - 2016-10-10 18:00:27 --> Config Class Initialized
INFO - 2016-10-10 18:00:27 --> Hooks Class Initialized
DEBUG - 2016-10-10 18:00:27 --> UTF-8 Support Enabled
INFO - 2016-10-10 18:00:27 --> Utf8 Class Initialized
INFO - 2016-10-10 18:00:27 --> URI Class Initialized
INFO - 2016-10-10 18:00:27 --> Router Class Initialized
INFO - 2016-10-10 18:00:27 --> Output Class Initialized
INFO - 2016-10-10 18:00:27 --> Security Class Initialized
DEBUG - 2016-10-10 18:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 18:00:27 --> Input Class Initialized
INFO - 2016-10-10 18:00:27 --> Language Class Initialized
ERROR - 2016-10-10 18:00:27 --> 404 Page Not Found: /index
INFO - 2016-10-10 18:00:28 --> Config Class Initialized
INFO - 2016-10-10 18:00:28 --> Hooks Class Initialized
DEBUG - 2016-10-10 18:00:28 --> UTF-8 Support Enabled
INFO - 2016-10-10 18:00:28 --> Utf8 Class Initialized
INFO - 2016-10-10 18:00:28 --> URI Class Initialized
INFO - 2016-10-10 18:00:28 --> Router Class Initialized
INFO - 2016-10-10 18:00:28 --> Output Class Initialized
INFO - 2016-10-10 18:00:28 --> Security Class Initialized
DEBUG - 2016-10-10 18:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 18:00:28 --> Input Class Initialized
INFO - 2016-10-10 18:00:28 --> Language Class Initialized
ERROR - 2016-10-10 18:00:28 --> 404 Page Not Found: /index
INFO - 2016-10-10 18:00:29 --> Config Class Initialized
INFO - 2016-10-10 18:00:29 --> Hooks Class Initialized
DEBUG - 2016-10-10 18:00:29 --> UTF-8 Support Enabled
INFO - 2016-10-10 18:00:29 --> Utf8 Class Initialized
INFO - 2016-10-10 18:00:29 --> URI Class Initialized
INFO - 2016-10-10 18:00:29 --> Router Class Initialized
INFO - 2016-10-10 18:00:29 --> Output Class Initialized
INFO - 2016-10-10 18:00:29 --> Security Class Initialized
DEBUG - 2016-10-10 18:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 18:00:29 --> Input Class Initialized
INFO - 2016-10-10 18:00:29 --> Language Class Initialized
ERROR - 2016-10-10 18:00:29 --> 404 Page Not Found: /index
INFO - 2016-10-10 20:04:50 --> Config Class Initialized
INFO - 2016-10-10 20:04:50 --> Hooks Class Initialized
DEBUG - 2016-10-10 20:04:50 --> UTF-8 Support Enabled
INFO - 2016-10-10 20:04:50 --> Utf8 Class Initialized
INFO - 2016-10-10 20:04:50 --> URI Class Initialized
INFO - 2016-10-10 20:04:50 --> Router Class Initialized
INFO - 2016-10-10 20:04:50 --> Output Class Initialized
INFO - 2016-10-10 20:04:50 --> Security Class Initialized
DEBUG - 2016-10-10 20:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 20:04:50 --> Input Class Initialized
INFO - 2016-10-10 20:04:50 --> Language Class Initialized
ERROR - 2016-10-10 20:04:50 --> 404 Page Not Found: /index
INFO - 2016-10-10 20:04:50 --> Config Class Initialized
INFO - 2016-10-10 20:04:50 --> Hooks Class Initialized
DEBUG - 2016-10-10 20:04:50 --> UTF-8 Support Enabled
INFO - 2016-10-10 20:04:50 --> Utf8 Class Initialized
INFO - 2016-10-10 20:04:50 --> URI Class Initialized
INFO - 2016-10-10 20:04:50 --> Router Class Initialized
INFO - 2016-10-10 20:04:50 --> Output Class Initialized
INFO - 2016-10-10 20:04:50 --> Security Class Initialized
DEBUG - 2016-10-10 20:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 20:04:50 --> Input Class Initialized
INFO - 2016-10-10 20:04:50 --> Language Class Initialized
INFO - 2016-10-10 20:04:50 --> Language Class Initialized
INFO - 2016-10-10 20:04:50 --> Config Class Initialized
INFO - 2016-10-10 20:04:50 --> Loader Class Initialized
INFO - 2016-10-10 20:04:50 --> Helper loaded: common_helper
INFO - 2016-10-10 20:04:50 --> Helper loaded: url_helper
INFO - 2016-10-10 20:04:50 --> Database Driver Class Initialized
INFO - 2016-10-10 20:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 20:04:50 --> Parser Class Initialized
INFO - 2016-10-10 20:04:50 --> Controller Class Initialized
DEBUG - 2016-10-10 20:04:50 --> Content MX_Controller Initialized
INFO - 2016-10-10 20:04:50 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 20:04:50 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 20:04:50 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 20:04:50 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 20:04:50 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 20:04:50 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 20:04:50 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 20:04:50 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 20:04:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 20:04:50 --> Final output sent to browser
DEBUG - 2016-10-10 20:04:50 --> Total execution time: 0.0709
INFO - 2016-10-10 20:04:51 --> Config Class Initialized
INFO - 2016-10-10 20:04:51 --> Hooks Class Initialized
DEBUG - 2016-10-10 20:04:51 --> UTF-8 Support Enabled
INFO - 2016-10-10 20:04:51 --> Utf8 Class Initialized
INFO - 2016-10-10 20:04:51 --> URI Class Initialized
INFO - 2016-10-10 20:04:51 --> Router Class Initialized
INFO - 2016-10-10 20:04:51 --> Output Class Initialized
INFO - 2016-10-10 20:04:51 --> Security Class Initialized
DEBUG - 2016-10-10 20:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 20:04:51 --> Input Class Initialized
INFO - 2016-10-10 20:04:51 --> Language Class Initialized
INFO - 2016-10-10 20:04:51 --> Language Class Initialized
INFO - 2016-10-10 20:04:51 --> Config Class Initialized
INFO - 2016-10-10 20:04:51 --> Loader Class Initialized
INFO - 2016-10-10 20:04:51 --> Helper loaded: common_helper
INFO - 2016-10-10 20:04:51 --> Helper loaded: url_helper
INFO - 2016-10-10 20:04:51 --> Database Driver Class Initialized
INFO - 2016-10-10 20:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 20:04:51 --> Parser Class Initialized
INFO - 2016-10-10 20:04:51 --> Controller Class Initialized
DEBUG - 2016-10-10 20:04:51 --> Content MX_Controller Initialized
INFO - 2016-10-10 20:04:51 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-10 20:04:51 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-10 20:04:51 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-10 20:04:51 --> Slider MX_Controller Initialized
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-10 20:04:51 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-10 20:04:51 --> Servers MX_Controller Initialized
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-10 20:04:51 --> Model Class Initialized
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-10 20:04:51 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 20:04:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-10 20:04:51 --> Final output sent to browser
DEBUG - 2016-10-10 20:04:51 --> Total execution time: 0.0704
INFO - 2016-10-10 20:51:30 --> Config Class Initialized
INFO - 2016-10-10 20:51:30 --> Hooks Class Initialized
DEBUG - 2016-10-10 20:51:30 --> UTF-8 Support Enabled
INFO - 2016-10-10 20:51:30 --> Utf8 Class Initialized
INFO - 2016-10-10 20:51:30 --> URI Class Initialized
DEBUG - 2016-10-10 20:51:30 --> No URI present. Default controller set.
INFO - 2016-10-10 20:51:30 --> Router Class Initialized
INFO - 2016-10-10 20:51:30 --> Output Class Initialized
INFO - 2016-10-10 20:51:30 --> Security Class Initialized
DEBUG - 2016-10-10 20:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 20:51:30 --> Input Class Initialized
INFO - 2016-10-10 20:51:30 --> Language Class Initialized
INFO - 2016-10-10 20:51:30 --> Language Class Initialized
INFO - 2016-10-10 20:51:30 --> Config Class Initialized
INFO - 2016-10-10 20:51:30 --> Loader Class Initialized
INFO - 2016-10-10 20:51:30 --> Helper loaded: common_helper
INFO - 2016-10-10 20:51:30 --> Helper loaded: url_helper
INFO - 2016-10-10 20:51:30 --> Database Driver Class Initialized
INFO - 2016-10-10 20:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 20:51:31 --> Parser Class Initialized
INFO - 2016-10-10 20:51:31 --> Controller Class Initialized
DEBUG - 2016-10-10 20:51:31 --> Home MX_Controller Initialized
INFO - 2016-10-10 20:51:31 --> Model Class Initialized
DEBUG - 2016-10-10 20:51:31 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 20:51:31 --> Model Class Initialized
ERROR - 2016-10-10 20:51:31 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 20:51:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 20:51:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 20:51:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 20:51:31 --> Final output sent to browser
DEBUG - 2016-10-10 20:51:31 --> Total execution time: 0.0432
INFO - 2016-10-10 22:24:33 --> Config Class Initialized
INFO - 2016-10-10 22:24:33 --> Hooks Class Initialized
DEBUG - 2016-10-10 22:24:33 --> UTF-8 Support Enabled
INFO - 2016-10-10 22:24:33 --> Utf8 Class Initialized
INFO - 2016-10-10 22:24:33 --> URI Class Initialized
DEBUG - 2016-10-10 22:24:33 --> No URI present. Default controller set.
INFO - 2016-10-10 22:24:33 --> Router Class Initialized
INFO - 2016-10-10 22:24:33 --> Output Class Initialized
INFO - 2016-10-10 22:24:33 --> Security Class Initialized
DEBUG - 2016-10-10 22:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-10 22:24:33 --> Input Class Initialized
INFO - 2016-10-10 22:24:33 --> Language Class Initialized
INFO - 2016-10-10 22:24:33 --> Language Class Initialized
INFO - 2016-10-10 22:24:33 --> Config Class Initialized
INFO - 2016-10-10 22:24:33 --> Loader Class Initialized
INFO - 2016-10-10 22:24:33 --> Helper loaded: common_helper
INFO - 2016-10-10 22:24:33 --> Helper loaded: url_helper
INFO - 2016-10-10 22:24:33 --> Database Driver Class Initialized
INFO - 2016-10-10 22:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-10 22:24:33 --> Parser Class Initialized
INFO - 2016-10-10 22:24:33 --> Controller Class Initialized
DEBUG - 2016-10-10 22:24:33 --> Home MX_Controller Initialized
INFO - 2016-10-10 22:24:33 --> Model Class Initialized
DEBUG - 2016-10-10 22:24:33 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-10 22:24:33 --> Model Class Initialized
ERROR - 2016-10-10 22:24:33 --> Module controller failed to run: banner/index
DEBUG - 2016-10-10 22:24:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-10 22:24:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-10 22:24:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-10 22:24:33 --> Final output sent to browser
DEBUG - 2016-10-10 22:24:33 --> Total execution time: 0.0420
