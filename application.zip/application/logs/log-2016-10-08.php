<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-08 10:53:13 --> Config Class Initialized
INFO - 2016-10-08 10:53:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 10:53:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 10:53:13 --> Utf8 Class Initialized
INFO - 2016-10-08 10:53:13 --> URI Class Initialized
INFO - 2016-10-08 10:53:13 --> Router Class Initialized
INFO - 2016-10-08 10:53:13 --> Output Class Initialized
INFO - 2016-10-08 10:53:13 --> Security Class Initialized
DEBUG - 2016-10-08 10:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 10:53:13 --> Input Class Initialized
INFO - 2016-10-08 10:53:13 --> Language Class Initialized
INFO - 2016-10-08 10:53:13 --> Language Class Initialized
INFO - 2016-10-08 10:53:13 --> Config Class Initialized
INFO - 2016-10-08 10:53:13 --> Loader Class Initialized
INFO - 2016-10-08 10:53:13 --> Helper loaded: common_helper
INFO - 2016-10-08 10:53:13 --> Helper loaded: url_helper
INFO - 2016-10-08 10:53:13 --> Database Driver Class Initialized
INFO - 2016-10-08 10:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 10:53:13 --> Parser Class Initialized
INFO - 2016-10-08 10:53:13 --> Controller Class Initialized
DEBUG - 2016-10-08 10:53:13 --> Content MX_Controller Initialized
INFO - 2016-10-08 10:53:13 --> Model Class Initialized
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 10:53:13 --> Model Class Initialized
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 10:53:13 --> Model Class Initialized
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 10:53:13 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 10:53:13 --> Model Class Initialized
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 10:53:13 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 10:53:13 --> Model Class Initialized
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 10:53:13 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 10:53:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 10:53:13 --> Final output sent to browser
DEBUG - 2016-10-08 10:53:13 --> Total execution time: 0.0674
INFO - 2016-10-08 10:54:34 --> Config Class Initialized
INFO - 2016-10-08 10:54:34 --> Hooks Class Initialized
DEBUG - 2016-10-08 10:54:34 --> UTF-8 Support Enabled
INFO - 2016-10-08 10:54:34 --> Utf8 Class Initialized
INFO - 2016-10-08 10:54:34 --> URI Class Initialized
INFO - 2016-10-08 10:54:34 --> Router Class Initialized
INFO - 2016-10-08 10:54:34 --> Output Class Initialized
INFO - 2016-10-08 10:54:34 --> Security Class Initialized
DEBUG - 2016-10-08 10:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 10:54:34 --> Input Class Initialized
INFO - 2016-10-08 10:54:34 --> Language Class Initialized
INFO - 2016-10-08 10:54:34 --> Language Class Initialized
INFO - 2016-10-08 10:54:34 --> Config Class Initialized
INFO - 2016-10-08 10:54:34 --> Loader Class Initialized
INFO - 2016-10-08 10:54:34 --> Helper loaded: common_helper
INFO - 2016-10-08 10:54:34 --> Helper loaded: url_helper
INFO - 2016-10-08 10:54:34 --> Database Driver Class Initialized
INFO - 2016-10-08 10:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 10:54:34 --> Parser Class Initialized
INFO - 2016-10-08 10:54:34 --> Controller Class Initialized
DEBUG - 2016-10-08 10:54:34 --> Content MX_Controller Initialized
INFO - 2016-10-08 10:54:34 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 10:54:34 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 10:54:34 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 10:54:34 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 10:54:34 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 10:54:34 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 10:54:34 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 10:54:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 10:54:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 10:54:34 --> Final output sent to browser
DEBUG - 2016-10-08 10:54:34 --> Total execution time: 0.0651
INFO - 2016-10-08 10:54:50 --> Config Class Initialized
INFO - 2016-10-08 10:54:50 --> Hooks Class Initialized
DEBUG - 2016-10-08 10:54:50 --> UTF-8 Support Enabled
INFO - 2016-10-08 10:54:50 --> Utf8 Class Initialized
INFO - 2016-10-08 10:54:50 --> URI Class Initialized
INFO - 2016-10-08 10:54:50 --> Router Class Initialized
INFO - 2016-10-08 10:54:50 --> Output Class Initialized
INFO - 2016-10-08 10:54:50 --> Security Class Initialized
DEBUG - 2016-10-08 10:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 10:54:50 --> Input Class Initialized
INFO - 2016-10-08 10:54:50 --> Language Class Initialized
INFO - 2016-10-08 10:54:50 --> Language Class Initialized
INFO - 2016-10-08 10:54:50 --> Config Class Initialized
INFO - 2016-10-08 10:54:50 --> Loader Class Initialized
INFO - 2016-10-08 10:54:50 --> Helper loaded: common_helper
INFO - 2016-10-08 10:54:50 --> Helper loaded: url_helper
INFO - 2016-10-08 10:54:50 --> Database Driver Class Initialized
INFO - 2016-10-08 10:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 10:54:50 --> Parser Class Initialized
INFO - 2016-10-08 10:54:50 --> Controller Class Initialized
DEBUG - 2016-10-08 10:54:50 --> User MX_Controller Initialized
INFO - 2016-10-08 10:54:50 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-08 10:54:50 --> Model Class Initialized
INFO - 2016-10-08 10:54:50 --> Helper loaded: cookie_helper
INFO - 2016-10-08 10:54:50 --> Helper loaded: form_helper
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 10:54:50 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 10:54:50 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/forgot_password.php
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 10:54:50 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 10:54:50 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 10:54:50 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 10:54:50 --> Model Class Initialized
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 10:54:50 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 10:54:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 10:54:50 --> Final output sent to browser
DEBUG - 2016-10-08 10:54:50 --> Total execution time: 0.0674
INFO - 2016-10-08 10:54:50 --> Config Class Initialized
INFO - 2016-10-08 10:54:50 --> Hooks Class Initialized
DEBUG - 2016-10-08 10:54:50 --> UTF-8 Support Enabled
INFO - 2016-10-08 10:54:50 --> Utf8 Class Initialized
INFO - 2016-10-08 10:54:50 --> URI Class Initialized
INFO - 2016-10-08 10:54:50 --> Router Class Initialized
INFO - 2016-10-08 10:54:50 --> Output Class Initialized
INFO - 2016-10-08 10:54:50 --> Security Class Initialized
DEBUG - 2016-10-08 10:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 10:54:50 --> Input Class Initialized
INFO - 2016-10-08 10:54:50 --> Language Class Initialized
ERROR - 2016-10-08 10:54:50 --> 404 Page Not Found: /index
INFO - 2016-10-08 10:54:50 --> Config Class Initialized
INFO - 2016-10-08 10:54:50 --> Hooks Class Initialized
DEBUG - 2016-10-08 10:54:50 --> UTF-8 Support Enabled
INFO - 2016-10-08 10:54:50 --> Utf8 Class Initialized
INFO - 2016-10-08 10:54:50 --> URI Class Initialized
INFO - 2016-10-08 10:54:50 --> Router Class Initialized
INFO - 2016-10-08 10:54:50 --> Output Class Initialized
INFO - 2016-10-08 10:54:50 --> Security Class Initialized
DEBUG - 2016-10-08 10:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 10:54:50 --> Input Class Initialized
INFO - 2016-10-08 10:54:50 --> Language Class Initialized
ERROR - 2016-10-08 10:54:50 --> 404 Page Not Found: /index
INFO - 2016-10-08 11:09:33 --> Config Class Initialized
INFO - 2016-10-08 11:09:33 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:09:33 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:09:33 --> Utf8 Class Initialized
INFO - 2016-10-08 11:09:33 --> URI Class Initialized
INFO - 2016-10-08 11:09:33 --> Router Class Initialized
INFO - 2016-10-08 11:09:33 --> Output Class Initialized
INFO - 2016-10-08 11:09:33 --> Security Class Initialized
DEBUG - 2016-10-08 11:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:09:33 --> Input Class Initialized
INFO - 2016-10-08 11:09:33 --> Language Class Initialized
INFO - 2016-10-08 11:09:33 --> Language Class Initialized
INFO - 2016-10-08 11:09:33 --> Config Class Initialized
INFO - 2016-10-08 11:09:33 --> Loader Class Initialized
INFO - 2016-10-08 11:09:33 --> Helper loaded: common_helper
INFO - 2016-10-08 11:09:33 --> Helper loaded: url_helper
INFO - 2016-10-08 11:09:33 --> Database Driver Class Initialized
INFO - 2016-10-08 11:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:09:33 --> Parser Class Initialized
INFO - 2016-10-08 11:09:33 --> Controller Class Initialized
DEBUG - 2016-10-08 11:09:33 --> Content MX_Controller Initialized
INFO - 2016-10-08 11:09:33 --> Model Class Initialized
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 11:09:33 --> Model Class Initialized
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:09:33 --> Model Class Initialized
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 11:09:33 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 11:09:33 --> Model Class Initialized
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 11:09:33 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 11:09:33 --> Model Class Initialized
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 11:09:33 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 11:09:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 11:09:33 --> Final output sent to browser
DEBUG - 2016-10-08 11:09:33 --> Total execution time: 0.0670
INFO - 2016-10-08 11:10:04 --> Config Class Initialized
INFO - 2016-10-08 11:10:04 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:10:04 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:10:04 --> Utf8 Class Initialized
INFO - 2016-10-08 11:10:04 --> URI Class Initialized
INFO - 2016-10-08 11:10:04 --> Router Class Initialized
INFO - 2016-10-08 11:10:04 --> Output Class Initialized
INFO - 2016-10-08 11:10:04 --> Security Class Initialized
DEBUG - 2016-10-08 11:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:10:04 --> Input Class Initialized
INFO - 2016-10-08 11:10:04 --> Language Class Initialized
ERROR - 2016-10-08 11:10:04 --> 404 Page Not Found: /index
INFO - 2016-10-08 11:10:05 --> Config Class Initialized
INFO - 2016-10-08 11:10:05 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:10:05 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:10:05 --> Utf8 Class Initialized
INFO - 2016-10-08 11:10:05 --> URI Class Initialized
INFO - 2016-10-08 11:10:05 --> Router Class Initialized
INFO - 2016-10-08 11:10:05 --> Output Class Initialized
INFO - 2016-10-08 11:10:05 --> Security Class Initialized
DEBUG - 2016-10-08 11:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:10:05 --> Input Class Initialized
INFO - 2016-10-08 11:10:05 --> Language Class Initialized
INFO - 2016-10-08 11:10:05 --> Language Class Initialized
INFO - 2016-10-08 11:10:05 --> Config Class Initialized
INFO - 2016-10-08 11:10:05 --> Loader Class Initialized
INFO - 2016-10-08 11:10:05 --> Helper loaded: common_helper
INFO - 2016-10-08 11:10:05 --> Helper loaded: url_helper
INFO - 2016-10-08 11:10:05 --> Database Driver Class Initialized
INFO - 2016-10-08 11:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:10:05 --> Parser Class Initialized
INFO - 2016-10-08 11:10:05 --> Controller Class Initialized
DEBUG - 2016-10-08 11:10:05 --> Servers MX_Controller Initialized
INFO - 2016-10-08 11:10:05 --> Model Class Initialized
DEBUG - 2016-10-08 11:10:05 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 11:10:05 --> Model Class Initialized
DEBUG - 2016-10-08 11:10:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:10:05 --> Model Class Initialized
INFO - 2016-10-08 11:10:06 --> Config Class Initialized
INFO - 2016-10-08 11:10:06 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:10:06 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:10:06 --> Utf8 Class Initialized
INFO - 2016-10-08 11:10:06 --> URI Class Initialized
INFO - 2016-10-08 11:10:06 --> Router Class Initialized
INFO - 2016-10-08 11:10:06 --> Output Class Initialized
INFO - 2016-10-08 11:10:06 --> Security Class Initialized
DEBUG - 2016-10-08 11:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:10:06 --> Input Class Initialized
INFO - 2016-10-08 11:10:06 --> Language Class Initialized
INFO - 2016-10-08 11:10:06 --> Language Class Initialized
INFO - 2016-10-08 11:10:06 --> Config Class Initialized
INFO - 2016-10-08 11:10:06 --> Loader Class Initialized
INFO - 2016-10-08 11:10:06 --> Helper loaded: common_helper
INFO - 2016-10-08 11:10:06 --> Helper loaded: url_helper
INFO - 2016-10-08 11:10:06 --> Database Driver Class Initialized
INFO - 2016-10-08 11:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:10:06 --> Parser Class Initialized
INFO - 2016-10-08 11:10:06 --> Controller Class Initialized
DEBUG - 2016-10-08 11:10:06 --> Home MX_Controller Initialized
INFO - 2016-10-08 11:10:06 --> Model Class Initialized
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 11:10:06 --> Model Class Initialized
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 11:10:06 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:10:06 --> Model Class Initialized
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 11:10:06 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 11:10:06 --> Model Class Initialized
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 11:10:06 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 11:10:06 --> Model Class Initialized
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 11:10:06 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 11:10:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 11:10:06 --> Final output sent to browser
DEBUG - 2016-10-08 11:10:06 --> Total execution time: 0.0557
INFO - 2016-10-08 11:16:00 --> Config Class Initialized
INFO - 2016-10-08 11:16:00 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:16:00 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:16:00 --> Utf8 Class Initialized
INFO - 2016-10-08 11:16:00 --> URI Class Initialized
INFO - 2016-10-08 11:16:00 --> Router Class Initialized
INFO - 2016-10-08 11:16:00 --> Output Class Initialized
INFO - 2016-10-08 11:16:00 --> Security Class Initialized
DEBUG - 2016-10-08 11:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:16:00 --> Input Class Initialized
INFO - 2016-10-08 11:16:00 --> Language Class Initialized
INFO - 2016-10-08 11:16:00 --> Language Class Initialized
INFO - 2016-10-08 11:16:00 --> Config Class Initialized
INFO - 2016-10-08 11:16:00 --> Loader Class Initialized
INFO - 2016-10-08 11:16:00 --> Helper loaded: common_helper
INFO - 2016-10-08 11:16:00 --> Helper loaded: url_helper
INFO - 2016-10-08 11:16:00 --> Database Driver Class Initialized
INFO - 2016-10-08 11:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:16:00 --> Parser Class Initialized
INFO - 2016-10-08 11:16:00 --> Controller Class Initialized
DEBUG - 2016-10-08 11:16:00 --> Content MX_Controller Initialized
INFO - 2016-10-08 11:16:00 --> Model Class Initialized
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 11:16:00 --> Model Class Initialized
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:16:00 --> Model Class Initialized
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 11:16:00 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 11:16:00 --> Model Class Initialized
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 11:16:00 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 11:16:00 --> Model Class Initialized
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 11:16:00 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 11:16:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 11:16:00 --> Final output sent to browser
DEBUG - 2016-10-08 11:16:00 --> Total execution time: 0.0822
INFO - 2016-10-08 11:20:24 --> Config Class Initialized
INFO - 2016-10-08 11:20:24 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:20:24 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:20:24 --> Utf8 Class Initialized
INFO - 2016-10-08 11:20:24 --> URI Class Initialized
INFO - 2016-10-08 11:20:24 --> Router Class Initialized
INFO - 2016-10-08 11:20:24 --> Output Class Initialized
INFO - 2016-10-08 11:20:24 --> Security Class Initialized
DEBUG - 2016-10-08 11:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:20:24 --> Input Class Initialized
INFO - 2016-10-08 11:20:24 --> Language Class Initialized
INFO - 2016-10-08 11:20:24 --> Language Class Initialized
INFO - 2016-10-08 11:20:24 --> Config Class Initialized
INFO - 2016-10-08 11:20:24 --> Loader Class Initialized
INFO - 2016-10-08 11:20:24 --> Helper loaded: common_helper
INFO - 2016-10-08 11:20:24 --> Helper loaded: url_helper
INFO - 2016-10-08 11:20:24 --> Database Driver Class Initialized
INFO - 2016-10-08 11:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:20:24 --> Parser Class Initialized
INFO - 2016-10-08 11:20:24 --> Controller Class Initialized
DEBUG - 2016-10-08 11:20:24 --> Servers MX_Controller Initialized
INFO - 2016-10-08 11:20:24 --> Model Class Initialized
DEBUG - 2016-10-08 11:20:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 11:20:24 --> Model Class Initialized
DEBUG - 2016-10-08 11:20:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:20:24 --> Model Class Initialized
INFO - 2016-10-08 11:20:25 --> Config Class Initialized
INFO - 2016-10-08 11:20:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:20:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:20:25 --> Utf8 Class Initialized
INFO - 2016-10-08 11:20:25 --> URI Class Initialized
INFO - 2016-10-08 11:20:25 --> Router Class Initialized
INFO - 2016-10-08 11:20:25 --> Output Class Initialized
INFO - 2016-10-08 11:20:25 --> Security Class Initialized
DEBUG - 2016-10-08 11:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:20:25 --> Input Class Initialized
INFO - 2016-10-08 11:20:25 --> Language Class Initialized
INFO - 2016-10-08 11:20:25 --> Language Class Initialized
INFO - 2016-10-08 11:20:25 --> Config Class Initialized
INFO - 2016-10-08 11:20:25 --> Loader Class Initialized
INFO - 2016-10-08 11:20:25 --> Helper loaded: common_helper
INFO - 2016-10-08 11:20:25 --> Helper loaded: url_helper
INFO - 2016-10-08 11:20:25 --> Database Driver Class Initialized
INFO - 2016-10-08 11:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:20:25 --> Parser Class Initialized
INFO - 2016-10-08 11:20:25 --> Controller Class Initialized
DEBUG - 2016-10-08 11:20:25 --> Home MX_Controller Initialized
INFO - 2016-10-08 11:20:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 11:20:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 11:20:25 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:20:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 11:20:25 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 11:20:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 11:20:25 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 11:20:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 11:20:25 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 11:20:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 11:20:25 --> Final output sent to browser
DEBUG - 2016-10-08 11:20:25 --> Total execution time: 0.0784
INFO - 2016-10-08 11:26:28 --> Config Class Initialized
INFO - 2016-10-08 11:26:28 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:26:28 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:26:28 --> Utf8 Class Initialized
INFO - 2016-10-08 11:26:28 --> URI Class Initialized
DEBUG - 2016-10-08 11:26:28 --> No URI present. Default controller set.
INFO - 2016-10-08 11:26:28 --> Router Class Initialized
INFO - 2016-10-08 11:26:28 --> Output Class Initialized
INFO - 2016-10-08 11:26:28 --> Security Class Initialized
DEBUG - 2016-10-08 11:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:26:28 --> Input Class Initialized
INFO - 2016-10-08 11:26:28 --> Language Class Initialized
INFO - 2016-10-08 11:26:28 --> Language Class Initialized
INFO - 2016-10-08 11:26:28 --> Config Class Initialized
INFO - 2016-10-08 11:26:28 --> Loader Class Initialized
INFO - 2016-10-08 11:26:28 --> Helper loaded: common_helper
INFO - 2016-10-08 11:26:28 --> Helper loaded: url_helper
INFO - 2016-10-08 11:26:28 --> Database Driver Class Initialized
INFO - 2016-10-08 11:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:26:28 --> Parser Class Initialized
INFO - 2016-10-08 11:26:28 --> Controller Class Initialized
DEBUG - 2016-10-08 11:26:28 --> Home MX_Controller Initialized
INFO - 2016-10-08 11:26:28 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:28 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 11:26:28 --> Model Class Initialized
ERROR - 2016-10-08 11:26:28 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 11:26:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 11:26:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 11:26:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-08 11:26:28 --> Final output sent to browser
DEBUG - 2016-10-08 11:26:28 --> Total execution time: 0.0557
INFO - 2016-10-08 11:26:32 --> Config Class Initialized
INFO - 2016-10-08 11:26:32 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:26:32 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:26:32 --> Utf8 Class Initialized
INFO - 2016-10-08 11:26:32 --> URI Class Initialized
INFO - 2016-10-08 11:26:32 --> Router Class Initialized
INFO - 2016-10-08 11:26:32 --> Output Class Initialized
INFO - 2016-10-08 11:26:32 --> Security Class Initialized
DEBUG - 2016-10-08 11:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:26:32 --> Input Class Initialized
INFO - 2016-10-08 11:26:32 --> Language Class Initialized
INFO - 2016-10-08 11:26:32 --> Language Class Initialized
INFO - 2016-10-08 11:26:32 --> Config Class Initialized
INFO - 2016-10-08 11:26:32 --> Loader Class Initialized
INFO - 2016-10-08 11:26:32 --> Helper loaded: common_helper
INFO - 2016-10-08 11:26:32 --> Helper loaded: url_helper
INFO - 2016-10-08 11:26:32 --> Database Driver Class Initialized
INFO - 2016-10-08 11:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:26:32 --> Parser Class Initialized
INFO - 2016-10-08 11:26:32 --> Controller Class Initialized
DEBUG - 2016-10-08 11:26:32 --> Popup MX_Controller Initialized
INFO - 2016-10-08 11:26:32 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:32 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-08 11:26:32 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:32 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-08 11:26:32 --> Final output sent to browser
DEBUG - 2016-10-08 11:26:32 --> Total execution time: 0.0352
INFO - 2016-10-08 11:26:37 --> Config Class Initialized
INFO - 2016-10-08 11:26:37 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:26:37 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:26:37 --> Utf8 Class Initialized
INFO - 2016-10-08 11:26:37 --> URI Class Initialized
INFO - 2016-10-08 11:26:37 --> Router Class Initialized
INFO - 2016-10-08 11:26:37 --> Output Class Initialized
INFO - 2016-10-08 11:26:37 --> Security Class Initialized
DEBUG - 2016-10-08 11:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:26:37 --> Input Class Initialized
INFO - 2016-10-08 11:26:37 --> Language Class Initialized
INFO - 2016-10-08 11:26:37 --> Language Class Initialized
INFO - 2016-10-08 11:26:37 --> Config Class Initialized
INFO - 2016-10-08 11:26:37 --> Loader Class Initialized
INFO - 2016-10-08 11:26:37 --> Helper loaded: common_helper
INFO - 2016-10-08 11:26:37 --> Helper loaded: url_helper
INFO - 2016-10-08 11:26:37 --> Database Driver Class Initialized
INFO - 2016-10-08 11:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:26:37 --> Parser Class Initialized
INFO - 2016-10-08 11:26:37 --> Controller Class Initialized
DEBUG - 2016-10-08 11:26:37 --> Home MX_Controller Initialized
INFO - 2016-10-08 11:26:37 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 11:26:37 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 11:26:37 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:26:37 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 11:26:37 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 11:26:37 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 11:26:37 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 11:26:37 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 11:26:37 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 11:26:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 11:26:37 --> Final output sent to browser
DEBUG - 2016-10-08 11:26:37 --> Total execution time: 0.0581
INFO - 2016-10-08 11:26:37 --> Config Class Initialized
INFO - 2016-10-08 11:26:37 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:26:37 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:26:37 --> Utf8 Class Initialized
INFO - 2016-10-08 11:26:37 --> URI Class Initialized
INFO - 2016-10-08 11:26:37 --> Router Class Initialized
INFO - 2016-10-08 11:26:38 --> Output Class Initialized
INFO - 2016-10-08 11:26:38 --> Security Class Initialized
DEBUG - 2016-10-08 11:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:26:38 --> Input Class Initialized
INFO - 2016-10-08 11:26:38 --> Language Class Initialized
ERROR - 2016-10-08 11:26:38 --> 404 Page Not Found: /index
INFO - 2016-10-08 11:26:51 --> Config Class Initialized
INFO - 2016-10-08 11:26:51 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:26:51 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:26:51 --> Utf8 Class Initialized
INFO - 2016-10-08 11:26:51 --> URI Class Initialized
INFO - 2016-10-08 11:26:51 --> Router Class Initialized
INFO - 2016-10-08 11:26:51 --> Output Class Initialized
INFO - 2016-10-08 11:26:51 --> Security Class Initialized
DEBUG - 2016-10-08 11:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:26:51 --> Input Class Initialized
INFO - 2016-10-08 11:26:51 --> Language Class Initialized
INFO - 2016-10-08 11:26:51 --> Language Class Initialized
INFO - 2016-10-08 11:26:51 --> Config Class Initialized
INFO - 2016-10-08 11:26:52 --> Loader Class Initialized
INFO - 2016-10-08 11:26:52 --> Helper loaded: common_helper
INFO - 2016-10-08 11:26:52 --> Helper loaded: url_helper
INFO - 2016-10-08 11:26:52 --> Database Driver Class Initialized
INFO - 2016-10-08 11:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:26:52 --> Parser Class Initialized
INFO - 2016-10-08 11:26:52 --> Controller Class Initialized
DEBUG - 2016-10-08 11:26:52 --> Admincp MX_Controller Initialized
INFO - 2016-10-08 11:26:52 --> Config Class Initialized
INFO - 2016-10-08 11:26:52 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:26:52 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:26:52 --> Utf8 Class Initialized
INFO - 2016-10-08 11:26:52 --> URI Class Initialized
INFO - 2016-10-08 11:26:52 --> Router Class Initialized
INFO - 2016-10-08 11:26:52 --> Output Class Initialized
INFO - 2016-10-08 11:26:52 --> Security Class Initialized
DEBUG - 2016-10-08 11:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:26:52 --> Input Class Initialized
INFO - 2016-10-08 11:26:52 --> Language Class Initialized
INFO - 2016-10-08 11:26:52 --> Language Class Initialized
INFO - 2016-10-08 11:26:52 --> Config Class Initialized
INFO - 2016-10-08 11:26:52 --> Loader Class Initialized
INFO - 2016-10-08 11:26:52 --> Helper loaded: common_helper
INFO - 2016-10-08 11:26:52 --> Helper loaded: url_helper
INFO - 2016-10-08 11:26:52 --> Database Driver Class Initialized
INFO - 2016-10-08 11:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:26:52 --> Parser Class Initialized
INFO - 2016-10-08 11:26:52 --> Controller Class Initialized
DEBUG - 2016-10-08 11:26:52 --> Admincp MX_Controller Initialized
INFO - 2016-10-08 11:26:52 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:26:52 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:52 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-08 11:26:52 --> Final output sent to browser
DEBUG - 2016-10-08 11:26:52 --> Total execution time: 0.0368
INFO - 2016-10-08 11:26:56 --> Config Class Initialized
INFO - 2016-10-08 11:26:56 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:26:56 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:26:56 --> Utf8 Class Initialized
INFO - 2016-10-08 11:26:56 --> URI Class Initialized
INFO - 2016-10-08 11:26:56 --> Router Class Initialized
INFO - 2016-10-08 11:26:56 --> Output Class Initialized
INFO - 2016-10-08 11:26:56 --> Security Class Initialized
DEBUG - 2016-10-08 11:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:26:56 --> Input Class Initialized
INFO - 2016-10-08 11:26:56 --> Language Class Initialized
INFO - 2016-10-08 11:26:56 --> Language Class Initialized
INFO - 2016-10-08 11:26:56 --> Config Class Initialized
INFO - 2016-10-08 11:26:56 --> Loader Class Initialized
INFO - 2016-10-08 11:26:56 --> Helper loaded: common_helper
INFO - 2016-10-08 11:26:56 --> Helper loaded: url_helper
INFO - 2016-10-08 11:26:56 --> Database Driver Class Initialized
INFO - 2016-10-08 11:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:26:56 --> Parser Class Initialized
INFO - 2016-10-08 11:26:56 --> Controller Class Initialized
DEBUG - 2016-10-08 11:26:56 --> Admincp MX_Controller Initialized
INFO - 2016-10-08 11:26:56 --> Model Class Initialized
DEBUG - 2016-10-08 11:26:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:26:56 --> Model Class Initialized
INFO - 2016-10-08 11:26:56 --> Final output sent to browser
DEBUG - 2016-10-08 11:26:56 --> Total execution time: 0.0425
INFO - 2016-10-08 11:27:05 --> Config Class Initialized
INFO - 2016-10-08 11:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:05 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:05 --> URI Class Initialized
INFO - 2016-10-08 11:27:05 --> Router Class Initialized
INFO - 2016-10-08 11:27:05 --> Output Class Initialized
INFO - 2016-10-08 11:27:05 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:05 --> Input Class Initialized
INFO - 2016-10-08 11:27:05 --> Language Class Initialized
INFO - 2016-10-08 11:27:05 --> Language Class Initialized
INFO - 2016-10-08 11:27:05 --> Config Class Initialized
INFO - 2016-10-08 11:27:05 --> Loader Class Initialized
INFO - 2016-10-08 11:27:05 --> Helper loaded: common_helper
INFO - 2016-10-08 11:27:05 --> Helper loaded: url_helper
INFO - 2016-10-08 11:27:05 --> Database Driver Class Initialized
INFO - 2016-10-08 11:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:27:05 --> Parser Class Initialized
INFO - 2016-10-08 11:27:05 --> Controller Class Initialized
DEBUG - 2016-10-08 11:27:05 --> Admincp MX_Controller Initialized
INFO - 2016-10-08 11:27:05 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:27:05 --> Model Class Initialized
INFO - 2016-10-08 11:27:05 --> Final output sent to browser
DEBUG - 2016-10-08 11:27:05 --> Total execution time: 0.0415
INFO - 2016-10-08 11:27:13 --> Config Class Initialized
INFO - 2016-10-08 11:27:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:13 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:13 --> URI Class Initialized
INFO - 2016-10-08 11:27:13 --> Router Class Initialized
INFO - 2016-10-08 11:27:13 --> Output Class Initialized
INFO - 2016-10-08 11:27:13 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:13 --> Input Class Initialized
INFO - 2016-10-08 11:27:13 --> Language Class Initialized
INFO - 2016-10-08 11:27:13 --> Language Class Initialized
INFO - 2016-10-08 11:27:13 --> Config Class Initialized
INFO - 2016-10-08 11:27:13 --> Loader Class Initialized
INFO - 2016-10-08 11:27:13 --> Helper loaded: common_helper
INFO - 2016-10-08 11:27:13 --> Helper loaded: url_helper
INFO - 2016-10-08 11:27:13 --> Database Driver Class Initialized
INFO - 2016-10-08 11:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:27:13 --> Parser Class Initialized
INFO - 2016-10-08 11:27:13 --> Controller Class Initialized
DEBUG - 2016-10-08 11:27:13 --> Admincp MX_Controller Initialized
INFO - 2016-10-08 11:27:13 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:27:13 --> Model Class Initialized
INFO - 2016-10-08 11:27:13 --> Final output sent to browser
DEBUG - 2016-10-08 11:27:13 --> Total execution time: 0.0429
INFO - 2016-10-08 11:27:13 --> Config Class Initialized
INFO - 2016-10-08 11:27:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:13 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:13 --> URI Class Initialized
INFO - 2016-10-08 11:27:13 --> Router Class Initialized
INFO - 2016-10-08 11:27:13 --> Output Class Initialized
INFO - 2016-10-08 11:27:13 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:13 --> Input Class Initialized
INFO - 2016-10-08 11:27:13 --> Language Class Initialized
INFO - 2016-10-08 11:27:13 --> Language Class Initialized
INFO - 2016-10-08 11:27:13 --> Config Class Initialized
INFO - 2016-10-08 11:27:13 --> Loader Class Initialized
INFO - 2016-10-08 11:27:13 --> Helper loaded: common_helper
INFO - 2016-10-08 11:27:13 --> Helper loaded: url_helper
INFO - 2016-10-08 11:27:13 --> Database Driver Class Initialized
INFO - 2016-10-08 11:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:27:13 --> Parser Class Initialized
INFO - 2016-10-08 11:27:13 --> Controller Class Initialized
DEBUG - 2016-10-08 11:27:13 --> Admincp MX_Controller Initialized
INFO - 2016-10-08 11:27:13 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:27:13 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-08 11:27:13 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:27:13 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-08 11:27:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:27:13 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-08 11:27:13 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-08 11:27:13 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-08 11:27:13 --> Final output sent to browser
DEBUG - 2016-10-08 11:27:13 --> Total execution time: 0.0489
INFO - 2016-10-08 11:27:15 --> Config Class Initialized
INFO - 2016-10-08 11:27:15 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:15 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:15 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:15 --> URI Class Initialized
INFO - 2016-10-08 11:27:15 --> Router Class Initialized
INFO - 2016-10-08 11:27:15 --> Output Class Initialized
INFO - 2016-10-08 11:27:15 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:15 --> Input Class Initialized
INFO - 2016-10-08 11:27:15 --> Language Class Initialized
ERROR - 2016-10-08 11:27:15 --> 404 Page Not Found: /index
INFO - 2016-10-08 11:27:20 --> Config Class Initialized
INFO - 2016-10-08 11:27:20 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:20 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:20 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:20 --> URI Class Initialized
INFO - 2016-10-08 11:27:20 --> Router Class Initialized
INFO - 2016-10-08 11:27:20 --> Output Class Initialized
INFO - 2016-10-08 11:27:20 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:20 --> Input Class Initialized
INFO - 2016-10-08 11:27:20 --> Language Class Initialized
ERROR - 2016-10-08 11:27:20 --> 404 Page Not Found: /index
INFO - 2016-10-08 11:27:20 --> Config Class Initialized
INFO - 2016-10-08 11:27:20 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:20 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:20 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:20 --> URI Class Initialized
INFO - 2016-10-08 11:27:20 --> Router Class Initialized
INFO - 2016-10-08 11:27:20 --> Output Class Initialized
INFO - 2016-10-08 11:27:20 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:20 --> Input Class Initialized
INFO - 2016-10-08 11:27:20 --> Language Class Initialized
ERROR - 2016-10-08 11:27:20 --> 404 Page Not Found: /index
INFO - 2016-10-08 11:27:22 --> Config Class Initialized
INFO - 2016-10-08 11:27:22 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:22 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:22 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:22 --> URI Class Initialized
INFO - 2016-10-08 11:27:22 --> Router Class Initialized
INFO - 2016-10-08 11:27:22 --> Output Class Initialized
INFO - 2016-10-08 11:27:22 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:22 --> Input Class Initialized
INFO - 2016-10-08 11:27:22 --> Language Class Initialized
INFO - 2016-10-08 11:27:22 --> Language Class Initialized
INFO - 2016-10-08 11:27:22 --> Config Class Initialized
INFO - 2016-10-08 11:27:22 --> Loader Class Initialized
INFO - 2016-10-08 11:27:22 --> Helper loaded: common_helper
INFO - 2016-10-08 11:27:22 --> Helper loaded: url_helper
INFO - 2016-10-08 11:27:22 --> Database Driver Class Initialized
INFO - 2016-10-08 11:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:27:22 --> Parser Class Initialized
INFO - 2016-10-08 11:27:22 --> Controller Class Initialized
DEBUG - 2016-10-08 11:27:22 --> Admincp MX_Controller Initialized
INFO - 2016-10-08 11:27:22 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:27:22 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-08 11:27:22 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:27:22 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-08 11:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:27:22 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-08 11:27:22 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-08 11:27:22 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-08 11:27:22 --> Final output sent to browser
DEBUG - 2016-10-08 11:27:22 --> Total execution time: 0.0613
INFO - 2016-10-08 11:27:25 --> Config Class Initialized
INFO - 2016-10-08 11:27:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:25 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:25 --> URI Class Initialized
INFO - 2016-10-08 11:27:25 --> Router Class Initialized
INFO - 2016-10-08 11:27:25 --> Output Class Initialized
INFO - 2016-10-08 11:27:25 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:25 --> Input Class Initialized
INFO - 2016-10-08 11:27:25 --> Language Class Initialized
INFO - 2016-10-08 11:27:25 --> Language Class Initialized
INFO - 2016-10-08 11:27:25 --> Config Class Initialized
INFO - 2016-10-08 11:27:25 --> Loader Class Initialized
INFO - 2016-10-08 11:27:25 --> Helper loaded: common_helper
INFO - 2016-10-08 11:27:25 --> Helper loaded: url_helper
INFO - 2016-10-08 11:27:25 --> Database Driver Class Initialized
INFO - 2016-10-08 11:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:27:25 --> Parser Class Initialized
INFO - 2016-10-08 11:27:25 --> Controller Class Initialized
DEBUG - 2016-10-08 11:27:25 --> Content MX_Controller Initialized
INFO - 2016-10-08 11:27:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 11:27:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:27:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-08 11:27:25 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-08 11:27:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:27:25 --> Model Class Initialized
ERROR - 2016-10-08 11:27:25 --> Severity: Warning --> Missing argument 1 for getFullCategoryOption(), called in /home/dolongpk/public_html/application/modules/content/views/BACKEND/index.php on line 21 and defined /home/dolongpk/public_html/application/helpers/common_helper.php 2002
ERROR - 2016-10-08 11:27:25 --> Severity: Notice --> Undefined variable: id_active /home/dolongpk/public_html/application/helpers/common_helper.php 2020
ERROR - 2016-10-08 11:27:25 --> Severity: Notice --> Undefined variable: id_active /home/dolongpk/public_html/application/helpers/common_helper.php 2020
ERROR - 2016-10-08 11:27:25 --> Severity: Notice --> Undefined variable: id_active /home/dolongpk/public_html/application/helpers/common_helper.php 2020
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/BACKEND/index.php
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-08 11:27:25 --> Final output sent to browser
DEBUG - 2016-10-08 11:27:25 --> Total execution time: 0.0499
INFO - 2016-10-08 11:27:25 --> Config Class Initialized
INFO - 2016-10-08 11:27:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:25 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:25 --> URI Class Initialized
INFO - 2016-10-08 11:27:25 --> Router Class Initialized
INFO - 2016-10-08 11:27:25 --> Output Class Initialized
INFO - 2016-10-08 11:27:25 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:25 --> Input Class Initialized
INFO - 2016-10-08 11:27:25 --> Language Class Initialized
ERROR - 2016-10-08 11:27:25 --> 404 Page Not Found: /index
INFO - 2016-10-08 11:27:25 --> Config Class Initialized
INFO - 2016-10-08 11:27:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:25 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:25 --> URI Class Initialized
INFO - 2016-10-08 11:27:25 --> Router Class Initialized
INFO - 2016-10-08 11:27:25 --> Output Class Initialized
INFO - 2016-10-08 11:27:25 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:25 --> Input Class Initialized
INFO - 2016-10-08 11:27:25 --> Language Class Initialized
INFO - 2016-10-08 11:27:25 --> Language Class Initialized
INFO - 2016-10-08 11:27:25 --> Config Class Initialized
INFO - 2016-10-08 11:27:25 --> Loader Class Initialized
INFO - 2016-10-08 11:27:25 --> Helper loaded: common_helper
INFO - 2016-10-08 11:27:25 --> Helper loaded: url_helper
INFO - 2016-10-08 11:27:25 --> Database Driver Class Initialized
INFO - 2016-10-08 11:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:27:25 --> Parser Class Initialized
INFO - 2016-10-08 11:27:25 --> Controller Class Initialized
DEBUG - 2016-10-08 11:27:25 --> Content MX_Controller Initialized
INFO - 2016-10-08 11:27:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 11:27:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:27:25 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:25 --> Pagination Class Initialized
DEBUG - 2016-10-08 11:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-08 11:27:25 --> Final output sent to browser
DEBUG - 2016-10-08 11:27:25 --> Total execution time: 0.0495
INFO - 2016-10-08 11:27:29 --> Config Class Initialized
INFO - 2016-10-08 11:27:29 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:29 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:29 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:29 --> URI Class Initialized
INFO - 2016-10-08 11:27:29 --> Router Class Initialized
INFO - 2016-10-08 11:27:29 --> Output Class Initialized
INFO - 2016-10-08 11:27:29 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:29 --> Input Class Initialized
INFO - 2016-10-08 11:27:29 --> Language Class Initialized
INFO - 2016-10-08 11:27:29 --> Language Class Initialized
INFO - 2016-10-08 11:27:29 --> Config Class Initialized
INFO - 2016-10-08 11:27:29 --> Loader Class Initialized
INFO - 2016-10-08 11:27:29 --> Helper loaded: common_helper
INFO - 2016-10-08 11:27:29 --> Helper loaded: url_helper
INFO - 2016-10-08 11:27:29 --> Database Driver Class Initialized
INFO - 2016-10-08 11:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:27:29 --> Parser Class Initialized
INFO - 2016-10-08 11:27:29 --> Controller Class Initialized
DEBUG - 2016-10-08 11:27:29 --> Content MX_Controller Initialized
INFO - 2016-10-08 11:27:29 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:29 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 11:27:29 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:27:29 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:29 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-08 11:27:29 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-08 11:27:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-08 11:27:29 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:27:29 --> Model Class Initialized
ERROR - 2016-10-08 11:27:29 --> Unable to load the requested class: Ckeditor
INFO - 2016-10-08 11:27:35 --> Config Class Initialized
INFO - 2016-10-08 11:27:35 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:35 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:35 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:35 --> URI Class Initialized
INFO - 2016-10-08 11:27:35 --> Router Class Initialized
INFO - 2016-10-08 11:27:35 --> Output Class Initialized
INFO - 2016-10-08 11:27:35 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:35 --> Input Class Initialized
INFO - 2016-10-08 11:27:35 --> Language Class Initialized
INFO - 2016-10-08 11:27:35 --> Language Class Initialized
INFO - 2016-10-08 11:27:35 --> Config Class Initialized
INFO - 2016-10-08 11:27:35 --> Loader Class Initialized
INFO - 2016-10-08 11:27:35 --> Helper loaded: common_helper
INFO - 2016-10-08 11:27:35 --> Helper loaded: url_helper
INFO - 2016-10-08 11:27:35 --> Database Driver Class Initialized
INFO - 2016-10-08 11:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:27:35 --> Parser Class Initialized
INFO - 2016-10-08 11:27:35 --> Controller Class Initialized
DEBUG - 2016-10-08 11:27:35 --> Content MX_Controller Initialized
INFO - 2016-10-08 11:27:35 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 11:27:35 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:27:35 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-08 11:27:35 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-08 11:27:35 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 11:27:35 --> Model Class Initialized
ERROR - 2016-10-08 11:27:35 --> Severity: Warning --> Missing argument 1 for getFullCategoryOption(), called in /home/dolongpk/public_html/application/modules/content/views/BACKEND/index.php on line 21 and defined /home/dolongpk/public_html/application/helpers/common_helper.php 2002
ERROR - 2016-10-08 11:27:35 --> Severity: Notice --> Undefined variable: id_active /home/dolongpk/public_html/application/helpers/common_helper.php 2020
ERROR - 2016-10-08 11:27:35 --> Severity: Notice --> Undefined variable: id_active /home/dolongpk/public_html/application/helpers/common_helper.php 2020
ERROR - 2016-10-08 11:27:35 --> Severity: Notice --> Undefined variable: id_active /home/dolongpk/public_html/application/helpers/common_helper.php 2020
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/BACKEND/index.php
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-08 11:27:35 --> Final output sent to browser
DEBUG - 2016-10-08 11:27:35 --> Total execution time: 0.0548
INFO - 2016-10-08 11:27:35 --> Config Class Initialized
INFO - 2016-10-08 11:27:35 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:27:35 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:27:35 --> Utf8 Class Initialized
INFO - 2016-10-08 11:27:35 --> URI Class Initialized
INFO - 2016-10-08 11:27:35 --> Router Class Initialized
INFO - 2016-10-08 11:27:35 --> Output Class Initialized
INFO - 2016-10-08 11:27:35 --> Security Class Initialized
DEBUG - 2016-10-08 11:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:27:35 --> Input Class Initialized
INFO - 2016-10-08 11:27:35 --> Language Class Initialized
INFO - 2016-10-08 11:27:35 --> Language Class Initialized
INFO - 2016-10-08 11:27:35 --> Config Class Initialized
INFO - 2016-10-08 11:27:35 --> Loader Class Initialized
INFO - 2016-10-08 11:27:35 --> Helper loaded: common_helper
INFO - 2016-10-08 11:27:35 --> Helper loaded: url_helper
INFO - 2016-10-08 11:27:35 --> Database Driver Class Initialized
INFO - 2016-10-08 11:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:27:35 --> Parser Class Initialized
INFO - 2016-10-08 11:27:35 --> Controller Class Initialized
DEBUG - 2016-10-08 11:27:35 --> Content MX_Controller Initialized
INFO - 2016-10-08 11:27:35 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 11:27:35 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:27:35 --> Model Class Initialized
DEBUG - 2016-10-08 11:27:35 --> Pagination Class Initialized
DEBUG - 2016-10-08 11:27:35 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-08 11:27:35 --> Final output sent to browser
DEBUG - 2016-10-08 11:27:35 --> Total execution time: 0.0350
INFO - 2016-10-08 11:33:53 --> Config Class Initialized
INFO - 2016-10-08 11:33:53 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:33:53 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:33:53 --> Utf8 Class Initialized
INFO - 2016-10-08 11:33:53 --> URI Class Initialized
INFO - 2016-10-08 11:33:53 --> Router Class Initialized
INFO - 2016-10-08 11:33:53 --> Output Class Initialized
INFO - 2016-10-08 11:33:53 --> Security Class Initialized
DEBUG - 2016-10-08 11:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:33:53 --> Input Class Initialized
INFO - 2016-10-08 11:33:53 --> Language Class Initialized
INFO - 2016-10-08 11:33:53 --> Language Class Initialized
INFO - 2016-10-08 11:33:53 --> Config Class Initialized
INFO - 2016-10-08 11:33:53 --> Loader Class Initialized
INFO - 2016-10-08 11:33:53 --> Helper loaded: common_helper
INFO - 2016-10-08 11:33:53 --> Helper loaded: url_helper
INFO - 2016-10-08 11:33:53 --> Database Driver Class Initialized
INFO - 2016-10-08 11:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:33:53 --> Parser Class Initialized
INFO - 2016-10-08 11:33:53 --> Controller Class Initialized
DEBUG - 2016-10-08 11:33:53 --> Content MX_Controller Initialized
INFO - 2016-10-08 11:33:53 --> Model Class Initialized
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 11:33:53 --> Model Class Initialized
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 11:33:53 --> Model Class Initialized
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 11:33:53 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 11:33:53 --> Model Class Initialized
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 11:33:53 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 11:33:53 --> Model Class Initialized
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 11:33:53 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 11:33:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 11:33:53 --> Final output sent to browser
DEBUG - 2016-10-08 11:33:53 --> Total execution time: 0.0562
INFO - 2016-10-08 11:39:31 --> Config Class Initialized
INFO - 2016-10-08 11:39:31 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:39:31 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:39:31 --> Utf8 Class Initialized
INFO - 2016-10-08 11:39:31 --> URI Class Initialized
INFO - 2016-10-08 11:39:31 --> Router Class Initialized
INFO - 2016-10-08 11:39:31 --> Output Class Initialized
INFO - 2016-10-08 11:39:31 --> Security Class Initialized
DEBUG - 2016-10-08 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:39:31 --> Input Class Initialized
INFO - 2016-10-08 11:39:31 --> Language Class Initialized
ERROR - 2016-10-08 11:39:31 --> 404 Page Not Found: /index
INFO - 2016-10-08 11:39:35 --> Config Class Initialized
INFO - 2016-10-08 11:39:35 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:39:35 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:39:35 --> Utf8 Class Initialized
INFO - 2016-10-08 11:39:35 --> URI Class Initialized
DEBUG - 2016-10-08 11:39:35 --> No URI present. Default controller set.
INFO - 2016-10-08 11:39:35 --> Router Class Initialized
INFO - 2016-10-08 11:39:35 --> Output Class Initialized
INFO - 2016-10-08 11:39:35 --> Security Class Initialized
DEBUG - 2016-10-08 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:39:35 --> Input Class Initialized
INFO - 2016-10-08 11:39:35 --> Language Class Initialized
INFO - 2016-10-08 11:39:35 --> Language Class Initialized
INFO - 2016-10-08 11:39:35 --> Config Class Initialized
INFO - 2016-10-08 11:39:35 --> Loader Class Initialized
INFO - 2016-10-08 11:39:35 --> Helper loaded: common_helper
INFO - 2016-10-08 11:39:35 --> Helper loaded: url_helper
INFO - 2016-10-08 11:39:35 --> Database Driver Class Initialized
INFO - 2016-10-08 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:39:35 --> Parser Class Initialized
INFO - 2016-10-08 11:39:35 --> Controller Class Initialized
DEBUG - 2016-10-08 11:39:35 --> Home MX_Controller Initialized
INFO - 2016-10-08 11:39:35 --> Model Class Initialized
DEBUG - 2016-10-08 11:39:35 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 11:39:35 --> Model Class Initialized
ERROR - 2016-10-08 11:39:35 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 11:39:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 11:39:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 11:39:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-08 11:39:35 --> Final output sent to browser
DEBUG - 2016-10-08 11:39:35 --> Total execution time: 0.0443
INFO - 2016-10-08 11:49:15 --> Config Class Initialized
INFO - 2016-10-08 11:49:15 --> Hooks Class Initialized
DEBUG - 2016-10-08 11:49:15 --> UTF-8 Support Enabled
INFO - 2016-10-08 11:49:15 --> Utf8 Class Initialized
INFO - 2016-10-08 11:49:15 --> URI Class Initialized
DEBUG - 2016-10-08 11:49:15 --> No URI present. Default controller set.
INFO - 2016-10-08 11:49:15 --> Router Class Initialized
INFO - 2016-10-08 11:49:15 --> Output Class Initialized
INFO - 2016-10-08 11:49:15 --> Security Class Initialized
DEBUG - 2016-10-08 11:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 11:49:15 --> Input Class Initialized
INFO - 2016-10-08 11:49:15 --> Language Class Initialized
INFO - 2016-10-08 11:49:15 --> Language Class Initialized
INFO - 2016-10-08 11:49:15 --> Config Class Initialized
INFO - 2016-10-08 11:49:15 --> Loader Class Initialized
INFO - 2016-10-08 11:49:15 --> Helper loaded: common_helper
INFO - 2016-10-08 11:49:15 --> Helper loaded: url_helper
INFO - 2016-10-08 11:49:15 --> Database Driver Class Initialized
INFO - 2016-10-08 11:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 11:49:15 --> Parser Class Initialized
INFO - 2016-10-08 11:49:15 --> Controller Class Initialized
DEBUG - 2016-10-08 11:49:15 --> Home MX_Controller Initialized
INFO - 2016-10-08 11:49:15 --> Model Class Initialized
DEBUG - 2016-10-08 11:49:15 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 11:49:15 --> Model Class Initialized
ERROR - 2016-10-08 11:49:15 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 11:49:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 11:49:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 11:49:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-08 11:49:15 --> Final output sent to browser
DEBUG - 2016-10-08 11:49:15 --> Total execution time: 0.0510
INFO - 2016-10-08 12:07:01 --> Config Class Initialized
INFO - 2016-10-08 12:07:01 --> Hooks Class Initialized
DEBUG - 2016-10-08 12:07:01 --> UTF-8 Support Enabled
INFO - 2016-10-08 12:07:01 --> Utf8 Class Initialized
INFO - 2016-10-08 12:07:01 --> URI Class Initialized
INFO - 2016-10-08 12:07:01 --> Router Class Initialized
INFO - 2016-10-08 12:07:01 --> Output Class Initialized
INFO - 2016-10-08 12:07:01 --> Security Class Initialized
DEBUG - 2016-10-08 12:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 12:07:01 --> Input Class Initialized
INFO - 2016-10-08 12:07:01 --> Language Class Initialized
INFO - 2016-10-08 12:07:01 --> Language Class Initialized
INFO - 2016-10-08 12:07:01 --> Config Class Initialized
INFO - 2016-10-08 12:07:01 --> Loader Class Initialized
INFO - 2016-10-08 12:07:01 --> Helper loaded: common_helper
INFO - 2016-10-08 12:07:01 --> Helper loaded: url_helper
INFO - 2016-10-08 12:07:01 --> Database Driver Class Initialized
INFO - 2016-10-08 12:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 12:07:01 --> Parser Class Initialized
INFO - 2016-10-08 12:07:01 --> Controller Class Initialized
DEBUG - 2016-10-08 12:07:01 --> Content MX_Controller Initialized
INFO - 2016-10-08 12:07:01 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 12:07:01 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 12:07:01 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 12:07:01 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 12:07:01 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 12:07:01 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 12:07:01 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 12:07:01 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 12:07:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 12:07:01 --> Final output sent to browser
DEBUG - 2016-10-08 12:07:01 --> Total execution time: 0.0645
INFO - 2016-10-08 12:07:12 --> Config Class Initialized
INFO - 2016-10-08 12:07:12 --> Hooks Class Initialized
DEBUG - 2016-10-08 12:07:12 --> UTF-8 Support Enabled
INFO - 2016-10-08 12:07:12 --> Utf8 Class Initialized
INFO - 2016-10-08 12:07:12 --> URI Class Initialized
INFO - 2016-10-08 12:07:12 --> Router Class Initialized
INFO - 2016-10-08 12:07:12 --> Output Class Initialized
INFO - 2016-10-08 12:07:12 --> Security Class Initialized
DEBUG - 2016-10-08 12:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 12:07:12 --> Input Class Initialized
INFO - 2016-10-08 12:07:12 --> Language Class Initialized
INFO - 2016-10-08 12:07:12 --> Language Class Initialized
INFO - 2016-10-08 12:07:12 --> Config Class Initialized
INFO - 2016-10-08 12:07:12 --> Loader Class Initialized
INFO - 2016-10-08 12:07:12 --> Helper loaded: common_helper
INFO - 2016-10-08 12:07:12 --> Helper loaded: url_helper
INFO - 2016-10-08 12:07:12 --> Database Driver Class Initialized
INFO - 2016-10-08 12:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 12:07:12 --> Parser Class Initialized
INFO - 2016-10-08 12:07:12 --> Controller Class Initialized
DEBUG - 2016-10-08 12:07:12 --> Content MX_Controller Initialized
INFO - 2016-10-08 12:07:12 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 12:07:12 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 12:07:12 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 12:07:12 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 12:07:12 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 12:07:12 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 12:07:12 --> Model Class Initialized
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 12:07:12 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 12:07:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 12:07:12 --> Final output sent to browser
DEBUG - 2016-10-08 12:07:12 --> Total execution time: 0.0766
INFO - 2016-10-08 12:09:21 --> Config Class Initialized
INFO - 2016-10-08 12:09:21 --> Hooks Class Initialized
DEBUG - 2016-10-08 12:09:21 --> UTF-8 Support Enabled
INFO - 2016-10-08 12:09:21 --> Utf8 Class Initialized
INFO - 2016-10-08 12:09:21 --> URI Class Initialized
INFO - 2016-10-08 12:09:21 --> Router Class Initialized
INFO - 2016-10-08 12:09:21 --> Output Class Initialized
INFO - 2016-10-08 12:09:21 --> Security Class Initialized
DEBUG - 2016-10-08 12:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 12:09:21 --> Input Class Initialized
INFO - 2016-10-08 12:09:21 --> Language Class Initialized
INFO - 2016-10-08 12:09:21 --> Language Class Initialized
INFO - 2016-10-08 12:09:21 --> Config Class Initialized
INFO - 2016-10-08 12:09:21 --> Loader Class Initialized
INFO - 2016-10-08 12:09:21 --> Helper loaded: common_helper
INFO - 2016-10-08 12:09:21 --> Helper loaded: url_helper
INFO - 2016-10-08 12:09:21 --> Database Driver Class Initialized
INFO - 2016-10-08 12:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 12:09:21 --> Parser Class Initialized
INFO - 2016-10-08 12:09:21 --> Controller Class Initialized
DEBUG - 2016-10-08 12:09:21 --> Content MX_Controller Initialized
INFO - 2016-10-08 12:09:21 --> Model Class Initialized
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 12:09:21 --> Model Class Initialized
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 12:09:21 --> Model Class Initialized
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 12:09:21 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 12:09:21 --> Model Class Initialized
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 12:09:21 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 12:09:21 --> Model Class Initialized
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 12:09:21 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 12:09:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 12:09:21 --> Final output sent to browser
DEBUG - 2016-10-08 12:09:21 --> Total execution time: 0.0851
INFO - 2016-10-08 12:34:23 --> Config Class Initialized
INFO - 2016-10-08 12:34:23 --> Hooks Class Initialized
DEBUG - 2016-10-08 12:34:23 --> UTF-8 Support Enabled
INFO - 2016-10-08 12:34:23 --> Utf8 Class Initialized
INFO - 2016-10-08 12:34:23 --> URI Class Initialized
INFO - 2016-10-08 12:34:23 --> Router Class Initialized
INFO - 2016-10-08 12:34:23 --> Output Class Initialized
INFO - 2016-10-08 12:34:23 --> Security Class Initialized
DEBUG - 2016-10-08 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 12:34:23 --> Input Class Initialized
INFO - 2016-10-08 12:34:23 --> Language Class Initialized
INFO - 2016-10-08 12:34:23 --> Language Class Initialized
INFO - 2016-10-08 12:34:23 --> Config Class Initialized
INFO - 2016-10-08 12:34:23 --> Loader Class Initialized
INFO - 2016-10-08 12:34:23 --> Helper loaded: common_helper
INFO - 2016-10-08 12:34:23 --> Helper loaded: url_helper
INFO - 2016-10-08 12:34:23 --> Database Driver Class Initialized
INFO - 2016-10-08 12:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 12:34:23 --> Parser Class Initialized
INFO - 2016-10-08 12:34:23 --> Controller Class Initialized
DEBUG - 2016-10-08 12:34:23 --> Content MX_Controller Initialized
INFO - 2016-10-08 12:34:23 --> Model Class Initialized
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 12:34:23 --> Model Class Initialized
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 12:34:23 --> Model Class Initialized
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 12:34:23 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 12:34:23 --> Model Class Initialized
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 12:34:23 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 12:34:23 --> Model Class Initialized
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 12:34:23 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 12:34:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 12:34:23 --> Final output sent to browser
DEBUG - 2016-10-08 12:34:23 --> Total execution time: 0.0551
INFO - 2016-10-08 12:59:35 --> Config Class Initialized
INFO - 2016-10-08 12:59:35 --> Hooks Class Initialized
DEBUG - 2016-10-08 12:59:35 --> UTF-8 Support Enabled
INFO - 2016-10-08 12:59:35 --> Utf8 Class Initialized
INFO - 2016-10-08 12:59:35 --> URI Class Initialized
INFO - 2016-10-08 12:59:35 --> Router Class Initialized
INFO - 2016-10-08 12:59:35 --> Output Class Initialized
INFO - 2016-10-08 12:59:35 --> Security Class Initialized
DEBUG - 2016-10-08 12:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 12:59:35 --> Input Class Initialized
INFO - 2016-10-08 12:59:35 --> Language Class Initialized
INFO - 2016-10-08 12:59:35 --> Language Class Initialized
INFO - 2016-10-08 12:59:35 --> Config Class Initialized
INFO - 2016-10-08 12:59:35 --> Loader Class Initialized
INFO - 2016-10-08 12:59:35 --> Helper loaded: common_helper
INFO - 2016-10-08 12:59:35 --> Helper loaded: url_helper
INFO - 2016-10-08 12:59:35 --> Database Driver Class Initialized
INFO - 2016-10-08 12:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 12:59:35 --> Parser Class Initialized
INFO - 2016-10-08 12:59:35 --> Controller Class Initialized
DEBUG - 2016-10-08 12:59:35 --> Content MX_Controller Initialized
INFO - 2016-10-08 12:59:35 --> Model Class Initialized
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 12:59:35 --> Model Class Initialized
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 12:59:35 --> Model Class Initialized
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 12:59:35 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 12:59:35 --> Model Class Initialized
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 12:59:35 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 12:59:35 --> Model Class Initialized
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 12:59:35 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 12:59:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 12:59:35 --> Final output sent to browser
DEBUG - 2016-10-08 12:59:35 --> Total execution time: 0.0573
INFO - 2016-10-08 13:03:36 --> Config Class Initialized
INFO - 2016-10-08 13:03:36 --> Hooks Class Initialized
DEBUG - 2016-10-08 13:03:36 --> UTF-8 Support Enabled
INFO - 2016-10-08 13:03:36 --> Utf8 Class Initialized
INFO - 2016-10-08 13:03:36 --> URI Class Initialized
INFO - 2016-10-08 13:03:36 --> Router Class Initialized
INFO - 2016-10-08 13:03:36 --> Output Class Initialized
INFO - 2016-10-08 13:03:36 --> Security Class Initialized
DEBUG - 2016-10-08 13:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 13:03:36 --> Input Class Initialized
INFO - 2016-10-08 13:03:36 --> Language Class Initialized
INFO - 2016-10-08 13:03:36 --> Language Class Initialized
INFO - 2016-10-08 13:03:36 --> Config Class Initialized
INFO - 2016-10-08 13:03:36 --> Loader Class Initialized
INFO - 2016-10-08 13:03:36 --> Helper loaded: common_helper
INFO - 2016-10-08 13:03:36 --> Helper loaded: url_helper
INFO - 2016-10-08 13:03:36 --> Database Driver Class Initialized
INFO - 2016-10-08 13:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 13:03:36 --> Parser Class Initialized
INFO - 2016-10-08 13:03:36 --> Controller Class Initialized
DEBUG - 2016-10-08 13:03:36 --> Content MX_Controller Initialized
INFO - 2016-10-08 13:03:36 --> Model Class Initialized
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 13:03:36 --> Model Class Initialized
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 13:03:36 --> Model Class Initialized
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 13:03:36 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 13:03:36 --> Model Class Initialized
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 13:03:36 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 13:03:36 --> Model Class Initialized
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 13:03:36 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 13:03:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 13:03:36 --> Final output sent to browser
DEBUG - 2016-10-08 13:03:36 --> Total execution time: 0.0561
INFO - 2016-10-08 13:08:02 --> Config Class Initialized
INFO - 2016-10-08 13:08:02 --> Hooks Class Initialized
DEBUG - 2016-10-08 13:08:02 --> UTF-8 Support Enabled
INFO - 2016-10-08 13:08:02 --> Utf8 Class Initialized
INFO - 2016-10-08 13:08:02 --> URI Class Initialized
INFO - 2016-10-08 13:08:02 --> Router Class Initialized
INFO - 2016-10-08 13:08:02 --> Output Class Initialized
INFO - 2016-10-08 13:08:02 --> Security Class Initialized
DEBUG - 2016-10-08 13:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 13:08:02 --> Input Class Initialized
INFO - 2016-10-08 13:08:02 --> Language Class Initialized
INFO - 2016-10-08 13:08:02 --> Language Class Initialized
INFO - 2016-10-08 13:08:02 --> Config Class Initialized
INFO - 2016-10-08 13:08:02 --> Loader Class Initialized
INFO - 2016-10-08 13:08:02 --> Helper loaded: common_helper
INFO - 2016-10-08 13:08:02 --> Helper loaded: url_helper
INFO - 2016-10-08 13:08:02 --> Database Driver Class Initialized
INFO - 2016-10-08 13:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 13:08:02 --> Parser Class Initialized
INFO - 2016-10-08 13:08:02 --> Controller Class Initialized
DEBUG - 2016-10-08 13:08:02 --> Content MX_Controller Initialized
INFO - 2016-10-08 13:08:02 --> Model Class Initialized
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 13:08:02 --> Model Class Initialized
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 13:08:02 --> Model Class Initialized
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 13:08:02 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 13:08:02 --> Model Class Initialized
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 13:08:02 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 13:08:02 --> Model Class Initialized
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 13:08:02 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 13:08:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 13:08:02 --> Final output sent to browser
DEBUG - 2016-10-08 13:08:02 --> Total execution time: 0.0589
INFO - 2016-10-08 13:51:13 --> Config Class Initialized
INFO - 2016-10-08 13:51:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 13:51:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 13:51:13 --> Utf8 Class Initialized
INFO - 2016-10-08 13:51:13 --> URI Class Initialized
DEBUG - 2016-10-08 13:51:13 --> No URI present. Default controller set.
INFO - 2016-10-08 13:51:13 --> Router Class Initialized
INFO - 2016-10-08 13:51:13 --> Output Class Initialized
INFO - 2016-10-08 13:51:13 --> Security Class Initialized
DEBUG - 2016-10-08 13:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 13:51:13 --> Input Class Initialized
INFO - 2016-10-08 13:51:13 --> Language Class Initialized
INFO - 2016-10-08 13:51:13 --> Language Class Initialized
INFO - 2016-10-08 13:51:13 --> Config Class Initialized
INFO - 2016-10-08 13:51:13 --> Loader Class Initialized
INFO - 2016-10-08 13:51:13 --> Helper loaded: common_helper
INFO - 2016-10-08 13:51:13 --> Helper loaded: url_helper
INFO - 2016-10-08 13:51:13 --> Database Driver Class Initialized
INFO - 2016-10-08 13:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 13:51:13 --> Parser Class Initialized
INFO - 2016-10-08 13:51:13 --> Controller Class Initialized
DEBUG - 2016-10-08 13:51:13 --> Home MX_Controller Initialized
INFO - 2016-10-08 13:51:13 --> Model Class Initialized
DEBUG - 2016-10-08 13:51:13 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 13:51:13 --> Model Class Initialized
ERROR - 2016-10-08 13:51:13 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 13:51:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 13:51:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 13:51:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-08 13:51:13 --> Final output sent to browser
DEBUG - 2016-10-08 13:51:13 --> Total execution time: 0.0452
INFO - 2016-10-08 13:51:15 --> Config Class Initialized
INFO - 2016-10-08 13:51:15 --> Hooks Class Initialized
DEBUG - 2016-10-08 13:51:15 --> UTF-8 Support Enabled
INFO - 2016-10-08 13:51:15 --> Utf8 Class Initialized
INFO - 2016-10-08 13:51:15 --> URI Class Initialized
DEBUG - 2016-10-08 13:51:15 --> No URI present. Default controller set.
INFO - 2016-10-08 13:51:15 --> Router Class Initialized
INFO - 2016-10-08 13:51:15 --> Output Class Initialized
INFO - 2016-10-08 13:51:15 --> Security Class Initialized
DEBUG - 2016-10-08 13:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 13:51:15 --> Input Class Initialized
INFO - 2016-10-08 13:51:15 --> Language Class Initialized
INFO - 2016-10-08 13:51:15 --> Language Class Initialized
INFO - 2016-10-08 13:51:15 --> Config Class Initialized
INFO - 2016-10-08 13:51:15 --> Loader Class Initialized
INFO - 2016-10-08 13:51:15 --> Helper loaded: common_helper
INFO - 2016-10-08 13:51:15 --> Helper loaded: url_helper
INFO - 2016-10-08 13:51:15 --> Database Driver Class Initialized
INFO - 2016-10-08 13:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 13:51:15 --> Parser Class Initialized
INFO - 2016-10-08 13:51:15 --> Controller Class Initialized
DEBUG - 2016-10-08 13:51:15 --> Home MX_Controller Initialized
INFO - 2016-10-08 13:51:15 --> Model Class Initialized
DEBUG - 2016-10-08 13:51:15 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 13:51:15 --> Model Class Initialized
ERROR - 2016-10-08 13:51:15 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 13:51:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 13:51:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 13:51:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-08 13:51:15 --> Final output sent to browser
DEBUG - 2016-10-08 13:51:15 --> Total execution time: 0.0461
INFO - 2016-10-08 13:51:23 --> Config Class Initialized
INFO - 2016-10-08 13:51:23 --> Hooks Class Initialized
DEBUG - 2016-10-08 13:51:23 --> UTF-8 Support Enabled
INFO - 2016-10-08 13:51:23 --> Utf8 Class Initialized
INFO - 2016-10-08 13:51:23 --> URI Class Initialized
INFO - 2016-10-08 13:51:23 --> Router Class Initialized
INFO - 2016-10-08 13:51:23 --> Output Class Initialized
INFO - 2016-10-08 13:51:23 --> Security Class Initialized
DEBUG - 2016-10-08 13:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 13:51:23 --> Input Class Initialized
INFO - 2016-10-08 13:51:23 --> Language Class Initialized
INFO - 2016-10-08 13:51:23 --> Language Class Initialized
INFO - 2016-10-08 13:51:23 --> Config Class Initialized
INFO - 2016-10-08 13:51:23 --> Loader Class Initialized
INFO - 2016-10-08 13:51:23 --> Helper loaded: common_helper
INFO - 2016-10-08 13:51:23 --> Helper loaded: url_helper
INFO - 2016-10-08 13:51:23 --> Database Driver Class Initialized
INFO - 2016-10-08 13:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 13:51:23 --> Parser Class Initialized
INFO - 2016-10-08 13:51:23 --> Controller Class Initialized
DEBUG - 2016-10-08 13:51:23 --> Popup MX_Controller Initialized
INFO - 2016-10-08 13:51:23 --> Model Class Initialized
DEBUG - 2016-10-08 13:51:23 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-08 13:51:23 --> Model Class Initialized
DEBUG - 2016-10-08 13:51:23 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-08 13:51:23 --> Final output sent to browser
DEBUG - 2016-10-08 13:51:23 --> Total execution time: 0.0529
INFO - 2016-10-08 13:51:23 --> Config Class Initialized
INFO - 2016-10-08 13:51:23 --> Hooks Class Initialized
DEBUG - 2016-10-08 13:51:23 --> UTF-8 Support Enabled
INFO - 2016-10-08 13:51:23 --> Utf8 Class Initialized
INFO - 2016-10-08 13:51:23 --> URI Class Initialized
INFO - 2016-10-08 13:51:23 --> Router Class Initialized
INFO - 2016-10-08 13:51:23 --> Output Class Initialized
INFO - 2016-10-08 13:51:23 --> Security Class Initialized
DEBUG - 2016-10-08 13:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 13:51:23 --> Input Class Initialized
INFO - 2016-10-08 13:51:23 --> Language Class Initialized
INFO - 2016-10-08 13:51:23 --> Language Class Initialized
INFO - 2016-10-08 13:51:23 --> Config Class Initialized
INFO - 2016-10-08 13:51:23 --> Loader Class Initialized
INFO - 2016-10-08 13:51:23 --> Helper loaded: common_helper
INFO - 2016-10-08 13:51:23 --> Helper loaded: url_helper
INFO - 2016-10-08 13:51:23 --> Database Driver Class Initialized
INFO - 2016-10-08 13:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 13:51:23 --> Parser Class Initialized
INFO - 2016-10-08 13:51:23 --> Controller Class Initialized
DEBUG - 2016-10-08 13:51:23 --> Popup MX_Controller Initialized
INFO - 2016-10-08 13:51:23 --> Model Class Initialized
DEBUG - 2016-10-08 13:51:23 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-08 13:51:23 --> Model Class Initialized
DEBUG - 2016-10-08 13:51:23 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-08 13:51:23 --> Final output sent to browser
DEBUG - 2016-10-08 13:51:23 --> Total execution time: 0.0317
INFO - 2016-10-08 13:54:27 --> Config Class Initialized
INFO - 2016-10-08 13:54:27 --> Hooks Class Initialized
DEBUG - 2016-10-08 13:54:27 --> UTF-8 Support Enabled
INFO - 2016-10-08 13:54:27 --> Utf8 Class Initialized
INFO - 2016-10-08 13:54:27 --> URI Class Initialized
INFO - 2016-10-08 13:54:27 --> Router Class Initialized
INFO - 2016-10-08 13:54:27 --> Output Class Initialized
INFO - 2016-10-08 13:54:27 --> Security Class Initialized
DEBUG - 2016-10-08 13:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 13:54:27 --> Input Class Initialized
INFO - 2016-10-08 13:54:27 --> Language Class Initialized
INFO - 2016-10-08 13:54:27 --> Language Class Initialized
INFO - 2016-10-08 13:54:27 --> Config Class Initialized
INFO - 2016-10-08 13:54:27 --> Loader Class Initialized
INFO - 2016-10-08 13:54:27 --> Helper loaded: common_helper
INFO - 2016-10-08 13:54:27 --> Helper loaded: url_helper
INFO - 2016-10-08 13:54:27 --> Database Driver Class Initialized
INFO - 2016-10-08 13:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 13:54:27 --> Parser Class Initialized
INFO - 2016-10-08 13:54:27 --> Controller Class Initialized
DEBUG - 2016-10-08 13:54:27 --> Content MX_Controller Initialized
INFO - 2016-10-08 13:54:27 --> Model Class Initialized
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 13:54:27 --> Model Class Initialized
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 13:54:27 --> Model Class Initialized
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 13:54:27 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 13:54:27 --> Model Class Initialized
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 13:54:27 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 13:54:27 --> Model Class Initialized
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 13:54:27 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 13:54:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 13:54:27 --> Final output sent to browser
DEBUG - 2016-10-08 13:54:27 --> Total execution time: 0.0749
INFO - 2016-10-08 14:32:31 --> Config Class Initialized
INFO - 2016-10-08 14:32:31 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:32:31 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:32:31 --> Utf8 Class Initialized
INFO - 2016-10-08 14:32:31 --> URI Class Initialized
INFO - 2016-10-08 14:32:31 --> Router Class Initialized
INFO - 2016-10-08 14:32:31 --> Output Class Initialized
INFO - 2016-10-08 14:32:31 --> Security Class Initialized
DEBUG - 2016-10-08 14:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:32:31 --> Input Class Initialized
INFO - 2016-10-08 14:32:31 --> Language Class Initialized
INFO - 2016-10-08 14:32:31 --> Language Class Initialized
INFO - 2016-10-08 14:32:31 --> Config Class Initialized
INFO - 2016-10-08 14:32:31 --> Loader Class Initialized
INFO - 2016-10-08 14:32:31 --> Helper loaded: common_helper
INFO - 2016-10-08 14:32:31 --> Helper loaded: url_helper
INFO - 2016-10-08 14:32:31 --> Database Driver Class Initialized
INFO - 2016-10-08 14:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 14:32:31 --> Parser Class Initialized
INFO - 2016-10-08 14:32:31 --> Controller Class Initialized
DEBUG - 2016-10-08 14:32:31 --> Content MX_Controller Initialized
INFO - 2016-10-08 14:32:31 --> Model Class Initialized
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 14:32:31 --> Model Class Initialized
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 14:32:31 --> Model Class Initialized
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 14:32:31 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 14:32:31 --> Model Class Initialized
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 14:32:31 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 14:32:31 --> Model Class Initialized
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 14:32:31 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 14:32:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 14:32:31 --> Final output sent to browser
DEBUG - 2016-10-08 14:32:31 --> Total execution time: 0.0561
INFO - 2016-10-08 14:39:12 --> Config Class Initialized
INFO - 2016-10-08 14:39:12 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:39:12 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:39:12 --> Utf8 Class Initialized
INFO - 2016-10-08 14:39:12 --> URI Class Initialized
INFO - 2016-10-08 14:39:12 --> Router Class Initialized
INFO - 2016-10-08 14:39:12 --> Output Class Initialized
INFO - 2016-10-08 14:39:12 --> Security Class Initialized
DEBUG - 2016-10-08 14:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:39:12 --> Input Class Initialized
INFO - 2016-10-08 14:39:12 --> Language Class Initialized
INFO - 2016-10-08 14:39:12 --> Language Class Initialized
INFO - 2016-10-08 14:39:12 --> Config Class Initialized
INFO - 2016-10-08 14:39:12 --> Loader Class Initialized
INFO - 2016-10-08 14:39:12 --> Helper loaded: common_helper
INFO - 2016-10-08 14:39:12 --> Helper loaded: url_helper
INFO - 2016-10-08 14:39:12 --> Database Driver Class Initialized
INFO - 2016-10-08 14:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 14:39:12 --> Parser Class Initialized
INFO - 2016-10-08 14:39:12 --> Controller Class Initialized
DEBUG - 2016-10-08 14:39:12 --> Content MX_Controller Initialized
INFO - 2016-10-08 14:39:12 --> Model Class Initialized
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 14:39:12 --> Model Class Initialized
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 14:39:12 --> Model Class Initialized
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 14:39:12 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 14:39:12 --> Model Class Initialized
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 14:39:12 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 14:39:12 --> Model Class Initialized
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 14:39:12 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 14:39:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 14:39:12 --> Final output sent to browser
DEBUG - 2016-10-08 14:39:12 --> Total execution time: 0.0617
INFO - 2016-10-08 14:44:26 --> Config Class Initialized
INFO - 2016-10-08 14:44:26 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:44:26 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:44:26 --> Utf8 Class Initialized
INFO - 2016-10-08 14:44:26 --> URI Class Initialized
INFO - 2016-10-08 14:44:26 --> Router Class Initialized
INFO - 2016-10-08 14:44:26 --> Output Class Initialized
INFO - 2016-10-08 14:44:26 --> Security Class Initialized
DEBUG - 2016-10-08 14:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:44:26 --> Input Class Initialized
INFO - 2016-10-08 14:44:26 --> Language Class Initialized
ERROR - 2016-10-08 14:44:26 --> 404 Page Not Found: /index
INFO - 2016-10-08 14:44:32 --> Config Class Initialized
INFO - 2016-10-08 14:44:32 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:44:32 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:44:32 --> Utf8 Class Initialized
INFO - 2016-10-08 14:44:32 --> URI Class Initialized
INFO - 2016-10-08 14:44:32 --> Router Class Initialized
INFO - 2016-10-08 14:44:32 --> Output Class Initialized
INFO - 2016-10-08 14:44:32 --> Security Class Initialized
DEBUG - 2016-10-08 14:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:44:32 --> Input Class Initialized
INFO - 2016-10-08 14:44:32 --> Language Class Initialized
INFO - 2016-10-08 14:44:32 --> Language Class Initialized
INFO - 2016-10-08 14:44:32 --> Config Class Initialized
INFO - 2016-10-08 14:44:32 --> Loader Class Initialized
INFO - 2016-10-08 14:44:32 --> Helper loaded: common_helper
INFO - 2016-10-08 14:44:32 --> Helper loaded: url_helper
INFO - 2016-10-08 14:44:32 --> Database Driver Class Initialized
INFO - 2016-10-08 14:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 14:44:32 --> Parser Class Initialized
INFO - 2016-10-08 14:44:32 --> Controller Class Initialized
DEBUG - 2016-10-08 14:44:32 --> User MX_Controller Initialized
INFO - 2016-10-08 14:44:32 --> Model Class Initialized
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-08 14:44:32 --> Model Class Initialized
INFO - 2016-10-08 14:44:32 --> Helper loaded: cookie_helper
INFO - 2016-10-08 14:44:32 --> Helper loaded: form_helper
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 14:44:32 --> Model Class Initialized
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 14:44:32 --> Model Class Initialized
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/forgot_password.php
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 14:44:32 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 14:44:32 --> Model Class Initialized
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 14:44:32 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 14:44:32 --> Model Class Initialized
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 14:44:32 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 14:44:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 14:44:32 --> Final output sent to browser
DEBUG - 2016-10-08 14:44:32 --> Total execution time: 0.0569
INFO - 2016-10-08 14:48:04 --> Config Class Initialized
INFO - 2016-10-08 14:48:04 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:48:04 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:48:04 --> Utf8 Class Initialized
INFO - 2016-10-08 14:48:04 --> URI Class Initialized
INFO - 2016-10-08 14:48:04 --> Router Class Initialized
INFO - 2016-10-08 14:48:04 --> Output Class Initialized
INFO - 2016-10-08 14:48:04 --> Security Class Initialized
DEBUG - 2016-10-08 14:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:48:04 --> Input Class Initialized
INFO - 2016-10-08 14:48:04 --> Language Class Initialized
INFO - 2016-10-08 14:48:04 --> Language Class Initialized
INFO - 2016-10-08 14:48:04 --> Config Class Initialized
INFO - 2016-10-08 14:48:04 --> Loader Class Initialized
INFO - 2016-10-08 14:48:04 --> Helper loaded: common_helper
INFO - 2016-10-08 14:48:04 --> Helper loaded: url_helper
INFO - 2016-10-08 14:48:04 --> Database Driver Class Initialized
INFO - 2016-10-08 14:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 14:48:04 --> Parser Class Initialized
INFO - 2016-10-08 14:48:04 --> Controller Class Initialized
DEBUG - 2016-10-08 14:48:04 --> Content MX_Controller Initialized
INFO - 2016-10-08 14:48:04 --> Model Class Initialized
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 14:48:04 --> Model Class Initialized
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 14:48:04 --> Model Class Initialized
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 14:48:04 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 14:48:04 --> Model Class Initialized
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 14:48:04 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 14:48:04 --> Model Class Initialized
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 14:48:04 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 14:48:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 14:48:04 --> Final output sent to browser
DEBUG - 2016-10-08 14:48:04 --> Total execution time: 0.0582
INFO - 2016-10-08 14:54:07 --> Config Class Initialized
INFO - 2016-10-08 14:54:07 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:54:07 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:54:07 --> Utf8 Class Initialized
INFO - 2016-10-08 14:54:07 --> URI Class Initialized
INFO - 2016-10-08 14:54:07 --> Router Class Initialized
INFO - 2016-10-08 14:54:07 --> Output Class Initialized
INFO - 2016-10-08 14:54:07 --> Security Class Initialized
DEBUG - 2016-10-08 14:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:54:07 --> Input Class Initialized
INFO - 2016-10-08 14:54:07 --> Language Class Initialized
ERROR - 2016-10-08 14:54:07 --> 404 Page Not Found: /index
INFO - 2016-10-08 14:54:08 --> Config Class Initialized
INFO - 2016-10-08 14:54:08 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:54:08 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:54:08 --> Utf8 Class Initialized
INFO - 2016-10-08 14:54:08 --> URI Class Initialized
INFO - 2016-10-08 14:54:08 --> Router Class Initialized
INFO - 2016-10-08 14:54:08 --> Output Class Initialized
INFO - 2016-10-08 14:54:08 --> Security Class Initialized
DEBUG - 2016-10-08 14:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:54:08 --> Input Class Initialized
INFO - 2016-10-08 14:54:08 --> Language Class Initialized
INFO - 2016-10-08 14:54:08 --> Language Class Initialized
INFO - 2016-10-08 14:54:08 --> Config Class Initialized
INFO - 2016-10-08 14:54:08 --> Loader Class Initialized
INFO - 2016-10-08 14:54:08 --> Helper loaded: common_helper
INFO - 2016-10-08 14:54:08 --> Helper loaded: url_helper
INFO - 2016-10-08 14:54:08 --> Database Driver Class Initialized
INFO - 2016-10-08 14:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 14:54:08 --> Parser Class Initialized
INFO - 2016-10-08 14:54:08 --> Controller Class Initialized
DEBUG - 2016-10-08 14:54:08 --> User MX_Controller Initialized
INFO - 2016-10-08 14:54:08 --> Model Class Initialized
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-08 14:54:08 --> Model Class Initialized
INFO - 2016-10-08 14:54:08 --> Helper loaded: cookie_helper
INFO - 2016-10-08 14:54:08 --> Helper loaded: form_helper
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 14:54:08 --> Model Class Initialized
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 14:54:08 --> Model Class Initialized
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/forgot_password.php
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 14:54:08 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 14:54:08 --> Model Class Initialized
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 14:54:08 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 14:54:08 --> Model Class Initialized
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 14:54:08 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 14:54:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 14:54:08 --> Final output sent to browser
DEBUG - 2016-10-08 14:54:08 --> Total execution time: 0.0588
INFO - 2016-10-08 14:54:12 --> Config Class Initialized
INFO - 2016-10-08 14:54:12 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:54:12 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:54:12 --> Utf8 Class Initialized
INFO - 2016-10-08 14:54:12 --> URI Class Initialized
INFO - 2016-10-08 14:54:12 --> Router Class Initialized
INFO - 2016-10-08 14:54:12 --> Output Class Initialized
INFO - 2016-10-08 14:54:12 --> Security Class Initialized
DEBUG - 2016-10-08 14:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:54:12 --> Input Class Initialized
INFO - 2016-10-08 14:54:12 --> Language Class Initialized
ERROR - 2016-10-08 14:54:12 --> 404 Page Not Found: /index
INFO - 2016-10-08 14:54:13 --> Config Class Initialized
INFO - 2016-10-08 14:54:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:54:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:54:13 --> Utf8 Class Initialized
INFO - 2016-10-08 14:54:13 --> URI Class Initialized
INFO - 2016-10-08 14:54:13 --> Router Class Initialized
INFO - 2016-10-08 14:54:13 --> Output Class Initialized
INFO - 2016-10-08 14:54:13 --> Security Class Initialized
DEBUG - 2016-10-08 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:54:13 --> Input Class Initialized
INFO - 2016-10-08 14:54:13 --> Language Class Initialized
ERROR - 2016-10-08 14:54:13 --> 404 Page Not Found: /index
INFO - 2016-10-08 14:54:13 --> Config Class Initialized
INFO - 2016-10-08 14:54:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:54:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:54:13 --> Utf8 Class Initialized
INFO - 2016-10-08 14:54:13 --> URI Class Initialized
INFO - 2016-10-08 14:54:13 --> Router Class Initialized
INFO - 2016-10-08 14:54:13 --> Output Class Initialized
INFO - 2016-10-08 14:54:13 --> Security Class Initialized
DEBUG - 2016-10-08 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:54:13 --> Input Class Initialized
INFO - 2016-10-08 14:54:13 --> Language Class Initialized
ERROR - 2016-10-08 14:54:13 --> 404 Page Not Found: /index
INFO - 2016-10-08 14:54:13 --> Config Class Initialized
INFO - 2016-10-08 14:54:13 --> Hooks Class Initialized
DEBUG - 2016-10-08 14:54:13 --> UTF-8 Support Enabled
INFO - 2016-10-08 14:54:13 --> Utf8 Class Initialized
INFO - 2016-10-08 14:54:13 --> URI Class Initialized
INFO - 2016-10-08 14:54:13 --> Router Class Initialized
INFO - 2016-10-08 14:54:13 --> Output Class Initialized
INFO - 2016-10-08 14:54:13 --> Security Class Initialized
DEBUG - 2016-10-08 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 14:54:13 --> Input Class Initialized
INFO - 2016-10-08 14:54:13 --> Language Class Initialized
ERROR - 2016-10-08 14:54:13 --> 404 Page Not Found: /index
INFO - 2016-10-08 15:03:54 --> Config Class Initialized
INFO - 2016-10-08 15:03:54 --> Hooks Class Initialized
DEBUG - 2016-10-08 15:03:54 --> UTF-8 Support Enabled
INFO - 2016-10-08 15:03:54 --> Utf8 Class Initialized
INFO - 2016-10-08 15:03:54 --> URI Class Initialized
INFO - 2016-10-08 15:03:54 --> Router Class Initialized
INFO - 2016-10-08 15:03:54 --> Output Class Initialized
INFO - 2016-10-08 15:03:54 --> Security Class Initialized
DEBUG - 2016-10-08 15:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 15:03:54 --> Input Class Initialized
INFO - 2016-10-08 15:03:54 --> Language Class Initialized
INFO - 2016-10-08 15:03:54 --> Language Class Initialized
INFO - 2016-10-08 15:03:54 --> Config Class Initialized
INFO - 2016-10-08 15:03:54 --> Loader Class Initialized
INFO - 2016-10-08 15:03:54 --> Helper loaded: common_helper
INFO - 2016-10-08 15:03:54 --> Helper loaded: url_helper
INFO - 2016-10-08 15:03:54 --> Database Driver Class Initialized
INFO - 2016-10-08 15:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 15:03:54 --> Parser Class Initialized
INFO - 2016-10-08 15:03:54 --> Controller Class Initialized
DEBUG - 2016-10-08 15:03:54 --> Content MX_Controller Initialized
INFO - 2016-10-08 15:03:54 --> Model Class Initialized
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 15:03:54 --> Model Class Initialized
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 15:03:54 --> Model Class Initialized
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 15:03:54 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 15:03:54 --> Model Class Initialized
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 15:03:54 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 15:03:54 --> Model Class Initialized
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 15:03:54 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 15:03:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 15:03:54 --> Final output sent to browser
DEBUG - 2016-10-08 15:03:54 --> Total execution time: 0.0567
INFO - 2016-10-08 15:09:05 --> Config Class Initialized
INFO - 2016-10-08 15:09:05 --> Hooks Class Initialized
DEBUG - 2016-10-08 15:09:05 --> UTF-8 Support Enabled
INFO - 2016-10-08 15:09:05 --> Utf8 Class Initialized
INFO - 2016-10-08 15:09:05 --> URI Class Initialized
INFO - 2016-10-08 15:09:05 --> Router Class Initialized
INFO - 2016-10-08 15:09:05 --> Output Class Initialized
INFO - 2016-10-08 15:09:05 --> Security Class Initialized
DEBUG - 2016-10-08 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 15:09:05 --> Input Class Initialized
INFO - 2016-10-08 15:09:05 --> Language Class Initialized
INFO - 2016-10-08 15:09:05 --> Language Class Initialized
INFO - 2016-10-08 15:09:05 --> Config Class Initialized
INFO - 2016-10-08 15:09:05 --> Loader Class Initialized
INFO - 2016-10-08 15:09:05 --> Helper loaded: common_helper
INFO - 2016-10-08 15:09:05 --> Helper loaded: url_helper
INFO - 2016-10-08 15:09:05 --> Database Driver Class Initialized
INFO - 2016-10-08 15:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 15:09:05 --> Parser Class Initialized
INFO - 2016-10-08 15:09:05 --> Controller Class Initialized
DEBUG - 2016-10-08 15:09:05 --> Content MX_Controller Initialized
INFO - 2016-10-08 15:09:05 --> Model Class Initialized
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 15:09:05 --> Model Class Initialized
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 15:09:05 --> Model Class Initialized
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 15:09:05 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 15:09:05 --> Model Class Initialized
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 15:09:05 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 15:09:05 --> Model Class Initialized
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 15:09:05 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 15:09:05 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 15:09:05 --> Final output sent to browser
DEBUG - 2016-10-08 15:09:05 --> Total execution time: 0.0777
INFO - 2016-10-08 15:31:03 --> Config Class Initialized
INFO - 2016-10-08 15:31:03 --> Hooks Class Initialized
DEBUG - 2016-10-08 15:31:03 --> UTF-8 Support Enabled
INFO - 2016-10-08 15:31:03 --> Utf8 Class Initialized
INFO - 2016-10-08 15:31:03 --> URI Class Initialized
INFO - 2016-10-08 15:31:03 --> Router Class Initialized
INFO - 2016-10-08 15:31:03 --> Output Class Initialized
INFO - 2016-10-08 15:31:03 --> Security Class Initialized
DEBUG - 2016-10-08 15:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 15:31:03 --> Input Class Initialized
INFO - 2016-10-08 15:31:03 --> Language Class Initialized
INFO - 2016-10-08 15:31:03 --> Language Class Initialized
INFO - 2016-10-08 15:31:03 --> Config Class Initialized
INFO - 2016-10-08 15:31:03 --> Loader Class Initialized
INFO - 2016-10-08 15:31:03 --> Helper loaded: common_helper
INFO - 2016-10-08 15:31:03 --> Helper loaded: url_helper
INFO - 2016-10-08 15:31:03 --> Database Driver Class Initialized
INFO - 2016-10-08 15:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 15:31:03 --> Parser Class Initialized
INFO - 2016-10-08 15:31:03 --> Controller Class Initialized
DEBUG - 2016-10-08 15:31:03 --> Home MX_Controller Initialized
INFO - 2016-10-08 15:31:03 --> Model Class Initialized
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 15:31:03 --> Model Class Initialized
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 15:31:03 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 15:31:03 --> Model Class Initialized
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 15:31:03 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 15:31:03 --> Model Class Initialized
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 15:31:03 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 15:31:03 --> Model Class Initialized
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 15:31:03 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 15:31:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 15:31:03 --> Final output sent to browser
DEBUG - 2016-10-08 15:31:03 --> Total execution time: 0.0608
INFO - 2016-10-08 15:55:07 --> Config Class Initialized
INFO - 2016-10-08 15:55:07 --> Hooks Class Initialized
DEBUG - 2016-10-08 15:55:07 --> UTF-8 Support Enabled
INFO - 2016-10-08 15:55:07 --> Utf8 Class Initialized
INFO - 2016-10-08 15:55:07 --> URI Class Initialized
INFO - 2016-10-08 15:55:07 --> Router Class Initialized
INFO - 2016-10-08 15:55:07 --> Output Class Initialized
INFO - 2016-10-08 15:55:07 --> Security Class Initialized
DEBUG - 2016-10-08 15:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 15:55:07 --> Input Class Initialized
INFO - 2016-10-08 15:55:07 --> Language Class Initialized
ERROR - 2016-10-08 15:55:07 --> 404 Page Not Found: /index
INFO - 2016-10-08 15:55:07 --> Config Class Initialized
INFO - 2016-10-08 15:55:07 --> Hooks Class Initialized
DEBUG - 2016-10-08 15:55:07 --> UTF-8 Support Enabled
INFO - 2016-10-08 15:55:07 --> Utf8 Class Initialized
INFO - 2016-10-08 15:55:07 --> URI Class Initialized
INFO - 2016-10-08 15:55:07 --> Router Class Initialized
INFO - 2016-10-08 15:55:07 --> Output Class Initialized
INFO - 2016-10-08 15:55:07 --> Security Class Initialized
DEBUG - 2016-10-08 15:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 15:55:07 --> Input Class Initialized
INFO - 2016-10-08 15:55:07 --> Language Class Initialized
INFO - 2016-10-08 15:55:07 --> Language Class Initialized
INFO - 2016-10-08 15:55:07 --> Config Class Initialized
INFO - 2016-10-08 15:55:07 --> Loader Class Initialized
INFO - 2016-10-08 15:55:07 --> Helper loaded: common_helper
INFO - 2016-10-08 15:55:07 --> Helper loaded: url_helper
INFO - 2016-10-08 15:55:07 --> Database Driver Class Initialized
INFO - 2016-10-08 15:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 15:55:07 --> Parser Class Initialized
INFO - 2016-10-08 15:55:07 --> Controller Class Initialized
DEBUG - 2016-10-08 15:55:07 --> Servers MX_Controller Initialized
INFO - 2016-10-08 15:55:07 --> Model Class Initialized
DEBUG - 2016-10-08 15:55:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 15:55:07 --> Model Class Initialized
DEBUG - 2016-10-08 15:55:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 15:55:07 --> Model Class Initialized
INFO - 2016-10-08 15:55:08 --> Config Class Initialized
INFO - 2016-10-08 15:55:08 --> Hooks Class Initialized
DEBUG - 2016-10-08 15:55:08 --> UTF-8 Support Enabled
INFO - 2016-10-08 15:55:08 --> Utf8 Class Initialized
INFO - 2016-10-08 15:55:08 --> URI Class Initialized
INFO - 2016-10-08 15:55:08 --> Router Class Initialized
INFO - 2016-10-08 15:55:08 --> Output Class Initialized
INFO - 2016-10-08 15:55:08 --> Security Class Initialized
DEBUG - 2016-10-08 15:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 15:55:08 --> Input Class Initialized
INFO - 2016-10-08 15:55:08 --> Language Class Initialized
INFO - 2016-10-08 15:55:08 --> Language Class Initialized
INFO - 2016-10-08 15:55:08 --> Config Class Initialized
INFO - 2016-10-08 15:55:08 --> Loader Class Initialized
INFO - 2016-10-08 15:55:08 --> Helper loaded: common_helper
INFO - 2016-10-08 15:55:08 --> Helper loaded: url_helper
INFO - 2016-10-08 15:55:08 --> Database Driver Class Initialized
INFO - 2016-10-08 15:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 15:55:08 --> Parser Class Initialized
INFO - 2016-10-08 15:55:08 --> Controller Class Initialized
DEBUG - 2016-10-08 15:55:08 --> Home MX_Controller Initialized
INFO - 2016-10-08 15:55:08 --> Model Class Initialized
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 15:55:08 --> Model Class Initialized
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 15:55:08 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 15:55:08 --> Model Class Initialized
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 15:55:08 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 15:55:08 --> Model Class Initialized
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 15:55:08 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 15:55:08 --> Model Class Initialized
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 15:55:08 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 15:55:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 15:55:08 --> Final output sent to browser
DEBUG - 2016-10-08 15:55:08 --> Total execution time: 0.0554
INFO - 2016-10-08 16:50:07 --> Config Class Initialized
INFO - 2016-10-08 16:50:07 --> Hooks Class Initialized
DEBUG - 2016-10-08 16:50:07 --> UTF-8 Support Enabled
INFO - 2016-10-08 16:50:07 --> Utf8 Class Initialized
INFO - 2016-10-08 16:50:07 --> URI Class Initialized
INFO - 2016-10-08 16:50:07 --> Router Class Initialized
INFO - 2016-10-08 16:50:07 --> Output Class Initialized
INFO - 2016-10-08 16:50:07 --> Security Class Initialized
DEBUG - 2016-10-08 16:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 16:50:07 --> Input Class Initialized
INFO - 2016-10-08 16:50:07 --> Language Class Initialized
INFO - 2016-10-08 16:50:07 --> Language Class Initialized
INFO - 2016-10-08 16:50:07 --> Config Class Initialized
INFO - 2016-10-08 16:50:07 --> Loader Class Initialized
INFO - 2016-10-08 16:50:07 --> Helper loaded: common_helper
INFO - 2016-10-08 16:50:07 --> Helper loaded: url_helper
INFO - 2016-10-08 16:50:07 --> Database Driver Class Initialized
INFO - 2016-10-08 16:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 16:50:07 --> Parser Class Initialized
INFO - 2016-10-08 16:50:07 --> Controller Class Initialized
DEBUG - 2016-10-08 16:50:07 --> User MX_Controller Initialized
INFO - 2016-10-08 16:50:07 --> Model Class Initialized
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-08 16:50:07 --> Model Class Initialized
INFO - 2016-10-08 16:50:07 --> Helper loaded: cookie_helper
INFO - 2016-10-08 16:50:07 --> Helper loaded: form_helper
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 16:50:07 --> Model Class Initialized
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 16:50:07 --> Model Class Initialized
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/forgot_password.php
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 16:50:07 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 16:50:07 --> Model Class Initialized
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 16:50:07 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 16:50:07 --> Model Class Initialized
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 16:50:07 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 16:50:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 16:50:07 --> Final output sent to browser
DEBUG - 2016-10-08 16:50:07 --> Total execution time: 0.0584
INFO - 2016-10-08 16:51:33 --> Config Class Initialized
INFO - 2016-10-08 16:51:33 --> Hooks Class Initialized
DEBUG - 2016-10-08 16:51:33 --> UTF-8 Support Enabled
INFO - 2016-10-08 16:51:33 --> Utf8 Class Initialized
INFO - 2016-10-08 16:51:33 --> URI Class Initialized
INFO - 2016-10-08 16:51:33 --> Router Class Initialized
INFO - 2016-10-08 16:51:33 --> Output Class Initialized
INFO - 2016-10-08 16:51:33 --> Security Class Initialized
DEBUG - 2016-10-08 16:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 16:51:33 --> Input Class Initialized
INFO - 2016-10-08 16:51:33 --> Language Class Initialized
ERROR - 2016-10-08 16:51:33 --> 404 Page Not Found: /index
INFO - 2016-10-08 16:51:34 --> Config Class Initialized
INFO - 2016-10-08 16:51:34 --> Hooks Class Initialized
DEBUG - 2016-10-08 16:51:34 --> UTF-8 Support Enabled
INFO - 2016-10-08 16:51:34 --> Utf8 Class Initialized
INFO - 2016-10-08 16:51:34 --> URI Class Initialized
INFO - 2016-10-08 16:51:34 --> Router Class Initialized
INFO - 2016-10-08 16:51:34 --> Output Class Initialized
INFO - 2016-10-08 16:51:34 --> Security Class Initialized
DEBUG - 2016-10-08 16:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 16:51:34 --> Input Class Initialized
INFO - 2016-10-08 16:51:34 --> Language Class Initialized
INFO - 2016-10-08 16:51:34 --> Language Class Initialized
INFO - 2016-10-08 16:51:34 --> Config Class Initialized
INFO - 2016-10-08 16:51:34 --> Loader Class Initialized
INFO - 2016-10-08 16:51:34 --> Helper loaded: common_helper
INFO - 2016-10-08 16:51:34 --> Helper loaded: url_helper
INFO - 2016-10-08 16:51:34 --> Database Driver Class Initialized
INFO - 2016-10-08 16:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 16:51:34 --> Parser Class Initialized
INFO - 2016-10-08 16:51:34 --> Controller Class Initialized
DEBUG - 2016-10-08 16:51:34 --> User MX_Controller Initialized
INFO - 2016-10-08 16:51:34 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-08 16:51:34 --> Model Class Initialized
INFO - 2016-10-08 16:51:34 --> Helper loaded: cookie_helper
INFO - 2016-10-08 16:51:34 --> Helper loaded: form_helper
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 16:51:34 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 16:51:34 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/forgot_password.php
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 16:51:34 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 16:51:34 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 16:51:34 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 16:51:34 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 16:51:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 16:51:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 16:51:34 --> Final output sent to browser
DEBUG - 2016-10-08 16:51:34 --> Total execution time: 0.0639
INFO - 2016-10-08 16:51:39 --> Config Class Initialized
INFO - 2016-10-08 16:51:39 --> Hooks Class Initialized
DEBUG - 2016-10-08 16:51:39 --> UTF-8 Support Enabled
INFO - 2016-10-08 16:51:39 --> Utf8 Class Initialized
INFO - 2016-10-08 16:51:39 --> URI Class Initialized
INFO - 2016-10-08 16:51:39 --> Router Class Initialized
INFO - 2016-10-08 16:51:39 --> Output Class Initialized
INFO - 2016-10-08 16:51:39 --> Security Class Initialized
DEBUG - 2016-10-08 16:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 16:51:39 --> Input Class Initialized
INFO - 2016-10-08 16:51:39 --> Language Class Initialized
ERROR - 2016-10-08 16:51:39 --> 404 Page Not Found: /index
INFO - 2016-10-08 16:51:40 --> Config Class Initialized
INFO - 2016-10-08 16:51:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 16:51:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 16:51:40 --> Utf8 Class Initialized
INFO - 2016-10-08 16:51:40 --> URI Class Initialized
INFO - 2016-10-08 16:51:40 --> Router Class Initialized
INFO - 2016-10-08 16:51:40 --> Output Class Initialized
INFO - 2016-10-08 16:51:40 --> Security Class Initialized
DEBUG - 2016-10-08 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 16:51:40 --> Input Class Initialized
INFO - 2016-10-08 16:51:40 --> Language Class Initialized
ERROR - 2016-10-08 16:51:40 --> 404 Page Not Found: /index
INFO - 2016-10-08 16:51:41 --> Config Class Initialized
INFO - 2016-10-08 16:51:41 --> Hooks Class Initialized
DEBUG - 2016-10-08 16:51:41 --> UTF-8 Support Enabled
INFO - 2016-10-08 16:51:41 --> Utf8 Class Initialized
INFO - 2016-10-08 16:51:41 --> URI Class Initialized
INFO - 2016-10-08 16:51:41 --> Router Class Initialized
INFO - 2016-10-08 16:51:41 --> Output Class Initialized
INFO - 2016-10-08 16:51:41 --> Security Class Initialized
DEBUG - 2016-10-08 16:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 16:51:41 --> Input Class Initialized
INFO - 2016-10-08 16:51:41 --> Language Class Initialized
ERROR - 2016-10-08 16:51:41 --> 404 Page Not Found: /index
INFO - 2016-10-08 16:51:42 --> Config Class Initialized
INFO - 2016-10-08 16:51:42 --> Hooks Class Initialized
DEBUG - 2016-10-08 16:51:42 --> UTF-8 Support Enabled
INFO - 2016-10-08 16:51:42 --> Utf8 Class Initialized
INFO - 2016-10-08 16:51:42 --> URI Class Initialized
INFO - 2016-10-08 16:51:42 --> Router Class Initialized
INFO - 2016-10-08 16:51:42 --> Output Class Initialized
INFO - 2016-10-08 16:51:42 --> Security Class Initialized
DEBUG - 2016-10-08 16:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 16:51:42 --> Input Class Initialized
INFO - 2016-10-08 16:51:42 --> Language Class Initialized
ERROR - 2016-10-08 16:51:42 --> 404 Page Not Found: /index
INFO - 2016-10-08 16:51:47 --> Config Class Initialized
INFO - 2016-10-08 16:51:47 --> Hooks Class Initialized
DEBUG - 2016-10-08 16:51:47 --> UTF-8 Support Enabled
INFO - 2016-10-08 16:51:47 --> Utf8 Class Initialized
INFO - 2016-10-08 16:51:47 --> URI Class Initialized
INFO - 2016-10-08 16:51:47 --> Router Class Initialized
INFO - 2016-10-08 16:51:47 --> Output Class Initialized
INFO - 2016-10-08 16:51:47 --> Security Class Initialized
DEBUG - 2016-10-08 16:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 16:51:47 --> Input Class Initialized
INFO - 2016-10-08 16:51:47 --> Language Class Initialized
INFO - 2016-10-08 16:51:47 --> Language Class Initialized
INFO - 2016-10-08 16:51:47 --> Config Class Initialized
INFO - 2016-10-08 16:51:47 --> Loader Class Initialized
INFO - 2016-10-08 16:51:47 --> Helper loaded: common_helper
INFO - 2016-10-08 16:51:47 --> Helper loaded: url_helper
INFO - 2016-10-08 16:51:47 --> Database Driver Class Initialized
INFO - 2016-10-08 16:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 16:51:47 --> Parser Class Initialized
INFO - 2016-10-08 16:51:47 --> Controller Class Initialized
DEBUG - 2016-10-08 16:51:47 --> Content MX_Controller Initialized
INFO - 2016-10-08 16:51:47 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 16:51:47 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 16:51:47 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 16:51:47 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 16:51:47 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 16:51:47 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 16:51:47 --> Model Class Initialized
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 16:51:47 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 16:51:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 16:51:47 --> Final output sent to browser
DEBUG - 2016-10-08 16:51:47 --> Total execution time: 0.0598
INFO - 2016-10-08 17:26:37 --> Config Class Initialized
INFO - 2016-10-08 17:26:37 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:26:37 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:26:37 --> Utf8 Class Initialized
INFO - 2016-10-08 17:26:37 --> URI Class Initialized
INFO - 2016-10-08 17:26:37 --> Router Class Initialized
INFO - 2016-10-08 17:26:37 --> Output Class Initialized
INFO - 2016-10-08 17:26:37 --> Security Class Initialized
DEBUG - 2016-10-08 17:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:26:37 --> Input Class Initialized
INFO - 2016-10-08 17:26:37 --> Language Class Initialized
INFO - 2016-10-08 17:26:37 --> Language Class Initialized
INFO - 2016-10-08 17:26:37 --> Config Class Initialized
INFO - 2016-10-08 17:26:37 --> Loader Class Initialized
INFO - 2016-10-08 17:26:37 --> Helper loaded: common_helper
INFO - 2016-10-08 17:26:37 --> Helper loaded: url_helper
INFO - 2016-10-08 17:26:37 --> Database Driver Class Initialized
INFO - 2016-10-08 17:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:26:37 --> Parser Class Initialized
INFO - 2016-10-08 17:26:37 --> Controller Class Initialized
DEBUG - 2016-10-08 17:26:37 --> User MX_Controller Initialized
INFO - 2016-10-08 17:26:37 --> Model Class Initialized
DEBUG - 2016-10-08 17:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-08 17:26:37 --> Model Class Initialized
INFO - 2016-10-08 17:26:37 --> Helper loaded: cookie_helper
INFO - 2016-10-08 17:26:37 --> Helper loaded: form_helper
DEBUG - 2016-10-08 17:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 17:26:37 --> Model Class Initialized
DEBUG - 2016-10-08 17:26:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 17:26:37 --> Model Class Initialized
ERROR - 2016-10-08 17:26:37 --> Severity: Notice --> Use of undefined constant REDIRECT_URL - assumed 'REDIRECT_URL' /home/dolongpk/public_html/application/helpers/common_helper.php 895
ERROR - 2016-10-08 17:26:37 --> Severity: Notice --> Use of undefined constant YH_CLIENT_KEY - assumed 'YH_CLIENT_KEY' /home/dolongpk/public_html/application/helpers/common_helper.php 897
INFO - 2016-10-08 17:37:17 --> Config Class Initialized
INFO - 2016-10-08 17:37:17 --> Hooks Class Initialized
DEBUG - 2016-10-08 17:37:17 --> UTF-8 Support Enabled
INFO - 2016-10-08 17:37:17 --> Utf8 Class Initialized
INFO - 2016-10-08 17:37:17 --> URI Class Initialized
INFO - 2016-10-08 17:37:17 --> Router Class Initialized
INFO - 2016-10-08 17:37:17 --> Output Class Initialized
INFO - 2016-10-08 17:37:17 --> Security Class Initialized
DEBUG - 2016-10-08 17:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 17:37:17 --> Input Class Initialized
INFO - 2016-10-08 17:37:17 --> Language Class Initialized
INFO - 2016-10-08 17:37:17 --> Language Class Initialized
INFO - 2016-10-08 17:37:17 --> Config Class Initialized
INFO - 2016-10-08 17:37:17 --> Loader Class Initialized
INFO - 2016-10-08 17:37:17 --> Helper loaded: common_helper
INFO - 2016-10-08 17:37:17 --> Helper loaded: url_helper
INFO - 2016-10-08 17:37:17 --> Database Driver Class Initialized
INFO - 2016-10-08 17:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 17:37:17 --> Parser Class Initialized
INFO - 2016-10-08 17:37:17 --> Controller Class Initialized
DEBUG - 2016-10-08 17:37:17 --> Content MX_Controller Initialized
INFO - 2016-10-08 17:37:17 --> Model Class Initialized
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 17:37:17 --> Model Class Initialized
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 17:37:17 --> Model Class Initialized
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 17:37:17 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 17:37:17 --> Model Class Initialized
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 17:37:17 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 17:37:17 --> Model Class Initialized
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 17:37:17 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 17:37:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 17:37:17 --> Final output sent to browser
DEBUG - 2016-10-08 17:37:17 --> Total execution time: 0.0596
INFO - 2016-10-08 18:30:36 --> Config Class Initialized
INFO - 2016-10-08 18:30:36 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:30:36 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:30:36 --> Utf8 Class Initialized
INFO - 2016-10-08 18:30:36 --> URI Class Initialized
DEBUG - 2016-10-08 18:30:36 --> No URI present. Default controller set.
INFO - 2016-10-08 18:30:36 --> Router Class Initialized
INFO - 2016-10-08 18:30:36 --> Output Class Initialized
INFO - 2016-10-08 18:30:36 --> Security Class Initialized
DEBUG - 2016-10-08 18:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:30:36 --> Input Class Initialized
INFO - 2016-10-08 18:30:36 --> Language Class Initialized
INFO - 2016-10-08 18:30:36 --> Language Class Initialized
INFO - 2016-10-08 18:30:36 --> Config Class Initialized
INFO - 2016-10-08 18:30:36 --> Loader Class Initialized
INFO - 2016-10-08 18:30:36 --> Helper loaded: common_helper
INFO - 2016-10-08 18:30:36 --> Helper loaded: url_helper
INFO - 2016-10-08 18:30:36 --> Database Driver Class Initialized
INFO - 2016-10-08 18:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:30:36 --> Parser Class Initialized
INFO - 2016-10-08 18:30:36 --> Controller Class Initialized
DEBUG - 2016-10-08 18:30:36 --> Home MX_Controller Initialized
INFO - 2016-10-08 18:30:36 --> Model Class Initialized
DEBUG - 2016-10-08 18:30:36 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 18:30:36 --> Model Class Initialized
ERROR - 2016-10-08 18:30:36 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 18:30:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 18:30:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 18:30:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-08 18:30:36 --> Final output sent to browser
DEBUG - 2016-10-08 18:30:36 --> Total execution time: 0.0497
INFO - 2016-10-08 18:30:38 --> Config Class Initialized
INFO - 2016-10-08 18:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:30:38 --> Utf8 Class Initialized
INFO - 2016-10-08 18:30:38 --> URI Class Initialized
INFO - 2016-10-08 18:30:38 --> Router Class Initialized
INFO - 2016-10-08 18:30:38 --> Output Class Initialized
INFO - 2016-10-08 18:30:38 --> Security Class Initialized
DEBUG - 2016-10-08 18:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:30:38 --> Input Class Initialized
INFO - 2016-10-08 18:30:38 --> Language Class Initialized
INFO - 2016-10-08 18:30:38 --> Language Class Initialized
INFO - 2016-10-08 18:30:38 --> Config Class Initialized
INFO - 2016-10-08 18:30:38 --> Loader Class Initialized
INFO - 2016-10-08 18:30:38 --> Helper loaded: common_helper
INFO - 2016-10-08 18:30:38 --> Helper loaded: url_helper
INFO - 2016-10-08 18:30:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:30:38 --> Parser Class Initialized
INFO - 2016-10-08 18:30:38 --> Controller Class Initialized
DEBUG - 2016-10-08 18:30:38 --> Popup MX_Controller Initialized
INFO - 2016-10-08 18:30:38 --> Model Class Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-08 18:30:38 --> Model Class Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-08 18:30:38 --> Final output sent to browser
DEBUG - 2016-10-08 18:30:38 --> Total execution time: 0.0435
INFO - 2016-10-08 18:30:38 --> Config Class Initialized
INFO - 2016-10-08 18:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:30:38 --> Utf8 Class Initialized
INFO - 2016-10-08 18:30:38 --> URI Class Initialized
INFO - 2016-10-08 18:30:38 --> Router Class Initialized
INFO - 2016-10-08 18:30:38 --> Output Class Initialized
INFO - 2016-10-08 18:30:38 --> Security Class Initialized
DEBUG - 2016-10-08 18:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:30:38 --> Input Class Initialized
INFO - 2016-10-08 18:30:38 --> Language Class Initialized
INFO - 2016-10-08 18:30:38 --> Language Class Initialized
INFO - 2016-10-08 18:30:38 --> Config Class Initialized
INFO - 2016-10-08 18:30:38 --> Loader Class Initialized
INFO - 2016-10-08 18:30:38 --> Helper loaded: common_helper
INFO - 2016-10-08 18:30:38 --> Helper loaded: url_helper
INFO - 2016-10-08 18:30:38 --> Database Driver Class Initialized
INFO - 2016-10-08 18:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:30:38 --> Parser Class Initialized
INFO - 2016-10-08 18:30:38 --> Controller Class Initialized
DEBUG - 2016-10-08 18:30:38 --> Home MX_Controller Initialized
INFO - 2016-10-08 18:30:38 --> Model Class Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 18:30:38 --> Model Class Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 18:30:38 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 18:30:38 --> Model Class Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 18:30:38 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 18:30:38 --> Model Class Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 18:30:38 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 18:30:38 --> Model Class Initialized
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 18:30:38 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 18:30:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 18:30:38 --> Final output sent to browser
DEBUG - 2016-10-08 18:30:38 --> Total execution time: 0.0511
INFO - 2016-10-08 18:30:38 --> Config Class Initialized
INFO - 2016-10-08 18:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:30:38 --> Utf8 Class Initialized
INFO - 2016-10-08 18:30:38 --> URI Class Initialized
INFO - 2016-10-08 18:30:38 --> Router Class Initialized
INFO - 2016-10-08 18:30:38 --> Output Class Initialized
INFO - 2016-10-08 18:30:38 --> Security Class Initialized
DEBUG - 2016-10-08 18:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:30:38 --> Input Class Initialized
INFO - 2016-10-08 18:30:38 --> Language Class Initialized
ERROR - 2016-10-08 18:30:38 --> 404 Page Not Found: /index
INFO - 2016-10-08 18:31:06 --> Config Class Initialized
INFO - 2016-10-08 18:31:06 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:06 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:06 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:06 --> URI Class Initialized
INFO - 2016-10-08 18:31:06 --> Router Class Initialized
INFO - 2016-10-08 18:31:06 --> Output Class Initialized
INFO - 2016-10-08 18:31:06 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:06 --> Input Class Initialized
INFO - 2016-10-08 18:31:06 --> Language Class Initialized
INFO - 2016-10-08 18:31:06 --> Language Class Initialized
INFO - 2016-10-08 18:31:06 --> Config Class Initialized
INFO - 2016-10-08 18:31:06 --> Loader Class Initialized
INFO - 2016-10-08 18:31:06 --> Helper loaded: common_helper
INFO - 2016-10-08 18:31:06 --> Helper loaded: url_helper
INFO - 2016-10-08 18:31:06 --> Database Driver Class Initialized
INFO - 2016-10-08 18:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:31:06 --> Parser Class Initialized
INFO - 2016-10-08 18:31:06 --> Controller Class Initialized
DEBUG - 2016-10-08 18:31:06 --> Home MX_Controller Initialized
INFO - 2016-10-08 18:31:06 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 18:31:06 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 18:31:06 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 18:31:06 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 18:31:06 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 18:31:06 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 18:31:06 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 18:31:06 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 18:31:06 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 18:31:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 18:31:06 --> Final output sent to browser
DEBUG - 2016-10-08 18:31:06 --> Total execution time: 0.0766
INFO - 2016-10-08 18:31:06 --> Config Class Initialized
INFO - 2016-10-08 18:31:06 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:06 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:06 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:06 --> URI Class Initialized
INFO - 2016-10-08 18:31:06 --> Router Class Initialized
INFO - 2016-10-08 18:31:06 --> Output Class Initialized
INFO - 2016-10-08 18:31:06 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:06 --> Input Class Initialized
INFO - 2016-10-08 18:31:06 --> Language Class Initialized
ERROR - 2016-10-08 18:31:06 --> 404 Page Not Found: /index
INFO - 2016-10-08 18:31:11 --> Config Class Initialized
INFO - 2016-10-08 18:31:11 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:11 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:11 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:11 --> URI Class Initialized
INFO - 2016-10-08 18:31:11 --> Router Class Initialized
INFO - 2016-10-08 18:31:11 --> Output Class Initialized
INFO - 2016-10-08 18:31:11 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:11 --> Input Class Initialized
INFO - 2016-10-08 18:31:11 --> Language Class Initialized
INFO - 2016-10-08 18:31:11 --> Language Class Initialized
INFO - 2016-10-08 18:31:11 --> Config Class Initialized
INFO - 2016-10-08 18:31:11 --> Loader Class Initialized
INFO - 2016-10-08 18:31:11 --> Helper loaded: common_helper
INFO - 2016-10-08 18:31:11 --> Helper loaded: url_helper
INFO - 2016-10-08 18:31:11 --> Database Driver Class Initialized
INFO - 2016-10-08 18:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:31:11 --> Parser Class Initialized
INFO - 2016-10-08 18:31:11 --> Controller Class Initialized
DEBUG - 2016-10-08 18:31:11 --> User MX_Controller Initialized
INFO - 2016-10-08 18:31:11 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:11 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-08 18:31:11 --> Model Class Initialized
INFO - 2016-10-08 18:31:11 --> Helper loaded: cookie_helper
INFO - 2016-10-08 18:31:11 --> Helper loaded: form_helper
DEBUG - 2016-10-08 18:31:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 18:31:11 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 18:31:11 --> Model Class Initialized
INFO - 2016-10-08 18:31:11 --> Final output sent to browser
DEBUG - 2016-10-08 18:31:11 --> Total execution time: 0.0480
INFO - 2016-10-08 18:31:16 --> Config Class Initialized
INFO - 2016-10-08 18:31:16 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:16 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:16 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:16 --> URI Class Initialized
INFO - 2016-10-08 18:31:16 --> Router Class Initialized
INFO - 2016-10-08 18:31:16 --> Output Class Initialized
INFO - 2016-10-08 18:31:16 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:16 --> Input Class Initialized
INFO - 2016-10-08 18:31:16 --> Language Class Initialized
INFO - 2016-10-08 18:31:16 --> Language Class Initialized
INFO - 2016-10-08 18:31:16 --> Config Class Initialized
INFO - 2016-10-08 18:31:16 --> Loader Class Initialized
INFO - 2016-10-08 18:31:16 --> Helper loaded: common_helper
INFO - 2016-10-08 18:31:16 --> Helper loaded: url_helper
INFO - 2016-10-08 18:31:16 --> Database Driver Class Initialized
INFO - 2016-10-08 18:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:31:16 --> Parser Class Initialized
INFO - 2016-10-08 18:31:16 --> Controller Class Initialized
DEBUG - 2016-10-08 18:31:16 --> Content MX_Controller Initialized
INFO - 2016-10-08 18:31:16 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 18:31:16 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 18:31:16 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 18:31:16 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 18:31:16 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 18:31:16 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 18:31:16 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 18:31:16 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 18:31:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 18:31:16 --> Final output sent to browser
DEBUG - 2016-10-08 18:31:16 --> Total execution time: 0.0804
INFO - 2016-10-08 18:31:16 --> Config Class Initialized
INFO - 2016-10-08 18:31:16 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:16 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:16 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:16 --> URI Class Initialized
INFO - 2016-10-08 18:31:16 --> Router Class Initialized
INFO - 2016-10-08 18:31:16 --> Output Class Initialized
INFO - 2016-10-08 18:31:16 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:16 --> Input Class Initialized
INFO - 2016-10-08 18:31:16 --> Language Class Initialized
ERROR - 2016-10-08 18:31:16 --> 404 Page Not Found: /index
INFO - 2016-10-08 18:31:16 --> Config Class Initialized
INFO - 2016-10-08 18:31:16 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:16 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:16 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:16 --> URI Class Initialized
INFO - 2016-10-08 18:31:16 --> Router Class Initialized
INFO - 2016-10-08 18:31:16 --> Output Class Initialized
INFO - 2016-10-08 18:31:16 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:16 --> Input Class Initialized
INFO - 2016-10-08 18:31:16 --> Language Class Initialized
ERROR - 2016-10-08 18:31:16 --> 404 Page Not Found: /index
INFO - 2016-10-08 18:31:16 --> Config Class Initialized
INFO - 2016-10-08 18:31:16 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:16 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:16 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:16 --> URI Class Initialized
INFO - 2016-10-08 18:31:16 --> Router Class Initialized
INFO - 2016-10-08 18:31:16 --> Output Class Initialized
INFO - 2016-10-08 18:31:16 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:16 --> Input Class Initialized
INFO - 2016-10-08 18:31:16 --> Language Class Initialized
ERROR - 2016-10-08 18:31:16 --> 404 Page Not Found: /index
INFO - 2016-10-08 18:31:20 --> Config Class Initialized
INFO - 2016-10-08 18:31:20 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:20 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:20 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:20 --> URI Class Initialized
INFO - 2016-10-08 18:31:20 --> Router Class Initialized
INFO - 2016-10-08 18:31:20 --> Output Class Initialized
INFO - 2016-10-08 18:31:20 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:20 --> Input Class Initialized
INFO - 2016-10-08 18:31:20 --> Language Class Initialized
INFO - 2016-10-08 18:31:20 --> Language Class Initialized
INFO - 2016-10-08 18:31:20 --> Config Class Initialized
INFO - 2016-10-08 18:31:20 --> Loader Class Initialized
INFO - 2016-10-08 18:31:20 --> Helper loaded: common_helper
INFO - 2016-10-08 18:31:20 --> Helper loaded: url_helper
INFO - 2016-10-08 18:31:20 --> Database Driver Class Initialized
INFO - 2016-10-08 18:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 18:31:20 --> Parser Class Initialized
INFO - 2016-10-08 18:31:20 --> Controller Class Initialized
DEBUG - 2016-10-08 18:31:20 --> User MX_Controller Initialized
INFO - 2016-10-08 18:31:20 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-08 18:31:20 --> Model Class Initialized
INFO - 2016-10-08 18:31:20 --> Helper loaded: cookie_helper
INFO - 2016-10-08 18:31:20 --> Helper loaded: form_helper
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-08 18:31:20 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 18:31:20 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/forgot_password.php
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 18:31:20 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 18:31:20 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 18:31:20 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 18:31:20 --> Model Class Initialized
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 18:31:20 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 18:31:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 18:31:20 --> Final output sent to browser
DEBUG - 2016-10-08 18:31:20 --> Total execution time: 0.0511
INFO - 2016-10-08 18:31:20 --> Config Class Initialized
INFO - 2016-10-08 18:31:20 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:21 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:21 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:21 --> URI Class Initialized
INFO - 2016-10-08 18:31:21 --> Router Class Initialized
INFO - 2016-10-08 18:31:21 --> Output Class Initialized
INFO - 2016-10-08 18:31:21 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:21 --> Input Class Initialized
INFO - 2016-10-08 18:31:21 --> Language Class Initialized
ERROR - 2016-10-08 18:31:21 --> 404 Page Not Found: /index
INFO - 2016-10-08 18:31:21 --> Config Class Initialized
INFO - 2016-10-08 18:31:21 --> Hooks Class Initialized
DEBUG - 2016-10-08 18:31:21 --> UTF-8 Support Enabled
INFO - 2016-10-08 18:31:21 --> Utf8 Class Initialized
INFO - 2016-10-08 18:31:21 --> URI Class Initialized
INFO - 2016-10-08 18:31:21 --> Router Class Initialized
INFO - 2016-10-08 18:31:21 --> Output Class Initialized
INFO - 2016-10-08 18:31:21 --> Security Class Initialized
DEBUG - 2016-10-08 18:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 18:31:21 --> Input Class Initialized
INFO - 2016-10-08 18:31:21 --> Language Class Initialized
ERROR - 2016-10-08 18:31:21 --> 404 Page Not Found: /index
INFO - 2016-10-08 20:55:37 --> Config Class Initialized
INFO - 2016-10-08 20:55:37 --> Hooks Class Initialized
DEBUG - 2016-10-08 20:55:37 --> UTF-8 Support Enabled
INFO - 2016-10-08 20:55:37 --> Utf8 Class Initialized
INFO - 2016-10-08 20:55:37 --> URI Class Initialized
INFO - 2016-10-08 20:55:37 --> Router Class Initialized
INFO - 2016-10-08 20:55:37 --> Output Class Initialized
INFO - 2016-10-08 20:55:37 --> Security Class Initialized
DEBUG - 2016-10-08 20:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 20:55:37 --> Input Class Initialized
INFO - 2016-10-08 20:55:37 --> Language Class Initialized
INFO - 2016-10-08 20:55:37 --> Language Class Initialized
INFO - 2016-10-08 20:55:37 --> Config Class Initialized
INFO - 2016-10-08 20:55:37 --> Loader Class Initialized
INFO - 2016-10-08 20:55:37 --> Helper loaded: common_helper
INFO - 2016-10-08 20:55:37 --> Helper loaded: url_helper
INFO - 2016-10-08 20:55:37 --> Database Driver Class Initialized
INFO - 2016-10-08 20:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 20:55:37 --> Parser Class Initialized
INFO - 2016-10-08 20:55:37 --> Controller Class Initialized
DEBUG - 2016-10-08 20:55:37 --> Home MX_Controller Initialized
INFO - 2016-10-08 20:55:37 --> Model Class Initialized
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 20:55:37 --> Model Class Initialized
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 20:55:37 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 20:55:37 --> Model Class Initialized
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 20:55:37 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 20:55:37 --> Model Class Initialized
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 20:55:37 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 20:55:37 --> Model Class Initialized
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 20:55:37 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 20:55:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 20:55:37 --> Final output sent to browser
DEBUG - 2016-10-08 20:55:37 --> Total execution time: 0.0629
INFO - 2016-10-08 21:58:32 --> Config Class Initialized
INFO - 2016-10-08 21:58:32 --> Hooks Class Initialized
DEBUG - 2016-10-08 21:58:32 --> UTF-8 Support Enabled
INFO - 2016-10-08 21:58:32 --> Utf8 Class Initialized
INFO - 2016-10-08 21:58:32 --> URI Class Initialized
INFO - 2016-10-08 21:58:32 --> Router Class Initialized
INFO - 2016-10-08 21:58:32 --> Output Class Initialized
INFO - 2016-10-08 21:58:32 --> Security Class Initialized
DEBUG - 2016-10-08 21:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 21:58:32 --> Input Class Initialized
INFO - 2016-10-08 21:58:32 --> Language Class Initialized
INFO - 2016-10-08 21:58:32 --> Language Class Initialized
INFO - 2016-10-08 21:58:32 --> Config Class Initialized
INFO - 2016-10-08 21:58:32 --> Loader Class Initialized
INFO - 2016-10-08 21:58:32 --> Helper loaded: common_helper
INFO - 2016-10-08 21:58:32 --> Helper loaded: url_helper
INFO - 2016-10-08 21:58:32 --> Database Driver Class Initialized
INFO - 2016-10-08 21:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 21:58:32 --> Parser Class Initialized
INFO - 2016-10-08 21:58:32 --> Controller Class Initialized
DEBUG - 2016-10-08 21:58:32 --> Servers MX_Controller Initialized
INFO - 2016-10-08 21:58:32 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 21:58:32 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 21:58:32 --> Model Class Initialized
INFO - 2016-10-08 21:58:33 --> Config Class Initialized
INFO - 2016-10-08 21:58:33 --> Hooks Class Initialized
DEBUG - 2016-10-08 21:58:33 --> UTF-8 Support Enabled
INFO - 2016-10-08 21:58:33 --> Utf8 Class Initialized
INFO - 2016-10-08 21:58:33 --> URI Class Initialized
INFO - 2016-10-08 21:58:33 --> Router Class Initialized
INFO - 2016-10-08 21:58:33 --> Output Class Initialized
INFO - 2016-10-08 21:58:33 --> Security Class Initialized
DEBUG - 2016-10-08 21:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 21:58:33 --> Input Class Initialized
INFO - 2016-10-08 21:58:33 --> Language Class Initialized
INFO - 2016-10-08 21:58:33 --> Language Class Initialized
INFO - 2016-10-08 21:58:33 --> Config Class Initialized
INFO - 2016-10-08 21:58:33 --> Loader Class Initialized
INFO - 2016-10-08 21:58:33 --> Helper loaded: common_helper
INFO - 2016-10-08 21:58:33 --> Helper loaded: url_helper
INFO - 2016-10-08 21:58:33 --> Database Driver Class Initialized
INFO - 2016-10-08 21:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 21:58:33 --> Parser Class Initialized
INFO - 2016-10-08 21:58:33 --> Controller Class Initialized
DEBUG - 2016-10-08 21:58:33 --> Home MX_Controller Initialized
INFO - 2016-10-08 21:58:33 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 21:58:33 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 21:58:33 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 21:58:33 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 21:58:33 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 21:58:33 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 21:58:33 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 21:58:33 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 21:58:33 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 21:58:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 21:58:33 --> Final output sent to browser
DEBUG - 2016-10-08 21:58:33 --> Total execution time: 0.0752
INFO - 2016-10-08 21:58:54 --> Config Class Initialized
INFO - 2016-10-08 21:58:54 --> Hooks Class Initialized
DEBUG - 2016-10-08 21:58:54 --> UTF-8 Support Enabled
INFO - 2016-10-08 21:58:54 --> Utf8 Class Initialized
INFO - 2016-10-08 21:58:54 --> URI Class Initialized
INFO - 2016-10-08 21:58:54 --> Router Class Initialized
INFO - 2016-10-08 21:58:54 --> Output Class Initialized
INFO - 2016-10-08 21:58:54 --> Security Class Initialized
DEBUG - 2016-10-08 21:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 21:58:54 --> Input Class Initialized
INFO - 2016-10-08 21:58:54 --> Language Class Initialized
INFO - 2016-10-08 21:58:54 --> Language Class Initialized
INFO - 2016-10-08 21:58:54 --> Config Class Initialized
INFO - 2016-10-08 21:58:54 --> Loader Class Initialized
INFO - 2016-10-08 21:58:54 --> Helper loaded: common_helper
INFO - 2016-10-08 21:58:54 --> Helper loaded: url_helper
INFO - 2016-10-08 21:58:54 --> Database Driver Class Initialized
INFO - 2016-10-08 21:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 21:58:54 --> Parser Class Initialized
INFO - 2016-10-08 21:58:54 --> Controller Class Initialized
DEBUG - 2016-10-08 21:58:54 --> Servers MX_Controller Initialized
INFO - 2016-10-08 21:58:54 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 21:58:54 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 21:58:54 --> Model Class Initialized
INFO - 2016-10-08 21:58:54 --> Config Class Initialized
INFO - 2016-10-08 21:58:54 --> Hooks Class Initialized
DEBUG - 2016-10-08 21:58:54 --> UTF-8 Support Enabled
INFO - 2016-10-08 21:58:54 --> Utf8 Class Initialized
INFO - 2016-10-08 21:58:54 --> URI Class Initialized
INFO - 2016-10-08 21:58:54 --> Router Class Initialized
INFO - 2016-10-08 21:58:54 --> Output Class Initialized
INFO - 2016-10-08 21:58:54 --> Security Class Initialized
DEBUG - 2016-10-08 21:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 21:58:54 --> Input Class Initialized
INFO - 2016-10-08 21:58:54 --> Language Class Initialized
INFO - 2016-10-08 21:58:54 --> Language Class Initialized
INFO - 2016-10-08 21:58:54 --> Config Class Initialized
INFO - 2016-10-08 21:58:54 --> Loader Class Initialized
INFO - 2016-10-08 21:58:54 --> Helper loaded: common_helper
INFO - 2016-10-08 21:58:54 --> Helper loaded: url_helper
INFO - 2016-10-08 21:58:54 --> Database Driver Class Initialized
INFO - 2016-10-08 21:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 21:58:54 --> Parser Class Initialized
INFO - 2016-10-08 21:58:54 --> Controller Class Initialized
DEBUG - 2016-10-08 21:58:54 --> Home MX_Controller Initialized
INFO - 2016-10-08 21:58:54 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 21:58:54 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 21:58:54 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 21:58:54 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 21:58:54 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 21:58:54 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 21:58:54 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 21:58:54 --> Model Class Initialized
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 21:58:54 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 21:58:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 21:58:54 --> Final output sent to browser
DEBUG - 2016-10-08 21:58:54 --> Total execution time: 0.0484
INFO - 2016-10-08 21:59:17 --> Config Class Initialized
INFO - 2016-10-08 21:59:17 --> Hooks Class Initialized
DEBUG - 2016-10-08 21:59:17 --> UTF-8 Support Enabled
INFO - 2016-10-08 21:59:17 --> Utf8 Class Initialized
INFO - 2016-10-08 21:59:17 --> URI Class Initialized
INFO - 2016-10-08 21:59:17 --> Router Class Initialized
INFO - 2016-10-08 21:59:17 --> Output Class Initialized
INFO - 2016-10-08 21:59:17 --> Security Class Initialized
DEBUG - 2016-10-08 21:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 21:59:17 --> Input Class Initialized
INFO - 2016-10-08 21:59:17 --> Language Class Initialized
INFO - 2016-10-08 21:59:17 --> Language Class Initialized
INFO - 2016-10-08 21:59:17 --> Config Class Initialized
INFO - 2016-10-08 21:59:17 --> Loader Class Initialized
INFO - 2016-10-08 21:59:17 --> Helper loaded: common_helper
INFO - 2016-10-08 21:59:17 --> Helper loaded: url_helper
INFO - 2016-10-08 21:59:17 --> Database Driver Class Initialized
INFO - 2016-10-08 21:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 21:59:17 --> Parser Class Initialized
INFO - 2016-10-08 21:59:17 --> Controller Class Initialized
DEBUG - 2016-10-08 21:59:17 --> Servers MX_Controller Initialized
INFO - 2016-10-08 21:59:17 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 21:59:17 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 21:59:17 --> Model Class Initialized
INFO - 2016-10-08 21:59:18 --> Config Class Initialized
INFO - 2016-10-08 21:59:18 --> Hooks Class Initialized
DEBUG - 2016-10-08 21:59:18 --> UTF-8 Support Enabled
INFO - 2016-10-08 21:59:18 --> Utf8 Class Initialized
INFO - 2016-10-08 21:59:18 --> URI Class Initialized
INFO - 2016-10-08 21:59:18 --> Router Class Initialized
INFO - 2016-10-08 21:59:18 --> Output Class Initialized
INFO - 2016-10-08 21:59:18 --> Security Class Initialized
DEBUG - 2016-10-08 21:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 21:59:18 --> Input Class Initialized
INFO - 2016-10-08 21:59:18 --> Language Class Initialized
INFO - 2016-10-08 21:59:18 --> Language Class Initialized
INFO - 2016-10-08 21:59:18 --> Config Class Initialized
INFO - 2016-10-08 21:59:18 --> Loader Class Initialized
INFO - 2016-10-08 21:59:18 --> Helper loaded: common_helper
INFO - 2016-10-08 21:59:18 --> Helper loaded: url_helper
INFO - 2016-10-08 21:59:18 --> Database Driver Class Initialized
INFO - 2016-10-08 21:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 21:59:18 --> Parser Class Initialized
INFO - 2016-10-08 21:59:18 --> Controller Class Initialized
DEBUG - 2016-10-08 21:59:18 --> Home MX_Controller Initialized
INFO - 2016-10-08 21:59:18 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 21:59:18 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 21:59:18 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 21:59:18 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 21:59:18 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 21:59:18 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 21:59:18 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 21:59:18 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 21:59:18 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 21:59:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 21:59:18 --> Final output sent to browser
DEBUG - 2016-10-08 21:59:18 --> Total execution time: 0.0647
INFO - 2016-10-08 21:59:40 --> Config Class Initialized
INFO - 2016-10-08 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 21:59:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 21:59:40 --> Utf8 Class Initialized
INFO - 2016-10-08 21:59:40 --> URI Class Initialized
INFO - 2016-10-08 21:59:40 --> Router Class Initialized
INFO - 2016-10-08 21:59:40 --> Output Class Initialized
INFO - 2016-10-08 21:59:40 --> Security Class Initialized
DEBUG - 2016-10-08 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 21:59:40 --> Input Class Initialized
INFO - 2016-10-08 21:59:40 --> Language Class Initialized
INFO - 2016-10-08 21:59:40 --> Language Class Initialized
INFO - 2016-10-08 21:59:40 --> Config Class Initialized
INFO - 2016-10-08 21:59:40 --> Loader Class Initialized
INFO - 2016-10-08 21:59:40 --> Helper loaded: common_helper
INFO - 2016-10-08 21:59:40 --> Helper loaded: url_helper
INFO - 2016-10-08 21:59:40 --> Database Driver Class Initialized
INFO - 2016-10-08 21:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 21:59:40 --> Parser Class Initialized
INFO - 2016-10-08 21:59:40 --> Controller Class Initialized
DEBUG - 2016-10-08 21:59:40 --> Servers MX_Controller Initialized
INFO - 2016-10-08 21:59:40 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 21:59:40 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 21:59:40 --> Model Class Initialized
INFO - 2016-10-08 21:59:40 --> Config Class Initialized
INFO - 2016-10-08 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 21:59:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 21:59:40 --> Utf8 Class Initialized
INFO - 2016-10-08 21:59:40 --> URI Class Initialized
INFO - 2016-10-08 21:59:40 --> Router Class Initialized
INFO - 2016-10-08 21:59:40 --> Output Class Initialized
INFO - 2016-10-08 21:59:40 --> Security Class Initialized
DEBUG - 2016-10-08 21:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 21:59:40 --> Input Class Initialized
INFO - 2016-10-08 21:59:40 --> Language Class Initialized
INFO - 2016-10-08 21:59:40 --> Language Class Initialized
INFO - 2016-10-08 21:59:40 --> Config Class Initialized
INFO - 2016-10-08 21:59:40 --> Loader Class Initialized
INFO - 2016-10-08 21:59:40 --> Helper loaded: common_helper
INFO - 2016-10-08 21:59:40 --> Helper loaded: url_helper
INFO - 2016-10-08 21:59:40 --> Database Driver Class Initialized
INFO - 2016-10-08 21:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 21:59:40 --> Parser Class Initialized
INFO - 2016-10-08 21:59:40 --> Controller Class Initialized
DEBUG - 2016-10-08 21:59:40 --> Home MX_Controller Initialized
INFO - 2016-10-08 21:59:40 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 21:59:40 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 21:59:40 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 21:59:40 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 21:59:40 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 21:59:40 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 21:59:40 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 21:59:40 --> Model Class Initialized
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 21:59:40 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 21:59:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 21:59:40 --> Final output sent to browser
DEBUG - 2016-10-08 21:59:40 --> Total execution time: 0.0621
INFO - 2016-10-08 22:00:02 --> Config Class Initialized
INFO - 2016-10-08 22:00:02 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:00:02 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:00:02 --> Utf8 Class Initialized
INFO - 2016-10-08 22:00:02 --> URI Class Initialized
INFO - 2016-10-08 22:00:02 --> Router Class Initialized
INFO - 2016-10-08 22:00:02 --> Output Class Initialized
INFO - 2016-10-08 22:00:02 --> Security Class Initialized
DEBUG - 2016-10-08 22:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:00:02 --> Input Class Initialized
INFO - 2016-10-08 22:00:02 --> Language Class Initialized
INFO - 2016-10-08 22:00:02 --> Language Class Initialized
INFO - 2016-10-08 22:00:02 --> Config Class Initialized
INFO - 2016-10-08 22:00:02 --> Loader Class Initialized
INFO - 2016-10-08 22:00:02 --> Helper loaded: common_helper
INFO - 2016-10-08 22:00:02 --> Helper loaded: url_helper
INFO - 2016-10-08 22:00:02 --> Database Driver Class Initialized
INFO - 2016-10-08 22:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:00:02 --> Parser Class Initialized
INFO - 2016-10-08 22:00:02 --> Controller Class Initialized
DEBUG - 2016-10-08 22:00:02 --> Servers MX_Controller Initialized
INFO - 2016-10-08 22:00:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:00:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:00:02 --> Model Class Initialized
INFO - 2016-10-08 22:00:03 --> Config Class Initialized
INFO - 2016-10-08 22:00:03 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:00:03 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:00:03 --> Utf8 Class Initialized
INFO - 2016-10-08 22:00:03 --> URI Class Initialized
INFO - 2016-10-08 22:00:03 --> Router Class Initialized
INFO - 2016-10-08 22:00:03 --> Output Class Initialized
INFO - 2016-10-08 22:00:03 --> Security Class Initialized
DEBUG - 2016-10-08 22:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:00:03 --> Input Class Initialized
INFO - 2016-10-08 22:00:03 --> Language Class Initialized
INFO - 2016-10-08 22:00:03 --> Language Class Initialized
INFO - 2016-10-08 22:00:03 --> Config Class Initialized
INFO - 2016-10-08 22:00:03 --> Loader Class Initialized
INFO - 2016-10-08 22:00:03 --> Helper loaded: common_helper
INFO - 2016-10-08 22:00:03 --> Helper loaded: url_helper
INFO - 2016-10-08 22:00:03 --> Database Driver Class Initialized
INFO - 2016-10-08 22:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:00:03 --> Parser Class Initialized
INFO - 2016-10-08 22:00:03 --> Controller Class Initialized
DEBUG - 2016-10-08 22:00:03 --> Home MX_Controller Initialized
INFO - 2016-10-08 22:00:03 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 22:00:03 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 22:00:03 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:00:03 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:00:03 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:00:03 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:00:03 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:00:03 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:00:03 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:00:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:00:03 --> Final output sent to browser
DEBUG - 2016-10-08 22:00:03 --> Total execution time: 0.0572
INFO - 2016-10-08 22:00:25 --> Config Class Initialized
INFO - 2016-10-08 22:00:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:00:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:00:25 --> Utf8 Class Initialized
INFO - 2016-10-08 22:00:25 --> URI Class Initialized
INFO - 2016-10-08 22:00:25 --> Router Class Initialized
INFO - 2016-10-08 22:00:25 --> Output Class Initialized
INFO - 2016-10-08 22:00:25 --> Security Class Initialized
DEBUG - 2016-10-08 22:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:00:25 --> Input Class Initialized
INFO - 2016-10-08 22:00:25 --> Language Class Initialized
INFO - 2016-10-08 22:00:25 --> Language Class Initialized
INFO - 2016-10-08 22:00:25 --> Config Class Initialized
INFO - 2016-10-08 22:00:25 --> Loader Class Initialized
INFO - 2016-10-08 22:00:25 --> Helper loaded: common_helper
INFO - 2016-10-08 22:00:25 --> Helper loaded: url_helper
INFO - 2016-10-08 22:00:25 --> Database Driver Class Initialized
INFO - 2016-10-08 22:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:00:25 --> Parser Class Initialized
INFO - 2016-10-08 22:00:25 --> Controller Class Initialized
DEBUG - 2016-10-08 22:00:25 --> Servers MX_Controller Initialized
INFO - 2016-10-08 22:00:25 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:00:25 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:00:25 --> Model Class Initialized
INFO - 2016-10-08 22:00:25 --> Config Class Initialized
INFO - 2016-10-08 22:00:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:00:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:00:25 --> Utf8 Class Initialized
INFO - 2016-10-08 22:00:25 --> URI Class Initialized
INFO - 2016-10-08 22:00:25 --> Router Class Initialized
INFO - 2016-10-08 22:00:25 --> Output Class Initialized
INFO - 2016-10-08 22:00:25 --> Security Class Initialized
DEBUG - 2016-10-08 22:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:00:25 --> Input Class Initialized
INFO - 2016-10-08 22:00:25 --> Language Class Initialized
INFO - 2016-10-08 22:00:25 --> Language Class Initialized
INFO - 2016-10-08 22:00:25 --> Config Class Initialized
INFO - 2016-10-08 22:00:25 --> Loader Class Initialized
INFO - 2016-10-08 22:00:25 --> Helper loaded: common_helper
INFO - 2016-10-08 22:00:25 --> Helper loaded: url_helper
INFO - 2016-10-08 22:00:25 --> Database Driver Class Initialized
INFO - 2016-10-08 22:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:00:25 --> Parser Class Initialized
INFO - 2016-10-08 22:00:25 --> Controller Class Initialized
DEBUG - 2016-10-08 22:00:25 --> Home MX_Controller Initialized
INFO - 2016-10-08 22:00:25 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 22:00:25 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 22:00:25 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:00:25 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:00:25 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:00:25 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:00:25 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:00:25 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:00:25 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:00:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:00:25 --> Final output sent to browser
DEBUG - 2016-10-08 22:00:25 --> Total execution time: 0.0681
INFO - 2016-10-08 22:00:48 --> Config Class Initialized
INFO - 2016-10-08 22:00:48 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:00:48 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:00:48 --> Utf8 Class Initialized
INFO - 2016-10-08 22:00:48 --> URI Class Initialized
INFO - 2016-10-08 22:00:48 --> Router Class Initialized
INFO - 2016-10-08 22:00:48 --> Output Class Initialized
INFO - 2016-10-08 22:00:48 --> Security Class Initialized
DEBUG - 2016-10-08 22:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:00:48 --> Input Class Initialized
INFO - 2016-10-08 22:00:48 --> Language Class Initialized
INFO - 2016-10-08 22:00:48 --> Language Class Initialized
INFO - 2016-10-08 22:00:48 --> Config Class Initialized
INFO - 2016-10-08 22:00:48 --> Loader Class Initialized
INFO - 2016-10-08 22:00:48 --> Helper loaded: common_helper
INFO - 2016-10-08 22:00:48 --> Helper loaded: url_helper
INFO - 2016-10-08 22:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 22:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:00:48 --> Parser Class Initialized
INFO - 2016-10-08 22:00:48 --> Controller Class Initialized
DEBUG - 2016-10-08 22:00:48 --> Servers MX_Controller Initialized
INFO - 2016-10-08 22:00:48 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:00:48 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:00:48 --> Model Class Initialized
INFO - 2016-10-08 22:00:48 --> Config Class Initialized
INFO - 2016-10-08 22:00:48 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:00:48 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:00:48 --> Utf8 Class Initialized
INFO - 2016-10-08 22:00:48 --> URI Class Initialized
INFO - 2016-10-08 22:00:48 --> Router Class Initialized
INFO - 2016-10-08 22:00:48 --> Output Class Initialized
INFO - 2016-10-08 22:00:48 --> Security Class Initialized
DEBUG - 2016-10-08 22:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:00:48 --> Input Class Initialized
INFO - 2016-10-08 22:00:48 --> Language Class Initialized
INFO - 2016-10-08 22:00:48 --> Language Class Initialized
INFO - 2016-10-08 22:00:48 --> Config Class Initialized
INFO - 2016-10-08 22:00:48 --> Loader Class Initialized
INFO - 2016-10-08 22:00:48 --> Helper loaded: common_helper
INFO - 2016-10-08 22:00:48 --> Helper loaded: url_helper
INFO - 2016-10-08 22:00:48 --> Database Driver Class Initialized
INFO - 2016-10-08 22:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:00:48 --> Parser Class Initialized
INFO - 2016-10-08 22:00:48 --> Controller Class Initialized
DEBUG - 2016-10-08 22:00:48 --> Home MX_Controller Initialized
INFO - 2016-10-08 22:00:48 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 22:00:48 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 22:00:48 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:00:48 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:00:48 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:00:48 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:00:48 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:00:48 --> Model Class Initialized
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:00:48 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:00:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:00:48 --> Final output sent to browser
DEBUG - 2016-10-08 22:00:48 --> Total execution time: 0.0550
INFO - 2016-10-08 22:01:11 --> Config Class Initialized
INFO - 2016-10-08 22:01:11 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:01:11 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:01:11 --> Utf8 Class Initialized
INFO - 2016-10-08 22:01:11 --> URI Class Initialized
INFO - 2016-10-08 22:01:11 --> Router Class Initialized
INFO - 2016-10-08 22:01:11 --> Output Class Initialized
INFO - 2016-10-08 22:01:11 --> Security Class Initialized
DEBUG - 2016-10-08 22:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:01:11 --> Input Class Initialized
INFO - 2016-10-08 22:01:11 --> Language Class Initialized
INFO - 2016-10-08 22:01:11 --> Language Class Initialized
INFO - 2016-10-08 22:01:11 --> Config Class Initialized
INFO - 2016-10-08 22:01:11 --> Loader Class Initialized
INFO - 2016-10-08 22:01:11 --> Helper loaded: common_helper
INFO - 2016-10-08 22:01:11 --> Helper loaded: url_helper
INFO - 2016-10-08 22:01:11 --> Database Driver Class Initialized
INFO - 2016-10-08 22:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:01:11 --> Parser Class Initialized
INFO - 2016-10-08 22:01:11 --> Controller Class Initialized
DEBUG - 2016-10-08 22:01:11 --> Servers MX_Controller Initialized
INFO - 2016-10-08 22:01:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:01:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:01:11 --> Model Class Initialized
INFO - 2016-10-08 22:01:11 --> Config Class Initialized
INFO - 2016-10-08 22:01:11 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:01:11 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:01:11 --> Utf8 Class Initialized
INFO - 2016-10-08 22:01:11 --> URI Class Initialized
INFO - 2016-10-08 22:01:11 --> Router Class Initialized
INFO - 2016-10-08 22:01:11 --> Output Class Initialized
INFO - 2016-10-08 22:01:11 --> Security Class Initialized
DEBUG - 2016-10-08 22:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:01:11 --> Input Class Initialized
INFO - 2016-10-08 22:01:11 --> Language Class Initialized
INFO - 2016-10-08 22:01:11 --> Language Class Initialized
INFO - 2016-10-08 22:01:11 --> Config Class Initialized
INFO - 2016-10-08 22:01:11 --> Loader Class Initialized
INFO - 2016-10-08 22:01:11 --> Helper loaded: common_helper
INFO - 2016-10-08 22:01:11 --> Helper loaded: url_helper
INFO - 2016-10-08 22:01:11 --> Database Driver Class Initialized
INFO - 2016-10-08 22:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:01:11 --> Parser Class Initialized
INFO - 2016-10-08 22:01:11 --> Controller Class Initialized
DEBUG - 2016-10-08 22:01:11 --> Home MX_Controller Initialized
INFO - 2016-10-08 22:01:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 22:01:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 22:01:11 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:01:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:01:11 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:01:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:01:11 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:01:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:01:11 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:01:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:01:11 --> Final output sent to browser
DEBUG - 2016-10-08 22:01:11 --> Total execution time: 0.0553
INFO - 2016-10-08 22:01:34 --> Config Class Initialized
INFO - 2016-10-08 22:01:34 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:01:34 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:01:34 --> Utf8 Class Initialized
INFO - 2016-10-08 22:01:34 --> URI Class Initialized
INFO - 2016-10-08 22:01:34 --> Router Class Initialized
INFO - 2016-10-08 22:01:34 --> Output Class Initialized
INFO - 2016-10-08 22:01:34 --> Security Class Initialized
DEBUG - 2016-10-08 22:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:01:34 --> Input Class Initialized
INFO - 2016-10-08 22:01:34 --> Language Class Initialized
INFO - 2016-10-08 22:01:34 --> Language Class Initialized
INFO - 2016-10-08 22:01:34 --> Config Class Initialized
INFO - 2016-10-08 22:01:34 --> Loader Class Initialized
INFO - 2016-10-08 22:01:34 --> Helper loaded: common_helper
INFO - 2016-10-08 22:01:34 --> Helper loaded: url_helper
INFO - 2016-10-08 22:01:34 --> Database Driver Class Initialized
INFO - 2016-10-08 22:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:01:34 --> Parser Class Initialized
INFO - 2016-10-08 22:01:34 --> Controller Class Initialized
DEBUG - 2016-10-08 22:01:34 --> Servers MX_Controller Initialized
INFO - 2016-10-08 22:01:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:01:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:01:34 --> Model Class Initialized
INFO - 2016-10-08 22:01:34 --> Config Class Initialized
INFO - 2016-10-08 22:01:34 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:01:34 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:01:34 --> Utf8 Class Initialized
INFO - 2016-10-08 22:01:34 --> URI Class Initialized
INFO - 2016-10-08 22:01:34 --> Router Class Initialized
INFO - 2016-10-08 22:01:34 --> Output Class Initialized
INFO - 2016-10-08 22:01:34 --> Security Class Initialized
DEBUG - 2016-10-08 22:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:01:34 --> Input Class Initialized
INFO - 2016-10-08 22:01:34 --> Language Class Initialized
INFO - 2016-10-08 22:01:34 --> Language Class Initialized
INFO - 2016-10-08 22:01:34 --> Config Class Initialized
INFO - 2016-10-08 22:01:34 --> Loader Class Initialized
INFO - 2016-10-08 22:01:34 --> Helper loaded: common_helper
INFO - 2016-10-08 22:01:34 --> Helper loaded: url_helper
INFO - 2016-10-08 22:01:34 --> Database Driver Class Initialized
INFO - 2016-10-08 22:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:01:34 --> Parser Class Initialized
INFO - 2016-10-08 22:01:34 --> Controller Class Initialized
DEBUG - 2016-10-08 22:01:34 --> Home MX_Controller Initialized
INFO - 2016-10-08 22:01:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 22:01:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 22:01:34 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:01:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:01:34 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:01:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:01:34 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:01:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:01:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:01:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:01:34 --> Final output sent to browser
DEBUG - 2016-10-08 22:01:34 --> Total execution time: 0.0557
INFO - 2016-10-08 22:01:57 --> Config Class Initialized
INFO - 2016-10-08 22:01:57 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:01:57 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:01:57 --> Utf8 Class Initialized
INFO - 2016-10-08 22:01:57 --> URI Class Initialized
INFO - 2016-10-08 22:01:57 --> Router Class Initialized
INFO - 2016-10-08 22:01:57 --> Output Class Initialized
INFO - 2016-10-08 22:01:57 --> Security Class Initialized
DEBUG - 2016-10-08 22:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:01:57 --> Input Class Initialized
INFO - 2016-10-08 22:01:57 --> Language Class Initialized
INFO - 2016-10-08 22:01:57 --> Language Class Initialized
INFO - 2016-10-08 22:01:57 --> Config Class Initialized
INFO - 2016-10-08 22:01:57 --> Loader Class Initialized
INFO - 2016-10-08 22:01:57 --> Helper loaded: common_helper
INFO - 2016-10-08 22:01:57 --> Helper loaded: url_helper
INFO - 2016-10-08 22:01:57 --> Database Driver Class Initialized
INFO - 2016-10-08 22:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:01:57 --> Parser Class Initialized
INFO - 2016-10-08 22:01:57 --> Controller Class Initialized
DEBUG - 2016-10-08 22:01:57 --> Servers MX_Controller Initialized
INFO - 2016-10-08 22:01:57 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:01:57 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:01:57 --> Model Class Initialized
INFO - 2016-10-08 22:01:57 --> Config Class Initialized
INFO - 2016-10-08 22:01:57 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:01:57 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:01:57 --> Utf8 Class Initialized
INFO - 2016-10-08 22:01:57 --> URI Class Initialized
INFO - 2016-10-08 22:01:57 --> Router Class Initialized
INFO - 2016-10-08 22:01:57 --> Output Class Initialized
INFO - 2016-10-08 22:01:57 --> Security Class Initialized
DEBUG - 2016-10-08 22:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:01:57 --> Input Class Initialized
INFO - 2016-10-08 22:01:57 --> Language Class Initialized
INFO - 2016-10-08 22:01:57 --> Language Class Initialized
INFO - 2016-10-08 22:01:57 --> Config Class Initialized
INFO - 2016-10-08 22:01:57 --> Loader Class Initialized
INFO - 2016-10-08 22:01:57 --> Helper loaded: common_helper
INFO - 2016-10-08 22:01:57 --> Helper loaded: url_helper
INFO - 2016-10-08 22:01:57 --> Database Driver Class Initialized
INFO - 2016-10-08 22:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:01:57 --> Parser Class Initialized
INFO - 2016-10-08 22:01:57 --> Controller Class Initialized
DEBUG - 2016-10-08 22:01:57 --> Home MX_Controller Initialized
INFO - 2016-10-08 22:01:57 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-08 22:01:57 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-08 22:01:57 --> Content MX_Controller Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:01:57 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:01:57 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:01:57 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:01:57 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:01:57 --> Model Class Initialized
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:01:57 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:01:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:01:57 --> Final output sent to browser
DEBUG - 2016-10-08 22:01:57 --> Total execution time: 0.0504
INFO - 2016-10-08 22:02:20 --> Config Class Initialized
INFO - 2016-10-08 22:02:20 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:02:20 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:02:20 --> Utf8 Class Initialized
INFO - 2016-10-08 22:02:20 --> URI Class Initialized
INFO - 2016-10-08 22:02:20 --> Router Class Initialized
INFO - 2016-10-08 22:02:20 --> Output Class Initialized
INFO - 2016-10-08 22:02:20 --> Security Class Initialized
DEBUG - 2016-10-08 22:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:02:20 --> Input Class Initialized
INFO - 2016-10-08 22:02:20 --> Language Class Initialized
INFO - 2016-10-08 22:02:20 --> Language Class Initialized
INFO - 2016-10-08 22:02:20 --> Config Class Initialized
INFO - 2016-10-08 22:02:20 --> Loader Class Initialized
INFO - 2016-10-08 22:02:20 --> Helper loaded: common_helper
INFO - 2016-10-08 22:02:20 --> Helper loaded: url_helper
INFO - 2016-10-08 22:02:20 --> Database Driver Class Initialized
INFO - 2016-10-08 22:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:02:20 --> Parser Class Initialized
INFO - 2016-10-08 22:02:20 --> Controller Class Initialized
DEBUG - 2016-10-08 22:02:20 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:02:20 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:02:20 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:02:20 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:02:20 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:02:20 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:02:20 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:02:20 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:02:20 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:02:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:02:20 --> Final output sent to browser
DEBUG - 2016-10-08 22:02:20 --> Total execution time: 0.0553
INFO - 2016-10-08 22:02:44 --> Config Class Initialized
INFO - 2016-10-08 22:02:44 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:02:44 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:02:44 --> Utf8 Class Initialized
INFO - 2016-10-08 22:02:44 --> URI Class Initialized
INFO - 2016-10-08 22:02:44 --> Router Class Initialized
INFO - 2016-10-08 22:02:44 --> Output Class Initialized
INFO - 2016-10-08 22:02:44 --> Security Class Initialized
DEBUG - 2016-10-08 22:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:02:44 --> Input Class Initialized
INFO - 2016-10-08 22:02:44 --> Language Class Initialized
INFO - 2016-10-08 22:02:44 --> Language Class Initialized
INFO - 2016-10-08 22:02:44 --> Config Class Initialized
INFO - 2016-10-08 22:02:44 --> Loader Class Initialized
INFO - 2016-10-08 22:02:44 --> Helper loaded: common_helper
INFO - 2016-10-08 22:02:44 --> Helper loaded: url_helper
INFO - 2016-10-08 22:02:44 --> Database Driver Class Initialized
INFO - 2016-10-08 22:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:02:44 --> Parser Class Initialized
INFO - 2016-10-08 22:02:44 --> Controller Class Initialized
DEBUG - 2016-10-08 22:02:44 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:02:44 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:02:44 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:02:44 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:02:44 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:02:44 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:02:44 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:02:44 --> Model Class Initialized
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:02:44 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:02:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:02:44 --> Final output sent to browser
DEBUG - 2016-10-08 22:02:44 --> Total execution time: 0.0562
INFO - 2016-10-08 22:03:12 --> Config Class Initialized
INFO - 2016-10-08 22:03:12 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:03:12 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:03:12 --> Utf8 Class Initialized
INFO - 2016-10-08 22:03:12 --> URI Class Initialized
INFO - 2016-10-08 22:03:12 --> Router Class Initialized
INFO - 2016-10-08 22:03:12 --> Output Class Initialized
INFO - 2016-10-08 22:03:12 --> Security Class Initialized
DEBUG - 2016-10-08 22:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:03:12 --> Input Class Initialized
INFO - 2016-10-08 22:03:12 --> Language Class Initialized
INFO - 2016-10-08 22:03:12 --> Language Class Initialized
INFO - 2016-10-08 22:03:12 --> Config Class Initialized
INFO - 2016-10-08 22:03:12 --> Loader Class Initialized
INFO - 2016-10-08 22:03:12 --> Helper loaded: common_helper
INFO - 2016-10-08 22:03:12 --> Helper loaded: url_helper
INFO - 2016-10-08 22:03:12 --> Database Driver Class Initialized
INFO - 2016-10-08 22:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:03:12 --> Parser Class Initialized
INFO - 2016-10-08 22:03:12 --> Controller Class Initialized
DEBUG - 2016-10-08 22:03:12 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:03:12 --> Model Class Initialized
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:03:12 --> Model Class Initialized
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:03:12 --> Model Class Initialized
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:03:12 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:03:12 --> Model Class Initialized
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:03:12 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:03:12 --> Model Class Initialized
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:03:12 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:03:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:03:12 --> Final output sent to browser
DEBUG - 2016-10-08 22:03:12 --> Total execution time: 0.0571
INFO - 2016-10-08 22:05:19 --> Config Class Initialized
INFO - 2016-10-08 22:05:19 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:05:19 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:05:19 --> Utf8 Class Initialized
INFO - 2016-10-08 22:05:19 --> URI Class Initialized
INFO - 2016-10-08 22:05:19 --> Router Class Initialized
INFO - 2016-10-08 22:05:19 --> Output Class Initialized
INFO - 2016-10-08 22:05:19 --> Security Class Initialized
DEBUG - 2016-10-08 22:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:05:19 --> Input Class Initialized
INFO - 2016-10-08 22:05:19 --> Language Class Initialized
INFO - 2016-10-08 22:05:19 --> Language Class Initialized
INFO - 2016-10-08 22:05:19 --> Config Class Initialized
INFO - 2016-10-08 22:05:19 --> Loader Class Initialized
INFO - 2016-10-08 22:05:19 --> Helper loaded: common_helper
INFO - 2016-10-08 22:05:19 --> Helper loaded: url_helper
INFO - 2016-10-08 22:05:19 --> Database Driver Class Initialized
INFO - 2016-10-08 22:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:05:19 --> Parser Class Initialized
INFO - 2016-10-08 22:05:19 --> Controller Class Initialized
DEBUG - 2016-10-08 22:05:19 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:05:19 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:05:19 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:05:19 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:05:19 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:05:19 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:05:19 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:05:19 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:05:19 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:05:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:05:19 --> Final output sent to browser
DEBUG - 2016-10-08 22:05:19 --> Total execution time: 0.0577
INFO - 2016-10-08 22:05:30 --> Config Class Initialized
INFO - 2016-10-08 22:05:30 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:05:30 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:05:30 --> Utf8 Class Initialized
INFO - 2016-10-08 22:05:30 --> URI Class Initialized
INFO - 2016-10-08 22:05:30 --> Router Class Initialized
INFO - 2016-10-08 22:05:30 --> Output Class Initialized
INFO - 2016-10-08 22:05:30 --> Security Class Initialized
DEBUG - 2016-10-08 22:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:05:30 --> Input Class Initialized
INFO - 2016-10-08 22:05:30 --> Language Class Initialized
INFO - 2016-10-08 22:05:30 --> Language Class Initialized
INFO - 2016-10-08 22:05:30 --> Config Class Initialized
INFO - 2016-10-08 22:05:30 --> Loader Class Initialized
INFO - 2016-10-08 22:05:30 --> Helper loaded: common_helper
INFO - 2016-10-08 22:05:30 --> Helper loaded: url_helper
INFO - 2016-10-08 22:05:30 --> Database Driver Class Initialized
INFO - 2016-10-08 22:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:05:30 --> Parser Class Initialized
INFO - 2016-10-08 22:05:30 --> Controller Class Initialized
DEBUG - 2016-10-08 22:05:30 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:05:30 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:05:30 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:05:30 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/list.php
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:05:30 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:05:30 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:05:30 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:05:30 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:05:30 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:05:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:05:30 --> Final output sent to browser
DEBUG - 2016-10-08 22:05:30 --> Total execution time: 0.0569
INFO - 2016-10-08 22:05:49 --> Config Class Initialized
INFO - 2016-10-08 22:05:49 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:05:49 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:05:49 --> Utf8 Class Initialized
INFO - 2016-10-08 22:05:49 --> URI Class Initialized
INFO - 2016-10-08 22:05:49 --> Router Class Initialized
INFO - 2016-10-08 22:05:49 --> Output Class Initialized
INFO - 2016-10-08 22:05:49 --> Security Class Initialized
DEBUG - 2016-10-08 22:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:05:49 --> Input Class Initialized
INFO - 2016-10-08 22:05:49 --> Language Class Initialized
INFO - 2016-10-08 22:05:49 --> Language Class Initialized
INFO - 2016-10-08 22:05:49 --> Config Class Initialized
INFO - 2016-10-08 22:05:49 --> Loader Class Initialized
INFO - 2016-10-08 22:05:49 --> Helper loaded: common_helper
INFO - 2016-10-08 22:05:49 --> Helper loaded: url_helper
INFO - 2016-10-08 22:05:49 --> Database Driver Class Initialized
INFO - 2016-10-08 22:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:05:49 --> Parser Class Initialized
INFO - 2016-10-08 22:05:49 --> Controller Class Initialized
DEBUG - 2016-10-08 22:05:49 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:05:49 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:05:49 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:05:49 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:05:49 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:05:49 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:05:49 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:05:49 --> Model Class Initialized
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:05:49 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:05:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:05:49 --> Final output sent to browser
DEBUG - 2016-10-08 22:05:49 --> Total execution time: 0.0560
INFO - 2016-10-08 22:06:16 --> Config Class Initialized
INFO - 2016-10-08 22:06:16 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:06:16 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:06:16 --> Utf8 Class Initialized
INFO - 2016-10-08 22:06:16 --> URI Class Initialized
INFO - 2016-10-08 22:06:16 --> Router Class Initialized
INFO - 2016-10-08 22:06:16 --> Output Class Initialized
INFO - 2016-10-08 22:06:16 --> Security Class Initialized
DEBUG - 2016-10-08 22:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:06:16 --> Input Class Initialized
INFO - 2016-10-08 22:06:16 --> Language Class Initialized
INFO - 2016-10-08 22:06:16 --> Language Class Initialized
INFO - 2016-10-08 22:06:16 --> Config Class Initialized
INFO - 2016-10-08 22:06:16 --> Loader Class Initialized
INFO - 2016-10-08 22:06:16 --> Helper loaded: common_helper
INFO - 2016-10-08 22:06:16 --> Helper loaded: url_helper
INFO - 2016-10-08 22:06:16 --> Database Driver Class Initialized
INFO - 2016-10-08 22:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:06:16 --> Parser Class Initialized
INFO - 2016-10-08 22:06:16 --> Controller Class Initialized
DEBUG - 2016-10-08 22:06:16 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:06:16 --> Model Class Initialized
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:06:16 --> Model Class Initialized
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:06:16 --> Model Class Initialized
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:06:16 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:06:16 --> Model Class Initialized
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:06:16 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:06:16 --> Model Class Initialized
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:06:16 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:06:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:06:16 --> Final output sent to browser
DEBUG - 2016-10-08 22:06:16 --> Total execution time: 0.0650
INFO - 2016-10-08 22:06:25 --> Config Class Initialized
INFO - 2016-10-08 22:06:25 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:06:25 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:06:25 --> Utf8 Class Initialized
INFO - 2016-10-08 22:06:25 --> URI Class Initialized
INFO - 2016-10-08 22:06:25 --> Router Class Initialized
INFO - 2016-10-08 22:06:25 --> Output Class Initialized
INFO - 2016-10-08 22:06:25 --> Security Class Initialized
DEBUG - 2016-10-08 22:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:06:25 --> Input Class Initialized
INFO - 2016-10-08 22:06:25 --> Language Class Initialized
ERROR - 2016-10-08 22:06:25 --> 404 Page Not Found: /index
INFO - 2016-10-08 22:09:02 --> Config Class Initialized
INFO - 2016-10-08 22:09:02 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:09:02 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:09:02 --> Utf8 Class Initialized
INFO - 2016-10-08 22:09:02 --> URI Class Initialized
INFO - 2016-10-08 22:09:02 --> Router Class Initialized
INFO - 2016-10-08 22:09:02 --> Output Class Initialized
INFO - 2016-10-08 22:09:02 --> Security Class Initialized
DEBUG - 2016-10-08 22:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:09:02 --> Input Class Initialized
INFO - 2016-10-08 22:09:02 --> Language Class Initialized
INFO - 2016-10-08 22:09:02 --> Language Class Initialized
INFO - 2016-10-08 22:09:02 --> Config Class Initialized
INFO - 2016-10-08 22:09:02 --> Loader Class Initialized
INFO - 2016-10-08 22:09:02 --> Helper loaded: common_helper
INFO - 2016-10-08 22:09:02 --> Helper loaded: url_helper
INFO - 2016-10-08 22:09:02 --> Database Driver Class Initialized
INFO - 2016-10-08 22:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:09:02 --> Parser Class Initialized
INFO - 2016-10-08 22:09:02 --> Controller Class Initialized
DEBUG - 2016-10-08 22:09:02 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:09:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:09:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:09:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:09:02 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:09:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:09:02 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:09:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:09:02 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:09:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:09:02 --> Final output sent to browser
DEBUG - 2016-10-08 22:09:02 --> Total execution time: 0.0559
INFO - 2016-10-08 22:09:31 --> Config Class Initialized
INFO - 2016-10-08 22:09:31 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:09:31 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:09:31 --> Utf8 Class Initialized
INFO - 2016-10-08 22:09:31 --> URI Class Initialized
INFO - 2016-10-08 22:09:31 --> Router Class Initialized
INFO - 2016-10-08 22:09:31 --> Output Class Initialized
INFO - 2016-10-08 22:09:31 --> Security Class Initialized
DEBUG - 2016-10-08 22:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:09:31 --> Input Class Initialized
INFO - 2016-10-08 22:09:31 --> Language Class Initialized
INFO - 2016-10-08 22:09:31 --> Language Class Initialized
INFO - 2016-10-08 22:09:31 --> Config Class Initialized
INFO - 2016-10-08 22:09:31 --> Loader Class Initialized
INFO - 2016-10-08 22:09:31 --> Helper loaded: common_helper
INFO - 2016-10-08 22:09:31 --> Helper loaded: url_helper
INFO - 2016-10-08 22:09:31 --> Database Driver Class Initialized
INFO - 2016-10-08 22:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:09:31 --> Parser Class Initialized
INFO - 2016-10-08 22:09:31 --> Controller Class Initialized
DEBUG - 2016-10-08 22:09:31 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:09:31 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:09:31 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:09:31 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/list.php
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:09:31 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:09:31 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:09:31 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:09:31 --> Model Class Initialized
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:09:31 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:09:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:09:31 --> Final output sent to browser
DEBUG - 2016-10-08 22:09:31 --> Total execution time: 0.0557
INFO - 2016-10-08 22:10:02 --> Config Class Initialized
INFO - 2016-10-08 22:10:02 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:10:02 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:10:02 --> Utf8 Class Initialized
INFO - 2016-10-08 22:10:02 --> URI Class Initialized
INFO - 2016-10-08 22:10:02 --> Router Class Initialized
INFO - 2016-10-08 22:10:02 --> Output Class Initialized
INFO - 2016-10-08 22:10:02 --> Security Class Initialized
DEBUG - 2016-10-08 22:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:10:02 --> Input Class Initialized
INFO - 2016-10-08 22:10:02 --> Language Class Initialized
INFO - 2016-10-08 22:10:02 --> Language Class Initialized
INFO - 2016-10-08 22:10:02 --> Config Class Initialized
INFO - 2016-10-08 22:10:02 --> Loader Class Initialized
INFO - 2016-10-08 22:10:02 --> Helper loaded: common_helper
INFO - 2016-10-08 22:10:02 --> Helper loaded: url_helper
INFO - 2016-10-08 22:10:02 --> Database Driver Class Initialized
INFO - 2016-10-08 22:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:10:02 --> Parser Class Initialized
INFO - 2016-10-08 22:10:02 --> Controller Class Initialized
DEBUG - 2016-10-08 22:10:02 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:10:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:10:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:10:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/list.php
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:10:02 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:10:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:10:02 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:10:02 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:10:02 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:10:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:10:02 --> Final output sent to browser
DEBUG - 2016-10-08 22:10:02 --> Total execution time: 0.0636
INFO - 2016-10-08 22:10:34 --> Config Class Initialized
INFO - 2016-10-08 22:10:34 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:10:34 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:10:34 --> Utf8 Class Initialized
INFO - 2016-10-08 22:10:34 --> URI Class Initialized
INFO - 2016-10-08 22:10:34 --> Router Class Initialized
INFO - 2016-10-08 22:10:34 --> Output Class Initialized
INFO - 2016-10-08 22:10:34 --> Security Class Initialized
DEBUG - 2016-10-08 22:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:10:34 --> Input Class Initialized
INFO - 2016-10-08 22:10:34 --> Language Class Initialized
INFO - 2016-10-08 22:10:34 --> Language Class Initialized
INFO - 2016-10-08 22:10:34 --> Config Class Initialized
INFO - 2016-10-08 22:10:34 --> Loader Class Initialized
INFO - 2016-10-08 22:10:34 --> Helper loaded: common_helper
INFO - 2016-10-08 22:10:34 --> Helper loaded: url_helper
INFO - 2016-10-08 22:10:34 --> Database Driver Class Initialized
INFO - 2016-10-08 22:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:10:34 --> Parser Class Initialized
INFO - 2016-10-08 22:10:34 --> Controller Class Initialized
DEBUG - 2016-10-08 22:10:34 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:10:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:10:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:10:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:10:34 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:10:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:10:34 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:10:34 --> Model Class Initialized
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:10:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:10:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:10:34 --> Final output sent to browser
DEBUG - 2016-10-08 22:10:34 --> Total execution time: 0.0574
INFO - 2016-10-08 22:11:11 --> Config Class Initialized
INFO - 2016-10-08 22:11:11 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:11:11 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:11:11 --> Utf8 Class Initialized
INFO - 2016-10-08 22:11:11 --> URI Class Initialized
INFO - 2016-10-08 22:11:11 --> Router Class Initialized
INFO - 2016-10-08 22:11:11 --> Output Class Initialized
INFO - 2016-10-08 22:11:11 --> Security Class Initialized
DEBUG - 2016-10-08 22:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:11:11 --> Input Class Initialized
INFO - 2016-10-08 22:11:11 --> Language Class Initialized
INFO - 2016-10-08 22:11:11 --> Language Class Initialized
INFO - 2016-10-08 22:11:11 --> Config Class Initialized
INFO - 2016-10-08 22:11:11 --> Loader Class Initialized
INFO - 2016-10-08 22:11:11 --> Helper loaded: common_helper
INFO - 2016-10-08 22:11:11 --> Helper loaded: url_helper
INFO - 2016-10-08 22:11:11 --> Database Driver Class Initialized
INFO - 2016-10-08 22:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:11:11 --> Parser Class Initialized
INFO - 2016-10-08 22:11:11 --> Controller Class Initialized
DEBUG - 2016-10-08 22:11:11 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:11:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:11:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:11:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:11:11 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:11:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:11:11 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:11:11 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:11:11 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:11:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:11:11 --> Final output sent to browser
DEBUG - 2016-10-08 22:11:11 --> Total execution time: 0.0561
INFO - 2016-10-08 22:11:40 --> Config Class Initialized
INFO - 2016-10-08 22:11:40 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:11:40 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:11:40 --> Utf8 Class Initialized
INFO - 2016-10-08 22:11:40 --> URI Class Initialized
INFO - 2016-10-08 22:11:40 --> Router Class Initialized
INFO - 2016-10-08 22:11:40 --> Output Class Initialized
INFO - 2016-10-08 22:11:40 --> Security Class Initialized
DEBUG - 2016-10-08 22:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:11:40 --> Input Class Initialized
INFO - 2016-10-08 22:11:40 --> Language Class Initialized
INFO - 2016-10-08 22:11:40 --> Language Class Initialized
INFO - 2016-10-08 22:11:40 --> Config Class Initialized
INFO - 2016-10-08 22:11:40 --> Loader Class Initialized
INFO - 2016-10-08 22:11:40 --> Helper loaded: common_helper
INFO - 2016-10-08 22:11:40 --> Helper loaded: url_helper
INFO - 2016-10-08 22:11:40 --> Database Driver Class Initialized
INFO - 2016-10-08 22:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:11:40 --> Parser Class Initialized
INFO - 2016-10-08 22:11:40 --> Controller Class Initialized
DEBUG - 2016-10-08 22:11:40 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:11:40 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:11:40 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:11:40 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/list.php
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:11:40 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:11:40 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:11:40 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:11:40 --> Model Class Initialized
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:11:40 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:11:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:11:40 --> Final output sent to browser
DEBUG - 2016-10-08 22:11:40 --> Total execution time: 0.0553
INFO - 2016-10-08 22:12:26 --> Config Class Initialized
INFO - 2016-10-08 22:12:26 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:12:26 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:12:26 --> Utf8 Class Initialized
INFO - 2016-10-08 22:12:26 --> URI Class Initialized
INFO - 2016-10-08 22:12:26 --> Router Class Initialized
INFO - 2016-10-08 22:12:26 --> Output Class Initialized
INFO - 2016-10-08 22:12:26 --> Security Class Initialized
DEBUG - 2016-10-08 22:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:12:26 --> Input Class Initialized
INFO - 2016-10-08 22:12:26 --> Language Class Initialized
INFO - 2016-10-08 22:12:26 --> Language Class Initialized
INFO - 2016-10-08 22:12:26 --> Config Class Initialized
INFO - 2016-10-08 22:12:26 --> Loader Class Initialized
INFO - 2016-10-08 22:12:26 --> Helper loaded: common_helper
INFO - 2016-10-08 22:12:26 --> Helper loaded: url_helper
INFO - 2016-10-08 22:12:26 --> Database Driver Class Initialized
INFO - 2016-10-08 22:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:12:26 --> Parser Class Initialized
INFO - 2016-10-08 22:12:26 --> Controller Class Initialized
DEBUG - 2016-10-08 22:12:26 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:12:26 --> Model Class Initialized
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:12:26 --> Model Class Initialized
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:12:26 --> Model Class Initialized
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:12:26 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:12:26 --> Model Class Initialized
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:12:26 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:12:26 --> Model Class Initialized
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:12:26 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:12:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:12:26 --> Final output sent to browser
DEBUG - 2016-10-08 22:12:26 --> Total execution time: 0.0593
INFO - 2016-10-08 22:13:17 --> Config Class Initialized
INFO - 2016-10-08 22:13:17 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:13:17 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:13:17 --> Utf8 Class Initialized
INFO - 2016-10-08 22:13:17 --> URI Class Initialized
INFO - 2016-10-08 22:13:17 --> Router Class Initialized
INFO - 2016-10-08 22:13:17 --> Output Class Initialized
INFO - 2016-10-08 22:13:17 --> Security Class Initialized
DEBUG - 2016-10-08 22:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:13:17 --> Input Class Initialized
INFO - 2016-10-08 22:13:17 --> Language Class Initialized
INFO - 2016-10-08 22:13:17 --> Language Class Initialized
INFO - 2016-10-08 22:13:17 --> Config Class Initialized
INFO - 2016-10-08 22:13:17 --> Loader Class Initialized
INFO - 2016-10-08 22:13:17 --> Helper loaded: common_helper
INFO - 2016-10-08 22:13:17 --> Helper loaded: url_helper
INFO - 2016-10-08 22:13:17 --> Database Driver Class Initialized
INFO - 2016-10-08 22:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:13:17 --> Parser Class Initialized
INFO - 2016-10-08 22:13:17 --> Controller Class Initialized
DEBUG - 2016-10-08 22:13:17 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:13:17 --> Model Class Initialized
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:13:17 --> Model Class Initialized
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:13:17 --> Model Class Initialized
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:13:17 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:13:17 --> Model Class Initialized
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:13:17 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:13:17 --> Model Class Initialized
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:13:17 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:13:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:13:17 --> Final output sent to browser
DEBUG - 2016-10-08 22:13:17 --> Total execution time: 0.0797
INFO - 2016-10-08 22:14:07 --> Config Class Initialized
INFO - 2016-10-08 22:14:07 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:14:07 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:14:07 --> Utf8 Class Initialized
INFO - 2016-10-08 22:14:07 --> URI Class Initialized
INFO - 2016-10-08 22:14:07 --> Router Class Initialized
INFO - 2016-10-08 22:14:07 --> Output Class Initialized
INFO - 2016-10-08 22:14:07 --> Security Class Initialized
DEBUG - 2016-10-08 22:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:14:07 --> Input Class Initialized
INFO - 2016-10-08 22:14:07 --> Language Class Initialized
INFO - 2016-10-08 22:14:07 --> Language Class Initialized
INFO - 2016-10-08 22:14:07 --> Config Class Initialized
INFO - 2016-10-08 22:14:07 --> Loader Class Initialized
INFO - 2016-10-08 22:14:07 --> Helper loaded: common_helper
INFO - 2016-10-08 22:14:07 --> Helper loaded: url_helper
INFO - 2016-10-08 22:14:07 --> Database Driver Class Initialized
INFO - 2016-10-08 22:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:14:07 --> Parser Class Initialized
INFO - 2016-10-08 22:14:07 --> Controller Class Initialized
DEBUG - 2016-10-08 22:14:07 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:14:07 --> Model Class Initialized
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:14:07 --> Model Class Initialized
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:14:07 --> Model Class Initialized
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:14:07 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:14:07 --> Model Class Initialized
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:14:07 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:14:07 --> Model Class Initialized
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:14:07 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:14:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:14:07 --> Final output sent to browser
DEBUG - 2016-10-08 22:14:07 --> Total execution time: 0.0573
INFO - 2016-10-08 22:21:09 --> Config Class Initialized
INFO - 2016-10-08 22:21:09 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:21:09 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:21:09 --> Utf8 Class Initialized
INFO - 2016-10-08 22:21:09 --> URI Class Initialized
INFO - 2016-10-08 22:21:09 --> Router Class Initialized
INFO - 2016-10-08 22:21:09 --> Output Class Initialized
INFO - 2016-10-08 22:21:09 --> Security Class Initialized
DEBUG - 2016-10-08 22:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:21:09 --> Input Class Initialized
INFO - 2016-10-08 22:21:09 --> Language Class Initialized
INFO - 2016-10-08 22:21:09 --> Language Class Initialized
INFO - 2016-10-08 22:21:09 --> Config Class Initialized
INFO - 2016-10-08 22:21:09 --> Loader Class Initialized
INFO - 2016-10-08 22:21:09 --> Helper loaded: common_helper
INFO - 2016-10-08 22:21:09 --> Helper loaded: url_helper
INFO - 2016-10-08 22:21:09 --> Database Driver Class Initialized
INFO - 2016-10-08 22:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:21:09 --> Parser Class Initialized
INFO - 2016-10-08 22:21:09 --> Controller Class Initialized
DEBUG - 2016-10-08 22:21:09 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:21:09 --> Model Class Initialized
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:21:09 --> Model Class Initialized
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:21:09 --> Model Class Initialized
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:21:09 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:21:09 --> Model Class Initialized
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:21:09 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:21:09 --> Model Class Initialized
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:21:09 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:21:09 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:21:09 --> Final output sent to browser
DEBUG - 2016-10-08 22:21:09 --> Total execution time: 0.0567
INFO - 2016-10-08 22:40:37 --> Config Class Initialized
INFO - 2016-10-08 22:40:37 --> Hooks Class Initialized
DEBUG - 2016-10-08 22:40:37 --> UTF-8 Support Enabled
INFO - 2016-10-08 22:40:37 --> Utf8 Class Initialized
INFO - 2016-10-08 22:40:37 --> URI Class Initialized
INFO - 2016-10-08 22:40:37 --> Router Class Initialized
INFO - 2016-10-08 22:40:37 --> Output Class Initialized
INFO - 2016-10-08 22:40:37 --> Security Class Initialized
DEBUG - 2016-10-08 22:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 22:40:37 --> Input Class Initialized
INFO - 2016-10-08 22:40:37 --> Language Class Initialized
INFO - 2016-10-08 22:40:37 --> Language Class Initialized
INFO - 2016-10-08 22:40:37 --> Config Class Initialized
INFO - 2016-10-08 22:40:37 --> Loader Class Initialized
INFO - 2016-10-08 22:40:37 --> Helper loaded: common_helper
INFO - 2016-10-08 22:40:37 --> Helper loaded: url_helper
INFO - 2016-10-08 22:40:37 --> Database Driver Class Initialized
INFO - 2016-10-08 22:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 22:40:37 --> Parser Class Initialized
INFO - 2016-10-08 22:40:37 --> Controller Class Initialized
DEBUG - 2016-10-08 22:40:37 --> Content MX_Controller Initialized
INFO - 2016-10-08 22:40:37 --> Model Class Initialized
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 22:40:37 --> Model Class Initialized
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 22:40:37 --> Model Class Initialized
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 22:40:37 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 22:40:37 --> Model Class Initialized
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 22:40:37 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 22:40:37 --> Model Class Initialized
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 22:40:37 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 22:40:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 22:40:37 --> Final output sent to browser
DEBUG - 2016-10-08 22:40:37 --> Total execution time: 0.0590
INFO - 2016-10-08 23:36:56 --> Config Class Initialized
INFO - 2016-10-08 23:36:56 --> Hooks Class Initialized
DEBUG - 2016-10-08 23:36:56 --> UTF-8 Support Enabled
INFO - 2016-10-08 23:36:56 --> Utf8 Class Initialized
INFO - 2016-10-08 23:36:56 --> URI Class Initialized
INFO - 2016-10-08 23:36:56 --> Router Class Initialized
INFO - 2016-10-08 23:36:56 --> Output Class Initialized
INFO - 2016-10-08 23:36:56 --> Security Class Initialized
DEBUG - 2016-10-08 23:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-08 23:36:56 --> Input Class Initialized
INFO - 2016-10-08 23:36:56 --> Language Class Initialized
INFO - 2016-10-08 23:36:56 --> Language Class Initialized
INFO - 2016-10-08 23:36:56 --> Config Class Initialized
INFO - 2016-10-08 23:36:56 --> Loader Class Initialized
INFO - 2016-10-08 23:36:56 --> Helper loaded: common_helper
INFO - 2016-10-08 23:36:56 --> Helper loaded: url_helper
INFO - 2016-10-08 23:36:56 --> Database Driver Class Initialized
INFO - 2016-10-08 23:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-08 23:36:56 --> Parser Class Initialized
INFO - 2016-10-08 23:36:56 --> Controller Class Initialized
DEBUG - 2016-10-08 23:36:56 --> Content MX_Controller Initialized
INFO - 2016-10-08 23:36:56 --> Model Class Initialized
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-08 23:36:56 --> Model Class Initialized
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-08 23:36:56 --> Model Class Initialized
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-08 23:36:56 --> Slider MX_Controller Initialized
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-08 23:36:56 --> Model Class Initialized
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-08 23:36:56 --> Servers MX_Controller Initialized
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-08 23:36:56 --> Model Class Initialized
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-08 23:36:56 --> Module controller failed to run: banner/index
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-08 23:36:56 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-08 23:36:56 --> Final output sent to browser
DEBUG - 2016-10-08 23:36:56 --> Total execution time: 0.0633
