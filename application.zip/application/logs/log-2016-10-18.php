<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-18 05:22:41 --> Config Class Initialized
INFO - 2016-10-18 05:22:41 --> Hooks Class Initialized
DEBUG - 2016-10-18 05:22:41 --> UTF-8 Support Enabled
INFO - 2016-10-18 05:22:41 --> Utf8 Class Initialized
INFO - 2016-10-18 05:22:41 --> URI Class Initialized
DEBUG - 2016-10-18 05:22:41 --> No URI present. Default controller set.
INFO - 2016-10-18 05:22:41 --> Router Class Initialized
INFO - 2016-10-18 05:22:41 --> Output Class Initialized
INFO - 2016-10-18 05:22:41 --> Security Class Initialized
DEBUG - 2016-10-18 05:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 05:22:41 --> Input Class Initialized
INFO - 2016-10-18 05:22:41 --> Language Class Initialized
INFO - 2016-10-18 05:22:41 --> Language Class Initialized
INFO - 2016-10-18 05:22:41 --> Config Class Initialized
INFO - 2016-10-18 05:22:41 --> Loader Class Initialized
INFO - 2016-10-18 05:22:41 --> Helper loaded: common_helper
INFO - 2016-10-18 05:22:41 --> Helper loaded: url_helper
INFO - 2016-10-18 05:22:41 --> Database Driver Class Initialized
INFO - 2016-10-18 05:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 05:22:41 --> Parser Class Initialized
INFO - 2016-10-18 05:22:41 --> Controller Class Initialized
DEBUG - 2016-10-18 05:22:41 --> Home MX_Controller Initialized
INFO - 2016-10-18 05:22:41 --> Model Class Initialized
DEBUG - 2016-10-18 05:22:41 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-18 05:22:41 --> Model Class Initialized
ERROR - 2016-10-18 05:22:41 --> Module controller failed to run: banner/index
DEBUG - 2016-10-18 05:22:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-18 05:22:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-18 05:22:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-18 05:22:41 --> Final output sent to browser
DEBUG - 2016-10-18 05:22:41 --> Total execution time: 0.8723
INFO - 2016-10-18 09:48:30 --> Config Class Initialized
INFO - 2016-10-18 09:48:30 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:48:30 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:48:30 --> Utf8 Class Initialized
INFO - 2016-10-18 09:48:30 --> URI Class Initialized
DEBUG - 2016-10-18 09:48:30 --> No URI present. Default controller set.
INFO - 2016-10-18 09:48:30 --> Router Class Initialized
INFO - 2016-10-18 09:48:30 --> Output Class Initialized
INFO - 2016-10-18 09:48:30 --> Security Class Initialized
DEBUG - 2016-10-18 09:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:48:30 --> Input Class Initialized
INFO - 2016-10-18 09:48:30 --> Language Class Initialized
INFO - 2016-10-18 09:48:30 --> Language Class Initialized
INFO - 2016-10-18 09:48:30 --> Config Class Initialized
INFO - 2016-10-18 09:48:30 --> Loader Class Initialized
INFO - 2016-10-18 09:48:30 --> Helper loaded: common_helper
INFO - 2016-10-18 09:48:30 --> Helper loaded: url_helper
INFO - 2016-10-18 09:48:30 --> Database Driver Class Initialized
INFO - 2016-10-18 09:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:48:30 --> Parser Class Initialized
INFO - 2016-10-18 09:48:30 --> Controller Class Initialized
DEBUG - 2016-10-18 09:48:30 --> Home MX_Controller Initialized
INFO - 2016-10-18 09:48:30 --> Model Class Initialized
DEBUG - 2016-10-18 09:48:30 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-18 09:48:30 --> Model Class Initialized
ERROR - 2016-10-18 09:48:30 --> Module controller failed to run: banner/index
DEBUG - 2016-10-18 09:48:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-18 09:48:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-18 09:48:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-18 09:48:30 --> Final output sent to browser
DEBUG - 2016-10-18 09:48:30 --> Total execution time: 0.0433
INFO - 2016-10-18 09:49:04 --> Config Class Initialized
INFO - 2016-10-18 09:49:04 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:49:04 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:49:04 --> Utf8 Class Initialized
INFO - 2016-10-18 09:49:04 --> URI Class Initialized
INFO - 2016-10-18 09:49:04 --> Router Class Initialized
INFO - 2016-10-18 09:49:04 --> Output Class Initialized
INFO - 2016-10-18 09:49:04 --> Security Class Initialized
DEBUG - 2016-10-18 09:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:49:04 --> Input Class Initialized
INFO - 2016-10-18 09:49:04 --> Language Class Initialized
INFO - 2016-10-18 09:49:04 --> Language Class Initialized
INFO - 2016-10-18 09:49:04 --> Config Class Initialized
INFO - 2016-10-18 09:49:04 --> Loader Class Initialized
INFO - 2016-10-18 09:49:04 --> Helper loaded: common_helper
INFO - 2016-10-18 09:49:04 --> Helper loaded: url_helper
INFO - 2016-10-18 09:49:04 --> Database Driver Class Initialized
INFO - 2016-10-18 09:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:49:04 --> Parser Class Initialized
INFO - 2016-10-18 09:49:04 --> Controller Class Initialized
DEBUG - 2016-10-18 09:49:04 --> User MX_Controller Initialized
INFO - 2016-10-18 09:49:04 --> Model Class Initialized
DEBUG - 2016-10-18 09:49:04 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-18 09:49:04 --> Model Class Initialized
INFO - 2016-10-18 09:49:04 --> Helper loaded: cookie_helper
INFO - 2016-10-18 09:49:04 --> Helper loaded: form_helper
DEBUG - 2016-10-18 09:49:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-18 09:49:04 --> Model Class Initialized
DEBUG - 2016-10-18 09:49:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-18 09:49:04 --> Model Class Initialized
INFO - 2016-10-18 09:49:04 --> Final output sent to browser
DEBUG - 2016-10-18 09:49:04 --> Total execution time: 0.0927
INFO - 2016-10-18 09:49:09 --> Config Class Initialized
INFO - 2016-10-18 09:49:09 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:49:09 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:49:09 --> Utf8 Class Initialized
INFO - 2016-10-18 09:49:09 --> URI Class Initialized
INFO - 2016-10-18 09:49:09 --> Router Class Initialized
INFO - 2016-10-18 09:49:09 --> Output Class Initialized
INFO - 2016-10-18 09:49:09 --> Security Class Initialized
DEBUG - 2016-10-18 09:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:49:09 --> Input Class Initialized
INFO - 2016-10-18 09:49:09 --> Language Class Initialized
INFO - 2016-10-18 09:49:09 --> Language Class Initialized
INFO - 2016-10-18 09:49:09 --> Config Class Initialized
INFO - 2016-10-18 09:49:09 --> Loader Class Initialized
INFO - 2016-10-18 09:49:09 --> Helper loaded: common_helper
INFO - 2016-10-18 09:49:09 --> Helper loaded: url_helper
INFO - 2016-10-18 09:49:09 --> Database Driver Class Initialized
INFO - 2016-10-18 09:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:49:09 --> Parser Class Initialized
INFO - 2016-10-18 09:49:09 --> Controller Class Initialized
DEBUG - 2016-10-18 09:49:09 --> User MX_Controller Initialized
INFO - 2016-10-18 09:49:09 --> Model Class Initialized
DEBUG - 2016-10-18 09:49:09 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-18 09:49:09 --> Model Class Initialized
INFO - 2016-10-18 09:49:09 --> Helper loaded: cookie_helper
INFO - 2016-10-18 09:49:09 --> Helper loaded: form_helper
DEBUG - 2016-10-18 09:49:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-18 09:49:09 --> Model Class Initialized
DEBUG - 2016-10-18 09:49:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-18 09:49:09 --> Model Class Initialized
INFO - 2016-10-18 09:49:09 --> Final output sent to browser
DEBUG - 2016-10-18 09:49:09 --> Total execution time: 0.0480
INFO - 2016-10-18 09:49:43 --> Config Class Initialized
INFO - 2016-10-18 09:49:43 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:49:43 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:49:43 --> Utf8 Class Initialized
INFO - 2016-10-18 09:49:43 --> URI Class Initialized
INFO - 2016-10-18 09:49:43 --> Router Class Initialized
INFO - 2016-10-18 09:49:43 --> Output Class Initialized
INFO - 2016-10-18 09:49:43 --> Security Class Initialized
DEBUG - 2016-10-18 09:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:49:43 --> Input Class Initialized
INFO - 2016-10-18 09:49:43 --> Language Class Initialized
INFO - 2016-10-18 09:49:43 --> Language Class Initialized
INFO - 2016-10-18 09:49:43 --> Config Class Initialized
INFO - 2016-10-18 09:49:43 --> Loader Class Initialized
INFO - 2016-10-18 09:49:43 --> Helper loaded: common_helper
INFO - 2016-10-18 09:49:43 --> Helper loaded: url_helper
INFO - 2016-10-18 09:49:43 --> Database Driver Class Initialized
INFO - 2016-10-18 09:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:49:43 --> Parser Class Initialized
INFO - 2016-10-18 09:49:43 --> Controller Class Initialized
DEBUG - 2016-10-18 09:49:43 --> User MX_Controller Initialized
INFO - 2016-10-18 09:49:43 --> Model Class Initialized
DEBUG - 2016-10-18 09:49:43 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-18 09:49:43 --> Model Class Initialized
INFO - 2016-10-18 09:49:43 --> Helper loaded: cookie_helper
INFO - 2016-10-18 09:49:43 --> Helper loaded: form_helper
DEBUG - 2016-10-18 09:49:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-18 09:49:43 --> Model Class Initialized
DEBUG - 2016-10-18 09:49:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-18 09:49:43 --> Model Class Initialized
INFO - 2016-10-18 09:49:43 --> Final output sent to browser
DEBUG - 2016-10-18 09:49:43 --> Total execution time: 0.0683
INFO - 2016-10-18 09:49:46 --> Config Class Initialized
INFO - 2016-10-18 09:49:46 --> Hooks Class Initialized
DEBUG - 2016-10-18 09:49:46 --> UTF-8 Support Enabled
INFO - 2016-10-18 09:49:46 --> Utf8 Class Initialized
INFO - 2016-10-18 09:49:46 --> URI Class Initialized
DEBUG - 2016-10-18 09:49:46 --> No URI present. Default controller set.
INFO - 2016-10-18 09:49:46 --> Router Class Initialized
INFO - 2016-10-18 09:49:46 --> Output Class Initialized
INFO - 2016-10-18 09:49:46 --> Security Class Initialized
DEBUG - 2016-10-18 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 09:49:46 --> Input Class Initialized
INFO - 2016-10-18 09:49:46 --> Language Class Initialized
INFO - 2016-10-18 09:49:46 --> Language Class Initialized
INFO - 2016-10-18 09:49:46 --> Config Class Initialized
INFO - 2016-10-18 09:49:46 --> Loader Class Initialized
INFO - 2016-10-18 09:49:46 --> Helper loaded: common_helper
INFO - 2016-10-18 09:49:46 --> Helper loaded: url_helper
INFO - 2016-10-18 09:49:46 --> Database Driver Class Initialized
INFO - 2016-10-18 09:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 09:49:46 --> Parser Class Initialized
INFO - 2016-10-18 09:49:46 --> Controller Class Initialized
DEBUG - 2016-10-18 09:49:46 --> Home MX_Controller Initialized
INFO - 2016-10-18 09:49:46 --> Model Class Initialized
DEBUG - 2016-10-18 09:49:46 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-18 09:49:46 --> Model Class Initialized
DEBUG - 2016-10-18 09:49:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-18 09:49:46 --> Module controller failed to run: banner/index
DEBUG - 2016-10-18 09:49:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-18 09:49:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-18 09:49:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-18 09:49:46 --> Final output sent to browser
DEBUG - 2016-10-18 09:49:46 --> Total execution time: 0.0592
INFO - 2016-10-18 14:08:45 --> Config Class Initialized
INFO - 2016-10-18 14:08:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 14:08:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 14:08:45 --> Utf8 Class Initialized
INFO - 2016-10-18 14:08:45 --> URI Class Initialized
INFO - 2016-10-18 14:08:45 --> Router Class Initialized
INFO - 2016-10-18 14:08:45 --> Output Class Initialized
INFO - 2016-10-18 14:08:45 --> Security Class Initialized
DEBUG - 2016-10-18 14:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 14:08:45 --> Input Class Initialized
INFO - 2016-10-18 14:08:45 --> Language Class Initialized
ERROR - 2016-10-18 14:08:45 --> 404 Page Not Found: /index
INFO - 2016-10-18 16:10:17 --> Config Class Initialized
INFO - 2016-10-18 16:10:17 --> Hooks Class Initialized
DEBUG - 2016-10-18 16:10:17 --> UTF-8 Support Enabled
INFO - 2016-10-18 16:10:17 --> Utf8 Class Initialized
INFO - 2016-10-18 16:10:17 --> URI Class Initialized
INFO - 2016-10-18 16:10:17 --> Router Class Initialized
INFO - 2016-10-18 16:10:17 --> Output Class Initialized
INFO - 2016-10-18 16:10:17 --> Security Class Initialized
DEBUG - 2016-10-18 16:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 16:10:17 --> Input Class Initialized
INFO - 2016-10-18 16:10:17 --> Language Class Initialized
ERROR - 2016-10-18 16:10:17 --> 404 Page Not Found: /index
INFO - 2016-10-18 17:40:19 --> Config Class Initialized
INFO - 2016-10-18 17:40:19 --> Hooks Class Initialized
DEBUG - 2016-10-18 17:40:19 --> UTF-8 Support Enabled
INFO - 2016-10-18 17:40:19 --> Utf8 Class Initialized
INFO - 2016-10-18 17:40:19 --> URI Class Initialized
INFO - 2016-10-18 17:40:19 --> Router Class Initialized
INFO - 2016-10-18 17:40:19 --> Output Class Initialized
INFO - 2016-10-18 17:40:19 --> Security Class Initialized
DEBUG - 2016-10-18 17:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 17:40:19 --> Input Class Initialized
INFO - 2016-10-18 17:40:19 --> Language Class Initialized
ERROR - 2016-10-18 17:40:19 --> 404 Page Not Found: /index
INFO - 2016-10-18 18:19:45 --> Config Class Initialized
INFO - 2016-10-18 18:19:45 --> Hooks Class Initialized
DEBUG - 2016-10-18 18:19:45 --> UTF-8 Support Enabled
INFO - 2016-10-18 18:19:45 --> Utf8 Class Initialized
INFO - 2016-10-18 18:19:45 --> URI Class Initialized
DEBUG - 2016-10-18 18:19:45 --> No URI present. Default controller set.
INFO - 2016-10-18 18:19:45 --> Router Class Initialized
INFO - 2016-10-18 18:19:45 --> Output Class Initialized
INFO - 2016-10-18 18:19:45 --> Security Class Initialized
DEBUG - 2016-10-18 18:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 18:19:45 --> Input Class Initialized
INFO - 2016-10-18 18:19:45 --> Language Class Initialized
INFO - 2016-10-18 18:19:45 --> Language Class Initialized
INFO - 2016-10-18 18:19:45 --> Config Class Initialized
INFO - 2016-10-18 18:19:45 --> Loader Class Initialized
INFO - 2016-10-18 18:19:45 --> Helper loaded: common_helper
INFO - 2016-10-18 18:19:45 --> Helper loaded: url_helper
INFO - 2016-10-18 18:19:45 --> Database Driver Class Initialized
INFO - 2016-10-18 18:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 18:19:45 --> Parser Class Initialized
INFO - 2016-10-18 18:19:45 --> Controller Class Initialized
DEBUG - 2016-10-18 18:19:45 --> Home MX_Controller Initialized
INFO - 2016-10-18 18:19:45 --> Model Class Initialized
DEBUG - 2016-10-18 18:19:45 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-18 18:19:45 --> Model Class Initialized
ERROR - 2016-10-18 18:19:45 --> Module controller failed to run: banner/index
DEBUG - 2016-10-18 18:19:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-18 18:19:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-18 18:19:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-18 18:19:45 --> Final output sent to browser
DEBUG - 2016-10-18 18:19:45 --> Total execution time: 0.0465
INFO - 2016-10-18 19:20:38 --> Config Class Initialized
INFO - 2016-10-18 19:20:38 --> Hooks Class Initialized
DEBUG - 2016-10-18 19:20:38 --> UTF-8 Support Enabled
INFO - 2016-10-18 19:20:38 --> Utf8 Class Initialized
INFO - 2016-10-18 19:20:38 --> URI Class Initialized
INFO - 2016-10-18 19:20:38 --> Router Class Initialized
INFO - 2016-10-18 19:20:38 --> Output Class Initialized
INFO - 2016-10-18 19:20:38 --> Security Class Initialized
DEBUG - 2016-10-18 19:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 19:20:38 --> Input Class Initialized
INFO - 2016-10-18 19:20:38 --> Language Class Initialized
INFO - 2016-10-18 19:20:38 --> Language Class Initialized
INFO - 2016-10-18 19:20:38 --> Config Class Initialized
INFO - 2016-10-18 19:20:38 --> Loader Class Initialized
INFO - 2016-10-18 19:20:38 --> Helper loaded: common_helper
INFO - 2016-10-18 19:20:38 --> Helper loaded: url_helper
INFO - 2016-10-18 19:20:38 --> Database Driver Class Initialized
INFO - 2016-10-18 19:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-18 19:20:38 --> Parser Class Initialized
INFO - 2016-10-18 19:20:38 --> Controller Class Initialized
DEBUG - 2016-10-18 19:20:38 --> Content MX_Controller Initialized
INFO - 2016-10-18 19:20:38 --> Model Class Initialized
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-18 19:20:38 --> Model Class Initialized
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-18 19:20:38 --> Model Class Initialized
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-18 19:20:38 --> Slider MX_Controller Initialized
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-18 19:20:38 --> Model Class Initialized
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-18 19:20:38 --> Servers MX_Controller Initialized
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-18 19:20:38 --> Model Class Initialized
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-18 19:20:38 --> Module controller failed to run: banner/index
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-18 19:20:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-18 19:20:38 --> Final output sent to browser
DEBUG - 2016-10-18 19:20:38 --> Total execution time: 0.0819
INFO - 2016-10-18 22:08:18 --> Config Class Initialized
INFO - 2016-10-18 22:08:18 --> Hooks Class Initialized
DEBUG - 2016-10-18 22:08:18 --> UTF-8 Support Enabled
INFO - 2016-10-18 22:08:18 --> Utf8 Class Initialized
INFO - 2016-10-18 22:08:18 --> URI Class Initialized
INFO - 2016-10-18 22:08:18 --> Router Class Initialized
INFO - 2016-10-18 22:08:18 --> Output Class Initialized
INFO - 2016-10-18 22:08:18 --> Security Class Initialized
DEBUG - 2016-10-18 22:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-18 22:08:18 --> Input Class Initialized
INFO - 2016-10-18 22:08:18 --> Language Class Initialized
ERROR - 2016-10-18 22:08:18 --> 404 Page Not Found: /index
