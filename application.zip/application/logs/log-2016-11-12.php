<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-11-12 23:06:56 --> Config Class Initialized
INFO - 2016-11-12 23:06:56 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:06:56 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:06:56 --> Utf8 Class Initialized
INFO - 2016-11-12 23:06:56 --> URI Class Initialized
DEBUG - 2016-11-12 23:06:56 --> No URI present. Default controller set.
INFO - 2016-11-12 23:06:56 --> Router Class Initialized
INFO - 2016-11-12 23:06:56 --> Output Class Initialized
INFO - 2016-11-12 23:06:56 --> Security Class Initialized
DEBUG - 2016-11-12 23:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:06:56 --> Input Class Initialized
INFO - 2016-11-12 23:06:56 --> Language Class Initialized
INFO - 2016-11-12 23:06:56 --> Language Class Initialized
INFO - 2016-11-12 23:06:56 --> Config Class Initialized
INFO - 2016-11-12 23:06:56 --> Loader Class Initialized
INFO - 2016-11-12 23:06:56 --> Helper loaded: common_helper
INFO - 2016-11-12 23:06:56 --> Helper loaded: url_helper
INFO - 2016-11-12 23:06:57 --> Database Driver Class Initialized
INFO - 2016-11-12 23:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:06:57 --> Parser Class Initialized
INFO - 2016-11-12 23:06:57 --> Controller Class Initialized
DEBUG - 2016-11-12 23:06:57 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:06:57 --> Model Class Initialized
DEBUG - 2016-11-12 23:06:57 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:06:57 --> Model Class Initialized
DEBUG - 2016-11-12 23:06:57 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:06:57 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:06:57 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:06:57 --> Model Class Initialized
DEBUG - 2016-11-12 23:06:57 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:06:57 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:06:57 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:06:57 --> Model Class Initialized
DEBUG - 2016-11-12 23:06:57 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:06:57 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:06:58 --> Model Class Initialized
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:06:58 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:06:58 --> Model Class Initialized
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:06:58 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:06:58 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:06:58 --> Final output sent to browser
DEBUG - 2016-11-12 23:06:58 --> Total execution time: 2.0372
INFO - 2016-11-12 23:18:08 --> Config Class Initialized
INFO - 2016-11-12 23:18:08 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:18:08 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:18:08 --> Utf8 Class Initialized
INFO - 2016-11-12 23:18:08 --> URI Class Initialized
DEBUG - 2016-11-12 23:18:08 --> No URI present. Default controller set.
INFO - 2016-11-12 23:18:08 --> Router Class Initialized
INFO - 2016-11-12 23:18:08 --> Output Class Initialized
INFO - 2016-11-12 23:18:08 --> Security Class Initialized
DEBUG - 2016-11-12 23:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:18:08 --> Input Class Initialized
INFO - 2016-11-12 23:18:08 --> Language Class Initialized
INFO - 2016-11-12 23:18:08 --> Language Class Initialized
INFO - 2016-11-12 23:18:08 --> Config Class Initialized
INFO - 2016-11-12 23:18:08 --> Loader Class Initialized
INFO - 2016-11-12 23:18:08 --> Helper loaded: common_helper
INFO - 2016-11-12 23:18:08 --> Helper loaded: url_helper
INFO - 2016-11-12 23:18:08 --> Database Driver Class Initialized
INFO - 2016-11-12 23:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:18:08 --> Parser Class Initialized
INFO - 2016-11-12 23:18:08 --> Controller Class Initialized
DEBUG - 2016-11-12 23:18:08 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:18:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:18:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:18:08 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:18:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:18:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:18:08 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:18:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:18:08 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:18:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:18:08 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:18:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:18:08 --> Final output sent to browser
DEBUG - 2016-11-12 23:18:08 --> Total execution time: 0.1979
INFO - 2016-11-12 23:31:42 --> Config Class Initialized
INFO - 2016-11-12 23:31:42 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:31:42 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:31:42 --> Utf8 Class Initialized
INFO - 2016-11-12 23:31:42 --> URI Class Initialized
DEBUG - 2016-11-12 23:31:42 --> No URI present. Default controller set.
INFO - 2016-11-12 23:31:42 --> Router Class Initialized
INFO - 2016-11-12 23:31:42 --> Output Class Initialized
INFO - 2016-11-12 23:31:42 --> Security Class Initialized
DEBUG - 2016-11-12 23:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:31:42 --> Input Class Initialized
INFO - 2016-11-12 23:31:42 --> Language Class Initialized
INFO - 2016-11-12 23:31:42 --> Language Class Initialized
INFO - 2016-11-12 23:31:42 --> Config Class Initialized
INFO - 2016-11-12 23:31:42 --> Loader Class Initialized
INFO - 2016-11-12 23:31:42 --> Helper loaded: common_helper
INFO - 2016-11-12 23:31:42 --> Helper loaded: url_helper
INFO - 2016-11-12 23:31:42 --> Database Driver Class Initialized
INFO - 2016-11-12 23:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:31:42 --> Parser Class Initialized
INFO - 2016-11-12 23:31:42 --> Controller Class Initialized
DEBUG - 2016-11-12 23:31:42 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:31:42 --> Model Class Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:31:42 --> Model Class Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:31:42 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:31:42 --> Model Class Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:31:42 --> Model Class Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:31:42 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:31:42 --> Model Class Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:31:42 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:31:42 --> Model Class Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:31:42 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:31:42 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:31:42 --> Final output sent to browser
DEBUG - 2016-11-12 23:31:42 --> Total execution time: 0.1715
INFO - 2016-11-12 23:36:54 --> Config Class Initialized
INFO - 2016-11-12 23:36:54 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:36:54 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:36:54 --> Utf8 Class Initialized
INFO - 2016-11-12 23:36:54 --> URI Class Initialized
DEBUG - 2016-11-12 23:36:54 --> No URI present. Default controller set.
INFO - 2016-11-12 23:36:54 --> Router Class Initialized
INFO - 2016-11-12 23:36:54 --> Output Class Initialized
INFO - 2016-11-12 23:36:54 --> Security Class Initialized
DEBUG - 2016-11-12 23:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:36:54 --> Input Class Initialized
INFO - 2016-11-12 23:36:54 --> Language Class Initialized
INFO - 2016-11-12 23:36:54 --> Language Class Initialized
INFO - 2016-11-12 23:36:54 --> Config Class Initialized
INFO - 2016-11-12 23:36:54 --> Loader Class Initialized
INFO - 2016-11-12 23:36:54 --> Helper loaded: common_helper
INFO - 2016-11-12 23:36:54 --> Helper loaded: url_helper
INFO - 2016-11-12 23:36:54 --> Database Driver Class Initialized
INFO - 2016-11-12 23:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:36:54 --> Parser Class Initialized
INFO - 2016-11-12 23:36:54 --> Controller Class Initialized
DEBUG - 2016-11-12 23:36:54 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:36:54 --> Model Class Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:36:54 --> Model Class Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:36:54 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:36:54 --> Model Class Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:36:54 --> Model Class Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:36:54 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:36:54 --> Model Class Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:36:54 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:36:54 --> Model Class Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:36:54 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:36:54 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:36:54 --> Final output sent to browser
DEBUG - 2016-11-12 23:36:54 --> Total execution time: 0.1751
INFO - 2016-11-12 23:37:00 --> Config Class Initialized
INFO - 2016-11-12 23:37:00 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:37:00 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:37:00 --> Utf8 Class Initialized
INFO - 2016-11-12 23:37:00 --> URI Class Initialized
DEBUG - 2016-11-12 23:37:00 --> No URI present. Default controller set.
INFO - 2016-11-12 23:37:00 --> Router Class Initialized
INFO - 2016-11-12 23:37:00 --> Output Class Initialized
INFO - 2016-11-12 23:37:00 --> Security Class Initialized
DEBUG - 2016-11-12 23:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:37:00 --> Input Class Initialized
INFO - 2016-11-12 23:37:00 --> Language Class Initialized
INFO - 2016-11-12 23:37:00 --> Language Class Initialized
INFO - 2016-11-12 23:37:00 --> Config Class Initialized
INFO - 2016-11-12 23:37:00 --> Loader Class Initialized
INFO - 2016-11-12 23:37:00 --> Helper loaded: common_helper
INFO - 2016-11-12 23:37:00 --> Helper loaded: url_helper
INFO - 2016-11-12 23:37:00 --> Database Driver Class Initialized
INFO - 2016-11-12 23:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:37:00 --> Parser Class Initialized
INFO - 2016-11-12 23:37:00 --> Controller Class Initialized
DEBUG - 2016-11-12 23:37:00 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:37:00 --> Model Class Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:37:00 --> Model Class Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:37:00 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:37:00 --> Model Class Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:37:00 --> Model Class Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:37:00 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:37:00 --> Model Class Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:37:00 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:37:00 --> Model Class Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:37:00 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:37:00 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:37:00 --> Final output sent to browser
DEBUG - 2016-11-12 23:37:00 --> Total execution time: 0.1675
INFO - 2016-11-12 23:39:22 --> Config Class Initialized
INFO - 2016-11-12 23:39:22 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:39:22 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:39:22 --> Utf8 Class Initialized
INFO - 2016-11-12 23:39:22 --> URI Class Initialized
DEBUG - 2016-11-12 23:39:22 --> No URI present. Default controller set.
INFO - 2016-11-12 23:39:22 --> Router Class Initialized
INFO - 2016-11-12 23:39:22 --> Output Class Initialized
INFO - 2016-11-12 23:39:22 --> Security Class Initialized
DEBUG - 2016-11-12 23:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:39:22 --> Input Class Initialized
INFO - 2016-11-12 23:39:22 --> Language Class Initialized
INFO - 2016-11-12 23:39:22 --> Language Class Initialized
INFO - 2016-11-12 23:39:22 --> Config Class Initialized
INFO - 2016-11-12 23:39:22 --> Loader Class Initialized
INFO - 2016-11-12 23:39:22 --> Helper loaded: common_helper
INFO - 2016-11-12 23:39:22 --> Helper loaded: url_helper
INFO - 2016-11-12 23:39:22 --> Database Driver Class Initialized
INFO - 2016-11-12 23:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:39:22 --> Parser Class Initialized
INFO - 2016-11-12 23:39:22 --> Controller Class Initialized
DEBUG - 2016-11-12 23:39:22 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:39:22 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:39:22 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:39:22 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:39:22 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:39:22 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:39:22 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:39:22 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:39:22 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:39:22 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:39:22 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:39:22 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:39:22 --> Final output sent to browser
DEBUG - 2016-11-12 23:39:22 --> Total execution time: 0.1754
INFO - 2016-11-12 23:39:25 --> Config Class Initialized
INFO - 2016-11-12 23:39:25 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:39:25 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:39:25 --> Utf8 Class Initialized
INFO - 2016-11-12 23:39:25 --> URI Class Initialized
DEBUG - 2016-11-12 23:39:25 --> No URI present. Default controller set.
INFO - 2016-11-12 23:39:25 --> Router Class Initialized
INFO - 2016-11-12 23:39:26 --> Output Class Initialized
INFO - 2016-11-12 23:39:26 --> Security Class Initialized
DEBUG - 2016-11-12 23:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:39:26 --> Input Class Initialized
INFO - 2016-11-12 23:39:26 --> Language Class Initialized
INFO - 2016-11-12 23:39:26 --> Language Class Initialized
INFO - 2016-11-12 23:39:26 --> Config Class Initialized
INFO - 2016-11-12 23:39:26 --> Loader Class Initialized
INFO - 2016-11-12 23:39:26 --> Helper loaded: common_helper
INFO - 2016-11-12 23:39:26 --> Helper loaded: url_helper
INFO - 2016-11-12 23:39:26 --> Database Driver Class Initialized
INFO - 2016-11-12 23:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:39:26 --> Parser Class Initialized
INFO - 2016-11-12 23:39:26 --> Controller Class Initialized
DEBUG - 2016-11-12 23:39:26 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:39:26 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:39:26 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:39:26 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:39:26 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:39:26 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:39:26 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:39:26 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:39:26 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:39:26 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:39:26 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:39:26 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:39:26 --> Final output sent to browser
DEBUG - 2016-11-12 23:39:26 --> Total execution time: 0.1599
INFO - 2016-11-12 23:39:26 --> Config Class Initialized
INFO - 2016-11-12 23:39:26 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:39:26 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:39:26 --> Utf8 Class Initialized
INFO - 2016-11-12 23:39:26 --> URI Class Initialized
DEBUG - 2016-11-12 23:39:26 --> No URI present. Default controller set.
INFO - 2016-11-12 23:39:26 --> Router Class Initialized
INFO - 2016-11-12 23:39:26 --> Output Class Initialized
INFO - 2016-11-12 23:39:26 --> Security Class Initialized
DEBUG - 2016-11-12 23:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:39:26 --> Input Class Initialized
INFO - 2016-11-12 23:39:26 --> Language Class Initialized
INFO - 2016-11-12 23:39:26 --> Language Class Initialized
INFO - 2016-11-12 23:39:26 --> Config Class Initialized
INFO - 2016-11-12 23:39:26 --> Loader Class Initialized
INFO - 2016-11-12 23:39:26 --> Helper loaded: common_helper
INFO - 2016-11-12 23:39:26 --> Helper loaded: url_helper
INFO - 2016-11-12 23:39:26 --> Database Driver Class Initialized
INFO - 2016-11-12 23:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:39:26 --> Parser Class Initialized
INFO - 2016-11-12 23:39:27 --> Controller Class Initialized
DEBUG - 2016-11-12 23:39:27 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:39:27 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:39:27 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:39:27 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:39:27 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:39:27 --> Final output sent to browser
DEBUG - 2016-11-12 23:39:27 --> Total execution time: 0.2011
INFO - 2016-11-12 23:39:27 --> Config Class Initialized
INFO - 2016-11-12 23:39:27 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:39:27 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:39:27 --> Utf8 Class Initialized
INFO - 2016-11-12 23:39:27 --> URI Class Initialized
DEBUG - 2016-11-12 23:39:27 --> No URI present. Default controller set.
INFO - 2016-11-12 23:39:27 --> Router Class Initialized
INFO - 2016-11-12 23:39:27 --> Output Class Initialized
INFO - 2016-11-12 23:39:27 --> Security Class Initialized
DEBUG - 2016-11-12 23:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:39:27 --> Input Class Initialized
INFO - 2016-11-12 23:39:27 --> Language Class Initialized
INFO - 2016-11-12 23:39:27 --> Language Class Initialized
INFO - 2016-11-12 23:39:27 --> Config Class Initialized
INFO - 2016-11-12 23:39:27 --> Loader Class Initialized
INFO - 2016-11-12 23:39:27 --> Helper loaded: common_helper
INFO - 2016-11-12 23:39:27 --> Helper loaded: url_helper
INFO - 2016-11-12 23:39:27 --> Database Driver Class Initialized
INFO - 2016-11-12 23:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:39:27 --> Parser Class Initialized
INFO - 2016-11-12 23:39:27 --> Controller Class Initialized
DEBUG - 2016-11-12 23:39:27 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:39:27 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:39:27 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:39:27 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:39:27 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:39:27 --> Final output sent to browser
DEBUG - 2016-11-12 23:39:27 --> Total execution time: 0.2047
INFO - 2016-11-12 23:39:27 --> Config Class Initialized
INFO - 2016-11-12 23:39:27 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:39:27 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:39:27 --> Utf8 Class Initialized
INFO - 2016-11-12 23:39:27 --> URI Class Initialized
DEBUG - 2016-11-12 23:39:27 --> No URI present. Default controller set.
INFO - 2016-11-12 23:39:27 --> Router Class Initialized
INFO - 2016-11-12 23:39:27 --> Output Class Initialized
INFO - 2016-11-12 23:39:27 --> Security Class Initialized
DEBUG - 2016-11-12 23:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:39:27 --> Input Class Initialized
INFO - 2016-11-12 23:39:27 --> Language Class Initialized
INFO - 2016-11-12 23:39:27 --> Language Class Initialized
INFO - 2016-11-12 23:39:27 --> Config Class Initialized
INFO - 2016-11-12 23:39:27 --> Loader Class Initialized
INFO - 2016-11-12 23:39:27 --> Helper loaded: common_helper
INFO - 2016-11-12 23:39:27 --> Helper loaded: url_helper
INFO - 2016-11-12 23:39:27 --> Database Driver Class Initialized
INFO - 2016-11-12 23:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:39:27 --> Parser Class Initialized
INFO - 2016-11-12 23:39:27 --> Controller Class Initialized
DEBUG - 2016-11-12 23:39:27 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:39:27 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
INFO - 2016-11-12 23:39:27 --> Config Class Initialized
INFO - 2016-11-12 23:39:27 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:39:27 --> Utf8 Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:39:27 --> URI Class Initialized
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:39:27 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> No URI present. Default controller set.
INFO - 2016-11-12 23:39:27 --> Router Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
INFO - 2016-11-12 23:39:27 --> Output Class Initialized
INFO - 2016-11-12 23:39:27 --> Config Class Initialized
INFO - 2016-11-12 23:39:27 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
INFO - 2016-11-12 23:39:27 --> Security Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:39:27 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 23:39:27 --> Servers MX_Controller Initialized
INFO - 2016-11-12 23:39:27 --> Utf8 Class Initialized
DEBUG - 2016-11-12 23:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:39:27 --> Input Class Initialized
INFO - 2016-11-12 23:39:27 --> URI Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
INFO - 2016-11-12 23:39:27 --> Language Class Initialized
DEBUG - 2016-11-12 23:39:27 --> No URI present. Default controller set.
INFO - 2016-11-12 23:39:27 --> Router Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
INFO - 2016-11-12 23:39:27 --> Language Class Initialized
INFO - 2016-11-12 23:39:27 --> Config Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
INFO - 2016-11-12 23:39:27 --> Output Class Initialized
DEBUG - 2016-11-12 23:39:27 --> Banner MX_Controller Initialized
INFO - 2016-11-12 23:39:27 --> Security Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
INFO - 2016-11-12 23:39:27 --> Input Class Initialized
INFO - 2016-11-12 23:39:27 --> Loader Class Initialized
INFO - 2016-11-12 23:39:27 --> Language Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:39:27 --> Final output sent to browser
DEBUG - 2016-11-12 23:39:27 --> Total execution time: 0.2425
INFO - 2016-11-12 23:39:27 --> Language Class Initialized
INFO - 2016-11-12 23:39:27 --> Config Class Initialized
INFO - 2016-11-12 23:39:27 --> Loader Class Initialized
INFO - 2016-11-12 23:39:27 --> Helper loaded: common_helper
INFO - 2016-11-12 23:39:27 --> Helper loaded: url_helper
INFO - 2016-11-12 23:39:27 --> Helper loaded: common_helper
INFO - 2016-11-12 23:39:27 --> Helper loaded: url_helper
INFO - 2016-11-12 23:39:27 --> Database Driver Class Initialized
INFO - 2016-11-12 23:39:27 --> Database Driver Class Initialized
INFO - 2016-11-12 23:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:39:27 --> Parser Class Initialized
INFO - 2016-11-12 23:39:27 --> Controller Class Initialized
DEBUG - 2016-11-12 23:39:27 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:39:27 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:39:27 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:39:27 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:39:27 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:39:27 --> Final output sent to browser
DEBUG - 2016-11-12 23:39:27 --> Total execution time: 0.2196
INFO - 2016-11-12 23:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:39:27 --> Parser Class Initialized
INFO - 2016-11-12 23:39:27 --> Controller Class Initialized
DEBUG - 2016-11-12 23:39:27 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:39:27 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:39:27 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:39:27 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:39:27 --> Model Class Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:39:27 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:39:27 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:39:27 --> Final output sent to browser
DEBUG - 2016-11-12 23:39:27 --> Total execution time: 0.2514
INFO - 2016-11-12 23:46:59 --> Config Class Initialized
INFO - 2016-11-12 23:46:59 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:46:59 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:46:59 --> Utf8 Class Initialized
INFO - 2016-11-12 23:46:59 --> URI Class Initialized
DEBUG - 2016-11-12 23:46:59 --> No URI present. Default controller set.
INFO - 2016-11-12 23:46:59 --> Router Class Initialized
INFO - 2016-11-12 23:46:59 --> Output Class Initialized
INFO - 2016-11-12 23:46:59 --> Security Class Initialized
DEBUG - 2016-11-12 23:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:46:59 --> Input Class Initialized
INFO - 2016-11-12 23:46:59 --> Language Class Initialized
INFO - 2016-11-12 23:46:59 --> Language Class Initialized
INFO - 2016-11-12 23:46:59 --> Config Class Initialized
INFO - 2016-11-12 23:46:59 --> Loader Class Initialized
INFO - 2016-11-12 23:46:59 --> Helper loaded: common_helper
INFO - 2016-11-12 23:46:59 --> Helper loaded: url_helper
INFO - 2016-11-12 23:46:59 --> Database Driver Class Initialized
INFO - 2016-11-12 23:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:46:59 --> Parser Class Initialized
INFO - 2016-11-12 23:46:59 --> Controller Class Initialized
DEBUG - 2016-11-12 23:46:59 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:46:59 --> Model Class Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:46:59 --> Model Class Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:46:59 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:46:59 --> Model Class Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:46:59 --> Model Class Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:46:59 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:46:59 --> Model Class Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:46:59 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:46:59 --> Model Class Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:46:59 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:46:59 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:46:59 --> Final output sent to browser
DEBUG - 2016-11-12 23:46:59 --> Total execution time: 0.2116
INFO - 2016-11-12 23:47:01 --> Config Class Initialized
INFO - 2016-11-12 23:47:01 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:47:01 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:47:01 --> Utf8 Class Initialized
INFO - 2016-11-12 23:47:01 --> URI Class Initialized
DEBUG - 2016-11-12 23:47:01 --> No URI present. Default controller set.
INFO - 2016-11-12 23:47:01 --> Router Class Initialized
INFO - 2016-11-12 23:47:01 --> Output Class Initialized
INFO - 2016-11-12 23:47:01 --> Security Class Initialized
DEBUG - 2016-11-12 23:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:47:01 --> Input Class Initialized
INFO - 2016-11-12 23:47:01 --> Language Class Initialized
INFO - 2016-11-12 23:47:01 --> Language Class Initialized
INFO - 2016-11-12 23:47:01 --> Config Class Initialized
INFO - 2016-11-12 23:47:01 --> Loader Class Initialized
INFO - 2016-11-12 23:47:01 --> Helper loaded: common_helper
INFO - 2016-11-12 23:47:01 --> Helper loaded: url_helper
INFO - 2016-11-12 23:47:01 --> Database Driver Class Initialized
INFO - 2016-11-12 23:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:47:01 --> Parser Class Initialized
INFO - 2016-11-12 23:47:01 --> Controller Class Initialized
DEBUG - 2016-11-12 23:47:01 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:47:01 --> Model Class Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:47:01 --> Model Class Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:47:01 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:47:01 --> Model Class Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:47:01 --> Model Class Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:47:01 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:47:01 --> Model Class Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:47:01 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:47:01 --> Model Class Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:47:01 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:47:01 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:47:01 --> Final output sent to browser
DEBUG - 2016-11-12 23:47:01 --> Total execution time: 0.1727
INFO - 2016-11-12 23:50:03 --> Config Class Initialized
INFO - 2016-11-12 23:50:03 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:50:03 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:50:03 --> Utf8 Class Initialized
INFO - 2016-11-12 23:50:03 --> URI Class Initialized
DEBUG - 2016-11-12 23:50:03 --> No URI present. Default controller set.
INFO - 2016-11-12 23:50:03 --> Router Class Initialized
INFO - 2016-11-12 23:50:03 --> Output Class Initialized
INFO - 2016-11-12 23:50:03 --> Security Class Initialized
DEBUG - 2016-11-12 23:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:50:03 --> Input Class Initialized
INFO - 2016-11-12 23:50:03 --> Language Class Initialized
INFO - 2016-11-12 23:50:03 --> Language Class Initialized
INFO - 2016-11-12 23:50:03 --> Config Class Initialized
INFO - 2016-11-12 23:50:03 --> Loader Class Initialized
INFO - 2016-11-12 23:50:03 --> Helper loaded: common_helper
INFO - 2016-11-12 23:50:03 --> Helper loaded: url_helper
INFO - 2016-11-12 23:50:03 --> Database Driver Class Initialized
INFO - 2016-11-12 23:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:50:03 --> Parser Class Initialized
INFO - 2016-11-12 23:50:03 --> Controller Class Initialized
DEBUG - 2016-11-12 23:50:03 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:50:03 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:50:03 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:50:03 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:50:03 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:50:03 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:50:03 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:50:03 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:50:03 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:50:03 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:50:03 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:50:03 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:50:03 --> Final output sent to browser
DEBUG - 2016-11-12 23:50:03 --> Total execution time: 0.1528
INFO - 2016-11-12 23:50:07 --> Config Class Initialized
INFO - 2016-11-12 23:50:07 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:50:07 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:50:07 --> Utf8 Class Initialized
INFO - 2016-11-12 23:50:07 --> URI Class Initialized
DEBUG - 2016-11-12 23:50:07 --> No URI present. Default controller set.
INFO - 2016-11-12 23:50:07 --> Router Class Initialized
INFO - 2016-11-12 23:50:07 --> Output Class Initialized
INFO - 2016-11-12 23:50:07 --> Security Class Initialized
DEBUG - 2016-11-12 23:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:50:07 --> Input Class Initialized
INFO - 2016-11-12 23:50:07 --> Language Class Initialized
INFO - 2016-11-12 23:50:07 --> Language Class Initialized
INFO - 2016-11-12 23:50:07 --> Config Class Initialized
INFO - 2016-11-12 23:50:07 --> Loader Class Initialized
INFO - 2016-11-12 23:50:07 --> Helper loaded: common_helper
INFO - 2016-11-12 23:50:07 --> Helper loaded: url_helper
INFO - 2016-11-12 23:50:07 --> Database Driver Class Initialized
INFO - 2016-11-12 23:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:50:07 --> Parser Class Initialized
INFO - 2016-11-12 23:50:07 --> Controller Class Initialized
DEBUG - 2016-11-12 23:50:07 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:50:07 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:50:07 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:50:07 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:50:07 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:50:07 --> Final output sent to browser
DEBUG - 2016-11-12 23:50:07 --> Total execution time: 0.1460
INFO - 2016-11-12 23:50:07 --> Config Class Initialized
INFO - 2016-11-12 23:50:07 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:50:07 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:50:07 --> Utf8 Class Initialized
INFO - 2016-11-12 23:50:07 --> URI Class Initialized
DEBUG - 2016-11-12 23:50:07 --> No URI present. Default controller set.
INFO - 2016-11-12 23:50:07 --> Router Class Initialized
INFO - 2016-11-12 23:50:07 --> Output Class Initialized
INFO - 2016-11-12 23:50:07 --> Security Class Initialized
DEBUG - 2016-11-12 23:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:50:07 --> Input Class Initialized
INFO - 2016-11-12 23:50:07 --> Language Class Initialized
INFO - 2016-11-12 23:50:07 --> Language Class Initialized
INFO - 2016-11-12 23:50:07 --> Config Class Initialized
INFO - 2016-11-12 23:50:07 --> Loader Class Initialized
INFO - 2016-11-12 23:50:07 --> Helper loaded: common_helper
INFO - 2016-11-12 23:50:07 --> Helper loaded: url_helper
INFO - 2016-11-12 23:50:07 --> Database Driver Class Initialized
INFO - 2016-11-12 23:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:50:07 --> Parser Class Initialized
INFO - 2016-11-12 23:50:07 --> Controller Class Initialized
DEBUG - 2016-11-12 23:50:07 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:50:07 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:50:07 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:50:07 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:50:07 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:50:07 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:50:07 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:50:07 --> Final output sent to browser
DEBUG - 2016-11-12 23:50:07 --> Total execution time: 0.1615
INFO - 2016-11-12 23:50:08 --> Config Class Initialized
INFO - 2016-11-12 23:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:50:08 --> Utf8 Class Initialized
INFO - 2016-11-12 23:50:08 --> URI Class Initialized
DEBUG - 2016-11-12 23:50:08 --> No URI present. Default controller set.
INFO - 2016-11-12 23:50:08 --> Router Class Initialized
INFO - 2016-11-12 23:50:08 --> Output Class Initialized
INFO - 2016-11-12 23:50:08 --> Security Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:50:08 --> Input Class Initialized
INFO - 2016-11-12 23:50:08 --> Language Class Initialized
INFO - 2016-11-12 23:50:08 --> Language Class Initialized
INFO - 2016-11-12 23:50:08 --> Config Class Initialized
INFO - 2016-11-12 23:50:08 --> Loader Class Initialized
INFO - 2016-11-12 23:50:08 --> Config Class Initialized
INFO - 2016-11-12 23:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:50:08 --> Utf8 Class Initialized
INFO - 2016-11-12 23:50:08 --> Helper loaded: common_helper
INFO - 2016-11-12 23:50:08 --> URI Class Initialized
INFO - 2016-11-12 23:50:08 --> Helper loaded: url_helper
DEBUG - 2016-11-12 23:50:08 --> No URI present. Default controller set.
INFO - 2016-11-12 23:50:08 --> Router Class Initialized
INFO - 2016-11-12 23:50:08 --> Output Class Initialized
INFO - 2016-11-12 23:50:08 --> Database Driver Class Initialized
INFO - 2016-11-12 23:50:08 --> Security Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:50:08 --> Input Class Initialized
INFO - 2016-11-12 23:50:08 --> Language Class Initialized
INFO - 2016-11-12 23:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:50:08 --> Language Class Initialized
INFO - 2016-11-12 23:50:08 --> Config Class Initialized
INFO - 2016-11-12 23:50:08 --> Parser Class Initialized
INFO - 2016-11-12 23:50:08 --> Controller Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
INFO - 2016-11-12 23:50:08 --> Loader Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:50:08 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
INFO - 2016-11-12 23:50:08 --> Helper loaded: common_helper
INFO - 2016-11-12 23:50:08 --> Helper loaded: url_helper
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
INFO - 2016-11-12 23:50:08 --> Database Driver Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:50:08 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:50:08 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:50:08 --> Final output sent to browser
DEBUG - 2016-11-12 23:50:08 --> Total execution time: 0.2338
INFO - 2016-11-12 23:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:50:08 --> Parser Class Initialized
INFO - 2016-11-12 23:50:08 --> Controller Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:50:08 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:50:08 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
INFO - 2016-11-12 23:50:08 --> Config Class Initialized
INFO - 2016-11-12 23:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:50:08 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 23:50:08 --> Servers MX_Controller Initialized
INFO - 2016-11-12 23:50:08 --> Utf8 Class Initialized
INFO - 2016-11-12 23:50:08 --> URI Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:50:08 --> No URI present. Default controller set.
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
INFO - 2016-11-12 23:50:08 --> Router Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Banner MX_Controller Initialized
INFO - 2016-11-12 23:50:08 --> Output Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
INFO - 2016-11-12 23:50:08 --> Security Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:50:08 --> Input Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:50:08 --> Final output sent to browser
INFO - 2016-11-12 23:50:08 --> Language Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Total execution time: 0.2139
INFO - 2016-11-12 23:50:08 --> Language Class Initialized
INFO - 2016-11-12 23:50:08 --> Config Class Initialized
INFO - 2016-11-12 23:50:08 --> Loader Class Initialized
INFO - 2016-11-12 23:50:08 --> Helper loaded: common_helper
INFO - 2016-11-12 23:50:08 --> Helper loaded: url_helper
INFO - 2016-11-12 23:50:08 --> Database Driver Class Initialized
INFO - 2016-11-12 23:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:50:08 --> Parser Class Initialized
INFO - 2016-11-12 23:50:08 --> Controller Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:50:08 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:50:08 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:50:08 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:50:08 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:50:08 --> Final output sent to browser
DEBUG - 2016-11-12 23:50:08 --> Total execution time: 0.1492
INFO - 2016-11-12 23:50:08 --> Config Class Initialized
INFO - 2016-11-12 23:50:08 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:50:08 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:50:08 --> Utf8 Class Initialized
INFO - 2016-11-12 23:50:08 --> URI Class Initialized
DEBUG - 2016-11-12 23:50:08 --> No URI present. Default controller set.
INFO - 2016-11-12 23:50:08 --> Router Class Initialized
INFO - 2016-11-12 23:50:08 --> Output Class Initialized
INFO - 2016-11-12 23:50:08 --> Security Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:50:08 --> Input Class Initialized
INFO - 2016-11-12 23:50:08 --> Language Class Initialized
INFO - 2016-11-12 23:50:08 --> Language Class Initialized
INFO - 2016-11-12 23:50:08 --> Config Class Initialized
INFO - 2016-11-12 23:50:08 --> Loader Class Initialized
INFO - 2016-11-12 23:50:08 --> Helper loaded: common_helper
INFO - 2016-11-12 23:50:08 --> Helper loaded: url_helper
INFO - 2016-11-12 23:50:08 --> Database Driver Class Initialized
INFO - 2016-11-12 23:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:50:08 --> Parser Class Initialized
INFO - 2016-11-12 23:50:08 --> Controller Class Initialized
DEBUG - 2016-11-12 23:50:08 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:50:08 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:50:08 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:50:08 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:50:08 --> Model Class Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:50:08 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:50:08 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:50:08 --> Final output sent to browser
DEBUG - 2016-11-12 23:50:08 --> Total execution time: 0.1446
INFO - 2016-11-12 23:55:39 --> Config Class Initialized
INFO - 2016-11-12 23:55:39 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:55:39 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:55:39 --> Utf8 Class Initialized
INFO - 2016-11-12 23:55:39 --> URI Class Initialized
DEBUG - 2016-11-12 23:55:39 --> No URI present. Default controller set.
INFO - 2016-11-12 23:55:39 --> Router Class Initialized
INFO - 2016-11-12 23:55:39 --> Output Class Initialized
INFO - 2016-11-12 23:55:39 --> Security Class Initialized
DEBUG - 2016-11-12 23:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:55:39 --> Input Class Initialized
INFO - 2016-11-12 23:55:39 --> Language Class Initialized
INFO - 2016-11-12 23:55:39 --> Language Class Initialized
INFO - 2016-11-12 23:55:39 --> Config Class Initialized
INFO - 2016-11-12 23:55:39 --> Loader Class Initialized
INFO - 2016-11-12 23:55:39 --> Helper loaded: common_helper
INFO - 2016-11-12 23:55:39 --> Helper loaded: url_helper
INFO - 2016-11-12 23:55:39 --> Database Driver Class Initialized
INFO - 2016-11-12 23:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:55:39 --> Parser Class Initialized
INFO - 2016-11-12 23:55:39 --> Controller Class Initialized
DEBUG - 2016-11-12 23:55:39 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:55:39 --> Model Class Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:55:39 --> Model Class Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:55:39 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:55:39 --> Model Class Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:55:39 --> Model Class Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:55:39 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:55:39 --> Model Class Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:55:39 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:55:39 --> Model Class Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:55:39 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:55:39 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:55:39 --> Final output sent to browser
DEBUG - 2016-11-12 23:55:39 --> Total execution time: 0.1638
INFO - 2016-11-12 23:56:29 --> Config Class Initialized
INFO - 2016-11-12 23:56:29 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:56:29 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:56:29 --> Utf8 Class Initialized
INFO - 2016-11-12 23:56:29 --> URI Class Initialized
DEBUG - 2016-11-12 23:56:29 --> No URI present. Default controller set.
INFO - 2016-11-12 23:56:29 --> Router Class Initialized
INFO - 2016-11-12 23:56:29 --> Output Class Initialized
INFO - 2016-11-12 23:56:29 --> Security Class Initialized
DEBUG - 2016-11-12 23:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:56:29 --> Input Class Initialized
INFO - 2016-11-12 23:56:29 --> Language Class Initialized
INFO - 2016-11-12 23:56:29 --> Language Class Initialized
INFO - 2016-11-12 23:56:29 --> Config Class Initialized
INFO - 2016-11-12 23:56:29 --> Loader Class Initialized
INFO - 2016-11-12 23:56:29 --> Helper loaded: common_helper
INFO - 2016-11-12 23:56:29 --> Helper loaded: url_helper
INFO - 2016-11-12 23:56:29 --> Database Driver Class Initialized
INFO - 2016-11-12 23:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:56:29 --> Parser Class Initialized
INFO - 2016-11-12 23:56:29 --> Controller Class Initialized
DEBUG - 2016-11-12 23:56:29 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:56:29 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:56:29 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:56:29 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:56:29 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:56:29 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:56:29 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:56:29 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:56:29 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:56:29 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:56:29 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:56:29 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:56:29 --> Final output sent to browser
DEBUG - 2016-11-12 23:56:29 --> Total execution time: 0.1475
INFO - 2016-11-12 23:56:37 --> Config Class Initialized
INFO - 2016-11-12 23:56:37 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:56:37 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:56:37 --> Utf8 Class Initialized
INFO - 2016-11-12 23:56:37 --> URI Class Initialized
DEBUG - 2016-11-12 23:56:37 --> No URI present. Default controller set.
INFO - 2016-11-12 23:56:37 --> Router Class Initialized
INFO - 2016-11-12 23:56:37 --> Output Class Initialized
INFO - 2016-11-12 23:56:37 --> Security Class Initialized
DEBUG - 2016-11-12 23:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:56:37 --> Input Class Initialized
INFO - 2016-11-12 23:56:37 --> Language Class Initialized
INFO - 2016-11-12 23:56:37 --> Language Class Initialized
INFO - 2016-11-12 23:56:37 --> Config Class Initialized
INFO - 2016-11-12 23:56:37 --> Loader Class Initialized
INFO - 2016-11-12 23:56:37 --> Helper loaded: common_helper
INFO - 2016-11-12 23:56:37 --> Helper loaded: url_helper
INFO - 2016-11-12 23:56:37 --> Database Driver Class Initialized
INFO - 2016-11-12 23:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:56:37 --> Parser Class Initialized
INFO - 2016-11-12 23:56:37 --> Controller Class Initialized
DEBUG - 2016-11-12 23:56:37 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:56:37 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:56:37 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:56:37 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:56:37 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:56:37 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:56:37 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:56:37 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:56:37 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:56:37 --> Model Class Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:56:37 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:56:37 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:56:37 --> Final output sent to browser
DEBUG - 2016-11-12 23:56:37 --> Total execution time: 0.1628
INFO - 2016-11-12 23:57:49 --> Config Class Initialized
INFO - 2016-11-12 23:57:49 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:57:49 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:57:49 --> Utf8 Class Initialized
INFO - 2016-11-12 23:57:49 --> URI Class Initialized
DEBUG - 2016-11-12 23:57:49 --> No URI present. Default controller set.
INFO - 2016-11-12 23:57:49 --> Router Class Initialized
INFO - 2016-11-12 23:57:49 --> Output Class Initialized
INFO - 2016-11-12 23:57:49 --> Security Class Initialized
DEBUG - 2016-11-12 23:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:57:49 --> Input Class Initialized
INFO - 2016-11-12 23:57:49 --> Language Class Initialized
INFO - 2016-11-12 23:57:49 --> Language Class Initialized
INFO - 2016-11-12 23:57:49 --> Config Class Initialized
INFO - 2016-11-12 23:57:49 --> Loader Class Initialized
INFO - 2016-11-12 23:57:49 --> Helper loaded: common_helper
INFO - 2016-11-12 23:57:49 --> Helper loaded: url_helper
INFO - 2016-11-12 23:57:49 --> Database Driver Class Initialized
INFO - 2016-11-12 23:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:57:49 --> Parser Class Initialized
INFO - 2016-11-12 23:57:49 --> Controller Class Initialized
DEBUG - 2016-11-12 23:57:49 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:57:49 --> Model Class Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:57:49 --> Model Class Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:57:49 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:57:49 --> Model Class Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:57:49 --> Model Class Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:57:49 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:57:49 --> Model Class Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:57:49 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:57:49 --> Model Class Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:57:49 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:57:49 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:57:49 --> Final output sent to browser
DEBUG - 2016-11-12 23:57:49 --> Total execution time: 0.1533
INFO - 2016-11-12 23:58:05 --> Config Class Initialized
INFO - 2016-11-12 23:58:05 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:58:05 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:58:05 --> Utf8 Class Initialized
INFO - 2016-11-12 23:58:05 --> URI Class Initialized
DEBUG - 2016-11-12 23:58:05 --> No URI present. Default controller set.
INFO - 2016-11-12 23:58:05 --> Router Class Initialized
INFO - 2016-11-12 23:58:05 --> Output Class Initialized
INFO - 2016-11-12 23:58:05 --> Security Class Initialized
DEBUG - 2016-11-12 23:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:58:05 --> Input Class Initialized
INFO - 2016-11-12 23:58:05 --> Language Class Initialized
INFO - 2016-11-12 23:58:05 --> Language Class Initialized
INFO - 2016-11-12 23:58:05 --> Config Class Initialized
INFO - 2016-11-12 23:58:05 --> Loader Class Initialized
INFO - 2016-11-12 23:58:05 --> Helper loaded: common_helper
INFO - 2016-11-12 23:58:05 --> Helper loaded: url_helper
INFO - 2016-11-12 23:58:05 --> Database Driver Class Initialized
INFO - 2016-11-12 23:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:58:05 --> Parser Class Initialized
INFO - 2016-11-12 23:58:05 --> Controller Class Initialized
DEBUG - 2016-11-12 23:58:05 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:58:05 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:58:05 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:58:05 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:58:05 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:58:05 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:58:05 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:58:05 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:58:05 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:58:05 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:58:05 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:06 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:58:06 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:58:06 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:58:06 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:06 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:58:06 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:58:06 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:58:06 --> Final output sent to browser
DEBUG - 2016-11-12 23:58:06 --> Total execution time: 0.2011
INFO - 2016-11-12 23:58:21 --> Config Class Initialized
INFO - 2016-11-12 23:58:21 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:58:21 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:58:21 --> Utf8 Class Initialized
INFO - 2016-11-12 23:58:21 --> URI Class Initialized
DEBUG - 2016-11-12 23:58:21 --> No URI present. Default controller set.
INFO - 2016-11-12 23:58:21 --> Router Class Initialized
INFO - 2016-11-12 23:58:21 --> Output Class Initialized
INFO - 2016-11-12 23:58:21 --> Security Class Initialized
DEBUG - 2016-11-12 23:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:58:21 --> Input Class Initialized
INFO - 2016-11-12 23:58:21 --> Language Class Initialized
INFO - 2016-11-12 23:58:21 --> Language Class Initialized
INFO - 2016-11-12 23:58:21 --> Config Class Initialized
INFO - 2016-11-12 23:58:21 --> Loader Class Initialized
INFO - 2016-11-12 23:58:21 --> Helper loaded: common_helper
INFO - 2016-11-12 23:58:21 --> Helper loaded: url_helper
INFO - 2016-11-12 23:58:21 --> Database Driver Class Initialized
INFO - 2016-11-12 23:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:58:21 --> Parser Class Initialized
INFO - 2016-11-12 23:58:21 --> Controller Class Initialized
DEBUG - 2016-11-12 23:58:21 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:58:21 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:58:21 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:58:21 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:58:21 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:58:21 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:58:21 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:58:21 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:58:21 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:58:21 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:58:21 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:58:21 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:58:21 --> Final output sent to browser
DEBUG - 2016-11-12 23:58:21 --> Total execution time: 0.1616
INFO - 2016-11-12 23:58:32 --> Config Class Initialized
INFO - 2016-11-12 23:58:32 --> Hooks Class Initialized
DEBUG - 2016-11-12 23:58:32 --> UTF-8 Support Enabled
INFO - 2016-11-12 23:58:32 --> Utf8 Class Initialized
INFO - 2016-11-12 23:58:32 --> URI Class Initialized
DEBUG - 2016-11-12 23:58:32 --> No URI present. Default controller set.
INFO - 2016-11-12 23:58:32 --> Router Class Initialized
INFO - 2016-11-12 23:58:32 --> Output Class Initialized
INFO - 2016-11-12 23:58:32 --> Security Class Initialized
DEBUG - 2016-11-12 23:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-11-12 23:58:32 --> Input Class Initialized
INFO - 2016-11-12 23:58:32 --> Language Class Initialized
INFO - 2016-11-12 23:58:32 --> Language Class Initialized
INFO - 2016-11-12 23:58:32 --> Config Class Initialized
INFO - 2016-11-12 23:58:32 --> Loader Class Initialized
INFO - 2016-11-12 23:58:32 --> Helper loaded: common_helper
INFO - 2016-11-12 23:58:32 --> Helper loaded: url_helper
INFO - 2016-11-12 23:58:32 --> Database Driver Class Initialized
INFO - 2016-11-12 23:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-11-12 23:58:32 --> Parser Class Initialized
INFO - 2016-11-12 23:58:32 --> Controller Class Initialized
DEBUG - 2016-11-12 23:58:32 --> Home MX_Controller Initialized
INFO - 2016-11-12 23:58:32 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/models/Home_model.php
INFO - 2016-11-12 23:58:32 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/content/controllers/Content.php
DEBUG - 2016-11-12 23:58:32 --> Content MX_Controller Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-11-12 23:58:32 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/content/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/home/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/date_server/models/Date_server_model.php
INFO - 2016-11-12 23:58:32 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-11-12 23:58:32 --> Slider MX_Controller Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/models/Slider_model.php
INFO - 2016-11-12 23:58:32 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/slider/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-11-12 23:58:32 --> Servers MX_Controller Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/models/Servers_model.php
INFO - 2016-11-12 23:58:32 --> Model Class Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\controllers/../modules/banner/controllers/Banner.php
DEBUG - 2016-11-12 23:58:32 --> Banner MX_Controller Initialized
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\modules/banner/views/FRONTEND/index.php
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/popup/account.php
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/modules/tracking.php
DEBUG - 2016-11-12 23:58:32 --> File loaded: C:\xampp\htdocs\do_long\application\views\FRONTEND/template.php
INFO - 2016-11-12 23:58:32 --> Final output sent to browser
DEBUG - 2016-11-12 23:58:32 --> Total execution time: 0.1578
