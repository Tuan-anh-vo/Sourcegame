<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-11 03:40:31 --> Config Class Initialized
INFO - 2016-10-11 03:40:31 --> Hooks Class Initialized
DEBUG - 2016-10-11 03:40:31 --> UTF-8 Support Enabled
INFO - 2016-10-11 03:40:31 --> Utf8 Class Initialized
INFO - 2016-10-11 03:40:31 --> URI Class Initialized
INFO - 2016-10-11 03:40:31 --> Router Class Initialized
INFO - 2016-10-11 03:40:31 --> Output Class Initialized
INFO - 2016-10-11 03:40:32 --> Security Class Initialized
DEBUG - 2016-10-11 03:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 03:40:32 --> Input Class Initialized
INFO - 2016-10-11 03:40:32 --> Language Class Initialized
ERROR - 2016-10-11 03:40:32 --> 404 Page Not Found: /index
INFO - 2016-10-11 03:40:32 --> Config Class Initialized
INFO - 2016-10-11 03:40:32 --> Hooks Class Initialized
DEBUG - 2016-10-11 03:40:32 --> UTF-8 Support Enabled
INFO - 2016-10-11 03:40:32 --> Utf8 Class Initialized
INFO - 2016-10-11 03:40:32 --> URI Class Initialized
INFO - 2016-10-11 03:40:32 --> Router Class Initialized
INFO - 2016-10-11 03:40:32 --> Output Class Initialized
INFO - 2016-10-11 03:40:32 --> Security Class Initialized
DEBUG - 2016-10-11 03:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 03:40:32 --> Input Class Initialized
INFO - 2016-10-11 03:40:32 --> Language Class Initialized
ERROR - 2016-10-11 03:40:32 --> 404 Page Not Found: /index
INFO - 2016-10-11 07:53:02 --> Config Class Initialized
INFO - 2016-10-11 07:53:02 --> Hooks Class Initialized
DEBUG - 2016-10-11 07:53:02 --> UTF-8 Support Enabled
INFO - 2016-10-11 07:53:02 --> Utf8 Class Initialized
INFO - 2016-10-11 07:53:02 --> URI Class Initialized
DEBUG - 2016-10-11 07:53:02 --> No URI present. Default controller set.
INFO - 2016-10-11 07:53:02 --> Router Class Initialized
INFO - 2016-10-11 07:53:02 --> Output Class Initialized
INFO - 2016-10-11 07:53:02 --> Security Class Initialized
DEBUG - 2016-10-11 07:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 07:53:02 --> Input Class Initialized
INFO - 2016-10-11 07:53:02 --> Language Class Initialized
INFO - 2016-10-11 07:53:02 --> Language Class Initialized
INFO - 2016-10-11 07:53:02 --> Config Class Initialized
INFO - 2016-10-11 07:53:02 --> Loader Class Initialized
INFO - 2016-10-11 07:53:02 --> Helper loaded: common_helper
INFO - 2016-10-11 07:53:02 --> Helper loaded: url_helper
INFO - 2016-10-11 07:53:03 --> Database Driver Class Initialized
INFO - 2016-10-11 07:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 07:53:03 --> Parser Class Initialized
INFO - 2016-10-11 07:53:03 --> Controller Class Initialized
DEBUG - 2016-10-11 07:53:03 --> Home MX_Controller Initialized
INFO - 2016-10-11 07:53:03 --> Model Class Initialized
DEBUG - 2016-10-11 07:53:03 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-11 07:53:03 --> Model Class Initialized
ERROR - 2016-10-11 07:53:03 --> Module controller failed to run: banner/index
DEBUG - 2016-10-11 07:53:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-11 07:53:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-11 07:53:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-11 07:53:03 --> Final output sent to browser
DEBUG - 2016-10-11 07:53:03 --> Total execution time: 0.5053
INFO - 2016-10-11 08:24:25 --> Config Class Initialized
INFO - 2016-10-11 08:24:25 --> Hooks Class Initialized
DEBUG - 2016-10-11 08:24:25 --> UTF-8 Support Enabled
INFO - 2016-10-11 08:24:25 --> Utf8 Class Initialized
INFO - 2016-10-11 08:24:25 --> URI Class Initialized
INFO - 2016-10-11 08:24:25 --> Router Class Initialized
INFO - 2016-10-11 08:24:25 --> Output Class Initialized
INFO - 2016-10-11 08:24:25 --> Security Class Initialized
DEBUG - 2016-10-11 08:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 08:24:25 --> Input Class Initialized
INFO - 2016-10-11 08:24:25 --> Language Class Initialized
INFO - 2016-10-11 08:24:25 --> Language Class Initialized
INFO - 2016-10-11 08:24:25 --> Config Class Initialized
INFO - 2016-10-11 08:24:25 --> Loader Class Initialized
INFO - 2016-10-11 08:24:25 --> Helper loaded: common_helper
INFO - 2016-10-11 08:24:25 --> Helper loaded: url_helper
INFO - 2016-10-11 08:24:25 --> Database Driver Class Initialized
INFO - 2016-10-11 08:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 08:24:25 --> Parser Class Initialized
INFO - 2016-10-11 08:24:25 --> Controller Class Initialized
DEBUG - 2016-10-11 08:24:25 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 08:24:25 --> Config Class Initialized
INFO - 2016-10-11 08:24:25 --> Hooks Class Initialized
DEBUG - 2016-10-11 08:24:25 --> UTF-8 Support Enabled
INFO - 2016-10-11 08:24:25 --> Utf8 Class Initialized
INFO - 2016-10-11 08:24:25 --> URI Class Initialized
INFO - 2016-10-11 08:24:25 --> Router Class Initialized
INFO - 2016-10-11 08:24:25 --> Output Class Initialized
INFO - 2016-10-11 08:24:25 --> Security Class Initialized
DEBUG - 2016-10-11 08:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 08:24:25 --> Input Class Initialized
INFO - 2016-10-11 08:24:25 --> Language Class Initialized
INFO - 2016-10-11 08:24:25 --> Language Class Initialized
INFO - 2016-10-11 08:24:25 --> Config Class Initialized
INFO - 2016-10-11 08:24:25 --> Loader Class Initialized
INFO - 2016-10-11 08:24:25 --> Helper loaded: common_helper
INFO - 2016-10-11 08:24:25 --> Helper loaded: url_helper
INFO - 2016-10-11 08:24:25 --> Database Driver Class Initialized
INFO - 2016-10-11 08:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 08:24:25 --> Parser Class Initialized
INFO - 2016-10-11 08:24:25 --> Controller Class Initialized
DEBUG - 2016-10-11 08:24:25 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 08:24:25 --> Model Class Initialized
DEBUG - 2016-10-11 08:24:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 08:24:25 --> Model Class Initialized
DEBUG - 2016-10-11 08:24:25 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-11 08:24:25 --> Final output sent to browser
DEBUG - 2016-10-11 08:24:25 --> Total execution time: 0.0341
INFO - 2016-10-11 08:24:27 --> Config Class Initialized
INFO - 2016-10-11 08:24:27 --> Hooks Class Initialized
DEBUG - 2016-10-11 08:24:27 --> UTF-8 Support Enabled
INFO - 2016-10-11 08:24:27 --> Utf8 Class Initialized
INFO - 2016-10-11 08:24:27 --> URI Class Initialized
INFO - 2016-10-11 08:24:27 --> Router Class Initialized
INFO - 2016-10-11 08:24:27 --> Output Class Initialized
INFO - 2016-10-11 08:24:27 --> Security Class Initialized
DEBUG - 2016-10-11 08:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 08:24:27 --> Input Class Initialized
INFO - 2016-10-11 08:24:27 --> Language Class Initialized
INFO - 2016-10-11 08:24:27 --> Language Class Initialized
INFO - 2016-10-11 08:24:27 --> Config Class Initialized
INFO - 2016-10-11 08:24:27 --> Loader Class Initialized
INFO - 2016-10-11 08:24:27 --> Helper loaded: common_helper
INFO - 2016-10-11 08:24:27 --> Helper loaded: url_helper
INFO - 2016-10-11 08:24:27 --> Database Driver Class Initialized
INFO - 2016-10-11 08:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 08:24:27 --> Parser Class Initialized
INFO - 2016-10-11 08:24:27 --> Controller Class Initialized
DEBUG - 2016-10-11 08:24:27 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 08:24:27 --> Model Class Initialized
DEBUG - 2016-10-11 08:24:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 08:24:27 --> Model Class Initialized
INFO - 2016-10-11 08:24:27 --> Final output sent to browser
DEBUG - 2016-10-11 08:24:27 --> Total execution time: 0.0345
INFO - 2016-10-11 08:24:27 --> Config Class Initialized
INFO - 2016-10-11 08:24:27 --> Hooks Class Initialized
DEBUG - 2016-10-11 08:24:27 --> UTF-8 Support Enabled
INFO - 2016-10-11 08:24:27 --> Utf8 Class Initialized
INFO - 2016-10-11 08:24:27 --> URI Class Initialized
INFO - 2016-10-11 08:24:27 --> Router Class Initialized
INFO - 2016-10-11 08:24:27 --> Output Class Initialized
INFO - 2016-10-11 08:24:27 --> Security Class Initialized
DEBUG - 2016-10-11 08:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 08:24:27 --> Input Class Initialized
INFO - 2016-10-11 08:24:27 --> Language Class Initialized
INFO - 2016-10-11 08:24:27 --> Language Class Initialized
INFO - 2016-10-11 08:24:27 --> Config Class Initialized
INFO - 2016-10-11 08:24:27 --> Loader Class Initialized
INFO - 2016-10-11 08:24:27 --> Helper loaded: common_helper
INFO - 2016-10-11 08:24:27 --> Helper loaded: url_helper
INFO - 2016-10-11 08:24:27 --> Database Driver Class Initialized
INFO - 2016-10-11 08:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 08:24:27 --> Parser Class Initialized
INFO - 2016-10-11 08:24:27 --> Controller Class Initialized
DEBUG - 2016-10-11 08:24:27 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 08:24:27 --> Model Class Initialized
DEBUG - 2016-10-11 08:24:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 08:24:27 --> Model Class Initialized
DEBUG - 2016-10-11 08:24:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-11 08:24:27 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 08:24:27 --> Model Class Initialized
DEBUG - 2016-10-11 08:24:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 08:24:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 08:24:27 --> Model Class Initialized
DEBUG - 2016-10-11 08:24:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 08:24:27 --> Model Class Initialized
DEBUG - 2016-10-11 08:24:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 08:24:27 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 08:24:27 --> Final output sent to browser
DEBUG - 2016-10-11 08:24:27 --> Total execution time: 0.1000
INFO - 2016-10-11 08:24:29 --> Config Class Initialized
INFO - 2016-10-11 08:24:29 --> Hooks Class Initialized
DEBUG - 2016-10-11 08:24:29 --> UTF-8 Support Enabled
INFO - 2016-10-11 08:24:29 --> Utf8 Class Initialized
INFO - 2016-10-11 08:24:29 --> URI Class Initialized
INFO - 2016-10-11 08:24:29 --> Router Class Initialized
INFO - 2016-10-11 08:24:29 --> Output Class Initialized
INFO - 2016-10-11 08:24:29 --> Security Class Initialized
DEBUG - 2016-10-11 08:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 08:24:29 --> Input Class Initialized
INFO - 2016-10-11 08:24:29 --> Language Class Initialized
ERROR - 2016-10-11 08:24:29 --> 404 Page Not Found: /index
INFO - 2016-10-11 09:23:34 --> Config Class Initialized
INFO - 2016-10-11 09:23:34 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:23:34 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:23:34 --> Utf8 Class Initialized
INFO - 2016-10-11 09:23:34 --> URI Class Initialized
INFO - 2016-10-11 09:23:34 --> Router Class Initialized
INFO - 2016-10-11 09:23:34 --> Output Class Initialized
INFO - 2016-10-11 09:23:34 --> Security Class Initialized
DEBUG - 2016-10-11 09:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:23:34 --> Input Class Initialized
INFO - 2016-10-11 09:23:34 --> Language Class Initialized
INFO - 2016-10-11 09:23:34 --> Language Class Initialized
INFO - 2016-10-11 09:23:34 --> Config Class Initialized
INFO - 2016-10-11 09:23:34 --> Loader Class Initialized
INFO - 2016-10-11 09:23:34 --> Helper loaded: common_helper
INFO - 2016-10-11 09:23:34 --> Helper loaded: url_helper
INFO - 2016-10-11 09:23:34 --> Database Driver Class Initialized
INFO - 2016-10-11 09:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 09:23:34 --> Parser Class Initialized
INFO - 2016-10-11 09:23:34 --> Controller Class Initialized
DEBUG - 2016-10-11 09:23:34 --> Home MX_Controller Initialized
INFO - 2016-10-11 09:23:34 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-11 09:23:34 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-11 09:23:34 --> Content MX_Controller Initialized
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 09:23:34 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-11 09:23:34 --> Slider MX_Controller Initialized
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-11 09:23:34 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-11 09:23:34 --> Servers MX_Controller Initialized
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 09:23:34 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-11 09:23:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-11 09:23:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-11 09:23:34 --> Final output sent to browser
DEBUG - 2016-10-11 09:23:34 --> Total execution time: 0.1585
INFO - 2016-10-11 09:23:34 --> Config Class Initialized
INFO - 2016-10-11 09:23:34 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:23:34 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:23:34 --> Utf8 Class Initialized
INFO - 2016-10-11 09:23:34 --> URI Class Initialized
INFO - 2016-10-11 09:23:34 --> Router Class Initialized
INFO - 2016-10-11 09:23:34 --> Output Class Initialized
INFO - 2016-10-11 09:23:34 --> Security Class Initialized
DEBUG - 2016-10-11 09:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:23:34 --> Input Class Initialized
INFO - 2016-10-11 09:23:34 --> Language Class Initialized
ERROR - 2016-10-11 09:23:34 --> 404 Page Not Found: /index
INFO - 2016-10-11 09:23:45 --> Config Class Initialized
INFO - 2016-10-11 09:23:45 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:23:45 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:23:45 --> Utf8 Class Initialized
INFO - 2016-10-11 09:23:45 --> URI Class Initialized
INFO - 2016-10-11 09:23:45 --> Router Class Initialized
INFO - 2016-10-11 09:23:45 --> Output Class Initialized
INFO - 2016-10-11 09:23:45 --> Security Class Initialized
DEBUG - 2016-10-11 09:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:23:45 --> Input Class Initialized
INFO - 2016-10-11 09:23:45 --> Language Class Initialized
INFO - 2016-10-11 09:23:45 --> Language Class Initialized
INFO - 2016-10-11 09:23:45 --> Config Class Initialized
INFO - 2016-10-11 09:23:45 --> Loader Class Initialized
INFO - 2016-10-11 09:23:45 --> Helper loaded: common_helper
INFO - 2016-10-11 09:23:45 --> Helper loaded: url_helper
INFO - 2016-10-11 09:23:45 --> Database Driver Class Initialized
INFO - 2016-10-11 09:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 09:23:45 --> Parser Class Initialized
INFO - 2016-10-11 09:23:45 --> Controller Class Initialized
DEBUG - 2016-10-11 09:23:45 --> User MX_Controller Initialized
INFO - 2016-10-11 09:23:45 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:45 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-11 09:23:45 --> Model Class Initialized
INFO - 2016-10-11 09:23:45 --> Helper loaded: cookie_helper
INFO - 2016-10-11 09:23:45 --> Helper loaded: form_helper
DEBUG - 2016-10-11 09:23:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 09:23:45 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 09:23:45 --> Model Class Initialized
INFO - 2016-10-11 09:23:45 --> Final output sent to browser
DEBUG - 2016-10-11 09:23:45 --> Total execution time: 0.0792
INFO - 2016-10-11 09:23:47 --> Config Class Initialized
INFO - 2016-10-11 09:23:47 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:23:47 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:23:47 --> Utf8 Class Initialized
INFO - 2016-10-11 09:23:47 --> URI Class Initialized
DEBUG - 2016-10-11 09:23:47 --> No URI present. Default controller set.
INFO - 2016-10-11 09:23:47 --> Router Class Initialized
INFO - 2016-10-11 09:23:47 --> Output Class Initialized
INFO - 2016-10-11 09:23:47 --> Security Class Initialized
DEBUG - 2016-10-11 09:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:23:47 --> Input Class Initialized
INFO - 2016-10-11 09:23:47 --> Language Class Initialized
INFO - 2016-10-11 09:23:47 --> Language Class Initialized
INFO - 2016-10-11 09:23:47 --> Config Class Initialized
INFO - 2016-10-11 09:23:47 --> Loader Class Initialized
INFO - 2016-10-11 09:23:47 --> Helper loaded: common_helper
INFO - 2016-10-11 09:23:47 --> Helper loaded: url_helper
INFO - 2016-10-11 09:23:47 --> Database Driver Class Initialized
INFO - 2016-10-11 09:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 09:23:47 --> Parser Class Initialized
INFO - 2016-10-11 09:23:47 --> Controller Class Initialized
DEBUG - 2016-10-11 09:23:47 --> Home MX_Controller Initialized
INFO - 2016-10-11 09:23:47 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:47 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-11 09:23:47 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-11 09:23:47 --> Module controller failed to run: banner/index
DEBUG - 2016-10-11 09:23:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-11 09:23:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-11 09:23:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-11 09:23:47 --> Final output sent to browser
DEBUG - 2016-10-11 09:23:47 --> Total execution time: 0.0595
INFO - 2016-10-11 09:23:51 --> Config Class Initialized
INFO - 2016-10-11 09:23:51 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:23:51 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:23:51 --> Utf8 Class Initialized
INFO - 2016-10-11 09:23:51 --> URI Class Initialized
INFO - 2016-10-11 09:23:51 --> Router Class Initialized
INFO - 2016-10-11 09:23:51 --> Output Class Initialized
INFO - 2016-10-11 09:23:51 --> Security Class Initialized
DEBUG - 2016-10-11 09:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:23:51 --> Input Class Initialized
INFO - 2016-10-11 09:23:51 --> Language Class Initialized
INFO - 2016-10-11 09:23:51 --> Language Class Initialized
INFO - 2016-10-11 09:23:51 --> Config Class Initialized
INFO - 2016-10-11 09:23:51 --> Loader Class Initialized
INFO - 2016-10-11 09:23:51 --> Helper loaded: common_helper
INFO - 2016-10-11 09:23:51 --> Helper loaded: url_helper
INFO - 2016-10-11 09:23:51 --> Database Driver Class Initialized
INFO - 2016-10-11 09:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 09:23:51 --> Parser Class Initialized
INFO - 2016-10-11 09:23:51 --> Controller Class Initialized
DEBUG - 2016-10-11 09:23:51 --> Donate_report MX_Controller Initialized
INFO - 2016-10-11 09:23:51 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 09:23:51 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 09:23:51 --> Model Class Initialized
INFO - 2016-10-11 09:23:51 --> Helper loaded: form_helper
INFO - 2016-10-11 09:23:51 --> Form Validation Class Initialized
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/views/FRONTEND/pagedonate_new.php
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-11 09:23:51 --> Slider MX_Controller Initialized
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-11 09:23:51 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-11 09:23:51 --> Servers MX_Controller Initialized
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 09:23:51 --> Model Class Initialized
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-11 09:23:51 --> Module controller failed to run: banner/index
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-11 09:23:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-11 09:23:51 --> Final output sent to browser
DEBUG - 2016-10-11 09:23:51 --> Total execution time: 0.1286
INFO - 2016-10-11 09:23:52 --> Config Class Initialized
INFO - 2016-10-11 09:23:52 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:23:52 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:23:52 --> Utf8 Class Initialized
INFO - 2016-10-11 09:23:52 --> URI Class Initialized
INFO - 2016-10-11 09:23:52 --> Router Class Initialized
INFO - 2016-10-11 09:23:52 --> Config Class Initialized
INFO - 2016-10-11 09:23:52 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:23:52 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:23:52 --> Utf8 Class Initialized
INFO - 2016-10-11 09:23:52 --> URI Class Initialized
INFO - 2016-10-11 09:23:52 --> Output Class Initialized
INFO - 2016-10-11 09:23:52 --> Security Class Initialized
DEBUG - 2016-10-11 09:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:23:52 --> Input Class Initialized
INFO - 2016-10-11 09:23:52 --> Language Class Initialized
ERROR - 2016-10-11 09:23:52 --> 404 Page Not Found: /index
INFO - 2016-10-11 09:23:52 --> Router Class Initialized
INFO - 2016-10-11 09:23:52 --> Output Class Initialized
INFO - 2016-10-11 09:23:52 --> Security Class Initialized
DEBUG - 2016-10-11 09:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:23:52 --> Input Class Initialized
INFO - 2016-10-11 09:23:52 --> Language Class Initialized
ERROR - 2016-10-11 09:23:52 --> 404 Page Not Found: /index
INFO - 2016-10-11 09:24:08 --> Config Class Initialized
INFO - 2016-10-11 09:24:08 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:24:08 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:24:08 --> Utf8 Class Initialized
INFO - 2016-10-11 09:24:08 --> URI Class Initialized
INFO - 2016-10-11 09:24:08 --> Router Class Initialized
INFO - 2016-10-11 09:24:08 --> Output Class Initialized
INFO - 2016-10-11 09:24:08 --> Security Class Initialized
DEBUG - 2016-10-11 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:24:08 --> Input Class Initialized
INFO - 2016-10-11 09:24:08 --> Language Class Initialized
INFO - 2016-10-11 09:24:08 --> Language Class Initialized
INFO - 2016-10-11 09:24:08 --> Config Class Initialized
INFO - 2016-10-11 09:24:08 --> Loader Class Initialized
INFO - 2016-10-11 09:24:08 --> Helper loaded: common_helper
INFO - 2016-10-11 09:24:08 --> Helper loaded: url_helper
INFO - 2016-10-11 09:24:08 --> Database Driver Class Initialized
INFO - 2016-10-11 09:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 09:24:08 --> Parser Class Initialized
INFO - 2016-10-11 09:24:08 --> Controller Class Initialized
DEBUG - 2016-10-11 09:24:08 --> Donate_report MX_Controller Initialized
INFO - 2016-10-11 09:24:08 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:08 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-11 09:24:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 09:24:08 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 09:24:08 --> Model Class Initialized
INFO - 2016-10-11 09:24:08 --> Helper loaded: form_helper
INFO - 2016-10-11 09:24:08 --> Form Validation Class Initialized
DEBUG - 2016-10-11 09:24:08 --> File loaded: /home/dolongpk/public_html/application/modules/donate_config/models/Donate_config_model.php
DEBUG - 2016-10-11 09:24:08 --> Config file loaded: /home/dolongpk/public_html/application/config/donate_config_setting.php
DEBUG - 2016-10-11 09:24:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 09:24:08 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:08 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-11 09:24:08 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:08 --> File loaded: /home/dolongpk/public_html/application/modules/mobile_card/models/Mobile_card_model.php
INFO - 2016-10-11 09:24:08 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:08 --> Config file loaded: /home/dolongpk/public_html/application/config/mobile_card_config.php
INFO - 2016-10-11 09:24:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-11 09:24:13 --> Final output sent to browser
DEBUG - 2016-10-11 09:24:13 --> Total execution time: 4.9447
INFO - 2016-10-11 09:24:43 --> Config Class Initialized
INFO - 2016-10-11 09:24:43 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:24:43 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:24:43 --> Utf8 Class Initialized
INFO - 2016-10-11 09:24:43 --> URI Class Initialized
INFO - 2016-10-11 09:24:43 --> Router Class Initialized
INFO - 2016-10-11 09:24:43 --> Output Class Initialized
INFO - 2016-10-11 09:24:43 --> Security Class Initialized
DEBUG - 2016-10-11 09:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:24:43 --> Input Class Initialized
INFO - 2016-10-11 09:24:43 --> Language Class Initialized
INFO - 2016-10-11 09:24:43 --> Language Class Initialized
INFO - 2016-10-11 09:24:43 --> Config Class Initialized
INFO - 2016-10-11 09:24:43 --> Loader Class Initialized
INFO - 2016-10-11 09:24:43 --> Helper loaded: common_helper
INFO - 2016-10-11 09:24:43 --> Helper loaded: url_helper
INFO - 2016-10-11 09:24:43 --> Database Driver Class Initialized
INFO - 2016-10-11 09:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 09:24:43 --> Parser Class Initialized
INFO - 2016-10-11 09:24:43 --> Controller Class Initialized
DEBUG - 2016-10-11 09:24:43 --> Donate_report MX_Controller Initialized
INFO - 2016-10-11 09:24:43 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:43 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-11 09:24:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 09:24:43 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 09:24:43 --> Model Class Initialized
INFO - 2016-10-11 09:24:43 --> Helper loaded: form_helper
INFO - 2016-10-11 09:24:43 --> Form Validation Class Initialized
DEBUG - 2016-10-11 09:24:43 --> File loaded: /home/dolongpk/public_html/application/modules/donate_config/models/Donate_config_model.php
DEBUG - 2016-10-11 09:24:43 --> Config file loaded: /home/dolongpk/public_html/application/config/donate_config_setting.php
DEBUG - 2016-10-11 09:24:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 09:24:43 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:43 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-11 09:24:43 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:43 --> File loaded: /home/dolongpk/public_html/application/modules/mobile_card/models/Mobile_card_model.php
INFO - 2016-10-11 09:24:43 --> Model Class Initialized
DEBUG - 2016-10-11 09:24:43 --> Config file loaded: /home/dolongpk/public_html/application/config/mobile_card_config.php
INFO - 2016-10-11 09:24:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-10-11 09:24:46 --> Final output sent to browser
DEBUG - 2016-10-11 09:24:46 --> Total execution time: 3.6415
INFO - 2016-10-11 09:37:00 --> Config Class Initialized
INFO - 2016-10-11 09:37:00 --> Hooks Class Initialized
DEBUG - 2016-10-11 09:37:00 --> UTF-8 Support Enabled
INFO - 2016-10-11 09:37:00 --> Utf8 Class Initialized
INFO - 2016-10-11 09:37:00 --> URI Class Initialized
INFO - 2016-10-11 09:37:00 --> Router Class Initialized
INFO - 2016-10-11 09:37:00 --> Output Class Initialized
INFO - 2016-10-11 09:37:00 --> Security Class Initialized
DEBUG - 2016-10-11 09:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 09:37:00 --> Input Class Initialized
INFO - 2016-10-11 09:37:00 --> Language Class Initialized
INFO - 2016-10-11 09:37:00 --> Language Class Initialized
INFO - 2016-10-11 09:37:00 --> Config Class Initialized
INFO - 2016-10-11 09:37:00 --> Loader Class Initialized
INFO - 2016-10-11 09:37:00 --> Helper loaded: common_helper
INFO - 2016-10-11 09:37:00 --> Helper loaded: url_helper
INFO - 2016-10-11 09:37:00 --> Database Driver Class Initialized
INFO - 2016-10-11 09:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 09:37:00 --> Parser Class Initialized
INFO - 2016-10-11 09:37:00 --> Controller Class Initialized
DEBUG - 2016-10-11 09:37:00 --> Content MX_Controller Initialized
INFO - 2016-10-11 09:37:00 --> Model Class Initialized
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-11 09:37:00 --> Model Class Initialized
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 09:37:00 --> Model Class Initialized
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-11 09:37:00 --> Slider MX_Controller Initialized
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-11 09:37:00 --> Model Class Initialized
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-11 09:37:00 --> Servers MX_Controller Initialized
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 09:37:00 --> Model Class Initialized
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-11 09:37:00 --> Module controller failed to run: banner/index
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-11 09:37:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-11 09:37:00 --> Final output sent to browser
DEBUG - 2016-10-11 09:37:00 --> Total execution time: 0.0867
INFO - 2016-10-11 10:54:30 --> Config Class Initialized
INFO - 2016-10-11 10:54:30 --> Hooks Class Initialized
DEBUG - 2016-10-11 10:54:30 --> UTF-8 Support Enabled
INFO - 2016-10-11 10:54:30 --> Utf8 Class Initialized
INFO - 2016-10-11 10:54:30 --> URI Class Initialized
INFO - 2016-10-11 10:54:30 --> Router Class Initialized
INFO - 2016-10-11 10:54:30 --> Output Class Initialized
INFO - 2016-10-11 10:54:30 --> Security Class Initialized
DEBUG - 2016-10-11 10:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 10:54:30 --> Input Class Initialized
INFO - 2016-10-11 10:54:30 --> Language Class Initialized
ERROR - 2016-10-11 10:54:30 --> 404 Page Not Found: /index
INFO - 2016-10-11 10:54:30 --> Config Class Initialized
INFO - 2016-10-11 10:54:30 --> Hooks Class Initialized
DEBUG - 2016-10-11 10:54:30 --> UTF-8 Support Enabled
INFO - 2016-10-11 10:54:30 --> Utf8 Class Initialized
INFO - 2016-10-11 10:54:30 --> URI Class Initialized
INFO - 2016-10-11 10:54:30 --> Router Class Initialized
INFO - 2016-10-11 10:54:30 --> Output Class Initialized
INFO - 2016-10-11 10:54:30 --> Security Class Initialized
DEBUG - 2016-10-11 10:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 10:54:30 --> Input Class Initialized
INFO - 2016-10-11 10:54:30 --> Language Class Initialized
ERROR - 2016-10-11 10:54:30 --> 404 Page Not Found: /index
INFO - 2016-10-11 11:06:41 --> Config Class Initialized
INFO - 2016-10-11 11:06:41 --> Hooks Class Initialized
DEBUG - 2016-10-11 11:06:41 --> UTF-8 Support Enabled
INFO - 2016-10-11 11:06:41 --> Utf8 Class Initialized
INFO - 2016-10-11 11:06:41 --> URI Class Initialized
INFO - 2016-10-11 11:06:41 --> Router Class Initialized
INFO - 2016-10-11 11:06:41 --> Output Class Initialized
INFO - 2016-10-11 11:06:41 --> Security Class Initialized
DEBUG - 2016-10-11 11:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 11:06:41 --> Input Class Initialized
INFO - 2016-10-11 11:06:41 --> Language Class Initialized
ERROR - 2016-10-11 11:06:41 --> 404 Page Not Found: /index
INFO - 2016-10-11 12:32:32 --> Config Class Initialized
INFO - 2016-10-11 12:32:32 --> Hooks Class Initialized
DEBUG - 2016-10-11 12:32:32 --> UTF-8 Support Enabled
INFO - 2016-10-11 12:32:32 --> Utf8 Class Initialized
INFO - 2016-10-11 12:32:32 --> URI Class Initialized
DEBUG - 2016-10-11 12:32:32 --> No URI present. Default controller set.
INFO - 2016-10-11 12:32:32 --> Router Class Initialized
INFO - 2016-10-11 12:32:32 --> Output Class Initialized
INFO - 2016-10-11 12:32:32 --> Security Class Initialized
DEBUG - 2016-10-11 12:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 12:32:32 --> Input Class Initialized
INFO - 2016-10-11 12:32:32 --> Language Class Initialized
INFO - 2016-10-11 12:32:32 --> Language Class Initialized
INFO - 2016-10-11 12:32:32 --> Config Class Initialized
INFO - 2016-10-11 12:32:32 --> Loader Class Initialized
INFO - 2016-10-11 12:32:32 --> Helper loaded: common_helper
INFO - 2016-10-11 12:32:32 --> Helper loaded: url_helper
INFO - 2016-10-11 12:32:32 --> Database Driver Class Initialized
INFO - 2016-10-11 12:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 12:32:32 --> Parser Class Initialized
INFO - 2016-10-11 12:32:32 --> Controller Class Initialized
DEBUG - 2016-10-11 12:32:32 --> Home MX_Controller Initialized
INFO - 2016-10-11 12:32:32 --> Model Class Initialized
DEBUG - 2016-10-11 12:32:32 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-11 12:32:32 --> Model Class Initialized
ERROR - 2016-10-11 12:32:32 --> Module controller failed to run: banner/index
DEBUG - 2016-10-11 12:32:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-11 12:32:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-11 12:32:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-11 12:32:32 --> Final output sent to browser
DEBUG - 2016-10-11 12:32:32 --> Total execution time: 0.0696
INFO - 2016-10-11 20:35:39 --> Config Class Initialized
INFO - 2016-10-11 20:35:39 --> Hooks Class Initialized
DEBUG - 2016-10-11 20:35:39 --> UTF-8 Support Enabled
INFO - 2016-10-11 20:35:39 --> Utf8 Class Initialized
INFO - 2016-10-11 20:35:39 --> URI Class Initialized
DEBUG - 2016-10-11 20:35:39 --> No URI present. Default controller set.
INFO - 2016-10-11 20:35:39 --> Router Class Initialized
INFO - 2016-10-11 20:35:39 --> Output Class Initialized
INFO - 2016-10-11 20:35:39 --> Security Class Initialized
DEBUG - 2016-10-11 20:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 20:35:39 --> Input Class Initialized
INFO - 2016-10-11 20:35:39 --> Language Class Initialized
INFO - 2016-10-11 20:35:39 --> Language Class Initialized
INFO - 2016-10-11 20:35:39 --> Config Class Initialized
INFO - 2016-10-11 20:35:39 --> Loader Class Initialized
INFO - 2016-10-11 20:35:39 --> Helper loaded: common_helper
INFO - 2016-10-11 20:35:39 --> Helper loaded: url_helper
INFO - 2016-10-11 20:35:39 --> Database Driver Class Initialized
INFO - 2016-10-11 20:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 20:35:39 --> Parser Class Initialized
INFO - 2016-10-11 20:35:39 --> Controller Class Initialized
DEBUG - 2016-10-11 20:35:39 --> Home MX_Controller Initialized
INFO - 2016-10-11 20:35:39 --> Model Class Initialized
DEBUG - 2016-10-11 20:35:39 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-11 20:35:39 --> Model Class Initialized
ERROR - 2016-10-11 20:35:39 --> Module controller failed to run: banner/index
DEBUG - 2016-10-11 20:35:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-11 20:35:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-11 20:35:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-11 20:35:39 --> Final output sent to browser
DEBUG - 2016-10-11 20:35:39 --> Total execution time: 0.0432
INFO - 2016-10-11 22:44:30 --> Config Class Initialized
INFO - 2016-10-11 22:44:30 --> Hooks Class Initialized
DEBUG - 2016-10-11 22:44:30 --> UTF-8 Support Enabled
INFO - 2016-10-11 22:44:30 --> Utf8 Class Initialized
INFO - 2016-10-11 22:44:30 --> URI Class Initialized
INFO - 2016-10-11 22:44:30 --> Router Class Initialized
INFO - 2016-10-11 22:44:30 --> Output Class Initialized
INFO - 2016-10-11 22:44:30 --> Security Class Initialized
DEBUG - 2016-10-11 22:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 22:44:30 --> Input Class Initialized
INFO - 2016-10-11 22:44:30 --> Language Class Initialized
INFO - 2016-10-11 22:44:30 --> Language Class Initialized
INFO - 2016-10-11 22:44:30 --> Config Class Initialized
INFO - 2016-10-11 22:44:30 --> Loader Class Initialized
INFO - 2016-10-11 22:44:30 --> Helper loaded: common_helper
INFO - 2016-10-11 22:44:30 --> Helper loaded: url_helper
INFO - 2016-10-11 22:44:30 --> Database Driver Class Initialized
INFO - 2016-10-11 22:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 22:44:30 --> Parser Class Initialized
INFO - 2016-10-11 22:44:30 --> Controller Class Initialized
DEBUG - 2016-10-11 22:44:30 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 22:44:30 --> Config Class Initialized
INFO - 2016-10-11 22:44:30 --> Hooks Class Initialized
DEBUG - 2016-10-11 22:44:30 --> UTF-8 Support Enabled
INFO - 2016-10-11 22:44:30 --> Utf8 Class Initialized
INFO - 2016-10-11 22:44:30 --> URI Class Initialized
INFO - 2016-10-11 22:44:30 --> Router Class Initialized
INFO - 2016-10-11 22:44:30 --> Output Class Initialized
INFO - 2016-10-11 22:44:30 --> Security Class Initialized
DEBUG - 2016-10-11 22:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 22:44:30 --> Input Class Initialized
INFO - 2016-10-11 22:44:30 --> Language Class Initialized
INFO - 2016-10-11 22:44:30 --> Language Class Initialized
INFO - 2016-10-11 22:44:30 --> Config Class Initialized
INFO - 2016-10-11 22:44:30 --> Loader Class Initialized
INFO - 2016-10-11 22:44:30 --> Helper loaded: common_helper
INFO - 2016-10-11 22:44:30 --> Helper loaded: url_helper
INFO - 2016-10-11 22:44:30 --> Database Driver Class Initialized
INFO - 2016-10-11 22:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 22:44:30 --> Parser Class Initialized
INFO - 2016-10-11 22:44:30 --> Controller Class Initialized
DEBUG - 2016-10-11 22:44:30 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 22:44:30 --> Model Class Initialized
DEBUG - 2016-10-11 22:44:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 22:44:30 --> Model Class Initialized
DEBUG - 2016-10-11 22:44:30 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-11 22:44:30 --> Final output sent to browser
DEBUG - 2016-10-11 22:44:30 --> Total execution time: 0.0320
INFO - 2016-10-11 22:44:32 --> Config Class Initialized
INFO - 2016-10-11 22:44:32 --> Hooks Class Initialized
DEBUG - 2016-10-11 22:44:32 --> UTF-8 Support Enabled
INFO - 2016-10-11 22:44:32 --> Utf8 Class Initialized
INFO - 2016-10-11 22:44:32 --> URI Class Initialized
INFO - 2016-10-11 22:44:32 --> Router Class Initialized
INFO - 2016-10-11 22:44:32 --> Output Class Initialized
INFO - 2016-10-11 22:44:32 --> Security Class Initialized
DEBUG - 2016-10-11 22:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 22:44:32 --> Input Class Initialized
INFO - 2016-10-11 22:44:32 --> Language Class Initialized
INFO - 2016-10-11 22:44:32 --> Language Class Initialized
INFO - 2016-10-11 22:44:32 --> Config Class Initialized
INFO - 2016-10-11 22:44:32 --> Loader Class Initialized
INFO - 2016-10-11 22:44:32 --> Helper loaded: common_helper
INFO - 2016-10-11 22:44:32 --> Helper loaded: url_helper
INFO - 2016-10-11 22:44:32 --> Database Driver Class Initialized
INFO - 2016-10-11 22:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 22:44:32 --> Parser Class Initialized
INFO - 2016-10-11 22:44:32 --> Controller Class Initialized
DEBUG - 2016-10-11 22:44:32 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 22:44:32 --> Model Class Initialized
DEBUG - 2016-10-11 22:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 22:44:32 --> Model Class Initialized
INFO - 2016-10-11 22:44:32 --> Final output sent to browser
DEBUG - 2016-10-11 22:44:32 --> Total execution time: 0.0504
INFO - 2016-10-11 22:44:32 --> Config Class Initialized
INFO - 2016-10-11 22:44:32 --> Hooks Class Initialized
DEBUG - 2016-10-11 22:44:32 --> UTF-8 Support Enabled
INFO - 2016-10-11 22:44:32 --> Utf8 Class Initialized
INFO - 2016-10-11 22:44:32 --> URI Class Initialized
INFO - 2016-10-11 22:44:32 --> Router Class Initialized
INFO - 2016-10-11 22:44:32 --> Output Class Initialized
INFO - 2016-10-11 22:44:32 --> Security Class Initialized
DEBUG - 2016-10-11 22:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 22:44:32 --> Input Class Initialized
INFO - 2016-10-11 22:44:32 --> Language Class Initialized
INFO - 2016-10-11 22:44:32 --> Language Class Initialized
INFO - 2016-10-11 22:44:32 --> Config Class Initialized
INFO - 2016-10-11 22:44:32 --> Loader Class Initialized
INFO - 2016-10-11 22:44:32 --> Helper loaded: common_helper
INFO - 2016-10-11 22:44:32 --> Helper loaded: url_helper
INFO - 2016-10-11 22:44:32 --> Database Driver Class Initialized
INFO - 2016-10-11 22:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 22:44:32 --> Parser Class Initialized
INFO - 2016-10-11 22:44:32 --> Controller Class Initialized
DEBUG - 2016-10-11 22:44:32 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 22:44:32 --> Model Class Initialized
DEBUG - 2016-10-11 22:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 22:44:32 --> Model Class Initialized
DEBUG - 2016-10-11 22:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-11 22:44:32 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 22:44:32 --> Model Class Initialized
DEBUG - 2016-10-11 22:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 22:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 22:44:32 --> Model Class Initialized
DEBUG - 2016-10-11 22:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 22:44:32 --> Model Class Initialized
DEBUG - 2016-10-11 22:44:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 22:44:32 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 22:44:32 --> Final output sent to browser
DEBUG - 2016-10-11 22:44:32 --> Total execution time: 0.0454
INFO - 2016-10-11 22:44:33 --> Config Class Initialized
INFO - 2016-10-11 22:44:33 --> Hooks Class Initialized
DEBUG - 2016-10-11 22:44:33 --> UTF-8 Support Enabled
INFO - 2016-10-11 22:44:33 --> Utf8 Class Initialized
INFO - 2016-10-11 22:44:33 --> URI Class Initialized
INFO - 2016-10-11 22:44:33 --> Router Class Initialized
INFO - 2016-10-11 22:44:33 --> Output Class Initialized
INFO - 2016-10-11 22:44:33 --> Security Class Initialized
DEBUG - 2016-10-11 22:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 22:44:33 --> Input Class Initialized
INFO - 2016-10-11 22:44:33 --> Language Class Initialized
ERROR - 2016-10-11 22:44:33 --> 404 Page Not Found: /index
INFO - 2016-10-11 22:56:06 --> Config Class Initialized
INFO - 2016-10-11 22:56:06 --> Hooks Class Initialized
DEBUG - 2016-10-11 22:56:06 --> UTF-8 Support Enabled
INFO - 2016-10-11 22:56:06 --> Utf8 Class Initialized
INFO - 2016-10-11 22:56:06 --> URI Class Initialized
INFO - 2016-10-11 22:56:06 --> Router Class Initialized
INFO - 2016-10-11 22:56:06 --> Output Class Initialized
INFO - 2016-10-11 22:56:06 --> Security Class Initialized
DEBUG - 2016-10-11 22:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 22:56:06 --> Input Class Initialized
INFO - 2016-10-11 22:56:06 --> Language Class Initialized
INFO - 2016-10-11 22:56:06 --> Language Class Initialized
INFO - 2016-10-11 22:56:06 --> Config Class Initialized
INFO - 2016-10-11 22:56:06 --> Loader Class Initialized
INFO - 2016-10-11 22:56:06 --> Helper loaded: common_helper
INFO - 2016-10-11 22:56:06 --> Helper loaded: url_helper
INFO - 2016-10-11 22:56:06 --> Database Driver Class Initialized
INFO - 2016-10-11 22:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 22:56:06 --> Parser Class Initialized
INFO - 2016-10-11 22:56:06 --> Controller Class Initialized
DEBUG - 2016-10-11 22:56:06 --> Servers MX_Controller Initialized
INFO - 2016-10-11 22:56:06 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 22:56:06 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 22:56:06 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 22:56:06 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 22:56:06 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 22:56:06 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 22:56:06 --> Final output sent to browser
DEBUG - 2016-10-11 22:56:06 --> Total execution time: 0.0599
INFO - 2016-10-11 22:56:06 --> Config Class Initialized
INFO - 2016-10-11 22:56:06 --> Hooks Class Initialized
DEBUG - 2016-10-11 22:56:06 --> UTF-8 Support Enabled
INFO - 2016-10-11 22:56:06 --> Utf8 Class Initialized
INFO - 2016-10-11 22:56:06 --> URI Class Initialized
INFO - 2016-10-11 22:56:06 --> Router Class Initialized
INFO - 2016-10-11 22:56:06 --> Output Class Initialized
INFO - 2016-10-11 22:56:06 --> Security Class Initialized
DEBUG - 2016-10-11 22:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 22:56:06 --> Input Class Initialized
INFO - 2016-10-11 22:56:06 --> Language Class Initialized
INFO - 2016-10-11 22:56:06 --> Language Class Initialized
INFO - 2016-10-11 22:56:06 --> Config Class Initialized
INFO - 2016-10-11 22:56:06 --> Loader Class Initialized
INFO - 2016-10-11 22:56:06 --> Helper loaded: common_helper
INFO - 2016-10-11 22:56:06 --> Helper loaded: url_helper
INFO - 2016-10-11 22:56:06 --> Database Driver Class Initialized
INFO - 2016-10-11 22:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 22:56:06 --> Parser Class Initialized
INFO - 2016-10-11 22:56:06 --> Controller Class Initialized
DEBUG - 2016-10-11 22:56:06 --> Servers MX_Controller Initialized
INFO - 2016-10-11 22:56:06 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 22:56:06 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 22:56:06 --> Model Class Initialized
INFO - 2016-10-11 22:56:06 --> Config Class Initialized
INFO - 2016-10-11 22:56:06 --> Hooks Class Initialized
DEBUG - 2016-10-11 22:56:06 --> UTF-8 Support Enabled
INFO - 2016-10-11 22:56:06 --> Utf8 Class Initialized
DEBUG - 2016-10-11 22:56:06 --> Pagination Class Initialized
INFO - 2016-10-11 22:56:06 --> URI Class Initialized
DEBUG - 2016-10-11 22:56:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-11 22:56:06 --> Final output sent to browser
DEBUG - 2016-10-11 22:56:06 --> Total execution time: 0.0882
INFO - 2016-10-11 22:56:06 --> Router Class Initialized
INFO - 2016-10-11 22:56:06 --> Output Class Initialized
INFO - 2016-10-11 22:56:06 --> Security Class Initialized
DEBUG - 2016-10-11 22:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 22:56:06 --> Input Class Initialized
INFO - 2016-10-11 22:56:06 --> Language Class Initialized
ERROR - 2016-10-11 22:56:06 --> 404 Page Not Found: /index
INFO - 2016-10-11 22:56:08 --> Config Class Initialized
INFO - 2016-10-11 22:56:08 --> Hooks Class Initialized
DEBUG - 2016-10-11 22:56:08 --> UTF-8 Support Enabled
INFO - 2016-10-11 22:56:08 --> Utf8 Class Initialized
INFO - 2016-10-11 22:56:08 --> URI Class Initialized
INFO - 2016-10-11 22:56:09 --> Router Class Initialized
INFO - 2016-10-11 22:56:09 --> Output Class Initialized
INFO - 2016-10-11 22:56:09 --> Security Class Initialized
DEBUG - 2016-10-11 22:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 22:56:09 --> Input Class Initialized
INFO - 2016-10-11 22:56:09 --> Language Class Initialized
INFO - 2016-10-11 22:56:09 --> Language Class Initialized
INFO - 2016-10-11 22:56:09 --> Config Class Initialized
INFO - 2016-10-11 22:56:09 --> Loader Class Initialized
INFO - 2016-10-11 22:56:09 --> Helper loaded: common_helper
INFO - 2016-10-11 22:56:09 --> Helper loaded: url_helper
INFO - 2016-10-11 22:56:09 --> Database Driver Class Initialized
INFO - 2016-10-11 22:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 22:56:09 --> Parser Class Initialized
INFO - 2016-10-11 22:56:09 --> Controller Class Initialized
DEBUG - 2016-10-11 22:56:09 --> Servers MX_Controller Initialized
INFO - 2016-10-11 22:56:09 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:09 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 22:56:09 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 22:56:09 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:09 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 22:56:09 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 22:56:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 22:56:09 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 22:56:09 --> Model Class Initialized
DEBUG - 2016-10-11 22:56:09 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-11 22:56:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 22:56:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 22:56:09 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 22:56:09 --> Final output sent to browser
DEBUG - 2016-10-11 22:56:09 --> Total execution time: 0.0678
INFO - 2016-10-11 23:00:13 --> Config Class Initialized
INFO - 2016-10-11 23:00:13 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:00:13 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:00:13 --> Utf8 Class Initialized
INFO - 2016-10-11 23:00:13 --> URI Class Initialized
INFO - 2016-10-11 23:00:13 --> Router Class Initialized
INFO - 2016-10-11 23:00:13 --> Output Class Initialized
INFO - 2016-10-11 23:00:13 --> Security Class Initialized
DEBUG - 2016-10-11 23:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:00:13 --> Input Class Initialized
INFO - 2016-10-11 23:00:13 --> Language Class Initialized
INFO - 2016-10-11 23:00:13 --> Language Class Initialized
INFO - 2016-10-11 23:00:13 --> Config Class Initialized
INFO - 2016-10-11 23:00:13 --> Loader Class Initialized
INFO - 2016-10-11 23:00:13 --> Helper loaded: common_helper
INFO - 2016-10-11 23:00:13 --> Helper loaded: url_helper
INFO - 2016-10-11 23:00:13 --> Database Driver Class Initialized
INFO - 2016-10-11 23:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:00:13 --> Parser Class Initialized
INFO - 2016-10-11 23:00:13 --> Controller Class Initialized
DEBUG - 2016-10-11 23:00:13 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:00:13 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:13 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:00:13 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:00:13 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:13 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:00:13 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:00:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:00:13 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:00:13 --> Model Class Initialized
INFO - 2016-10-11 23:00:33 --> Config Class Initialized
INFO - 2016-10-11 23:00:33 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:00:33 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:00:33 --> Utf8 Class Initialized
INFO - 2016-10-11 23:00:33 --> URI Class Initialized
INFO - 2016-10-11 23:00:33 --> Router Class Initialized
INFO - 2016-10-11 23:00:33 --> Output Class Initialized
INFO - 2016-10-11 23:00:33 --> Security Class Initialized
DEBUG - 2016-10-11 23:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:00:33 --> Input Class Initialized
INFO - 2016-10-11 23:00:33 --> Language Class Initialized
INFO - 2016-10-11 23:00:33 --> Language Class Initialized
INFO - 2016-10-11 23:00:33 --> Config Class Initialized
INFO - 2016-10-11 23:00:33 --> Loader Class Initialized
INFO - 2016-10-11 23:00:33 --> Helper loaded: common_helper
INFO - 2016-10-11 23:00:33 --> Helper loaded: url_helper
INFO - 2016-10-11 23:00:33 --> Database Driver Class Initialized
INFO - 2016-10-11 23:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:00:33 --> Parser Class Initialized
INFO - 2016-10-11 23:00:33 --> Controller Class Initialized
DEBUG - 2016-10-11 23:00:33 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:00:33 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:00:33 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:00:33 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:00:33 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:00:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:00:33 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:00:33 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-11 23:00:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:00:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:00:33 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:00:33 --> Final output sent to browser
DEBUG - 2016-10-11 23:00:33 --> Total execution time: 0.0476
INFO - 2016-10-11 23:00:52 --> Config Class Initialized
INFO - 2016-10-11 23:00:52 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:00:52 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:00:52 --> Utf8 Class Initialized
INFO - 2016-10-11 23:00:52 --> URI Class Initialized
INFO - 2016-10-11 23:00:52 --> Router Class Initialized
INFO - 2016-10-11 23:00:52 --> Output Class Initialized
INFO - 2016-10-11 23:00:52 --> Security Class Initialized
DEBUG - 2016-10-11 23:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:00:52 --> Input Class Initialized
INFO - 2016-10-11 23:00:52 --> Language Class Initialized
INFO - 2016-10-11 23:00:52 --> Language Class Initialized
INFO - 2016-10-11 23:00:52 --> Config Class Initialized
INFO - 2016-10-11 23:00:52 --> Loader Class Initialized
INFO - 2016-10-11 23:00:52 --> Helper loaded: common_helper
INFO - 2016-10-11 23:00:52 --> Helper loaded: url_helper
INFO - 2016-10-11 23:00:52 --> Database Driver Class Initialized
INFO - 2016-10-11 23:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:00:52 --> Parser Class Initialized
INFO - 2016-10-11 23:00:52 --> Controller Class Initialized
DEBUG - 2016-10-11 23:00:52 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:00:52 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:52 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:00:52 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:00:52 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:52 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:00:52 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:00:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:00:52 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:00:52 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:52 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-11 23:00:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:00:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:00:52 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:00:52 --> Final output sent to browser
DEBUG - 2016-10-11 23:00:52 --> Total execution time: 0.0520
INFO - 2016-10-11 23:00:53 --> Config Class Initialized
INFO - 2016-10-11 23:00:53 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:00:53 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:00:53 --> Utf8 Class Initialized
INFO - 2016-10-11 23:00:53 --> URI Class Initialized
INFO - 2016-10-11 23:00:53 --> Router Class Initialized
INFO - 2016-10-11 23:00:53 --> Output Class Initialized
INFO - 2016-10-11 23:00:53 --> Security Class Initialized
DEBUG - 2016-10-11 23:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:00:53 --> Input Class Initialized
INFO - 2016-10-11 23:00:53 --> Language Class Initialized
ERROR - 2016-10-11 23:00:53 --> 404 Page Not Found: /index
INFO - 2016-10-11 23:00:53 --> Config Class Initialized
INFO - 2016-10-11 23:00:53 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:00:53 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:00:53 --> Utf8 Class Initialized
INFO - 2016-10-11 23:00:53 --> URI Class Initialized
INFO - 2016-10-11 23:00:53 --> Router Class Initialized
INFO - 2016-10-11 23:00:53 --> Output Class Initialized
INFO - 2016-10-11 23:00:53 --> Security Class Initialized
DEBUG - 2016-10-11 23:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:00:53 --> Input Class Initialized
INFO - 2016-10-11 23:00:53 --> Language Class Initialized
INFO - 2016-10-11 23:00:53 --> Language Class Initialized
INFO - 2016-10-11 23:00:53 --> Config Class Initialized
INFO - 2016-10-11 23:00:53 --> Loader Class Initialized
INFO - 2016-10-11 23:00:53 --> Helper loaded: common_helper
INFO - 2016-10-11 23:00:53 --> Helper loaded: url_helper
INFO - 2016-10-11 23:00:53 --> Database Driver Class Initialized
INFO - 2016-10-11 23:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:00:53 --> Parser Class Initialized
INFO - 2016-10-11 23:00:53 --> Controller Class Initialized
DEBUG - 2016-10-11 23:00:53 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:00:53 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:00:53 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:00:53 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:53 --> Pagination Class Initialized
DEBUG - 2016-10-11 23:00:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-11 23:00:53 --> Final output sent to browser
DEBUG - 2016-10-11 23:00:53 --> Total execution time: 0.0476
INFO - 2016-10-11 23:00:54 --> Config Class Initialized
INFO - 2016-10-11 23:00:54 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:00:54 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:00:54 --> Utf8 Class Initialized
INFO - 2016-10-11 23:00:54 --> URI Class Initialized
INFO - 2016-10-11 23:00:54 --> Router Class Initialized
INFO - 2016-10-11 23:00:54 --> Output Class Initialized
INFO - 2016-10-11 23:00:54 --> Security Class Initialized
DEBUG - 2016-10-11 23:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:00:54 --> Input Class Initialized
INFO - 2016-10-11 23:00:54 --> Language Class Initialized
INFO - 2016-10-11 23:00:54 --> Language Class Initialized
INFO - 2016-10-11 23:00:54 --> Config Class Initialized
INFO - 2016-10-11 23:00:54 --> Loader Class Initialized
INFO - 2016-10-11 23:00:54 --> Helper loaded: common_helper
INFO - 2016-10-11 23:00:54 --> Helper loaded: url_helper
INFO - 2016-10-11 23:00:54 --> Database Driver Class Initialized
INFO - 2016-10-11 23:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:00:54 --> Parser Class Initialized
INFO - 2016-10-11 23:00:54 --> Controller Class Initialized
DEBUG - 2016-10-11 23:00:54 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:00:54 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:00:54 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:00:54 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:00:54 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:00:54 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:00:54 --> Model Class Initialized
DEBUG - 2016-10-11 23:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-11 23:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:00:54 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:00:54 --> Final output sent to browser
DEBUG - 2016-10-11 23:00:54 --> Total execution time: 0.0516
INFO - 2016-10-11 23:01:24 --> Config Class Initialized
INFO - 2016-10-11 23:01:24 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:01:24 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:01:24 --> Utf8 Class Initialized
INFO - 2016-10-11 23:01:24 --> URI Class Initialized
INFO - 2016-10-11 23:01:24 --> Router Class Initialized
INFO - 2016-10-11 23:01:24 --> Output Class Initialized
INFO - 2016-10-11 23:01:24 --> Security Class Initialized
DEBUG - 2016-10-11 23:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:01:24 --> Input Class Initialized
INFO - 2016-10-11 23:01:24 --> Language Class Initialized
INFO - 2016-10-11 23:01:24 --> Language Class Initialized
INFO - 2016-10-11 23:01:24 --> Config Class Initialized
INFO - 2016-10-11 23:01:24 --> Loader Class Initialized
INFO - 2016-10-11 23:01:24 --> Helper loaded: common_helper
INFO - 2016-10-11 23:01:24 --> Helper loaded: url_helper
INFO - 2016-10-11 23:01:24 --> Database Driver Class Initialized
INFO - 2016-10-11 23:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:01:24 --> Parser Class Initialized
INFO - 2016-10-11 23:01:24 --> Controller Class Initialized
DEBUG - 2016-10-11 23:01:24 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:01:24 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:01:24 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:01:24 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:24 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:01:24 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:01:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:01:24 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:01:24 --> Model Class Initialized
INFO - 2016-10-11 23:01:34 --> Config Class Initialized
INFO - 2016-10-11 23:01:34 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:01:34 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:01:34 --> Utf8 Class Initialized
INFO - 2016-10-11 23:01:34 --> URI Class Initialized
INFO - 2016-10-11 23:01:34 --> Router Class Initialized
INFO - 2016-10-11 23:01:34 --> Output Class Initialized
INFO - 2016-10-11 23:01:34 --> Security Class Initialized
DEBUG - 2016-10-11 23:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:01:34 --> Input Class Initialized
INFO - 2016-10-11 23:01:34 --> Language Class Initialized
INFO - 2016-10-11 23:01:34 --> Language Class Initialized
INFO - 2016-10-11 23:01:34 --> Config Class Initialized
INFO - 2016-10-11 23:01:34 --> Loader Class Initialized
INFO - 2016-10-11 23:01:34 --> Helper loaded: common_helper
INFO - 2016-10-11 23:01:34 --> Helper loaded: url_helper
INFO - 2016-10-11 23:01:34 --> Database Driver Class Initialized
INFO - 2016-10-11 23:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:01:34 --> Parser Class Initialized
INFO - 2016-10-11 23:01:34 --> Controller Class Initialized
DEBUG - 2016-10-11 23:01:34 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:01:34 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:01:34 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:01:34 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:01:34 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:01:34 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:01:34 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-11 23:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:01:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:01:34 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:01:34 --> Final output sent to browser
DEBUG - 2016-10-11 23:01:34 --> Total execution time: 0.0485
INFO - 2016-10-11 23:01:41 --> Config Class Initialized
INFO - 2016-10-11 23:01:41 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:01:41 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:01:41 --> Utf8 Class Initialized
INFO - 2016-10-11 23:01:41 --> URI Class Initialized
INFO - 2016-10-11 23:01:41 --> Router Class Initialized
INFO - 2016-10-11 23:01:41 --> Output Class Initialized
INFO - 2016-10-11 23:01:41 --> Security Class Initialized
DEBUG - 2016-10-11 23:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:01:41 --> Input Class Initialized
INFO - 2016-10-11 23:01:41 --> Language Class Initialized
INFO - 2016-10-11 23:01:41 --> Language Class Initialized
INFO - 2016-10-11 23:01:41 --> Config Class Initialized
INFO - 2016-10-11 23:01:41 --> Loader Class Initialized
INFO - 2016-10-11 23:01:41 --> Helper loaded: common_helper
INFO - 2016-10-11 23:01:41 --> Helper loaded: url_helper
INFO - 2016-10-11 23:01:41 --> Database Driver Class Initialized
INFO - 2016-10-11 23:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:01:41 --> Parser Class Initialized
INFO - 2016-10-11 23:01:41 --> Controller Class Initialized
DEBUG - 2016-10-11 23:01:41 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:01:41 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:01:41 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:01:41 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:01:41 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:01:41 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:01:41 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:01:41 --> Final output sent to browser
DEBUG - 2016-10-11 23:01:41 --> Total execution time: 0.0506
INFO - 2016-10-11 23:01:41 --> Config Class Initialized
INFO - 2016-10-11 23:01:41 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:01:41 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:01:41 --> Utf8 Class Initialized
INFO - 2016-10-11 23:01:41 --> URI Class Initialized
INFO - 2016-10-11 23:01:41 --> Router Class Initialized
INFO - 2016-10-11 23:01:41 --> Output Class Initialized
INFO - 2016-10-11 23:01:41 --> Security Class Initialized
DEBUG - 2016-10-11 23:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:01:41 --> Input Class Initialized
INFO - 2016-10-11 23:01:41 --> Language Class Initialized
ERROR - 2016-10-11 23:01:41 --> 404 Page Not Found: /index
INFO - 2016-10-11 23:01:41 --> Config Class Initialized
INFO - 2016-10-11 23:01:41 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:01:41 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:01:41 --> Utf8 Class Initialized
INFO - 2016-10-11 23:01:41 --> URI Class Initialized
INFO - 2016-10-11 23:01:41 --> Router Class Initialized
INFO - 2016-10-11 23:01:41 --> Output Class Initialized
INFO - 2016-10-11 23:01:41 --> Security Class Initialized
DEBUG - 2016-10-11 23:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:01:41 --> Input Class Initialized
INFO - 2016-10-11 23:01:41 --> Language Class Initialized
INFO - 2016-10-11 23:01:41 --> Language Class Initialized
INFO - 2016-10-11 23:01:41 --> Config Class Initialized
INFO - 2016-10-11 23:01:41 --> Loader Class Initialized
INFO - 2016-10-11 23:01:41 --> Helper loaded: common_helper
INFO - 2016-10-11 23:01:41 --> Helper loaded: url_helper
INFO - 2016-10-11 23:01:41 --> Database Driver Class Initialized
INFO - 2016-10-11 23:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:01:41 --> Parser Class Initialized
INFO - 2016-10-11 23:01:41 --> Controller Class Initialized
DEBUG - 2016-10-11 23:01:41 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:01:41 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:01:41 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:01:41 --> Model Class Initialized
DEBUG - 2016-10-11 23:01:41 --> Pagination Class Initialized
DEBUG - 2016-10-11 23:01:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-11 23:01:41 --> Final output sent to browser
DEBUG - 2016-10-11 23:01:41 --> Total execution time: 0.0377
INFO - 2016-10-11 23:02:08 --> Config Class Initialized
INFO - 2016-10-11 23:02:08 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:08 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:08 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:08 --> URI Class Initialized
INFO - 2016-10-11 23:02:08 --> Router Class Initialized
INFO - 2016-10-11 23:02:08 --> Output Class Initialized
INFO - 2016-10-11 23:02:08 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:08 --> Input Class Initialized
INFO - 2016-10-11 23:02:08 --> Language Class Initialized
INFO - 2016-10-11 23:02:08 --> Language Class Initialized
INFO - 2016-10-11 23:02:08 --> Config Class Initialized
INFO - 2016-10-11 23:02:08 --> Loader Class Initialized
INFO - 2016-10-11 23:02:08 --> Helper loaded: common_helper
INFO - 2016-10-11 23:02:08 --> Helper loaded: url_helper
INFO - 2016-10-11 23:02:08 --> Database Driver Class Initialized
INFO - 2016-10-11 23:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:02:08 --> Parser Class Initialized
INFO - 2016-10-11 23:02:08 --> Controller Class Initialized
DEBUG - 2016-10-11 23:02:08 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:02:08 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:02:08 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:02:08 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:02:08 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:02:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:02:08 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:02:08 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-11 23:02:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:02:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:02:08 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:02:08 --> Final output sent to browser
DEBUG - 2016-10-11 23:02:08 --> Total execution time: 0.0470
INFO - 2016-10-11 23:02:19 --> Config Class Initialized
INFO - 2016-10-11 23:02:19 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:19 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:19 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:19 --> URI Class Initialized
INFO - 2016-10-11 23:02:19 --> Router Class Initialized
INFO - 2016-10-11 23:02:19 --> Output Class Initialized
INFO - 2016-10-11 23:02:19 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:19 --> Input Class Initialized
INFO - 2016-10-11 23:02:19 --> Language Class Initialized
INFO - 2016-10-11 23:02:19 --> Language Class Initialized
INFO - 2016-10-11 23:02:19 --> Config Class Initialized
INFO - 2016-10-11 23:02:19 --> Loader Class Initialized
INFO - 2016-10-11 23:02:19 --> Helper loaded: common_helper
INFO - 2016-10-11 23:02:19 --> Helper loaded: url_helper
INFO - 2016-10-11 23:02:19 --> Database Driver Class Initialized
INFO - 2016-10-11 23:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:02:19 --> Parser Class Initialized
INFO - 2016-10-11 23:02:19 --> Controller Class Initialized
DEBUG - 2016-10-11 23:02:19 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:02:19 --> Config Class Initialized
INFO - 2016-10-11 23:02:19 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:19 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:19 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:19 --> URI Class Initialized
INFO - 2016-10-11 23:02:19 --> Router Class Initialized
INFO - 2016-10-11 23:02:19 --> Output Class Initialized
INFO - 2016-10-11 23:02:19 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:19 --> Input Class Initialized
INFO - 2016-10-11 23:02:19 --> Language Class Initialized
INFO - 2016-10-11 23:02:19 --> Language Class Initialized
INFO - 2016-10-11 23:02:19 --> Config Class Initialized
INFO - 2016-10-11 23:02:19 --> Loader Class Initialized
INFO - 2016-10-11 23:02:19 --> Helper loaded: common_helper
INFO - 2016-10-11 23:02:19 --> Helper loaded: url_helper
INFO - 2016-10-11 23:02:19 --> Database Driver Class Initialized
INFO - 2016-10-11 23:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:02:19 --> Parser Class Initialized
INFO - 2016-10-11 23:02:19 --> Controller Class Initialized
DEBUG - 2016-10-11 23:02:19 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:02:19 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:02:19 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:19 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-11 23:02:19 --> Final output sent to browser
DEBUG - 2016-10-11 23:02:19 --> Total execution time: 0.0335
INFO - 2016-10-11 23:02:23 --> Config Class Initialized
INFO - 2016-10-11 23:02:23 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:23 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:23 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:23 --> URI Class Initialized
INFO - 2016-10-11 23:02:23 --> Router Class Initialized
INFO - 2016-10-11 23:02:23 --> Output Class Initialized
INFO - 2016-10-11 23:02:23 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:23 --> Input Class Initialized
INFO - 2016-10-11 23:02:23 --> Language Class Initialized
INFO - 2016-10-11 23:02:23 --> Language Class Initialized
INFO - 2016-10-11 23:02:23 --> Config Class Initialized
INFO - 2016-10-11 23:02:23 --> Loader Class Initialized
INFO - 2016-10-11 23:02:23 --> Helper loaded: common_helper
INFO - 2016-10-11 23:02:23 --> Helper loaded: url_helper
INFO - 2016-10-11 23:02:23 --> Database Driver Class Initialized
INFO - 2016-10-11 23:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:02:23 --> Parser Class Initialized
INFO - 2016-10-11 23:02:23 --> Controller Class Initialized
DEBUG - 2016-10-11 23:02:23 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:02:23 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:02:23 --> Model Class Initialized
INFO - 2016-10-11 23:02:23 --> Final output sent to browser
DEBUG - 2016-10-11 23:02:23 --> Total execution time: 0.0308
INFO - 2016-10-11 23:02:23 --> Config Class Initialized
INFO - 2016-10-11 23:02:23 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:23 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:23 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:23 --> URI Class Initialized
INFO - 2016-10-11 23:02:23 --> Router Class Initialized
INFO - 2016-10-11 23:02:23 --> Output Class Initialized
INFO - 2016-10-11 23:02:23 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:23 --> Input Class Initialized
INFO - 2016-10-11 23:02:23 --> Language Class Initialized
INFO - 2016-10-11 23:02:23 --> Language Class Initialized
INFO - 2016-10-11 23:02:23 --> Config Class Initialized
INFO - 2016-10-11 23:02:23 --> Loader Class Initialized
INFO - 2016-10-11 23:02:23 --> Helper loaded: common_helper
INFO - 2016-10-11 23:02:23 --> Helper loaded: url_helper
INFO - 2016-10-11 23:02:23 --> Database Driver Class Initialized
INFO - 2016-10-11 23:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:02:23 --> Parser Class Initialized
INFO - 2016-10-11 23:02:23 --> Controller Class Initialized
DEBUG - 2016-10-11 23:02:23 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:02:23 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:02:23 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-11 23:02:23 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:02:23 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:02:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:02:23 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:02:23 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:02:23 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:02:23 --> Final output sent to browser
DEBUG - 2016-10-11 23:02:23 --> Total execution time: 0.0388
INFO - 2016-10-11 23:02:25 --> Config Class Initialized
INFO - 2016-10-11 23:02:25 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:25 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:25 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:25 --> URI Class Initialized
INFO - 2016-10-11 23:02:25 --> Router Class Initialized
INFO - 2016-10-11 23:02:25 --> Output Class Initialized
INFO - 2016-10-11 23:02:25 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:25 --> Input Class Initialized
INFO - 2016-10-11 23:02:25 --> Language Class Initialized
ERROR - 2016-10-11 23:02:25 --> 404 Page Not Found: /index
INFO - 2016-10-11 23:02:28 --> Config Class Initialized
INFO - 2016-10-11 23:02:28 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:28 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:28 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:28 --> URI Class Initialized
INFO - 2016-10-11 23:02:28 --> Router Class Initialized
INFO - 2016-10-11 23:02:28 --> Output Class Initialized
INFO - 2016-10-11 23:02:28 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:28 --> Input Class Initialized
INFO - 2016-10-11 23:02:28 --> Language Class Initialized
INFO - 2016-10-11 23:02:28 --> Language Class Initialized
INFO - 2016-10-11 23:02:28 --> Config Class Initialized
INFO - 2016-10-11 23:02:28 --> Loader Class Initialized
INFO - 2016-10-11 23:02:28 --> Helper loaded: common_helper
INFO - 2016-10-11 23:02:28 --> Helper loaded: url_helper
INFO - 2016-10-11 23:02:28 --> Database Driver Class Initialized
INFO - 2016-10-11 23:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:02:28 --> Parser Class Initialized
INFO - 2016-10-11 23:02:28 --> Controller Class Initialized
DEBUG - 2016-10-11 23:02:28 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:02:28 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:02:28 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:02:28 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:02:28 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:02:28 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:02:28 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:02:28 --> Final output sent to browser
DEBUG - 2016-10-11 23:02:28 --> Total execution time: 0.0434
INFO - 2016-10-11 23:02:28 --> Config Class Initialized
INFO - 2016-10-11 23:02:28 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:28 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:28 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:28 --> URI Class Initialized
INFO - 2016-10-11 23:02:28 --> Router Class Initialized
INFO - 2016-10-11 23:02:28 --> Output Class Initialized
INFO - 2016-10-11 23:02:28 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:28 --> Input Class Initialized
INFO - 2016-10-11 23:02:28 --> Language Class Initialized
ERROR - 2016-10-11 23:02:28 --> 404 Page Not Found: /index
INFO - 2016-10-11 23:02:28 --> Config Class Initialized
INFO - 2016-10-11 23:02:28 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:28 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:28 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:28 --> URI Class Initialized
INFO - 2016-10-11 23:02:28 --> Router Class Initialized
INFO - 2016-10-11 23:02:28 --> Output Class Initialized
INFO - 2016-10-11 23:02:28 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:28 --> Input Class Initialized
INFO - 2016-10-11 23:02:28 --> Language Class Initialized
INFO - 2016-10-11 23:02:28 --> Language Class Initialized
INFO - 2016-10-11 23:02:28 --> Config Class Initialized
INFO - 2016-10-11 23:02:28 --> Loader Class Initialized
INFO - 2016-10-11 23:02:28 --> Helper loaded: common_helper
INFO - 2016-10-11 23:02:28 --> Helper loaded: url_helper
INFO - 2016-10-11 23:02:28 --> Database Driver Class Initialized
INFO - 2016-10-11 23:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:02:28 --> Parser Class Initialized
INFO - 2016-10-11 23:02:28 --> Controller Class Initialized
DEBUG - 2016-10-11 23:02:28 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:02:28 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:02:28 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:02:28 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:28 --> Pagination Class Initialized
DEBUG - 2016-10-11 23:02:28 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-11 23:02:28 --> Final output sent to browser
DEBUG - 2016-10-11 23:02:28 --> Total execution time: 0.0519
INFO - 2016-10-11 23:02:30 --> Config Class Initialized
INFO - 2016-10-11 23:02:30 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:02:30 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:02:30 --> Utf8 Class Initialized
INFO - 2016-10-11 23:02:30 --> URI Class Initialized
INFO - 2016-10-11 23:02:30 --> Router Class Initialized
INFO - 2016-10-11 23:02:30 --> Output Class Initialized
INFO - 2016-10-11 23:02:30 --> Security Class Initialized
DEBUG - 2016-10-11 23:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:02:30 --> Input Class Initialized
INFO - 2016-10-11 23:02:30 --> Language Class Initialized
INFO - 2016-10-11 23:02:30 --> Language Class Initialized
INFO - 2016-10-11 23:02:30 --> Config Class Initialized
INFO - 2016-10-11 23:02:30 --> Loader Class Initialized
INFO - 2016-10-11 23:02:30 --> Helper loaded: common_helper
INFO - 2016-10-11 23:02:30 --> Helper loaded: url_helper
INFO - 2016-10-11 23:02:30 --> Database Driver Class Initialized
INFO - 2016-10-11 23:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:02:30 --> Parser Class Initialized
INFO - 2016-10-11 23:02:30 --> Controller Class Initialized
DEBUG - 2016-10-11 23:02:30 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:02:30 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:02:30 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:02:30 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:02:30 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:02:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:02:30 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:02:30 --> Model Class Initialized
DEBUG - 2016-10-11 23:02:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-11 23:02:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:02:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:02:30 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:02:30 --> Final output sent to browser
DEBUG - 2016-10-11 23:02:30 --> Total execution time: 0.0387
INFO - 2016-10-11 23:03:02 --> Config Class Initialized
INFO - 2016-10-11 23:03:02 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:03:02 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:03:02 --> Utf8 Class Initialized
INFO - 2016-10-11 23:03:03 --> URI Class Initialized
INFO - 2016-10-11 23:03:03 --> Router Class Initialized
INFO - 2016-10-11 23:03:03 --> Output Class Initialized
INFO - 2016-10-11 23:03:03 --> Security Class Initialized
DEBUG - 2016-10-11 23:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:03:03 --> Input Class Initialized
INFO - 2016-10-11 23:03:03 --> Language Class Initialized
INFO - 2016-10-11 23:03:03 --> Language Class Initialized
INFO - 2016-10-11 23:03:03 --> Config Class Initialized
INFO - 2016-10-11 23:03:03 --> Loader Class Initialized
INFO - 2016-10-11 23:03:03 --> Helper loaded: common_helper
INFO - 2016-10-11 23:03:03 --> Helper loaded: url_helper
INFO - 2016-10-11 23:03:03 --> Database Driver Class Initialized
INFO - 2016-10-11 23:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:03:03 --> Parser Class Initialized
INFO - 2016-10-11 23:03:03 --> Controller Class Initialized
DEBUG - 2016-10-11 23:03:03 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:03:03 --> Model Class Initialized
DEBUG - 2016-10-11 23:03:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:03:03 --> Model Class Initialized
DEBUG - 2016-10-11 23:03:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:03:03 --> Model Class Initialized
DEBUG - 2016-10-11 23:03:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:03:03 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:03:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:03:03 --> Model Class Initialized
DEBUG - 2016-10-11 23:03:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:03:03 --> Model Class Initialized
INFO - 2016-10-11 23:03:20 --> Config Class Initialized
INFO - 2016-10-11 23:03:20 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:03:20 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:03:20 --> Utf8 Class Initialized
INFO - 2016-10-11 23:03:20 --> URI Class Initialized
INFO - 2016-10-11 23:03:20 --> Router Class Initialized
INFO - 2016-10-11 23:03:20 --> Output Class Initialized
INFO - 2016-10-11 23:03:20 --> Security Class Initialized
DEBUG - 2016-10-11 23:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:03:20 --> Input Class Initialized
INFO - 2016-10-11 23:03:20 --> Language Class Initialized
INFO - 2016-10-11 23:03:20 --> Language Class Initialized
INFO - 2016-10-11 23:03:20 --> Config Class Initialized
INFO - 2016-10-11 23:03:20 --> Loader Class Initialized
INFO - 2016-10-11 23:03:20 --> Helper loaded: common_helper
INFO - 2016-10-11 23:03:20 --> Helper loaded: url_helper
INFO - 2016-10-11 23:03:20 --> Database Driver Class Initialized
INFO - 2016-10-11 23:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:03:20 --> Parser Class Initialized
INFO - 2016-10-11 23:03:20 --> Controller Class Initialized
DEBUG - 2016-10-11 23:03:20 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:03:20 --> Model Class Initialized
DEBUG - 2016-10-11 23:03:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:03:20 --> Model Class Initialized
DEBUG - 2016-10-11 23:03:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:03:20 --> Model Class Initialized
DEBUG - 2016-10-11 23:03:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:03:20 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-11 23:03:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-11 23:03:20 --> Model Class Initialized
DEBUG - 2016-10-11 23:03:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:03:20 --> Model Class Initialized
DEBUG - 2016-10-11 23:03:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-11 23:03:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-11 23:03:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-11 23:03:20 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-11 23:03:20 --> Final output sent to browser
DEBUG - 2016-10-11 23:03:20 --> Total execution time: 0.0526
INFO - 2016-10-11 23:07:54 --> Config Class Initialized
INFO - 2016-10-11 23:07:54 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:07:54 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:07:54 --> Utf8 Class Initialized
INFO - 2016-10-11 23:07:54 --> URI Class Initialized
INFO - 2016-10-11 23:07:54 --> Router Class Initialized
INFO - 2016-10-11 23:07:54 --> Output Class Initialized
INFO - 2016-10-11 23:07:54 --> Security Class Initialized
DEBUG - 2016-10-11 23:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:07:54 --> Input Class Initialized
INFO - 2016-10-11 23:07:54 --> Language Class Initialized
INFO - 2016-10-11 23:07:54 --> Language Class Initialized
INFO - 2016-10-11 23:07:54 --> Config Class Initialized
INFO - 2016-10-11 23:07:54 --> Loader Class Initialized
INFO - 2016-10-11 23:07:54 --> Helper loaded: common_helper
INFO - 2016-10-11 23:07:54 --> Helper loaded: url_helper
INFO - 2016-10-11 23:07:54 --> Database Driver Class Initialized
INFO - 2016-10-11 23:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:07:54 --> Parser Class Initialized
INFO - 2016-10-11 23:07:54 --> Controller Class Initialized
DEBUG - 2016-10-11 23:07:54 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:07:54 --> Model Class Initialized
DEBUG - 2016-10-11 23:07:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:07:54 --> Model Class Initialized
DEBUG - 2016-10-11 23:07:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:07:54 --> Model Class Initialized
DEBUG - 2016-10-11 23:07:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:07:54 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:07:55 --> Config Class Initialized
INFO - 2016-10-11 23:07:55 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:07:55 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:07:55 --> Utf8 Class Initialized
INFO - 2016-10-11 23:07:55 --> URI Class Initialized
INFO - 2016-10-11 23:07:55 --> Router Class Initialized
INFO - 2016-10-11 23:07:55 --> Output Class Initialized
INFO - 2016-10-11 23:07:55 --> Security Class Initialized
DEBUG - 2016-10-11 23:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:07:55 --> Input Class Initialized
INFO - 2016-10-11 23:07:55 --> Language Class Initialized
INFO - 2016-10-11 23:07:55 --> Language Class Initialized
INFO - 2016-10-11 23:07:55 --> Config Class Initialized
INFO - 2016-10-11 23:07:55 --> Loader Class Initialized
INFO - 2016-10-11 23:07:55 --> Helper loaded: common_helper
INFO - 2016-10-11 23:07:55 --> Helper loaded: url_helper
INFO - 2016-10-11 23:07:55 --> Database Driver Class Initialized
INFO - 2016-10-11 23:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:07:55 --> Parser Class Initialized
INFO - 2016-10-11 23:07:55 --> Controller Class Initialized
DEBUG - 2016-10-11 23:07:55 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:07:55 --> Model Class Initialized
DEBUG - 2016-10-11 23:07:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:07:55 --> Model Class Initialized
DEBUG - 2016-10-11 23:07:55 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-11 23:07:55 --> Final output sent to browser
DEBUG - 2016-10-11 23:07:55 --> Total execution time: 0.0407
INFO - 2016-10-11 23:09:14 --> Config Class Initialized
INFO - 2016-10-11 23:09:14 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:09:14 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:09:14 --> Utf8 Class Initialized
INFO - 2016-10-11 23:09:14 --> URI Class Initialized
INFO - 2016-10-11 23:09:14 --> Router Class Initialized
INFO - 2016-10-11 23:09:14 --> Output Class Initialized
INFO - 2016-10-11 23:09:14 --> Security Class Initialized
DEBUG - 2016-10-11 23:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:09:14 --> Input Class Initialized
INFO - 2016-10-11 23:09:14 --> Language Class Initialized
INFO - 2016-10-11 23:09:14 --> Language Class Initialized
INFO - 2016-10-11 23:09:14 --> Config Class Initialized
INFO - 2016-10-11 23:09:14 --> Loader Class Initialized
INFO - 2016-10-11 23:09:14 --> Helper loaded: common_helper
INFO - 2016-10-11 23:09:14 --> Helper loaded: url_helper
INFO - 2016-10-11 23:09:14 --> Database Driver Class Initialized
INFO - 2016-10-11 23:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:09:14 --> Parser Class Initialized
INFO - 2016-10-11 23:09:14 --> Controller Class Initialized
DEBUG - 2016-10-11 23:09:14 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:09:14 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:14 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:09:14 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:09:14 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:14 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:09:14 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:09:14 --> Config Class Initialized
INFO - 2016-10-11 23:09:14 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:09:14 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:09:14 --> Utf8 Class Initialized
INFO - 2016-10-11 23:09:14 --> URI Class Initialized
INFO - 2016-10-11 23:09:14 --> Router Class Initialized
INFO - 2016-10-11 23:09:14 --> Output Class Initialized
INFO - 2016-10-11 23:09:14 --> Security Class Initialized
DEBUG - 2016-10-11 23:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:09:14 --> Input Class Initialized
INFO - 2016-10-11 23:09:14 --> Language Class Initialized
INFO - 2016-10-11 23:09:14 --> Language Class Initialized
INFO - 2016-10-11 23:09:14 --> Config Class Initialized
INFO - 2016-10-11 23:09:14 --> Loader Class Initialized
INFO - 2016-10-11 23:09:14 --> Helper loaded: common_helper
INFO - 2016-10-11 23:09:14 --> Helper loaded: url_helper
INFO - 2016-10-11 23:09:14 --> Database Driver Class Initialized
INFO - 2016-10-11 23:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:09:14 --> Parser Class Initialized
INFO - 2016-10-11 23:09:14 --> Controller Class Initialized
DEBUG - 2016-10-11 23:09:14 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:09:14 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:14 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:09:14 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:09:14 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:14 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:09:14 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:09:15 --> Config Class Initialized
INFO - 2016-10-11 23:09:15 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:09:15 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:09:15 --> Utf8 Class Initialized
INFO - 2016-10-11 23:09:15 --> URI Class Initialized
INFO - 2016-10-11 23:09:15 --> Router Class Initialized
INFO - 2016-10-11 23:09:15 --> Output Class Initialized
INFO - 2016-10-11 23:09:15 --> Security Class Initialized
DEBUG - 2016-10-11 23:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:09:15 --> Input Class Initialized
INFO - 2016-10-11 23:09:15 --> Language Class Initialized
INFO - 2016-10-11 23:09:15 --> Language Class Initialized
INFO - 2016-10-11 23:09:15 --> Config Class Initialized
INFO - 2016-10-11 23:09:15 --> Loader Class Initialized
INFO - 2016-10-11 23:09:15 --> Helper loaded: common_helper
INFO - 2016-10-11 23:09:15 --> Helper loaded: url_helper
INFO - 2016-10-11 23:09:15 --> Database Driver Class Initialized
INFO - 2016-10-11 23:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:09:15 --> Parser Class Initialized
INFO - 2016-10-11 23:09:15 --> Controller Class Initialized
DEBUG - 2016-10-11 23:09:15 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:09:15 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:15 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:09:15 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:15 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-11 23:09:15 --> Final output sent to browser
DEBUG - 2016-10-11 23:09:15 --> Total execution time: 0.0395
INFO - 2016-10-11 23:09:15 --> Config Class Initialized
INFO - 2016-10-11 23:09:15 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:09:15 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:09:15 --> Utf8 Class Initialized
INFO - 2016-10-11 23:09:15 --> URI Class Initialized
INFO - 2016-10-11 23:09:15 --> Router Class Initialized
INFO - 2016-10-11 23:09:15 --> Output Class Initialized
INFO - 2016-10-11 23:09:15 --> Security Class Initialized
DEBUG - 2016-10-11 23:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:09:15 --> Input Class Initialized
INFO - 2016-10-11 23:09:15 --> Language Class Initialized
INFO - 2016-10-11 23:09:15 --> Language Class Initialized
INFO - 2016-10-11 23:09:15 --> Config Class Initialized
INFO - 2016-10-11 23:09:15 --> Loader Class Initialized
INFO - 2016-10-11 23:09:15 --> Helper loaded: common_helper
INFO - 2016-10-11 23:09:15 --> Helper loaded: url_helper
INFO - 2016-10-11 23:09:15 --> Database Driver Class Initialized
INFO - 2016-10-11 23:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:09:15 --> Parser Class Initialized
INFO - 2016-10-11 23:09:15 --> Controller Class Initialized
DEBUG - 2016-10-11 23:09:15 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:09:15 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:15 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:09:15 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:15 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-11 23:09:15 --> Final output sent to browser
DEBUG - 2016-10-11 23:09:15 --> Total execution time: 0.0332
INFO - 2016-10-11 23:09:17 --> Config Class Initialized
INFO - 2016-10-11 23:09:17 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:09:17 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:09:17 --> Utf8 Class Initialized
INFO - 2016-10-11 23:09:17 --> URI Class Initialized
INFO - 2016-10-11 23:09:17 --> Router Class Initialized
INFO - 2016-10-11 23:09:17 --> Output Class Initialized
INFO - 2016-10-11 23:09:17 --> Security Class Initialized
DEBUG - 2016-10-11 23:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:09:17 --> Input Class Initialized
INFO - 2016-10-11 23:09:17 --> Language Class Initialized
INFO - 2016-10-11 23:09:17 --> Language Class Initialized
INFO - 2016-10-11 23:09:17 --> Config Class Initialized
INFO - 2016-10-11 23:09:17 --> Loader Class Initialized
INFO - 2016-10-11 23:09:17 --> Helper loaded: common_helper
INFO - 2016-10-11 23:09:17 --> Helper loaded: url_helper
INFO - 2016-10-11 23:09:17 --> Database Driver Class Initialized
INFO - 2016-10-11 23:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:09:17 --> Parser Class Initialized
INFO - 2016-10-11 23:09:17 --> Controller Class Initialized
DEBUG - 2016-10-11 23:09:17 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:09:17 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:09:17 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:17 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-11 23:09:17 --> Final output sent to browser
DEBUG - 2016-10-11 23:09:17 --> Total execution time: 0.0334
INFO - 2016-10-11 23:09:24 --> Config Class Initialized
INFO - 2016-10-11 23:09:24 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:09:24 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:09:24 --> Utf8 Class Initialized
INFO - 2016-10-11 23:09:24 --> URI Class Initialized
INFO - 2016-10-11 23:09:24 --> Router Class Initialized
INFO - 2016-10-11 23:09:24 --> Output Class Initialized
INFO - 2016-10-11 23:09:24 --> Security Class Initialized
DEBUG - 2016-10-11 23:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:09:24 --> Input Class Initialized
INFO - 2016-10-11 23:09:24 --> Language Class Initialized
INFO - 2016-10-11 23:09:24 --> Language Class Initialized
INFO - 2016-10-11 23:09:24 --> Config Class Initialized
INFO - 2016-10-11 23:09:24 --> Loader Class Initialized
INFO - 2016-10-11 23:09:24 --> Helper loaded: common_helper
INFO - 2016-10-11 23:09:24 --> Helper loaded: url_helper
INFO - 2016-10-11 23:09:24 --> Database Driver Class Initialized
INFO - 2016-10-11 23:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:09:24 --> Parser Class Initialized
INFO - 2016-10-11 23:09:24 --> Controller Class Initialized
DEBUG - 2016-10-11 23:09:24 --> Servers MX_Controller Initialized
INFO - 2016-10-11 23:09:24 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-11 23:09:24 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-11 23:09:24 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:24 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-11 23:09:24 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:09:24 --> Config Class Initialized
INFO - 2016-10-11 23:09:24 --> Hooks Class Initialized
DEBUG - 2016-10-11 23:09:24 --> UTF-8 Support Enabled
INFO - 2016-10-11 23:09:24 --> Utf8 Class Initialized
INFO - 2016-10-11 23:09:24 --> URI Class Initialized
INFO - 2016-10-11 23:09:25 --> Router Class Initialized
INFO - 2016-10-11 23:09:25 --> Output Class Initialized
INFO - 2016-10-11 23:09:25 --> Security Class Initialized
DEBUG - 2016-10-11 23:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-11 23:09:25 --> Input Class Initialized
INFO - 2016-10-11 23:09:25 --> Language Class Initialized
INFO - 2016-10-11 23:09:25 --> Language Class Initialized
INFO - 2016-10-11 23:09:25 --> Config Class Initialized
INFO - 2016-10-11 23:09:25 --> Loader Class Initialized
INFO - 2016-10-11 23:09:25 --> Helper loaded: common_helper
INFO - 2016-10-11 23:09:25 --> Helper loaded: url_helper
INFO - 2016-10-11 23:09:25 --> Database Driver Class Initialized
INFO - 2016-10-11 23:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-11 23:09:25 --> Parser Class Initialized
INFO - 2016-10-11 23:09:25 --> Controller Class Initialized
DEBUG - 2016-10-11 23:09:25 --> Admincp MX_Controller Initialized
INFO - 2016-10-11 23:09:25 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-11 23:09:25 --> Model Class Initialized
DEBUG - 2016-10-11 23:09:25 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-11 23:09:25 --> Final output sent to browser
DEBUG - 2016-10-11 23:09:25 --> Total execution time: 0.0381
