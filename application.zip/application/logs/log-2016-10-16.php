<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-16 03:04:42 --> Config Class Initialized
INFO - 2016-10-16 03:04:42 --> Hooks Class Initialized
DEBUG - 2016-10-16 03:04:42 --> UTF-8 Support Enabled
INFO - 2016-10-16 03:04:42 --> Utf8 Class Initialized
INFO - 2016-10-16 03:04:42 --> URI Class Initialized
INFO - 2016-10-16 03:04:42 --> Router Class Initialized
INFO - 2016-10-16 03:04:42 --> Output Class Initialized
INFO - 2016-10-16 03:04:42 --> Security Class Initialized
DEBUG - 2016-10-16 03:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 03:04:42 --> Input Class Initialized
INFO - 2016-10-16 03:04:42 --> Language Class Initialized
ERROR - 2016-10-16 03:04:42 --> 404 Page Not Found: /index
INFO - 2016-10-16 03:04:43 --> Config Class Initialized
INFO - 2016-10-16 03:04:43 --> Hooks Class Initialized
DEBUG - 2016-10-16 03:04:43 --> UTF-8 Support Enabled
INFO - 2016-10-16 03:04:43 --> Utf8 Class Initialized
INFO - 2016-10-16 03:04:43 --> URI Class Initialized
DEBUG - 2016-10-16 03:04:43 --> No URI present. Default controller set.
INFO - 2016-10-16 03:04:43 --> Router Class Initialized
INFO - 2016-10-16 03:04:43 --> Output Class Initialized
INFO - 2016-10-16 03:04:43 --> Security Class Initialized
DEBUG - 2016-10-16 03:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 03:04:43 --> Input Class Initialized
INFO - 2016-10-16 03:04:43 --> Language Class Initialized
INFO - 2016-10-16 03:04:43 --> Language Class Initialized
INFO - 2016-10-16 03:04:43 --> Config Class Initialized
INFO - 2016-10-16 03:04:43 --> Loader Class Initialized
INFO - 2016-10-16 03:04:43 --> Helper loaded: common_helper
INFO - 2016-10-16 03:04:43 --> Helper loaded: url_helper
INFO - 2016-10-16 03:04:43 --> Database Driver Class Initialized
INFO - 2016-10-16 03:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 03:04:43 --> Parser Class Initialized
INFO - 2016-10-16 03:04:43 --> Controller Class Initialized
DEBUG - 2016-10-16 03:04:43 --> Home MX_Controller Initialized
INFO - 2016-10-16 03:04:43 --> Model Class Initialized
DEBUG - 2016-10-16 03:04:43 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-16 03:04:43 --> Model Class Initialized
ERROR - 2016-10-16 03:04:43 --> Module controller failed to run: banner/index
DEBUG - 2016-10-16 03:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-16 03:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-16 03:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-16 03:04:43 --> Final output sent to browser
DEBUG - 2016-10-16 03:04:43 --> Total execution time: 0.0837
INFO - 2016-10-16 14:06:30 --> Config Class Initialized
INFO - 2016-10-16 14:06:30 --> Hooks Class Initialized
DEBUG - 2016-10-16 14:06:30 --> UTF-8 Support Enabled
INFO - 2016-10-16 14:06:30 --> Utf8 Class Initialized
INFO - 2016-10-16 14:06:30 --> URI Class Initialized
INFO - 2016-10-16 14:06:30 --> Router Class Initialized
INFO - 2016-10-16 14:06:30 --> Output Class Initialized
INFO - 2016-10-16 14:06:30 --> Security Class Initialized
DEBUG - 2016-10-16 14:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 14:06:30 --> Input Class Initialized
INFO - 2016-10-16 14:06:30 --> Language Class Initialized
INFO - 2016-10-16 14:06:30 --> Language Class Initialized
INFO - 2016-10-16 14:06:30 --> Config Class Initialized
INFO - 2016-10-16 14:06:30 --> Loader Class Initialized
INFO - 2016-10-16 14:06:30 --> Helper loaded: common_helper
INFO - 2016-10-16 14:06:30 --> Helper loaded: url_helper
INFO - 2016-10-16 14:06:30 --> Database Driver Class Initialized
INFO - 2016-10-16 14:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 14:06:30 --> Parser Class Initialized
INFO - 2016-10-16 14:06:30 --> Controller Class Initialized
DEBUG - 2016-10-16 14:06:30 --> Content MX_Controller Initialized
INFO - 2016-10-16 14:06:30 --> Model Class Initialized
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-16 14:06:30 --> Model Class Initialized
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-16 14:06:30 --> Model Class Initialized
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-16 14:06:30 --> Slider MX_Controller Initialized
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-16 14:06:30 --> Model Class Initialized
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-16 14:06:30 --> Servers MX_Controller Initialized
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-16 14:06:30 --> Model Class Initialized
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-16 14:06:30 --> Module controller failed to run: banner/index
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-16 14:06:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-16 14:06:30 --> Final output sent to browser
DEBUG - 2016-10-16 14:06:30 --> Total execution time: 0.0800
INFO - 2016-10-16 15:49:33 --> Config Class Initialized
INFO - 2016-10-16 15:49:33 --> Hooks Class Initialized
DEBUG - 2016-10-16 15:49:33 --> UTF-8 Support Enabled
INFO - 2016-10-16 15:49:33 --> Utf8 Class Initialized
INFO - 2016-10-16 15:49:33 --> URI Class Initialized
INFO - 2016-10-16 15:49:33 --> Router Class Initialized
INFO - 2016-10-16 15:49:33 --> Output Class Initialized
INFO - 2016-10-16 15:49:33 --> Security Class Initialized
DEBUG - 2016-10-16 15:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 15:49:33 --> Input Class Initialized
INFO - 2016-10-16 15:49:33 --> Language Class Initialized
ERROR - 2016-10-16 15:49:33 --> 404 Page Not Found: /index
INFO - 2016-10-16 15:49:33 --> Config Class Initialized
INFO - 2016-10-16 15:49:33 --> Hooks Class Initialized
DEBUG - 2016-10-16 15:49:33 --> UTF-8 Support Enabled
INFO - 2016-10-16 15:49:33 --> Utf8 Class Initialized
INFO - 2016-10-16 15:49:33 --> URI Class Initialized
DEBUG - 2016-10-16 15:49:33 --> No URI present. Default controller set.
INFO - 2016-10-16 15:49:33 --> Router Class Initialized
INFO - 2016-10-16 15:49:33 --> Output Class Initialized
INFO - 2016-10-16 15:49:33 --> Security Class Initialized
DEBUG - 2016-10-16 15:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 15:49:33 --> Input Class Initialized
INFO - 2016-10-16 15:49:33 --> Language Class Initialized
INFO - 2016-10-16 15:49:33 --> Language Class Initialized
INFO - 2016-10-16 15:49:33 --> Config Class Initialized
INFO - 2016-10-16 15:49:33 --> Loader Class Initialized
INFO - 2016-10-16 15:49:33 --> Helper loaded: common_helper
INFO - 2016-10-16 15:49:33 --> Helper loaded: url_helper
INFO - 2016-10-16 15:49:33 --> Database Driver Class Initialized
INFO - 2016-10-16 15:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 15:49:33 --> Parser Class Initialized
INFO - 2016-10-16 15:49:33 --> Controller Class Initialized
DEBUG - 2016-10-16 15:49:33 --> Home MX_Controller Initialized
INFO - 2016-10-16 15:49:33 --> Model Class Initialized
DEBUG - 2016-10-16 15:49:33 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-16 15:49:33 --> Model Class Initialized
ERROR - 2016-10-16 15:49:33 --> Module controller failed to run: banner/index
DEBUG - 2016-10-16 15:49:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-16 15:49:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-16 15:49:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-16 15:49:33 --> Final output sent to browser
DEBUG - 2016-10-16 15:49:33 --> Total execution time: 0.0421
INFO - 2016-10-16 17:50:47 --> Config Class Initialized
INFO - 2016-10-16 17:50:47 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:50:47 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:50:47 --> Utf8 Class Initialized
INFO - 2016-10-16 17:50:47 --> URI Class Initialized
DEBUG - 2016-10-16 17:50:47 --> No URI present. Default controller set.
INFO - 2016-10-16 17:50:47 --> Router Class Initialized
INFO - 2016-10-16 17:50:47 --> Output Class Initialized
INFO - 2016-10-16 17:50:47 --> Security Class Initialized
DEBUG - 2016-10-16 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:50:47 --> Input Class Initialized
INFO - 2016-10-16 17:50:47 --> Language Class Initialized
INFO - 2016-10-16 17:50:47 --> Language Class Initialized
INFO - 2016-10-16 17:50:47 --> Config Class Initialized
INFO - 2016-10-16 17:50:47 --> Loader Class Initialized
INFO - 2016-10-16 17:50:47 --> Helper loaded: common_helper
INFO - 2016-10-16 17:50:47 --> Helper loaded: url_helper
INFO - 2016-10-16 17:50:47 --> Database Driver Class Initialized
INFO - 2016-10-16 17:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:50:47 --> Parser Class Initialized
INFO - 2016-10-16 17:50:47 --> Controller Class Initialized
DEBUG - 2016-10-16 17:50:47 --> Home MX_Controller Initialized
INFO - 2016-10-16 17:50:47 --> Model Class Initialized
DEBUG - 2016-10-16 17:50:47 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-16 17:50:47 --> Model Class Initialized
ERROR - 2016-10-16 17:50:47 --> Module controller failed to run: banner/index
DEBUG - 2016-10-16 17:50:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-16 17:50:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-16 17:50:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-16 17:50:47 --> Final output sent to browser
DEBUG - 2016-10-16 17:50:47 --> Total execution time: 0.0436
INFO - 2016-10-16 17:50:50 --> Config Class Initialized
INFO - 2016-10-16 17:50:50 --> Hooks Class Initialized
DEBUG - 2016-10-16 17:50:50 --> UTF-8 Support Enabled
INFO - 2016-10-16 17:50:50 --> Utf8 Class Initialized
INFO - 2016-10-16 17:50:50 --> URI Class Initialized
DEBUG - 2016-10-16 17:50:50 --> No URI present. Default controller set.
INFO - 2016-10-16 17:50:50 --> Router Class Initialized
INFO - 2016-10-16 17:50:50 --> Output Class Initialized
INFO - 2016-10-16 17:50:50 --> Security Class Initialized
DEBUG - 2016-10-16 17:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 17:50:50 --> Input Class Initialized
INFO - 2016-10-16 17:50:50 --> Language Class Initialized
INFO - 2016-10-16 17:50:50 --> Language Class Initialized
INFO - 2016-10-16 17:50:50 --> Config Class Initialized
INFO - 2016-10-16 17:50:50 --> Loader Class Initialized
INFO - 2016-10-16 17:50:50 --> Helper loaded: common_helper
INFO - 2016-10-16 17:50:50 --> Helper loaded: url_helper
INFO - 2016-10-16 17:50:50 --> Database Driver Class Initialized
INFO - 2016-10-16 17:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 17:50:50 --> Parser Class Initialized
INFO - 2016-10-16 17:50:50 --> Controller Class Initialized
DEBUG - 2016-10-16 17:50:50 --> Home MX_Controller Initialized
INFO - 2016-10-16 17:50:50 --> Model Class Initialized
DEBUG - 2016-10-16 17:50:50 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-16 17:50:50 --> Model Class Initialized
ERROR - 2016-10-16 17:50:50 --> Module controller failed to run: banner/index
DEBUG - 2016-10-16 17:50:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-16 17:50:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-16 17:50:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-16 17:50:50 --> Final output sent to browser
DEBUG - 2016-10-16 17:50:50 --> Total execution time: 0.0422
INFO - 2016-10-16 20:04:45 --> Config Class Initialized
INFO - 2016-10-16 20:04:45 --> Hooks Class Initialized
DEBUG - 2016-10-16 20:04:45 --> UTF-8 Support Enabled
INFO - 2016-10-16 20:04:45 --> Utf8 Class Initialized
INFO - 2016-10-16 20:04:45 --> URI Class Initialized
INFO - 2016-10-16 20:04:45 --> Router Class Initialized
INFO - 2016-10-16 20:04:45 --> Output Class Initialized
INFO - 2016-10-16 20:04:45 --> Security Class Initialized
DEBUG - 2016-10-16 20:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 20:04:45 --> Input Class Initialized
INFO - 2016-10-16 20:04:45 --> Language Class Initialized
ERROR - 2016-10-16 20:04:45 --> 404 Page Not Found: /index
INFO - 2016-10-16 20:17:49 --> Config Class Initialized
INFO - 2016-10-16 20:17:49 --> Hooks Class Initialized
DEBUG - 2016-10-16 20:17:49 --> UTF-8 Support Enabled
INFO - 2016-10-16 20:17:49 --> Utf8 Class Initialized
INFO - 2016-10-16 20:17:49 --> URI Class Initialized
INFO - 2016-10-16 20:17:49 --> Router Class Initialized
INFO - 2016-10-16 20:17:49 --> Output Class Initialized
INFO - 2016-10-16 20:17:49 --> Security Class Initialized
DEBUG - 2016-10-16 20:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 20:17:49 --> Input Class Initialized
INFO - 2016-10-16 20:17:49 --> Language Class Initialized
ERROR - 2016-10-16 20:17:49 --> 404 Page Not Found: /index
INFO - 2016-10-16 20:17:49 --> Config Class Initialized
INFO - 2016-10-16 20:17:49 --> Hooks Class Initialized
DEBUG - 2016-10-16 20:17:49 --> UTF-8 Support Enabled
INFO - 2016-10-16 20:17:49 --> Utf8 Class Initialized
INFO - 2016-10-16 20:17:49 --> URI Class Initialized
DEBUG - 2016-10-16 20:17:49 --> No URI present. Default controller set.
INFO - 2016-10-16 20:17:49 --> Router Class Initialized
INFO - 2016-10-16 20:17:49 --> Output Class Initialized
INFO - 2016-10-16 20:17:49 --> Security Class Initialized
DEBUG - 2016-10-16 20:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-16 20:17:49 --> Input Class Initialized
INFO - 2016-10-16 20:17:49 --> Language Class Initialized
INFO - 2016-10-16 20:17:49 --> Language Class Initialized
INFO - 2016-10-16 20:17:49 --> Config Class Initialized
INFO - 2016-10-16 20:17:49 --> Loader Class Initialized
INFO - 2016-10-16 20:17:49 --> Helper loaded: common_helper
INFO - 2016-10-16 20:17:49 --> Helper loaded: url_helper
INFO - 2016-10-16 20:17:49 --> Database Driver Class Initialized
INFO - 2016-10-16 20:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-16 20:17:49 --> Parser Class Initialized
INFO - 2016-10-16 20:17:49 --> Controller Class Initialized
DEBUG - 2016-10-16 20:17:49 --> Home MX_Controller Initialized
INFO - 2016-10-16 20:17:49 --> Model Class Initialized
DEBUG - 2016-10-16 20:17:49 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-16 20:17:49 --> Model Class Initialized
ERROR - 2016-10-16 20:17:49 --> Module controller failed to run: banner/index
DEBUG - 2016-10-16 20:17:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-16 20:17:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-16 20:17:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-16 20:17:49 --> Final output sent to browser
DEBUG - 2016-10-16 20:17:49 --> Total execution time: 0.0528
