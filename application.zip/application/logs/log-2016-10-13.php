<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-13 01:05:09 --> Config Class Initialized
INFO - 2016-10-13 01:05:09 --> Hooks Class Initialized
DEBUG - 2016-10-13 01:05:09 --> UTF-8 Support Enabled
INFO - 2016-10-13 01:05:09 --> Utf8 Class Initialized
INFO - 2016-10-13 01:05:09 --> URI Class Initialized
INFO - 2016-10-13 01:05:09 --> Router Class Initialized
INFO - 2016-10-13 01:05:09 --> Output Class Initialized
INFO - 2016-10-13 01:05:09 --> Security Class Initialized
DEBUG - 2016-10-13 01:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 01:05:09 --> Input Class Initialized
INFO - 2016-10-13 01:05:09 --> Language Class Initialized
ERROR - 2016-10-13 01:05:09 --> 404 Page Not Found: /index
INFO - 2016-10-13 01:11:23 --> Config Class Initialized
INFO - 2016-10-13 01:11:23 --> Hooks Class Initialized
DEBUG - 2016-10-13 01:11:23 --> UTF-8 Support Enabled
INFO - 2016-10-13 01:11:23 --> Utf8 Class Initialized
INFO - 2016-10-13 01:11:23 --> URI Class Initialized
INFO - 2016-10-13 01:11:23 --> Router Class Initialized
INFO - 2016-10-13 01:11:23 --> Output Class Initialized
INFO - 2016-10-13 01:11:23 --> Security Class Initialized
DEBUG - 2016-10-13 01:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 01:11:23 --> Input Class Initialized
INFO - 2016-10-13 01:11:23 --> Language Class Initialized
ERROR - 2016-10-13 01:11:23 --> 404 Page Not Found: /index
INFO - 2016-10-13 01:42:25 --> Config Class Initialized
INFO - 2016-10-13 01:42:25 --> Hooks Class Initialized
DEBUG - 2016-10-13 01:42:25 --> UTF-8 Support Enabled
INFO - 2016-10-13 01:42:25 --> Utf8 Class Initialized
INFO - 2016-10-13 01:42:25 --> URI Class Initialized
INFO - 2016-10-13 01:42:25 --> Router Class Initialized
INFO - 2016-10-13 01:42:25 --> Output Class Initialized
INFO - 2016-10-13 01:42:25 --> Security Class Initialized
DEBUG - 2016-10-13 01:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 01:42:25 --> Input Class Initialized
INFO - 2016-10-13 01:42:25 --> Language Class Initialized
ERROR - 2016-10-13 01:42:25 --> 404 Page Not Found: /index
INFO - 2016-10-13 02:32:05 --> Config Class Initialized
INFO - 2016-10-13 02:32:05 --> Hooks Class Initialized
DEBUG - 2016-10-13 02:32:05 --> UTF-8 Support Enabled
INFO - 2016-10-13 02:32:05 --> Utf8 Class Initialized
INFO - 2016-10-13 02:32:05 --> URI Class Initialized
INFO - 2016-10-13 02:32:05 --> Router Class Initialized
INFO - 2016-10-13 02:32:05 --> Output Class Initialized
INFO - 2016-10-13 02:32:05 --> Security Class Initialized
DEBUG - 2016-10-13 02:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 02:32:05 --> Input Class Initialized
INFO - 2016-10-13 02:32:05 --> Language Class Initialized
ERROR - 2016-10-13 02:32:05 --> 404 Page Not Found: /index
INFO - 2016-10-13 03:04:43 --> Config Class Initialized
INFO - 2016-10-13 03:04:43 --> Hooks Class Initialized
DEBUG - 2016-10-13 03:04:43 --> UTF-8 Support Enabled
INFO - 2016-10-13 03:04:43 --> Utf8 Class Initialized
INFO - 2016-10-13 03:04:43 --> URI Class Initialized
DEBUG - 2016-10-13 03:04:43 --> No URI present. Default controller set.
INFO - 2016-10-13 03:04:43 --> Router Class Initialized
INFO - 2016-10-13 03:04:43 --> Output Class Initialized
INFO - 2016-10-13 03:04:43 --> Security Class Initialized
DEBUG - 2016-10-13 03:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 03:04:43 --> Input Class Initialized
INFO - 2016-10-13 03:04:43 --> Language Class Initialized
INFO - 2016-10-13 03:04:43 --> Language Class Initialized
INFO - 2016-10-13 03:04:43 --> Config Class Initialized
INFO - 2016-10-13 03:04:43 --> Loader Class Initialized
INFO - 2016-10-13 03:04:43 --> Helper loaded: common_helper
INFO - 2016-10-13 03:04:43 --> Helper loaded: url_helper
INFO - 2016-10-13 03:04:43 --> Database Driver Class Initialized
INFO - 2016-10-13 03:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 03:04:43 --> Parser Class Initialized
INFO - 2016-10-13 03:04:43 --> Controller Class Initialized
DEBUG - 2016-10-13 03:04:43 --> Home MX_Controller Initialized
INFO - 2016-10-13 03:04:43 --> Model Class Initialized
DEBUG - 2016-10-13 03:04:43 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 03:04:43 --> Model Class Initialized
ERROR - 2016-10-13 03:04:43 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 03:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 03:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 03:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 03:04:43 --> Final output sent to browser
DEBUG - 2016-10-13 03:04:43 --> Total execution time: 0.1200
INFO - 2016-10-13 06:09:52 --> Config Class Initialized
INFO - 2016-10-13 06:09:52 --> Hooks Class Initialized
DEBUG - 2016-10-13 06:09:52 --> UTF-8 Support Enabled
INFO - 2016-10-13 06:09:52 --> Utf8 Class Initialized
INFO - 2016-10-13 06:09:52 --> URI Class Initialized
DEBUG - 2016-10-13 06:09:52 --> No URI present. Default controller set.
INFO - 2016-10-13 06:09:52 --> Router Class Initialized
INFO - 2016-10-13 06:09:52 --> Output Class Initialized
INFO - 2016-10-13 06:09:52 --> Security Class Initialized
DEBUG - 2016-10-13 06:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 06:09:52 --> Input Class Initialized
INFO - 2016-10-13 06:09:52 --> Language Class Initialized
INFO - 2016-10-13 06:09:52 --> Language Class Initialized
INFO - 2016-10-13 06:09:52 --> Config Class Initialized
INFO - 2016-10-13 06:09:52 --> Loader Class Initialized
INFO - 2016-10-13 06:09:52 --> Helper loaded: common_helper
INFO - 2016-10-13 06:09:52 --> Helper loaded: url_helper
INFO - 2016-10-13 06:09:52 --> Database Driver Class Initialized
INFO - 2016-10-13 06:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 06:09:52 --> Parser Class Initialized
INFO - 2016-10-13 06:09:52 --> Controller Class Initialized
DEBUG - 2016-10-13 06:09:52 --> Home MX_Controller Initialized
INFO - 2016-10-13 06:09:52 --> Model Class Initialized
DEBUG - 2016-10-13 06:09:52 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 06:09:52 --> Model Class Initialized
ERROR - 2016-10-13 06:09:52 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 06:09:52 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 06:09:52 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 06:09:52 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 06:09:52 --> Final output sent to browser
DEBUG - 2016-10-13 06:09:52 --> Total execution time: 0.0436
INFO - 2016-10-13 06:10:41 --> Config Class Initialized
INFO - 2016-10-13 06:10:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 06:10:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 06:10:41 --> Utf8 Class Initialized
INFO - 2016-10-13 06:10:41 --> URI Class Initialized
DEBUG - 2016-10-13 06:10:41 --> No URI present. Default controller set.
INFO - 2016-10-13 06:10:41 --> Router Class Initialized
INFO - 2016-10-13 06:10:41 --> Output Class Initialized
INFO - 2016-10-13 06:10:41 --> Security Class Initialized
DEBUG - 2016-10-13 06:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 06:10:41 --> Input Class Initialized
INFO - 2016-10-13 06:10:41 --> Language Class Initialized
INFO - 2016-10-13 06:10:41 --> Language Class Initialized
INFO - 2016-10-13 06:10:41 --> Config Class Initialized
INFO - 2016-10-13 06:10:41 --> Loader Class Initialized
INFO - 2016-10-13 06:10:41 --> Helper loaded: common_helper
INFO - 2016-10-13 06:10:41 --> Helper loaded: url_helper
INFO - 2016-10-13 06:10:41 --> Database Driver Class Initialized
INFO - 2016-10-13 06:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 06:10:41 --> Parser Class Initialized
INFO - 2016-10-13 06:10:41 --> Controller Class Initialized
DEBUG - 2016-10-13 06:10:41 --> Home MX_Controller Initialized
INFO - 2016-10-13 06:10:41 --> Model Class Initialized
DEBUG - 2016-10-13 06:10:41 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 06:10:41 --> Model Class Initialized
ERROR - 2016-10-13 06:10:41 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 06:10:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 06:10:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 06:10:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 06:10:41 --> Final output sent to browser
DEBUG - 2016-10-13 06:10:41 --> Total execution time: 0.0439
INFO - 2016-10-13 10:58:04 --> Config Class Initialized
INFO - 2016-10-13 10:58:04 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:04 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:04 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:04 --> URI Class Initialized
INFO - 2016-10-13 10:58:04 --> Router Class Initialized
INFO - 2016-10-13 10:58:04 --> Output Class Initialized
INFO - 2016-10-13 10:58:04 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:04 --> Input Class Initialized
INFO - 2016-10-13 10:58:04 --> Language Class Initialized
INFO - 2016-10-13 10:58:04 --> Language Class Initialized
INFO - 2016-10-13 10:58:04 --> Config Class Initialized
INFO - 2016-10-13 10:58:04 --> Loader Class Initialized
INFO - 2016-10-13 10:58:04 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:04 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:04 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:04 --> Parser Class Initialized
INFO - 2016-10-13 10:58:04 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:04 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 10:58:04 --> Config Class Initialized
INFO - 2016-10-13 10:58:04 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:04 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:04 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:04 --> URI Class Initialized
INFO - 2016-10-13 10:58:04 --> Router Class Initialized
INFO - 2016-10-13 10:58:04 --> Output Class Initialized
INFO - 2016-10-13 10:58:04 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:04 --> Input Class Initialized
INFO - 2016-10-13 10:58:04 --> Language Class Initialized
INFO - 2016-10-13 10:58:04 --> Language Class Initialized
INFO - 2016-10-13 10:58:04 --> Config Class Initialized
INFO - 2016-10-13 10:58:04 --> Loader Class Initialized
INFO - 2016-10-13 10:58:04 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:04 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:04 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:04 --> Parser Class Initialized
INFO - 2016-10-13 10:58:04 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:04 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 10:58:04 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 10:58:04 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:04 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-13 10:58:04 --> Final output sent to browser
DEBUG - 2016-10-13 10:58:04 --> Total execution time: 0.0377
INFO - 2016-10-13 10:58:06 --> Config Class Initialized
INFO - 2016-10-13 10:58:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:06 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:06 --> URI Class Initialized
INFO - 2016-10-13 10:58:06 --> Router Class Initialized
INFO - 2016-10-13 10:58:06 --> Output Class Initialized
INFO - 2016-10-13 10:58:06 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:06 --> Input Class Initialized
INFO - 2016-10-13 10:58:06 --> Language Class Initialized
INFO - 2016-10-13 10:58:06 --> Language Class Initialized
INFO - 2016-10-13 10:58:06 --> Config Class Initialized
INFO - 2016-10-13 10:58:06 --> Loader Class Initialized
INFO - 2016-10-13 10:58:06 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:06 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:06 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:06 --> Parser Class Initialized
INFO - 2016-10-13 10:58:06 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:06 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 10:58:06 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 10:58:06 --> Model Class Initialized
INFO - 2016-10-13 10:58:06 --> Final output sent to browser
DEBUG - 2016-10-13 10:58:06 --> Total execution time: 0.0359
INFO - 2016-10-13 10:58:06 --> Config Class Initialized
INFO - 2016-10-13 10:58:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:06 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:06 --> URI Class Initialized
INFO - 2016-10-13 10:58:06 --> Router Class Initialized
INFO - 2016-10-13 10:58:06 --> Output Class Initialized
INFO - 2016-10-13 10:58:06 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:06 --> Input Class Initialized
INFO - 2016-10-13 10:58:06 --> Language Class Initialized
INFO - 2016-10-13 10:58:06 --> Language Class Initialized
INFO - 2016-10-13 10:58:06 --> Config Class Initialized
INFO - 2016-10-13 10:58:06 --> Loader Class Initialized
INFO - 2016-10-13 10:58:06 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:06 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:06 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:06 --> Parser Class Initialized
INFO - 2016-10-13 10:58:06 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:06 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 10:58:06 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 10:58:06 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-13 10:58:06 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 10:58:06 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 10:58:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 10:58:06 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 10:58:06 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 10:58:06 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 10:58:06 --> Final output sent to browser
DEBUG - 2016-10-13 10:58:06 --> Total execution time: 0.0542
INFO - 2016-10-13 10:58:07 --> Config Class Initialized
INFO - 2016-10-13 10:58:07 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:07 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:07 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:07 --> URI Class Initialized
INFO - 2016-10-13 10:58:07 --> Router Class Initialized
INFO - 2016-10-13 10:58:07 --> Output Class Initialized
INFO - 2016-10-13 10:58:07 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:07 --> Input Class Initialized
INFO - 2016-10-13 10:58:07 --> Language Class Initialized
ERROR - 2016-10-13 10:58:07 --> 404 Page Not Found: /index
INFO - 2016-10-13 10:58:08 --> Config Class Initialized
INFO - 2016-10-13 10:58:08 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:08 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:08 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:08 --> URI Class Initialized
INFO - 2016-10-13 10:58:08 --> Router Class Initialized
INFO - 2016-10-13 10:58:08 --> Output Class Initialized
INFO - 2016-10-13 10:58:08 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:08 --> Input Class Initialized
INFO - 2016-10-13 10:58:08 --> Language Class Initialized
ERROR - 2016-10-13 10:58:08 --> 404 Page Not Found: /index
INFO - 2016-10-13 10:58:08 --> Config Class Initialized
INFO - 2016-10-13 10:58:08 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:08 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:08 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:08 --> URI Class Initialized
INFO - 2016-10-13 10:58:08 --> Router Class Initialized
INFO - 2016-10-13 10:58:08 --> Output Class Initialized
INFO - 2016-10-13 10:58:08 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:08 --> Input Class Initialized
INFO - 2016-10-13 10:58:08 --> Language Class Initialized
ERROR - 2016-10-13 10:58:08 --> 404 Page Not Found: /index
INFO - 2016-10-13 10:58:09 --> Config Class Initialized
INFO - 2016-10-13 10:58:09 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:09 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:09 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:09 --> URI Class Initialized
INFO - 2016-10-13 10:58:09 --> Router Class Initialized
INFO - 2016-10-13 10:58:09 --> Output Class Initialized
INFO - 2016-10-13 10:58:09 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:09 --> Input Class Initialized
INFO - 2016-10-13 10:58:09 --> Language Class Initialized
INFO - 2016-10-13 10:58:09 --> Language Class Initialized
INFO - 2016-10-13 10:58:09 --> Config Class Initialized
INFO - 2016-10-13 10:58:09 --> Loader Class Initialized
INFO - 2016-10-13 10:58:09 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:09 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:09 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:09 --> Parser Class Initialized
INFO - 2016-10-13 10:58:09 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:09 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 10:58:09 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 10:58:09 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-13 10:58:09 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 10:58:09 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 10:58:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 10:58:09 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 10:58:09 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 10:58:09 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 10:58:09 --> Final output sent to browser
DEBUG - 2016-10-13 10:58:09 --> Total execution time: 0.0534
INFO - 2016-10-13 10:58:15 --> Config Class Initialized
INFO - 2016-10-13 10:58:15 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:15 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:15 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:15 --> URI Class Initialized
INFO - 2016-10-13 10:58:15 --> Router Class Initialized
INFO - 2016-10-13 10:58:15 --> Output Class Initialized
INFO - 2016-10-13 10:58:15 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:15 --> Input Class Initialized
INFO - 2016-10-13 10:58:15 --> Language Class Initialized
INFO - 2016-10-13 10:58:15 --> Language Class Initialized
INFO - 2016-10-13 10:58:15 --> Config Class Initialized
INFO - 2016-10-13 10:58:15 --> Loader Class Initialized
INFO - 2016-10-13 10:58:15 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:15 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:15 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:15 --> Parser Class Initialized
INFO - 2016-10-13 10:58:15 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:15 --> Servers MX_Controller Initialized
INFO - 2016-10-13 10:58:15 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 10:58:15 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 10:58:15 --> Model Class Initialized
INFO - 2016-10-13 10:58:15 --> Config Class Initialized
INFO - 2016-10-13 10:58:15 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:15 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:15 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:15 --> URI Class Initialized
INFO - 2016-10-13 10:58:15 --> Router Class Initialized
INFO - 2016-10-13 10:58:15 --> Output Class Initialized
INFO - 2016-10-13 10:58:15 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:15 --> Input Class Initialized
INFO - 2016-10-13 10:58:15 --> Language Class Initialized
INFO - 2016-10-13 10:58:15 --> Language Class Initialized
INFO - 2016-10-13 10:58:15 --> Config Class Initialized
INFO - 2016-10-13 10:58:15 --> Loader Class Initialized
INFO - 2016-10-13 10:58:15 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:15 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:15 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:15 --> Parser Class Initialized
INFO - 2016-10-13 10:58:15 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:15 --> Home MX_Controller Initialized
INFO - 2016-10-13 10:58:15 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 10:58:15 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 10:58:15 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 10:58:15 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 10:58:15 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 10:58:15 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 10:58:15 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 10:58:15 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-13 10:58:15 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 10:58:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 10:58:15 --> Final output sent to browser
DEBUG - 2016-10-13 10:58:15 --> Total execution time: 0.0990
INFO - 2016-10-13 10:58:15 --> Config Class Initialized
INFO - 2016-10-13 10:58:15 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:15 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:15 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:15 --> URI Class Initialized
INFO - 2016-10-13 10:58:15 --> Router Class Initialized
INFO - 2016-10-13 10:58:15 --> Output Class Initialized
INFO - 2016-10-13 10:58:15 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:15 --> Input Class Initialized
INFO - 2016-10-13 10:58:15 --> Language Class Initialized
ERROR - 2016-10-13 10:58:15 --> 404 Page Not Found: /index
INFO - 2016-10-13 10:58:27 --> Config Class Initialized
INFO - 2016-10-13 10:58:27 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:27 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:27 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:27 --> URI Class Initialized
INFO - 2016-10-13 10:58:27 --> Router Class Initialized
INFO - 2016-10-13 10:58:27 --> Output Class Initialized
INFO - 2016-10-13 10:58:27 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:27 --> Input Class Initialized
INFO - 2016-10-13 10:58:27 --> Language Class Initialized
INFO - 2016-10-13 10:58:27 --> Language Class Initialized
INFO - 2016-10-13 10:58:27 --> Config Class Initialized
INFO - 2016-10-13 10:58:27 --> Loader Class Initialized
INFO - 2016-10-13 10:58:27 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:27 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:27 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:27 --> Parser Class Initialized
INFO - 2016-10-13 10:58:27 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:27 --> User MX_Controller Initialized
INFO - 2016-10-13 10:58:27 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:27 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-13 10:58:27 --> Model Class Initialized
INFO - 2016-10-13 10:58:27 --> Helper loaded: cookie_helper
INFO - 2016-10-13 10:58:27 --> Helper loaded: form_helper
DEBUG - 2016-10-13 10:58:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 10:58:27 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 10:58:27 --> Model Class Initialized
INFO - 2016-10-13 10:58:27 --> Final output sent to browser
DEBUG - 2016-10-13 10:58:27 --> Total execution time: 0.0569
INFO - 2016-10-13 10:58:32 --> Config Class Initialized
INFO - 2016-10-13 10:58:32 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:32 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:32 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:32 --> URI Class Initialized
INFO - 2016-10-13 10:58:32 --> Router Class Initialized
INFO - 2016-10-13 10:58:32 --> Output Class Initialized
INFO - 2016-10-13 10:58:32 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:32 --> Input Class Initialized
INFO - 2016-10-13 10:58:32 --> Language Class Initialized
INFO - 2016-10-13 10:58:32 --> Language Class Initialized
INFO - 2016-10-13 10:58:32 --> Config Class Initialized
INFO - 2016-10-13 10:58:32 --> Loader Class Initialized
INFO - 2016-10-13 10:58:32 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:32 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:32 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:32 --> Parser Class Initialized
INFO - 2016-10-13 10:58:32 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:32 --> User MX_Controller Initialized
INFO - 2016-10-13 10:58:32 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:32 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-13 10:58:32 --> Model Class Initialized
INFO - 2016-10-13 10:58:32 --> Helper loaded: cookie_helper
INFO - 2016-10-13 10:58:32 --> Helper loaded: form_helper
DEBUG - 2016-10-13 10:58:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 10:58:32 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 10:58:32 --> Model Class Initialized
INFO - 2016-10-13 10:58:32 --> Final output sent to browser
DEBUG - 2016-10-13 10:58:32 --> Total execution time: 0.0447
INFO - 2016-10-13 10:58:34 --> Config Class Initialized
INFO - 2016-10-13 10:58:34 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:34 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:34 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:34 --> URI Class Initialized
DEBUG - 2016-10-13 10:58:34 --> No URI present. Default controller set.
INFO - 2016-10-13 10:58:34 --> Router Class Initialized
INFO - 2016-10-13 10:58:34 --> Output Class Initialized
INFO - 2016-10-13 10:58:34 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:34 --> Input Class Initialized
INFO - 2016-10-13 10:58:34 --> Language Class Initialized
INFO - 2016-10-13 10:58:34 --> Language Class Initialized
INFO - 2016-10-13 10:58:34 --> Config Class Initialized
INFO - 2016-10-13 10:58:34 --> Loader Class Initialized
INFO - 2016-10-13 10:58:34 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:34 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:34 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:34 --> Parser Class Initialized
INFO - 2016-10-13 10:58:34 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:34 --> Home MX_Controller Initialized
INFO - 2016-10-13 10:58:34 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 10:58:34 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 10:58:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 10:58:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 10:58:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 10:58:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 10:58:34 --> Final output sent to browser
DEBUG - 2016-10-13 10:58:34 --> Total execution time: 0.0405
INFO - 2016-10-13 10:58:41 --> Config Class Initialized
INFO - 2016-10-13 10:58:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:58:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:58:41 --> Utf8 Class Initialized
INFO - 2016-10-13 10:58:41 --> URI Class Initialized
INFO - 2016-10-13 10:58:41 --> Router Class Initialized
INFO - 2016-10-13 10:58:41 --> Output Class Initialized
INFO - 2016-10-13 10:58:41 --> Security Class Initialized
DEBUG - 2016-10-13 10:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:58:41 --> Input Class Initialized
INFO - 2016-10-13 10:58:41 --> Language Class Initialized
INFO - 2016-10-13 10:58:41 --> Language Class Initialized
INFO - 2016-10-13 10:58:41 --> Config Class Initialized
INFO - 2016-10-13 10:58:41 --> Loader Class Initialized
INFO - 2016-10-13 10:58:41 --> Helper loaded: common_helper
INFO - 2016-10-13 10:58:41 --> Helper loaded: url_helper
INFO - 2016-10-13 10:58:41 --> Database Driver Class Initialized
INFO - 2016-10-13 10:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 10:58:41 --> Parser Class Initialized
INFO - 2016-10-13 10:58:41 --> Controller Class Initialized
DEBUG - 2016-10-13 10:58:41 --> Servers MX_Controller Initialized
INFO - 2016-10-13 10:58:41 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 10:58:41 --> Model Class Initialized
DEBUG - 2016-10-13 10:58:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 10:58:41 --> Model Class Initialized
ERROR - 2016-10-13 10:59:41 --> Severity: Warning --> file_get_contents(http://103.27.60.212:8888/api_new_account.php?account=pullup_858e630f86eadcb72dbd610c95bfdf04&sid=1): failed to open stream: Connection timed out /home/dolongpk/public_html/application/modules/servers/controllers/Servers.php 397
ERROR - 2016-10-13 10:59:41 --> Query error: MySQL server has gone away - Invalid query: SELECT * from admin_nqt_settings WHERE slug = 'is_local'
INFO - 2016-10-13 10:59:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-13 10:59:41 --> Config Class Initialized
INFO - 2016-10-13 10:59:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 10:59:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 10:59:41 --> Utf8 Class Initialized
INFO - 2016-10-13 10:59:41 --> URI Class Initialized
INFO - 2016-10-13 10:59:41 --> Router Class Initialized
INFO - 2016-10-13 10:59:41 --> Output Class Initialized
INFO - 2016-10-13 10:59:41 --> Security Class Initialized
DEBUG - 2016-10-13 10:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 10:59:41 --> Input Class Initialized
INFO - 2016-10-13 10:59:41 --> Language Class Initialized
ERROR - 2016-10-13 10:59:41 --> 404 Page Not Found: /index
INFO - 2016-10-13 11:28:45 --> Config Class Initialized
INFO - 2016-10-13 11:28:45 --> Hooks Class Initialized
DEBUG - 2016-10-13 11:28:45 --> UTF-8 Support Enabled
INFO - 2016-10-13 11:28:45 --> Utf8 Class Initialized
INFO - 2016-10-13 11:28:45 --> URI Class Initialized
DEBUG - 2016-10-13 11:28:45 --> No URI present. Default controller set.
INFO - 2016-10-13 11:28:45 --> Router Class Initialized
INFO - 2016-10-13 11:28:45 --> Output Class Initialized
INFO - 2016-10-13 11:28:45 --> Security Class Initialized
DEBUG - 2016-10-13 11:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 11:28:45 --> Input Class Initialized
INFO - 2016-10-13 11:28:45 --> Language Class Initialized
INFO - 2016-10-13 11:28:45 --> Language Class Initialized
INFO - 2016-10-13 11:28:45 --> Config Class Initialized
INFO - 2016-10-13 11:28:45 --> Loader Class Initialized
INFO - 2016-10-13 11:28:45 --> Helper loaded: common_helper
INFO - 2016-10-13 11:28:45 --> Helper loaded: url_helper
INFO - 2016-10-13 11:28:45 --> Database Driver Class Initialized
INFO - 2016-10-13 11:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 11:28:45 --> Parser Class Initialized
INFO - 2016-10-13 11:28:45 --> Controller Class Initialized
DEBUG - 2016-10-13 11:28:45 --> Home MX_Controller Initialized
INFO - 2016-10-13 11:28:45 --> Model Class Initialized
DEBUG - 2016-10-13 11:28:45 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 11:28:45 --> Model Class Initialized
ERROR - 2016-10-13 11:28:45 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 11:28:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 11:28:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 11:28:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 11:28:45 --> Final output sent to browser
DEBUG - 2016-10-13 11:28:45 --> Total execution time: 0.0440
INFO - 2016-10-13 14:05:47 --> Config Class Initialized
INFO - 2016-10-13 14:05:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 14:05:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 14:05:47 --> Utf8 Class Initialized
INFO - 2016-10-13 14:05:47 --> URI Class Initialized
DEBUG - 2016-10-13 14:05:47 --> No URI present. Default controller set.
INFO - 2016-10-13 14:05:47 --> Router Class Initialized
INFO - 2016-10-13 14:05:47 --> Output Class Initialized
INFO - 2016-10-13 14:05:47 --> Security Class Initialized
DEBUG - 2016-10-13 14:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 14:05:47 --> Input Class Initialized
INFO - 2016-10-13 14:05:47 --> Language Class Initialized
INFO - 2016-10-13 14:05:47 --> Language Class Initialized
INFO - 2016-10-13 14:05:47 --> Config Class Initialized
INFO - 2016-10-13 14:05:47 --> Loader Class Initialized
INFO - 2016-10-13 14:05:47 --> Helper loaded: common_helper
INFO - 2016-10-13 14:05:47 --> Helper loaded: url_helper
INFO - 2016-10-13 14:05:47 --> Database Driver Class Initialized
INFO - 2016-10-13 14:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 14:05:47 --> Parser Class Initialized
INFO - 2016-10-13 14:05:47 --> Controller Class Initialized
DEBUG - 2016-10-13 14:05:47 --> Home MX_Controller Initialized
INFO - 2016-10-13 14:05:47 --> Model Class Initialized
DEBUG - 2016-10-13 14:05:47 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 14:05:47 --> Model Class Initialized
ERROR - 2016-10-13 14:05:47 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 14:05:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 14:05:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 14:05:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 14:05:47 --> Final output sent to browser
DEBUG - 2016-10-13 14:05:47 --> Total execution time: 0.0583
INFO - 2016-10-13 14:06:26 --> Config Class Initialized
INFO - 2016-10-13 14:06:26 --> Hooks Class Initialized
DEBUG - 2016-10-13 14:06:26 --> UTF-8 Support Enabled
INFO - 2016-10-13 14:06:26 --> Utf8 Class Initialized
INFO - 2016-10-13 14:06:26 --> URI Class Initialized
DEBUG - 2016-10-13 14:06:26 --> No URI present. Default controller set.
INFO - 2016-10-13 14:06:26 --> Router Class Initialized
INFO - 2016-10-13 14:06:26 --> Output Class Initialized
INFO - 2016-10-13 14:06:26 --> Security Class Initialized
DEBUG - 2016-10-13 14:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 14:06:26 --> Input Class Initialized
INFO - 2016-10-13 14:06:26 --> Language Class Initialized
INFO - 2016-10-13 14:06:26 --> Language Class Initialized
INFO - 2016-10-13 14:06:26 --> Config Class Initialized
INFO - 2016-10-13 14:06:26 --> Loader Class Initialized
INFO - 2016-10-13 14:06:26 --> Helper loaded: common_helper
INFO - 2016-10-13 14:06:26 --> Helper loaded: url_helper
INFO - 2016-10-13 14:06:26 --> Database Driver Class Initialized
INFO - 2016-10-13 14:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 14:06:26 --> Parser Class Initialized
INFO - 2016-10-13 14:06:26 --> Controller Class Initialized
DEBUG - 2016-10-13 14:06:26 --> Home MX_Controller Initialized
INFO - 2016-10-13 14:06:26 --> Model Class Initialized
DEBUG - 2016-10-13 14:06:26 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 14:06:26 --> Model Class Initialized
ERROR - 2016-10-13 14:06:26 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 14:06:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 14:06:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 14:06:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 14:06:26 --> Final output sent to browser
DEBUG - 2016-10-13 14:06:26 --> Total execution time: 0.0426
INFO - 2016-10-13 14:59:55 --> Config Class Initialized
INFO - 2016-10-13 14:59:55 --> Hooks Class Initialized
DEBUG - 2016-10-13 14:59:55 --> UTF-8 Support Enabled
INFO - 2016-10-13 14:59:55 --> Utf8 Class Initialized
INFO - 2016-10-13 14:59:55 --> URI Class Initialized
INFO - 2016-10-13 14:59:55 --> Router Class Initialized
INFO - 2016-10-13 14:59:55 --> Output Class Initialized
INFO - 2016-10-13 14:59:55 --> Security Class Initialized
DEBUG - 2016-10-13 14:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 14:59:55 --> Input Class Initialized
INFO - 2016-10-13 14:59:55 --> Language Class Initialized
INFO - 2016-10-13 14:59:55 --> Language Class Initialized
INFO - 2016-10-13 14:59:55 --> Config Class Initialized
INFO - 2016-10-13 14:59:55 --> Loader Class Initialized
INFO - 2016-10-13 14:59:55 --> Helper loaded: common_helper
INFO - 2016-10-13 14:59:55 --> Helper loaded: url_helper
INFO - 2016-10-13 14:59:55 --> Database Driver Class Initialized
INFO - 2016-10-13 14:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 14:59:55 --> Parser Class Initialized
INFO - 2016-10-13 14:59:55 --> Controller Class Initialized
DEBUG - 2016-10-13 14:59:55 --> Donate_report MX_Controller Initialized
INFO - 2016-10-13 14:59:55 --> Model Class Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 14:59:55 --> Model Class Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 14:59:55 --> Model Class Initialized
INFO - 2016-10-13 14:59:55 --> Helper loaded: form_helper
INFO - 2016-10-13 14:59:55 --> Form Validation Class Initialized
INFO - 2016-10-13 14:59:55 --> Config Class Initialized
INFO - 2016-10-13 14:59:55 --> Hooks Class Initialized
DEBUG - 2016-10-13 14:59:55 --> UTF-8 Support Enabled
INFO - 2016-10-13 14:59:55 --> Utf8 Class Initialized
INFO - 2016-10-13 14:59:55 --> URI Class Initialized
INFO - 2016-10-13 14:59:55 --> Router Class Initialized
INFO - 2016-10-13 14:59:55 --> Output Class Initialized
INFO - 2016-10-13 14:59:55 --> Security Class Initialized
DEBUG - 2016-10-13 14:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 14:59:55 --> Input Class Initialized
INFO - 2016-10-13 14:59:55 --> Language Class Initialized
INFO - 2016-10-13 14:59:55 --> Language Class Initialized
INFO - 2016-10-13 14:59:55 --> Config Class Initialized
INFO - 2016-10-13 14:59:55 --> Loader Class Initialized
INFO - 2016-10-13 14:59:55 --> Helper loaded: common_helper
INFO - 2016-10-13 14:59:55 --> Helper loaded: url_helper
INFO - 2016-10-13 14:59:55 --> Database Driver Class Initialized
INFO - 2016-10-13 14:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 14:59:55 --> Parser Class Initialized
INFO - 2016-10-13 14:59:55 --> Controller Class Initialized
DEBUG - 2016-10-13 14:59:55 --> Home MX_Controller Initialized
INFO - 2016-10-13 14:59:55 --> Model Class Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 14:59:55 --> Model Class Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 14:59:55 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 14:59:55 --> Model Class Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 14:59:55 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 14:59:55 --> Model Class Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 14:59:55 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 14:59:55 --> Model Class Initialized
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-13 14:59:55 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 14:59:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 14:59:55 --> Final output sent to browser
DEBUG - 2016-10-13 14:59:55 --> Total execution time: 0.0554
INFO - 2016-10-13 14:59:55 --> Config Class Initialized
INFO - 2016-10-13 14:59:55 --> Hooks Class Initialized
DEBUG - 2016-10-13 14:59:55 --> UTF-8 Support Enabled
INFO - 2016-10-13 14:59:55 --> Utf8 Class Initialized
INFO - 2016-10-13 14:59:55 --> URI Class Initialized
INFO - 2016-10-13 14:59:55 --> Router Class Initialized
INFO - 2016-10-13 14:59:55 --> Output Class Initialized
INFO - 2016-10-13 14:59:55 --> Security Class Initialized
DEBUG - 2016-10-13 14:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 14:59:56 --> Input Class Initialized
INFO - 2016-10-13 14:59:56 --> Language Class Initialized
ERROR - 2016-10-13 14:59:56 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:11:37 --> Config Class Initialized
INFO - 2016-10-13 15:11:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:11:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:11:37 --> Utf8 Class Initialized
INFO - 2016-10-13 15:11:37 --> URI Class Initialized
DEBUG - 2016-10-13 15:11:37 --> No URI present. Default controller set.
INFO - 2016-10-13 15:11:37 --> Router Class Initialized
INFO - 2016-10-13 15:11:37 --> Output Class Initialized
INFO - 2016-10-13 15:11:37 --> Security Class Initialized
DEBUG - 2016-10-13 15:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:11:37 --> Input Class Initialized
INFO - 2016-10-13 15:11:37 --> Language Class Initialized
INFO - 2016-10-13 15:11:37 --> Language Class Initialized
INFO - 2016-10-13 15:11:37 --> Config Class Initialized
INFO - 2016-10-13 15:11:37 --> Loader Class Initialized
INFO - 2016-10-13 15:11:37 --> Helper loaded: common_helper
INFO - 2016-10-13 15:11:37 --> Helper loaded: url_helper
INFO - 2016-10-13 15:11:37 --> Database Driver Class Initialized
INFO - 2016-10-13 15:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:11:37 --> Parser Class Initialized
INFO - 2016-10-13 15:11:37 --> Controller Class Initialized
DEBUG - 2016-10-13 15:11:37 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:11:37 --> Model Class Initialized
DEBUG - 2016-10-13 15:11:37 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:11:37 --> Model Class Initialized
ERROR - 2016-10-13 15:11:37 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:11:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:11:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:11:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 15:11:37 --> Final output sent to browser
DEBUG - 2016-10-13 15:11:37 --> Total execution time: 0.0586
INFO - 2016-10-13 15:31:46 --> Config Class Initialized
INFO - 2016-10-13 15:31:46 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:31:46 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:31:46 --> Utf8 Class Initialized
INFO - 2016-10-13 15:31:46 --> URI Class Initialized
DEBUG - 2016-10-13 15:31:46 --> No URI present. Default controller set.
INFO - 2016-10-13 15:31:46 --> Router Class Initialized
INFO - 2016-10-13 15:31:46 --> Output Class Initialized
INFO - 2016-10-13 15:31:46 --> Security Class Initialized
DEBUG - 2016-10-13 15:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:31:46 --> Input Class Initialized
INFO - 2016-10-13 15:31:46 --> Language Class Initialized
INFO - 2016-10-13 15:31:46 --> Language Class Initialized
INFO - 2016-10-13 15:31:46 --> Config Class Initialized
INFO - 2016-10-13 15:31:46 --> Loader Class Initialized
INFO - 2016-10-13 15:31:46 --> Helper loaded: common_helper
INFO - 2016-10-13 15:31:46 --> Helper loaded: url_helper
INFO - 2016-10-13 15:31:46 --> Database Driver Class Initialized
INFO - 2016-10-13 15:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:31:46 --> Parser Class Initialized
INFO - 2016-10-13 15:31:46 --> Controller Class Initialized
DEBUG - 2016-10-13 15:31:46 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:31:46 --> Model Class Initialized
DEBUG - 2016-10-13 15:31:46 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:31:46 --> Model Class Initialized
ERROR - 2016-10-13 15:31:46 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:31:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:31:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:31:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 15:31:46 --> Final output sent to browser
DEBUG - 2016-10-13 15:31:46 --> Total execution time: 0.0439
INFO - 2016-10-13 15:32:06 --> Config Class Initialized
INFO - 2016-10-13 15:32:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:32:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:32:06 --> Utf8 Class Initialized
INFO - 2016-10-13 15:32:06 --> URI Class Initialized
INFO - 2016-10-13 15:32:06 --> Router Class Initialized
INFO - 2016-10-13 15:32:06 --> Output Class Initialized
INFO - 2016-10-13 15:32:06 --> Security Class Initialized
DEBUG - 2016-10-13 15:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:32:06 --> Input Class Initialized
INFO - 2016-10-13 15:32:06 --> Language Class Initialized
INFO - 2016-10-13 15:32:06 --> Language Class Initialized
INFO - 2016-10-13 15:32:06 --> Config Class Initialized
INFO - 2016-10-13 15:32:06 --> Loader Class Initialized
INFO - 2016-10-13 15:32:06 --> Helper loaded: common_helper
INFO - 2016-10-13 15:32:06 --> Helper loaded: url_helper
INFO - 2016-10-13 15:32:06 --> Database Driver Class Initialized
INFO - 2016-10-13 15:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:32:06 --> Parser Class Initialized
INFO - 2016-10-13 15:32:06 --> Controller Class Initialized
DEBUG - 2016-10-13 15:32:06 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:32:06 --> Model Class Initialized
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:32:06 --> Model Class Initialized
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 15:32:06 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:32:06 --> Model Class Initialized
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 15:32:06 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 15:32:06 --> Model Class Initialized
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 15:32:06 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:32:06 --> Model Class Initialized
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-13 15:32:06 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:32:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 15:32:06 --> Final output sent to browser
DEBUG - 2016-10-13 15:32:06 --> Total execution time: 0.0562
INFO - 2016-10-13 15:32:06 --> Config Class Initialized
INFO - 2016-10-13 15:32:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:32:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:32:06 --> Utf8 Class Initialized
INFO - 2016-10-13 15:32:06 --> URI Class Initialized
INFO - 2016-10-13 15:32:06 --> Router Class Initialized
INFO - 2016-10-13 15:32:06 --> Output Class Initialized
INFO - 2016-10-13 15:32:06 --> Security Class Initialized
DEBUG - 2016-10-13 15:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:32:06 --> Input Class Initialized
INFO - 2016-10-13 15:32:06 --> Language Class Initialized
ERROR - 2016-10-13 15:32:06 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:32:08 --> Config Class Initialized
INFO - 2016-10-13 15:32:08 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:32:08 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:32:08 --> Utf8 Class Initialized
INFO - 2016-10-13 15:32:08 --> URI Class Initialized
DEBUG - 2016-10-13 15:32:08 --> No URI present. Default controller set.
INFO - 2016-10-13 15:32:08 --> Router Class Initialized
INFO - 2016-10-13 15:32:08 --> Output Class Initialized
INFO - 2016-10-13 15:32:08 --> Security Class Initialized
DEBUG - 2016-10-13 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:32:08 --> Input Class Initialized
INFO - 2016-10-13 15:32:08 --> Language Class Initialized
INFO - 2016-10-13 15:32:08 --> Language Class Initialized
INFO - 2016-10-13 15:32:08 --> Config Class Initialized
INFO - 2016-10-13 15:32:08 --> Loader Class Initialized
INFO - 2016-10-13 15:32:08 --> Helper loaded: common_helper
INFO - 2016-10-13 15:32:08 --> Helper loaded: url_helper
INFO - 2016-10-13 15:32:08 --> Database Driver Class Initialized
INFO - 2016-10-13 15:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:32:08 --> Parser Class Initialized
INFO - 2016-10-13 15:32:08 --> Controller Class Initialized
DEBUG - 2016-10-13 15:32:08 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:32:08 --> Model Class Initialized
DEBUG - 2016-10-13 15:32:08 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:32:08 --> Model Class Initialized
ERROR - 2016-10-13 15:32:08 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:32:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:32:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:32:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 15:32:08 --> Final output sent to browser
DEBUG - 2016-10-13 15:32:08 --> Total execution time: 0.0439
INFO - 2016-10-13 15:46:41 --> Config Class Initialized
INFO - 2016-10-13 15:46:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:46:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:46:41 --> Utf8 Class Initialized
INFO - 2016-10-13 15:46:41 --> URI Class Initialized
DEBUG - 2016-10-13 15:46:41 --> No URI present. Default controller set.
INFO - 2016-10-13 15:46:41 --> Router Class Initialized
INFO - 2016-10-13 15:46:41 --> Output Class Initialized
INFO - 2016-10-13 15:46:41 --> Security Class Initialized
DEBUG - 2016-10-13 15:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:46:41 --> Input Class Initialized
INFO - 2016-10-13 15:46:41 --> Language Class Initialized
INFO - 2016-10-13 15:46:41 --> Language Class Initialized
INFO - 2016-10-13 15:46:41 --> Config Class Initialized
INFO - 2016-10-13 15:46:41 --> Loader Class Initialized
INFO - 2016-10-13 15:46:41 --> Helper loaded: common_helper
INFO - 2016-10-13 15:46:41 --> Helper loaded: url_helper
INFO - 2016-10-13 15:46:41 --> Database Driver Class Initialized
INFO - 2016-10-13 15:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:46:41 --> Parser Class Initialized
INFO - 2016-10-13 15:46:41 --> Controller Class Initialized
DEBUG - 2016-10-13 15:46:41 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:46:41 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:41 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:46:41 --> Model Class Initialized
ERROR - 2016-10-13 15:46:41 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:46:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:46:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:46:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 15:46:41 --> Final output sent to browser
DEBUG - 2016-10-13 15:46:41 --> Total execution time: 0.0531
INFO - 2016-10-13 15:46:43 --> Config Class Initialized
INFO - 2016-10-13 15:46:43 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:46:43 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:46:43 --> Utf8 Class Initialized
INFO - 2016-10-13 15:46:43 --> URI Class Initialized
INFO - 2016-10-13 15:46:43 --> Router Class Initialized
INFO - 2016-10-13 15:46:43 --> Output Class Initialized
INFO - 2016-10-13 15:46:43 --> Security Class Initialized
DEBUG - 2016-10-13 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:46:43 --> Input Class Initialized
INFO - 2016-10-13 15:46:43 --> Language Class Initialized
INFO - 2016-10-13 15:46:43 --> Language Class Initialized
INFO - 2016-10-13 15:46:43 --> Config Class Initialized
INFO - 2016-10-13 15:46:43 --> Loader Class Initialized
INFO - 2016-10-13 15:46:43 --> Helper loaded: common_helper
INFO - 2016-10-13 15:46:43 --> Helper loaded: url_helper
INFO - 2016-10-13 15:46:44 --> Database Driver Class Initialized
INFO - 2016-10-13 15:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:46:44 --> Parser Class Initialized
INFO - 2016-10-13 15:46:44 --> Controller Class Initialized
DEBUG - 2016-10-13 15:46:44 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:46:44 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:46:44 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 15:46:44 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:46:44 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 15:46:44 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 15:46:44 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 15:46:44 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:46:44 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-13 15:46:44 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:46:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 15:46:44 --> Final output sent to browser
DEBUG - 2016-10-13 15:46:44 --> Total execution time: 0.0759
INFO - 2016-10-13 15:46:44 --> Config Class Initialized
INFO - 2016-10-13 15:46:44 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:46:44 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:46:44 --> Utf8 Class Initialized
INFO - 2016-10-13 15:46:44 --> URI Class Initialized
INFO - 2016-10-13 15:46:44 --> Router Class Initialized
INFO - 2016-10-13 15:46:44 --> Output Class Initialized
INFO - 2016-10-13 15:46:44 --> Security Class Initialized
DEBUG - 2016-10-13 15:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:46:44 --> Input Class Initialized
INFO - 2016-10-13 15:46:44 --> Language Class Initialized
ERROR - 2016-10-13 15:46:44 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:46:53 --> Config Class Initialized
INFO - 2016-10-13 15:46:53 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:46:53 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:46:53 --> Utf8 Class Initialized
INFO - 2016-10-13 15:46:53 --> URI Class Initialized
INFO - 2016-10-13 15:46:53 --> Router Class Initialized
INFO - 2016-10-13 15:46:53 --> Output Class Initialized
INFO - 2016-10-13 15:46:53 --> Security Class Initialized
DEBUG - 2016-10-13 15:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:46:53 --> Input Class Initialized
INFO - 2016-10-13 15:46:53 --> Language Class Initialized
INFO - 2016-10-13 15:46:53 --> Language Class Initialized
INFO - 2016-10-13 15:46:53 --> Config Class Initialized
INFO - 2016-10-13 15:46:53 --> Loader Class Initialized
INFO - 2016-10-13 15:46:53 --> Helper loaded: common_helper
INFO - 2016-10-13 15:46:53 --> Helper loaded: url_helper
INFO - 2016-10-13 15:46:53 --> Database Driver Class Initialized
INFO - 2016-10-13 15:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:46:53 --> Parser Class Initialized
INFO - 2016-10-13 15:46:53 --> Controller Class Initialized
DEBUG - 2016-10-13 15:46:53 --> User MX_Controller Initialized
INFO - 2016-10-13 15:46:53 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:53 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-13 15:46:53 --> Model Class Initialized
INFO - 2016-10-13 15:46:53 --> Helper loaded: cookie_helper
INFO - 2016-10-13 15:46:53 --> Helper loaded: form_helper
DEBUG - 2016-10-13 15:46:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:46:53 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:46:53 --> Model Class Initialized
INFO - 2016-10-13 15:46:53 --> Final output sent to browser
DEBUG - 2016-10-13 15:46:53 --> Total execution time: 0.0468
INFO - 2016-10-13 15:46:55 --> Config Class Initialized
INFO - 2016-10-13 15:46:55 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:46:55 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:46:55 --> Utf8 Class Initialized
INFO - 2016-10-13 15:46:55 --> URI Class Initialized
DEBUG - 2016-10-13 15:46:55 --> No URI present. Default controller set.
INFO - 2016-10-13 15:46:55 --> Router Class Initialized
INFO - 2016-10-13 15:46:55 --> Output Class Initialized
INFO - 2016-10-13 15:46:55 --> Security Class Initialized
DEBUG - 2016-10-13 15:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:46:55 --> Input Class Initialized
INFO - 2016-10-13 15:46:55 --> Language Class Initialized
INFO - 2016-10-13 15:46:55 --> Language Class Initialized
INFO - 2016-10-13 15:46:55 --> Config Class Initialized
INFO - 2016-10-13 15:46:55 --> Loader Class Initialized
INFO - 2016-10-13 15:46:55 --> Helper loaded: common_helper
INFO - 2016-10-13 15:46:55 --> Helper loaded: url_helper
INFO - 2016-10-13 15:46:55 --> Database Driver Class Initialized
INFO - 2016-10-13 15:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:46:55 --> Parser Class Initialized
INFO - 2016-10-13 15:46:55 --> Controller Class Initialized
DEBUG - 2016-10-13 15:46:55 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:46:55 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:55 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:46:55 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 15:46:55 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:46:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:46:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:46:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 15:46:55 --> Final output sent to browser
DEBUG - 2016-10-13 15:46:55 --> Total execution time: 0.0456
INFO - 2016-10-13 15:46:59 --> Config Class Initialized
INFO - 2016-10-13 15:46:59 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:46:59 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:46:59 --> Utf8 Class Initialized
INFO - 2016-10-13 15:46:59 --> URI Class Initialized
INFO - 2016-10-13 15:46:59 --> Router Class Initialized
INFO - 2016-10-13 15:46:59 --> Output Class Initialized
INFO - 2016-10-13 15:46:59 --> Security Class Initialized
DEBUG - 2016-10-13 15:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:46:59 --> Input Class Initialized
INFO - 2016-10-13 15:46:59 --> Language Class Initialized
INFO - 2016-10-13 15:46:59 --> Language Class Initialized
INFO - 2016-10-13 15:46:59 --> Config Class Initialized
INFO - 2016-10-13 15:46:59 --> Loader Class Initialized
INFO - 2016-10-13 15:46:59 --> Helper loaded: common_helper
INFO - 2016-10-13 15:46:59 --> Helper loaded: url_helper
INFO - 2016-10-13 15:46:59 --> Database Driver Class Initialized
INFO - 2016-10-13 15:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:46:59 --> Parser Class Initialized
INFO - 2016-10-13 15:46:59 --> Controller Class Initialized
DEBUG - 2016-10-13 15:46:59 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:46:59 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:46:59 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:46:59 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 15:46:59 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 15:46:59 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:46:59 --> File already loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:46:59 --> Model Class Initialized
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 15:46:59 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:46:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 15:46:59 --> Final output sent to browser
DEBUG - 2016-10-13 15:46:59 --> Total execution time: 0.0539
INFO - 2016-10-13 15:46:59 --> Config Class Initialized
INFO - 2016-10-13 15:46:59 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:46:59 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:46:59 --> Utf8 Class Initialized
INFO - 2016-10-13 15:46:59 --> URI Class Initialized
INFO - 2016-10-13 15:46:59 --> Router Class Initialized
INFO - 2016-10-13 15:46:59 --> Output Class Initialized
INFO - 2016-10-13 15:46:59 --> Security Class Initialized
DEBUG - 2016-10-13 15:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:46:59 --> Input Class Initialized
INFO - 2016-10-13 15:46:59 --> Language Class Initialized
ERROR - 2016-10-13 15:46:59 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:46:59 --> Config Class Initialized
INFO - 2016-10-13 15:46:59 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:46:59 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:46:59 --> Utf8 Class Initialized
INFO - 2016-10-13 15:46:59 --> URI Class Initialized
INFO - 2016-10-13 15:46:59 --> Router Class Initialized
INFO - 2016-10-13 15:46:59 --> Output Class Initialized
INFO - 2016-10-13 15:46:59 --> Security Class Initialized
DEBUG - 2016-10-13 15:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:46:59 --> Input Class Initialized
INFO - 2016-10-13 15:46:59 --> Language Class Initialized
ERROR - 2016-10-13 15:46:59 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:47:03 --> Config Class Initialized
INFO - 2016-10-13 15:47:03 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:47:03 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:47:03 --> Utf8 Class Initialized
INFO - 2016-10-13 15:47:03 --> URI Class Initialized
INFO - 2016-10-13 15:47:03 --> Router Class Initialized
INFO - 2016-10-13 15:47:03 --> Output Class Initialized
INFO - 2016-10-13 15:47:03 --> Security Class Initialized
DEBUG - 2016-10-13 15:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:47:03 --> Input Class Initialized
INFO - 2016-10-13 15:47:03 --> Language Class Initialized
INFO - 2016-10-13 15:47:03 --> Language Class Initialized
INFO - 2016-10-13 15:47:03 --> Config Class Initialized
INFO - 2016-10-13 15:47:03 --> Loader Class Initialized
INFO - 2016-10-13 15:47:03 --> Helper loaded: common_helper
INFO - 2016-10-13 15:47:03 --> Helper loaded: url_helper
INFO - 2016-10-13 15:47:03 --> Database Driver Class Initialized
INFO - 2016-10-13 15:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:47:03 --> Parser Class Initialized
INFO - 2016-10-13 15:47:03 --> Controller Class Initialized
DEBUG - 2016-10-13 15:47:03 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:47:03 --> Model Class Initialized
DEBUG - 2016-10-13 15:47:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:47:03 --> Model Class Initialized
DEBUG - 2016-10-13 15:47:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:47:03 --> Model Class Initialized
DEBUG - 2016-10-13 15:47:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:47:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 15:47:03 --> Final output sent to browser
DEBUG - 2016-10-13 15:47:03 --> Total execution time: 0.0469
INFO - 2016-10-13 15:47:03 --> Config Class Initialized
INFO - 2016-10-13 15:47:03 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:47:03 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:47:03 --> Utf8 Class Initialized
INFO - 2016-10-13 15:47:03 --> URI Class Initialized
INFO - 2016-10-13 15:47:03 --> Router Class Initialized
INFO - 2016-10-13 15:47:03 --> Output Class Initialized
INFO - 2016-10-13 15:47:03 --> Security Class Initialized
DEBUG - 2016-10-13 15:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:47:03 --> Input Class Initialized
INFO - 2016-10-13 15:47:03 --> Language Class Initialized
INFO - 2016-10-13 15:47:03 --> Language Class Initialized
INFO - 2016-10-13 15:47:03 --> Config Class Initialized
INFO - 2016-10-13 15:47:03 --> Loader Class Initialized
INFO - 2016-10-13 15:47:03 --> Helper loaded: common_helper
INFO - 2016-10-13 15:47:03 --> Helper loaded: url_helper
INFO - 2016-10-13 15:47:03 --> Database Driver Class Initialized
INFO - 2016-10-13 15:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:47:03 --> Parser Class Initialized
INFO - 2016-10-13 15:47:03 --> Controller Class Initialized
DEBUG - 2016-10-13 15:47:03 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:47:03 --> Model Class Initialized
DEBUG - 2016-10-13 15:47:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:47:03 --> Model Class Initialized
DEBUG - 2016-10-13 15:47:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:47:03 --> Model Class Initialized
INFO - 2016-10-13 15:47:09 --> Config Class Initialized
INFO - 2016-10-13 15:47:09 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:47:09 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:47:09 --> Utf8 Class Initialized
INFO - 2016-10-13 15:47:09 --> URI Class Initialized
INFO - 2016-10-13 15:47:09 --> Router Class Initialized
INFO - 2016-10-13 15:47:09 --> Output Class Initialized
INFO - 2016-10-13 15:47:09 --> Security Class Initialized
DEBUG - 2016-10-13 15:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:47:09 --> Input Class Initialized
INFO - 2016-10-13 15:47:09 --> Language Class Initialized
INFO - 2016-10-13 15:47:09 --> Language Class Initialized
INFO - 2016-10-13 15:47:09 --> Config Class Initialized
INFO - 2016-10-13 15:47:10 --> Loader Class Initialized
INFO - 2016-10-13 15:47:10 --> Helper loaded: common_helper
INFO - 2016-10-13 15:47:10 --> Helper loaded: url_helper
INFO - 2016-10-13 15:47:10 --> Database Driver Class Initialized
INFO - 2016-10-13 15:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:47:10 --> Parser Class Initialized
INFO - 2016-10-13 15:47:10 --> Controller Class Initialized
DEBUG - 2016-10-13 15:47:10 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:47:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:47:10 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:47:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:47:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:47:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:47:10 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:47:10 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 15:47:10 --> Final output sent to browser
DEBUG - 2016-10-13 15:47:10 --> Total execution time: 0.0537
INFO - 2016-10-13 15:47:10 --> Config Class Initialized
INFO - 2016-10-13 15:47:10 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:47:10 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:47:10 --> Utf8 Class Initialized
INFO - 2016-10-13 15:47:10 --> URI Class Initialized
INFO - 2016-10-13 15:47:10 --> Router Class Initialized
INFO - 2016-10-13 15:47:10 --> Output Class Initialized
INFO - 2016-10-13 15:47:10 --> Security Class Initialized
DEBUG - 2016-10-13 15:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:47:10 --> Input Class Initialized
INFO - 2016-10-13 15:47:10 --> Language Class Initialized
ERROR - 2016-10-13 15:47:10 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:49:24 --> Config Class Initialized
INFO - 2016-10-13 15:49:24 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:49:24 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:49:24 --> Utf8 Class Initialized
INFO - 2016-10-13 15:49:24 --> URI Class Initialized
INFO - 2016-10-13 15:49:24 --> Router Class Initialized
INFO - 2016-10-13 15:49:24 --> Output Class Initialized
INFO - 2016-10-13 15:49:24 --> Security Class Initialized
DEBUG - 2016-10-13 15:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:49:24 --> Input Class Initialized
INFO - 2016-10-13 15:49:24 --> Language Class Initialized
INFO - 2016-10-13 15:49:24 --> Language Class Initialized
INFO - 2016-10-13 15:49:24 --> Config Class Initialized
INFO - 2016-10-13 15:49:24 --> Loader Class Initialized
INFO - 2016-10-13 15:49:24 --> Helper loaded: common_helper
INFO - 2016-10-13 15:49:24 --> Helper loaded: url_helper
INFO - 2016-10-13 15:49:24 --> Database Driver Class Initialized
INFO - 2016-10-13 15:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:49:24 --> Parser Class Initialized
INFO - 2016-10-13 15:49:24 --> Controller Class Initialized
DEBUG - 2016-10-13 15:49:24 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:49:24 --> Model Class Initialized
DEBUG - 2016-10-13 15:49:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:49:24 --> Model Class Initialized
DEBUG - 2016-10-13 15:49:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:49:24 --> Model Class Initialized
DEBUG - 2016-10-13 15:49:24 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:49:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 15:49:24 --> Final output sent to browser
DEBUG - 2016-10-13 15:49:24 --> Total execution time: 0.0561
INFO - 2016-10-13 15:49:24 --> Config Class Initialized
INFO - 2016-10-13 15:49:24 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:49:24 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:49:24 --> Utf8 Class Initialized
INFO - 2016-10-13 15:49:24 --> URI Class Initialized
INFO - 2016-10-13 15:49:24 --> Router Class Initialized
INFO - 2016-10-13 15:49:24 --> Output Class Initialized
INFO - 2016-10-13 15:49:24 --> Security Class Initialized
DEBUG - 2016-10-13 15:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:49:24 --> Input Class Initialized
INFO - 2016-10-13 15:49:24 --> Language Class Initialized
INFO - 2016-10-13 15:49:24 --> Language Class Initialized
INFO - 2016-10-13 15:49:24 --> Config Class Initialized
INFO - 2016-10-13 15:49:24 --> Loader Class Initialized
INFO - 2016-10-13 15:49:24 --> Helper loaded: common_helper
INFO - 2016-10-13 15:49:24 --> Helper loaded: url_helper
INFO - 2016-10-13 15:49:24 --> Database Driver Class Initialized
INFO - 2016-10-13 15:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:49:24 --> Parser Class Initialized
INFO - 2016-10-13 15:49:24 --> Controller Class Initialized
DEBUG - 2016-10-13 15:49:24 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:49:24 --> Model Class Initialized
DEBUG - 2016-10-13 15:49:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:49:24 --> Model Class Initialized
DEBUG - 2016-10-13 15:49:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:49:24 --> Model Class Initialized
INFO - 2016-10-13 15:50:58 --> Config Class Initialized
INFO - 2016-10-13 15:50:58 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:50:58 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:50:58 --> Utf8 Class Initialized
INFO - 2016-10-13 15:50:58 --> URI Class Initialized
INFO - 2016-10-13 15:50:58 --> Router Class Initialized
INFO - 2016-10-13 15:50:58 --> Output Class Initialized
INFO - 2016-10-13 15:50:58 --> Security Class Initialized
DEBUG - 2016-10-13 15:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:50:58 --> Input Class Initialized
INFO - 2016-10-13 15:50:58 --> Language Class Initialized
INFO - 2016-10-13 15:50:58 --> Language Class Initialized
INFO - 2016-10-13 15:50:58 --> Config Class Initialized
INFO - 2016-10-13 15:50:58 --> Loader Class Initialized
INFO - 2016-10-13 15:50:58 --> Helper loaded: common_helper
INFO - 2016-10-13 15:50:58 --> Helper loaded: url_helper
INFO - 2016-10-13 15:50:58 --> Database Driver Class Initialized
INFO - 2016-10-13 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:50:58 --> Parser Class Initialized
INFO - 2016-10-13 15:50:58 --> Controller Class Initialized
DEBUG - 2016-10-13 15:50:58 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 15:50:58 --> Config Class Initialized
INFO - 2016-10-13 15:50:58 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:50:58 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:50:58 --> Utf8 Class Initialized
INFO - 2016-10-13 15:50:58 --> URI Class Initialized
INFO - 2016-10-13 15:50:58 --> Router Class Initialized
INFO - 2016-10-13 15:50:58 --> Output Class Initialized
INFO - 2016-10-13 15:50:58 --> Security Class Initialized
DEBUG - 2016-10-13 15:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:50:58 --> Input Class Initialized
INFO - 2016-10-13 15:50:58 --> Language Class Initialized
INFO - 2016-10-13 15:50:58 --> Language Class Initialized
INFO - 2016-10-13 15:50:58 --> Config Class Initialized
INFO - 2016-10-13 15:50:58 --> Loader Class Initialized
INFO - 2016-10-13 15:50:58 --> Helper loaded: common_helper
INFO - 2016-10-13 15:50:58 --> Helper loaded: url_helper
INFO - 2016-10-13 15:50:58 --> Database Driver Class Initialized
INFO - 2016-10-13 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:50:58 --> Parser Class Initialized
INFO - 2016-10-13 15:50:58 --> Controller Class Initialized
DEBUG - 2016-10-13 15:50:58 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 15:50:58 --> Model Class Initialized
DEBUG - 2016-10-13 15:50:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:50:58 --> Model Class Initialized
DEBUG - 2016-10-13 15:50:58 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-13 15:50:58 --> Final output sent to browser
DEBUG - 2016-10-13 15:50:58 --> Total execution time: 0.0361
INFO - 2016-10-13 15:51:00 --> Config Class Initialized
INFO - 2016-10-13 15:51:00 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:00 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:00 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:00 --> URI Class Initialized
INFO - 2016-10-13 15:51:00 --> Router Class Initialized
INFO - 2016-10-13 15:51:00 --> Output Class Initialized
INFO - 2016-10-13 15:51:00 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:00 --> Input Class Initialized
INFO - 2016-10-13 15:51:00 --> Language Class Initialized
INFO - 2016-10-13 15:51:00 --> Language Class Initialized
INFO - 2016-10-13 15:51:00 --> Config Class Initialized
INFO - 2016-10-13 15:51:00 --> Loader Class Initialized
INFO - 2016-10-13 15:51:00 --> Helper loaded: common_helper
INFO - 2016-10-13 15:51:00 --> Helper loaded: url_helper
INFO - 2016-10-13 15:51:00 --> Database Driver Class Initialized
INFO - 2016-10-13 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:51:00 --> Parser Class Initialized
INFO - 2016-10-13 15:51:00 --> Controller Class Initialized
DEBUG - 2016-10-13 15:51:00 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 15:51:00 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:51:00 --> Model Class Initialized
INFO - 2016-10-13 15:51:00 --> Final output sent to browser
DEBUG - 2016-10-13 15:51:00 --> Total execution time: 0.0365
INFO - 2016-10-13 15:51:00 --> Config Class Initialized
INFO - 2016-10-13 15:51:00 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:00 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:00 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:00 --> URI Class Initialized
INFO - 2016-10-13 15:51:00 --> Router Class Initialized
INFO - 2016-10-13 15:51:00 --> Output Class Initialized
INFO - 2016-10-13 15:51:00 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:00 --> Input Class Initialized
INFO - 2016-10-13 15:51:00 --> Language Class Initialized
INFO - 2016-10-13 15:51:00 --> Language Class Initialized
INFO - 2016-10-13 15:51:00 --> Config Class Initialized
INFO - 2016-10-13 15:51:00 --> Loader Class Initialized
INFO - 2016-10-13 15:51:00 --> Helper loaded: common_helper
INFO - 2016-10-13 15:51:00 --> Helper loaded: url_helper
INFO - 2016-10-13 15:51:00 --> Database Driver Class Initialized
INFO - 2016-10-13 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:51:00 --> Parser Class Initialized
INFO - 2016-10-13 15:51:00 --> Controller Class Initialized
DEBUG - 2016-10-13 15:51:00 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 15:51:00 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:51:00 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-13 15:51:00 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:51:00 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:51:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:51:00 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:51:00 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:51:00 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:51:00 --> Final output sent to browser
DEBUG - 2016-10-13 15:51:00 --> Total execution time: 0.0453
INFO - 2016-10-13 15:51:01 --> Config Class Initialized
INFO - 2016-10-13 15:51:01 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:01 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:01 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:01 --> URI Class Initialized
INFO - 2016-10-13 15:51:01 --> Router Class Initialized
INFO - 2016-10-13 15:51:01 --> Output Class Initialized
INFO - 2016-10-13 15:51:01 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:01 --> Input Class Initialized
INFO - 2016-10-13 15:51:01 --> Language Class Initialized
ERROR - 2016-10-13 15:51:01 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:51:03 --> Config Class Initialized
INFO - 2016-10-13 15:51:03 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:03 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:03 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:03 --> URI Class Initialized
INFO - 2016-10-13 15:51:03 --> Router Class Initialized
INFO - 2016-10-13 15:51:03 --> Output Class Initialized
INFO - 2016-10-13 15:51:03 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:03 --> Input Class Initialized
INFO - 2016-10-13 15:51:03 --> Language Class Initialized
INFO - 2016-10-13 15:51:03 --> Language Class Initialized
INFO - 2016-10-13 15:51:03 --> Config Class Initialized
INFO - 2016-10-13 15:51:03 --> Loader Class Initialized
INFO - 2016-10-13 15:51:03 --> Helper loaded: common_helper
INFO - 2016-10-13 15:51:03 --> Helper loaded: url_helper
INFO - 2016-10-13 15:51:03 --> Database Driver Class Initialized
INFO - 2016-10-13 15:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:51:03 --> Parser Class Initialized
INFO - 2016-10-13 15:51:03 --> Controller Class Initialized
DEBUG - 2016-10-13 15:51:03 --> Donate_report MX_Controller Initialized
INFO - 2016-10-13 15:51:03 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:51:03 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:51:03 --> Model Class Initialized
INFO - 2016-10-13 15:51:03 --> Helper loaded: form_helper
INFO - 2016-10-13 15:51:03 --> Form Validation Class Initialized
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:51:03 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:51:03 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/views/BACKEND/accountpaychart.php
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/views/BACKEND/amountuserpaychart.php
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/views/BACKEND/script-donate.php
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/views/BACKEND/index.php
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:51:03 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:51:03 --> Final output sent to browser
DEBUG - 2016-10-13 15:51:03 --> Total execution time: 0.0738
INFO - 2016-10-13 15:51:04 --> Config Class Initialized
INFO - 2016-10-13 15:51:04 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:04 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:04 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:04 --> URI Class Initialized
INFO - 2016-10-13 15:51:04 --> Router Class Initialized
INFO - 2016-10-13 15:51:04 --> Output Class Initialized
INFO - 2016-10-13 15:51:04 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:04 --> Input Class Initialized
INFO - 2016-10-13 15:51:04 --> Language Class Initialized
ERROR - 2016-10-13 15:51:04 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:51:04 --> Config Class Initialized
INFO - 2016-10-13 15:51:04 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:04 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:04 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:04 --> URI Class Initialized
INFO - 2016-10-13 15:51:04 --> Router Class Initialized
INFO - 2016-10-13 15:51:04 --> Output Class Initialized
INFO - 2016-10-13 15:51:04 --> Config Class Initialized
INFO - 2016-10-13 15:51:04 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:04 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:04 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:04 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:04 --> Input Class Initialized
INFO - 2016-10-13 15:51:04 --> Language Class Initialized
INFO - 2016-10-13 15:51:04 --> URI Class Initialized
INFO - 2016-10-13 15:51:04 --> Router Class Initialized
INFO - 2016-10-13 15:51:04 --> Output Class Initialized
INFO - 2016-10-13 15:51:04 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:04 --> Input Class Initialized
INFO - 2016-10-13 15:51:04 --> Language Class Initialized
INFO - 2016-10-13 15:51:04 --> Language Class Initialized
INFO - 2016-10-13 15:51:04 --> Config Class Initialized
INFO - 2016-10-13 15:51:04 --> Loader Class Initialized
INFO - 2016-10-13 15:51:04 --> Language Class Initialized
INFO - 2016-10-13 15:51:04 --> Config Class Initialized
INFO - 2016-10-13 15:51:04 --> Loader Class Initialized
INFO - 2016-10-13 15:51:04 --> Helper loaded: common_helper
INFO - 2016-10-13 15:51:04 --> Helper loaded: url_helper
INFO - 2016-10-13 15:51:04 --> Helper loaded: common_helper
INFO - 2016-10-13 15:51:04 --> Helper loaded: url_helper
INFO - 2016-10-13 15:51:04 --> Database Driver Class Initialized
INFO - 2016-10-13 15:51:04 --> Database Driver Class Initialized
INFO - 2016-10-13 15:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:51:04 --> Parser Class Initialized
INFO - 2016-10-13 15:51:04 --> Controller Class Initialized
DEBUG - 2016-10-13 15:51:04 --> Donate_report MX_Controller Initialized
INFO - 2016-10-13 15:51:04 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:04 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-13 15:51:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:51:04 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:51:04 --> Model Class Initialized
INFO - 2016-10-13 15:51:04 --> Helper loaded: form_helper
INFO - 2016-10-13 15:51:04 --> Form Validation Class Initialized
DEBUG - 2016-10-13 15:51:04 --> Pagination Class Initialized
DEBUG - 2016-10-13 15:51:04 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 15:51:04 --> Final output sent to browser
DEBUG - 2016-10-13 15:51:04 --> Total execution time: 0.1056
INFO - 2016-10-13 15:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:51:04 --> Parser Class Initialized
INFO - 2016-10-13 15:51:04 --> Controller Class Initialized
DEBUG - 2016-10-13 15:51:04 --> Donate_report MX_Controller Initialized
INFO - 2016-10-13 15:51:04 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:04 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-13 15:51:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:51:04 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:51:04 --> Model Class Initialized
INFO - 2016-10-13 15:51:04 --> Helper loaded: form_helper
INFO - 2016-10-13 15:51:04 --> Form Validation Class Initialized
DEBUG - 2016-10-13 15:51:04 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/views/BACKEND/statisByChannel.php
INFO - 2016-10-13 15:51:04 --> Final output sent to browser
DEBUG - 2016-10-13 15:51:04 --> Total execution time: 0.1065
INFO - 2016-10-13 15:51:10 --> Config Class Initialized
INFO - 2016-10-13 15:51:10 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:10 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:10 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:10 --> URI Class Initialized
INFO - 2016-10-13 15:51:10 --> Router Class Initialized
INFO - 2016-10-13 15:51:10 --> Output Class Initialized
INFO - 2016-10-13 15:51:10 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:10 --> Input Class Initialized
INFO - 2016-10-13 15:51:10 --> Language Class Initialized
INFO - 2016-10-13 15:51:10 --> Language Class Initialized
INFO - 2016-10-13 15:51:10 --> Config Class Initialized
INFO - 2016-10-13 15:51:10 --> Loader Class Initialized
INFO - 2016-10-13 15:51:10 --> Helper loaded: common_helper
INFO - 2016-10-13 15:51:10 --> Helper loaded: url_helper
INFO - 2016-10-13 15:51:10 --> Database Driver Class Initialized
INFO - 2016-10-13 15:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:51:10 --> Parser Class Initialized
INFO - 2016-10-13 15:51:10 --> Controller Class Initialized
DEBUG - 2016-10-13 15:51:10 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:51:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:51:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:51:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:51:10 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:51:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:51:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:51:10 --> Final output sent to browser
DEBUG - 2016-10-13 15:51:10 --> Total execution time: 0.0561
INFO - 2016-10-13 15:51:10 --> Config Class Initialized
INFO - 2016-10-13 15:51:10 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:10 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:10 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:10 --> URI Class Initialized
INFO - 2016-10-13 15:51:10 --> Router Class Initialized
INFO - 2016-10-13 15:51:10 --> Output Class Initialized
INFO - 2016-10-13 15:51:10 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:10 --> Input Class Initialized
INFO - 2016-10-13 15:51:10 --> Language Class Initialized
ERROR - 2016-10-13 15:51:10 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:51:10 --> Config Class Initialized
INFO - 2016-10-13 15:51:10 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:10 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:10 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:10 --> URI Class Initialized
INFO - 2016-10-13 15:51:10 --> Router Class Initialized
INFO - 2016-10-13 15:51:10 --> Output Class Initialized
INFO - 2016-10-13 15:51:10 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:10 --> Input Class Initialized
INFO - 2016-10-13 15:51:10 --> Language Class Initialized
INFO - 2016-10-13 15:51:10 --> Language Class Initialized
INFO - 2016-10-13 15:51:10 --> Config Class Initialized
INFO - 2016-10-13 15:51:10 --> Loader Class Initialized
INFO - 2016-10-13 15:51:10 --> Helper loaded: common_helper
INFO - 2016-10-13 15:51:10 --> Helper loaded: url_helper
INFO - 2016-10-13 15:51:10 --> Database Driver Class Initialized
INFO - 2016-10-13 15:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:51:10 --> Parser Class Initialized
INFO - 2016-10-13 15:51:10 --> Controller Class Initialized
DEBUG - 2016-10-13 15:51:10 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:51:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:51:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:51:10 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:10 --> Pagination Class Initialized
DEBUG - 2016-10-13 15:51:10 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 15:51:10 --> Final output sent to browser
DEBUG - 2016-10-13 15:51:10 --> Total execution time: 0.0493
INFO - 2016-10-13 15:51:12 --> Config Class Initialized
INFO - 2016-10-13 15:51:12 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:51:12 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:51:12 --> Utf8 Class Initialized
INFO - 2016-10-13 15:51:12 --> URI Class Initialized
INFO - 2016-10-13 15:51:12 --> Router Class Initialized
INFO - 2016-10-13 15:51:12 --> Output Class Initialized
INFO - 2016-10-13 15:51:12 --> Security Class Initialized
DEBUG - 2016-10-13 15:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:51:12 --> Input Class Initialized
INFO - 2016-10-13 15:51:12 --> Language Class Initialized
INFO - 2016-10-13 15:51:12 --> Language Class Initialized
INFO - 2016-10-13 15:51:12 --> Config Class Initialized
INFO - 2016-10-13 15:51:12 --> Loader Class Initialized
INFO - 2016-10-13 15:51:12 --> Helper loaded: common_helper
INFO - 2016-10-13 15:51:12 --> Helper loaded: url_helper
INFO - 2016-10-13 15:51:12 --> Database Driver Class Initialized
INFO - 2016-10-13 15:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:51:12 --> Parser Class Initialized
INFO - 2016-10-13 15:51:12 --> Controller Class Initialized
DEBUG - 2016-10-13 15:51:12 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:51:12 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:51:12 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:51:12 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:12 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:51:12 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:51:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:51:12 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:51:12 --> Model Class Initialized
DEBUG - 2016-10-13 15:51:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 15:51:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:51:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:51:12 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:51:12 --> Final output sent to browser
DEBUG - 2016-10-13 15:51:12 --> Total execution time: 0.0603
INFO - 2016-10-13 15:52:44 --> Config Class Initialized
INFO - 2016-10-13 15:52:44 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:52:44 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:52:44 --> Utf8 Class Initialized
INFO - 2016-10-13 15:52:44 --> URI Class Initialized
INFO - 2016-10-13 15:52:44 --> Router Class Initialized
INFO - 2016-10-13 15:52:44 --> Output Class Initialized
INFO - 2016-10-13 15:52:44 --> Security Class Initialized
DEBUG - 2016-10-13 15:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:52:44 --> Input Class Initialized
INFO - 2016-10-13 15:52:44 --> Language Class Initialized
INFO - 2016-10-13 15:52:44 --> Language Class Initialized
INFO - 2016-10-13 15:52:44 --> Config Class Initialized
INFO - 2016-10-13 15:52:44 --> Loader Class Initialized
INFO - 2016-10-13 15:52:44 --> Helper loaded: common_helper
INFO - 2016-10-13 15:52:44 --> Helper loaded: url_helper
INFO - 2016-10-13 15:52:44 --> Database Driver Class Initialized
INFO - 2016-10-13 15:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:52:44 --> Parser Class Initialized
INFO - 2016-10-13 15:52:44 --> Controller Class Initialized
DEBUG - 2016-10-13 15:52:44 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:52:44 --> Model Class Initialized
DEBUG - 2016-10-13 15:52:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:52:44 --> Model Class Initialized
DEBUG - 2016-10-13 15:52:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:52:44 --> Model Class Initialized
INFO - 2016-10-13 15:56:04 --> Config Class Initialized
INFO - 2016-10-13 15:56:04 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:56:04 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:56:04 --> Utf8 Class Initialized
INFO - 2016-10-13 15:56:04 --> URI Class Initialized
INFO - 2016-10-13 15:56:04 --> Router Class Initialized
INFO - 2016-10-13 15:56:04 --> Output Class Initialized
INFO - 2016-10-13 15:56:04 --> Security Class Initialized
DEBUG - 2016-10-13 15:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:56:04 --> Input Class Initialized
INFO - 2016-10-13 15:56:04 --> Language Class Initialized
INFO - 2016-10-13 15:56:04 --> Language Class Initialized
INFO - 2016-10-13 15:56:04 --> Config Class Initialized
INFO - 2016-10-13 15:56:04 --> Loader Class Initialized
INFO - 2016-10-13 15:56:04 --> Helper loaded: common_helper
INFO - 2016-10-13 15:56:04 --> Helper loaded: url_helper
INFO - 2016-10-13 15:56:04 --> Database Driver Class Initialized
INFO - 2016-10-13 15:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:56:04 --> Parser Class Initialized
INFO - 2016-10-13 15:56:04 --> Controller Class Initialized
DEBUG - 2016-10-13 15:56:04 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:56:04 --> Model Class Initialized
DEBUG - 2016-10-13 15:56:04 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:56:04 --> Model Class Initialized
DEBUG - 2016-10-13 15:56:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:56:04 --> Model Class Initialized
INFO - 2016-10-13 15:57:23 --> Config Class Initialized
INFO - 2016-10-13 15:57:23 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:57:23 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:57:23 --> Utf8 Class Initialized
INFO - 2016-10-13 15:57:23 --> URI Class Initialized
INFO - 2016-10-13 15:57:23 --> Router Class Initialized
INFO - 2016-10-13 15:57:23 --> Output Class Initialized
INFO - 2016-10-13 15:57:23 --> Security Class Initialized
DEBUG - 2016-10-13 15:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:57:23 --> Input Class Initialized
INFO - 2016-10-13 15:57:23 --> Language Class Initialized
INFO - 2016-10-13 15:57:23 --> Language Class Initialized
INFO - 2016-10-13 15:57:23 --> Config Class Initialized
INFO - 2016-10-13 15:57:23 --> Loader Class Initialized
INFO - 2016-10-13 15:57:23 --> Helper loaded: common_helper
INFO - 2016-10-13 15:57:23 --> Helper loaded: url_helper
INFO - 2016-10-13 15:57:23 --> Database Driver Class Initialized
INFO - 2016-10-13 15:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:57:23 --> Parser Class Initialized
INFO - 2016-10-13 15:57:23 --> Controller Class Initialized
DEBUG - 2016-10-13 15:57:23 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 15:57:23 --> Config Class Initialized
INFO - 2016-10-13 15:57:23 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:57:23 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:57:23 --> Utf8 Class Initialized
INFO - 2016-10-13 15:57:23 --> URI Class Initialized
INFO - 2016-10-13 15:57:23 --> Router Class Initialized
INFO - 2016-10-13 15:57:23 --> Output Class Initialized
INFO - 2016-10-13 15:57:23 --> Security Class Initialized
DEBUG - 2016-10-13 15:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:57:23 --> Input Class Initialized
INFO - 2016-10-13 15:57:23 --> Language Class Initialized
INFO - 2016-10-13 15:57:23 --> Language Class Initialized
INFO - 2016-10-13 15:57:23 --> Config Class Initialized
INFO - 2016-10-13 15:57:23 --> Loader Class Initialized
INFO - 2016-10-13 15:57:23 --> Helper loaded: common_helper
INFO - 2016-10-13 15:57:23 --> Helper loaded: url_helper
INFO - 2016-10-13 15:57:23 --> Database Driver Class Initialized
INFO - 2016-10-13 15:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:57:23 --> Parser Class Initialized
INFO - 2016-10-13 15:57:23 --> Controller Class Initialized
DEBUG - 2016-10-13 15:57:23 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 15:57:23 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:57:23 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:23 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-13 15:57:23 --> Final output sent to browser
DEBUG - 2016-10-13 15:57:23 --> Total execution time: 0.0572
INFO - 2016-10-13 15:57:29 --> Config Class Initialized
INFO - 2016-10-13 15:57:29 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:57:29 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:57:29 --> Utf8 Class Initialized
INFO - 2016-10-13 15:57:29 --> URI Class Initialized
INFO - 2016-10-13 15:57:29 --> Router Class Initialized
INFO - 2016-10-13 15:57:29 --> Output Class Initialized
INFO - 2016-10-13 15:57:29 --> Security Class Initialized
DEBUG - 2016-10-13 15:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:57:29 --> Input Class Initialized
INFO - 2016-10-13 15:57:29 --> Language Class Initialized
INFO - 2016-10-13 15:57:29 --> Language Class Initialized
INFO - 2016-10-13 15:57:29 --> Config Class Initialized
INFO - 2016-10-13 15:57:29 --> Loader Class Initialized
INFO - 2016-10-13 15:57:29 --> Helper loaded: common_helper
INFO - 2016-10-13 15:57:29 --> Helper loaded: url_helper
INFO - 2016-10-13 15:57:29 --> Database Driver Class Initialized
INFO - 2016-10-13 15:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:57:29 --> Parser Class Initialized
INFO - 2016-10-13 15:57:29 --> Controller Class Initialized
DEBUG - 2016-10-13 15:57:29 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 15:57:29 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:57:29 --> Model Class Initialized
INFO - 2016-10-13 15:57:29 --> Final output sent to browser
DEBUG - 2016-10-13 15:57:29 --> Total execution time: 0.0431
INFO - 2016-10-13 15:57:29 --> Config Class Initialized
INFO - 2016-10-13 15:57:29 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:57:29 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:57:29 --> Utf8 Class Initialized
INFO - 2016-10-13 15:57:29 --> URI Class Initialized
INFO - 2016-10-13 15:57:29 --> Router Class Initialized
INFO - 2016-10-13 15:57:29 --> Output Class Initialized
INFO - 2016-10-13 15:57:29 --> Security Class Initialized
DEBUG - 2016-10-13 15:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:57:29 --> Input Class Initialized
INFO - 2016-10-13 15:57:29 --> Language Class Initialized
INFO - 2016-10-13 15:57:29 --> Language Class Initialized
INFO - 2016-10-13 15:57:29 --> Config Class Initialized
INFO - 2016-10-13 15:57:29 --> Loader Class Initialized
INFO - 2016-10-13 15:57:29 --> Helper loaded: common_helper
INFO - 2016-10-13 15:57:29 --> Helper loaded: url_helper
INFO - 2016-10-13 15:57:29 --> Database Driver Class Initialized
INFO - 2016-10-13 15:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:57:29 --> Parser Class Initialized
INFO - 2016-10-13 15:57:29 --> Controller Class Initialized
DEBUG - 2016-10-13 15:57:29 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 15:57:29 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:57:29 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-13 15:57:29 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:57:29 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:57:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:57:29 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:57:29 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:57:29 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:57:29 --> Final output sent to browser
DEBUG - 2016-10-13 15:57:29 --> Total execution time: 0.0431
INFO - 2016-10-13 15:57:31 --> Config Class Initialized
INFO - 2016-10-13 15:57:31 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:57:31 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:57:31 --> Utf8 Class Initialized
INFO - 2016-10-13 15:57:31 --> URI Class Initialized
INFO - 2016-10-13 15:57:31 --> Router Class Initialized
INFO - 2016-10-13 15:57:31 --> Output Class Initialized
INFO - 2016-10-13 15:57:31 --> Security Class Initialized
DEBUG - 2016-10-13 15:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:57:31 --> Input Class Initialized
INFO - 2016-10-13 15:57:31 --> Language Class Initialized
ERROR - 2016-10-13 15:57:31 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:57:35 --> Config Class Initialized
INFO - 2016-10-13 15:57:35 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:57:35 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:57:35 --> Utf8 Class Initialized
INFO - 2016-10-13 15:57:35 --> URI Class Initialized
INFO - 2016-10-13 15:57:35 --> Router Class Initialized
INFO - 2016-10-13 15:57:35 --> Output Class Initialized
INFO - 2016-10-13 15:57:35 --> Security Class Initialized
DEBUG - 2016-10-13 15:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:57:35 --> Input Class Initialized
INFO - 2016-10-13 15:57:35 --> Language Class Initialized
INFO - 2016-10-13 15:57:35 --> Language Class Initialized
INFO - 2016-10-13 15:57:35 --> Config Class Initialized
INFO - 2016-10-13 15:57:35 --> Loader Class Initialized
INFO - 2016-10-13 15:57:35 --> Helper loaded: common_helper
INFO - 2016-10-13 15:57:35 --> Helper loaded: url_helper
INFO - 2016-10-13 15:57:35 --> Database Driver Class Initialized
INFO - 2016-10-13 15:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:57:35 --> Parser Class Initialized
INFO - 2016-10-13 15:57:35 --> Controller Class Initialized
DEBUG - 2016-10-13 15:57:35 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:57:35 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:57:35 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:57:35 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:57:35 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:57:35 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:57:35 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:57:35 --> Final output sent to browser
DEBUG - 2016-10-13 15:57:35 --> Total execution time: 0.0424
INFO - 2016-10-13 15:57:35 --> Config Class Initialized
INFO - 2016-10-13 15:57:35 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:57:35 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:57:35 --> Utf8 Class Initialized
INFO - 2016-10-13 15:57:35 --> URI Class Initialized
INFO - 2016-10-13 15:57:35 --> Router Class Initialized
INFO - 2016-10-13 15:57:35 --> Output Class Initialized
INFO - 2016-10-13 15:57:35 --> Security Class Initialized
DEBUG - 2016-10-13 15:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:57:35 --> Input Class Initialized
INFO - 2016-10-13 15:57:35 --> Language Class Initialized
ERROR - 2016-10-13 15:57:35 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:57:35 --> Config Class Initialized
INFO - 2016-10-13 15:57:35 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:57:35 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:57:35 --> Utf8 Class Initialized
INFO - 2016-10-13 15:57:35 --> URI Class Initialized
INFO - 2016-10-13 15:57:35 --> Router Class Initialized
INFO - 2016-10-13 15:57:35 --> Output Class Initialized
INFO - 2016-10-13 15:57:35 --> Security Class Initialized
DEBUG - 2016-10-13 15:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:57:35 --> Input Class Initialized
INFO - 2016-10-13 15:57:35 --> Language Class Initialized
INFO - 2016-10-13 15:57:35 --> Language Class Initialized
INFO - 2016-10-13 15:57:35 --> Config Class Initialized
INFO - 2016-10-13 15:57:35 --> Loader Class Initialized
INFO - 2016-10-13 15:57:35 --> Helper loaded: common_helper
INFO - 2016-10-13 15:57:35 --> Helper loaded: url_helper
INFO - 2016-10-13 15:57:35 --> Database Driver Class Initialized
INFO - 2016-10-13 15:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:57:35 --> Parser Class Initialized
INFO - 2016-10-13 15:57:35 --> Controller Class Initialized
DEBUG - 2016-10-13 15:57:35 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:57:35 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:57:35 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:57:35 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:35 --> Pagination Class Initialized
DEBUG - 2016-10-13 15:57:35 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 15:57:35 --> Final output sent to browser
DEBUG - 2016-10-13 15:57:35 --> Total execution time: 0.0463
INFO - 2016-10-13 15:57:38 --> Config Class Initialized
INFO - 2016-10-13 15:57:38 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:57:38 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:57:38 --> Utf8 Class Initialized
INFO - 2016-10-13 15:57:38 --> URI Class Initialized
INFO - 2016-10-13 15:57:38 --> Router Class Initialized
INFO - 2016-10-13 15:57:38 --> Output Class Initialized
INFO - 2016-10-13 15:57:38 --> Security Class Initialized
DEBUG - 2016-10-13 15:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:57:38 --> Input Class Initialized
INFO - 2016-10-13 15:57:38 --> Language Class Initialized
INFO - 2016-10-13 15:57:38 --> Language Class Initialized
INFO - 2016-10-13 15:57:38 --> Config Class Initialized
INFO - 2016-10-13 15:57:38 --> Loader Class Initialized
INFO - 2016-10-13 15:57:38 --> Helper loaded: common_helper
INFO - 2016-10-13 15:57:38 --> Helper loaded: url_helper
INFO - 2016-10-13 15:57:38 --> Database Driver Class Initialized
INFO - 2016-10-13 15:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:57:38 --> Parser Class Initialized
INFO - 2016-10-13 15:57:38 --> Controller Class Initialized
DEBUG - 2016-10-13 15:57:38 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:57:38 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:57:38 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:57:38 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:57:38 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:57:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:57:38 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:57:38 --> Model Class Initialized
DEBUG - 2016-10-13 15:57:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 15:57:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:57:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:57:38 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:57:38 --> Final output sent to browser
DEBUG - 2016-10-13 15:57:38 --> Total execution time: 0.0523
INFO - 2016-10-13 15:58:30 --> Config Class Initialized
INFO - 2016-10-13 15:58:30 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:58:30 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:58:30 --> Utf8 Class Initialized
INFO - 2016-10-13 15:58:30 --> URI Class Initialized
INFO - 2016-10-13 15:58:30 --> Router Class Initialized
INFO - 2016-10-13 15:58:30 --> Output Class Initialized
INFO - 2016-10-13 15:58:30 --> Security Class Initialized
DEBUG - 2016-10-13 15:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:58:30 --> Input Class Initialized
INFO - 2016-10-13 15:58:30 --> Language Class Initialized
INFO - 2016-10-13 15:58:30 --> Language Class Initialized
INFO - 2016-10-13 15:58:30 --> Config Class Initialized
INFO - 2016-10-13 15:58:30 --> Loader Class Initialized
INFO - 2016-10-13 15:58:30 --> Helper loaded: common_helper
INFO - 2016-10-13 15:58:30 --> Helper loaded: url_helper
INFO - 2016-10-13 15:58:30 --> Database Driver Class Initialized
INFO - 2016-10-13 15:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:58:30 --> Parser Class Initialized
INFO - 2016-10-13 15:58:30 --> Controller Class Initialized
DEBUG - 2016-10-13 15:58:30 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:58:30 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:58:30 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:58:30 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:58:30 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:58:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:58:30 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:58:30 --> Model Class Initialized
ERROR - 2016-10-13 15:58:30 --> Severity: Notice --> Undefined variable: fileName /home/dolongpk/public_html/application/modules/servers/controllers/Servers.php 63
ERROR - 2016-10-13 15:58:30 --> Severity: Notice --> Undefined variable: fileName /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php 133
INFO - 2016-10-13 15:58:39 --> Config Class Initialized
INFO - 2016-10-13 15:58:39 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:58:39 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:58:39 --> Utf8 Class Initialized
INFO - 2016-10-13 15:58:39 --> URI Class Initialized
INFO - 2016-10-13 15:58:39 --> Router Class Initialized
INFO - 2016-10-13 15:58:39 --> Output Class Initialized
INFO - 2016-10-13 15:58:39 --> Security Class Initialized
DEBUG - 2016-10-13 15:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:58:39 --> Input Class Initialized
INFO - 2016-10-13 15:58:39 --> Language Class Initialized
INFO - 2016-10-13 15:58:39 --> Language Class Initialized
INFO - 2016-10-13 15:58:39 --> Config Class Initialized
INFO - 2016-10-13 15:58:39 --> Loader Class Initialized
INFO - 2016-10-13 15:58:39 --> Helper loaded: common_helper
INFO - 2016-10-13 15:58:39 --> Helper loaded: url_helper
INFO - 2016-10-13 15:58:39 --> Database Driver Class Initialized
INFO - 2016-10-13 15:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:58:39 --> Parser Class Initialized
INFO - 2016-10-13 15:58:39 --> Controller Class Initialized
DEBUG - 2016-10-13 15:58:39 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:58:39 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:58:39 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:58:39 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:39 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:58:39 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:58:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:58:39 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:58:39 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 15:58:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:58:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:58:39 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:58:39 --> Final output sent to browser
DEBUG - 2016-10-13 15:58:39 --> Total execution time: 0.0527
INFO - 2016-10-13 15:58:46 --> Config Class Initialized
INFO - 2016-10-13 15:58:46 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:58:46 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:58:46 --> Utf8 Class Initialized
INFO - 2016-10-13 15:58:46 --> URI Class Initialized
INFO - 2016-10-13 15:58:46 --> Router Class Initialized
INFO - 2016-10-13 15:58:46 --> Output Class Initialized
INFO - 2016-10-13 15:58:46 --> Security Class Initialized
DEBUG - 2016-10-13 15:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:58:46 --> Input Class Initialized
INFO - 2016-10-13 15:58:46 --> Language Class Initialized
INFO - 2016-10-13 15:58:46 --> Language Class Initialized
INFO - 2016-10-13 15:58:46 --> Config Class Initialized
INFO - 2016-10-13 15:58:46 --> Loader Class Initialized
INFO - 2016-10-13 15:58:46 --> Helper loaded: common_helper
INFO - 2016-10-13 15:58:46 --> Helper loaded: url_helper
INFO - 2016-10-13 15:58:46 --> Database Driver Class Initialized
INFO - 2016-10-13 15:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:58:46 --> Parser Class Initialized
INFO - 2016-10-13 15:58:46 --> Controller Class Initialized
DEBUG - 2016-10-13 15:58:46 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:58:46 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:58:46 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:58:46 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:46 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:58:46 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:58:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:58:46 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:58:46 --> Model Class Initialized
DEBUG - 2016-10-13 15:58:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 15:58:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:58:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:58:46 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:58:46 --> Final output sent to browser
DEBUG - 2016-10-13 15:58:46 --> Total execution time: 0.0589
INFO - 2016-10-13 15:59:08 --> Config Class Initialized
INFO - 2016-10-13 15:59:08 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:08 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:08 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:08 --> URI Class Initialized
INFO - 2016-10-13 15:59:08 --> Router Class Initialized
INFO - 2016-10-13 15:59:08 --> Output Class Initialized
INFO - 2016-10-13 15:59:08 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:08 --> Input Class Initialized
INFO - 2016-10-13 15:59:08 --> Language Class Initialized
INFO - 2016-10-13 15:59:08 --> Language Class Initialized
INFO - 2016-10-13 15:59:08 --> Config Class Initialized
INFO - 2016-10-13 15:59:08 --> Loader Class Initialized
INFO - 2016-10-13 15:59:08 --> Helper loaded: common_helper
INFO - 2016-10-13 15:59:08 --> Helper loaded: url_helper
INFO - 2016-10-13 15:59:08 --> Database Driver Class Initialized
INFO - 2016-10-13 15:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:59:08 --> Parser Class Initialized
INFO - 2016-10-13 15:59:08 --> Controller Class Initialized
DEBUG - 2016-10-13 15:59:08 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:59:08 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:59:08 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:59:08 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:59:08 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:59:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:59:08 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:59:08 --> Model Class Initialized
ERROR - 2016-10-13 15:59:08 --> Severity: Notice --> Undefined variable: fileName /home/dolongpk/public_html/application/modules/servers/controllers/Servers.php 63
ERROR - 2016-10-13 15:59:08 --> Severity: Notice --> Undefined variable: fileName /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php 133
INFO - 2016-10-13 15:59:24 --> Config Class Initialized
INFO - 2016-10-13 15:59:24 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:24 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:24 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:24 --> URI Class Initialized
INFO - 2016-10-13 15:59:24 --> Router Class Initialized
INFO - 2016-10-13 15:59:24 --> Output Class Initialized
INFO - 2016-10-13 15:59:24 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:24 --> Input Class Initialized
INFO - 2016-10-13 15:59:24 --> Language Class Initialized
INFO - 2016-10-13 15:59:24 --> Language Class Initialized
INFO - 2016-10-13 15:59:24 --> Config Class Initialized
INFO - 2016-10-13 15:59:24 --> Loader Class Initialized
INFO - 2016-10-13 15:59:24 --> Helper loaded: common_helper
INFO - 2016-10-13 15:59:24 --> Helper loaded: url_helper
INFO - 2016-10-13 15:59:24 --> Database Driver Class Initialized
INFO - 2016-10-13 15:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:59:24 --> Parser Class Initialized
INFO - 2016-10-13 15:59:24 --> Controller Class Initialized
DEBUG - 2016-10-13 15:59:24 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:59:24 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:59:24 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:59:24 --> Model Class Initialized
INFO - 2016-10-13 15:59:42 --> Config Class Initialized
INFO - 2016-10-13 15:59:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:42 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:42 --> URI Class Initialized
INFO - 2016-10-13 15:59:42 --> Router Class Initialized
INFO - 2016-10-13 15:59:42 --> Output Class Initialized
INFO - 2016-10-13 15:59:42 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:42 --> Input Class Initialized
INFO - 2016-10-13 15:59:42 --> Language Class Initialized
INFO - 2016-10-13 15:59:42 --> Language Class Initialized
INFO - 2016-10-13 15:59:42 --> Config Class Initialized
INFO - 2016-10-13 15:59:42 --> Loader Class Initialized
INFO - 2016-10-13 15:59:42 --> Helper loaded: common_helper
INFO - 2016-10-13 15:59:42 --> Helper loaded: url_helper
INFO - 2016-10-13 15:59:42 --> Database Driver Class Initialized
INFO - 2016-10-13 15:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:59:42 --> Parser Class Initialized
INFO - 2016-10-13 15:59:42 --> Controller Class Initialized
DEBUG - 2016-10-13 15:59:42 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:59:42 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:59:42 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:59:42 --> Model Class Initialized
INFO - 2016-10-13 15:59:42 --> Config Class Initialized
INFO - 2016-10-13 15:59:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:42 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:42 --> URI Class Initialized
INFO - 2016-10-13 15:59:42 --> Router Class Initialized
INFO - 2016-10-13 15:59:42 --> Output Class Initialized
INFO - 2016-10-13 15:59:42 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:42 --> Input Class Initialized
INFO - 2016-10-13 15:59:42 --> Language Class Initialized
INFO - 2016-10-13 15:59:42 --> Language Class Initialized
INFO - 2016-10-13 15:59:42 --> Config Class Initialized
INFO - 2016-10-13 15:59:42 --> Loader Class Initialized
INFO - 2016-10-13 15:59:42 --> Helper loaded: common_helper
INFO - 2016-10-13 15:59:42 --> Helper loaded: url_helper
INFO - 2016-10-13 15:59:42 --> Database Driver Class Initialized
INFO - 2016-10-13 15:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:59:42 --> Parser Class Initialized
INFO - 2016-10-13 15:59:42 --> Controller Class Initialized
DEBUG - 2016-10-13 15:59:42 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:59:42 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:59:42 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 15:59:42 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:59:42 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 15:59:42 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 15:59:42 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 15:59:42 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:59:42 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-13 15:59:42 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:59:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 15:59:42 --> Final output sent to browser
DEBUG - 2016-10-13 15:59:42 --> Total execution time: 0.0501
INFO - 2016-10-13 15:59:42 --> Config Class Initialized
INFO - 2016-10-13 15:59:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:42 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:42 --> URI Class Initialized
INFO - 2016-10-13 15:59:42 --> Router Class Initialized
INFO - 2016-10-13 15:59:42 --> Output Class Initialized
INFO - 2016-10-13 15:59:42 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:42 --> Input Class Initialized
INFO - 2016-10-13 15:59:42 --> Language Class Initialized
ERROR - 2016-10-13 15:59:42 --> 404 Page Not Found: /index
INFO - 2016-10-13 15:59:45 --> Config Class Initialized
INFO - 2016-10-13 15:59:45 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:45 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:45 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:45 --> URI Class Initialized
INFO - 2016-10-13 15:59:45 --> Router Class Initialized
INFO - 2016-10-13 15:59:45 --> Output Class Initialized
INFO - 2016-10-13 15:59:45 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:45 --> Input Class Initialized
INFO - 2016-10-13 15:59:45 --> Language Class Initialized
INFO - 2016-10-13 15:59:45 --> Language Class Initialized
INFO - 2016-10-13 15:59:45 --> Config Class Initialized
INFO - 2016-10-13 15:59:45 --> Loader Class Initialized
INFO - 2016-10-13 15:59:45 --> Helper loaded: common_helper
INFO - 2016-10-13 15:59:45 --> Helper loaded: url_helper
INFO - 2016-10-13 15:59:45 --> Database Driver Class Initialized
INFO - 2016-10-13 15:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:59:45 --> Parser Class Initialized
INFO - 2016-10-13 15:59:45 --> Controller Class Initialized
DEBUG - 2016-10-13 15:59:45 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:59:45 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:45 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:59:45 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:59:45 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:45 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 15:59:45 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 15:59:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 15:59:45 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:59:45 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:45 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 15:59:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 15:59:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 15:59:45 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 15:59:45 --> Final output sent to browser
DEBUG - 2016-10-13 15:59:45 --> Total execution time: 0.0557
INFO - 2016-10-13 15:59:52 --> Config Class Initialized
INFO - 2016-10-13 15:59:52 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:52 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:52 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:52 --> URI Class Initialized
INFO - 2016-10-13 15:59:52 --> Router Class Initialized
INFO - 2016-10-13 15:59:52 --> Output Class Initialized
INFO - 2016-10-13 15:59:52 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:52 --> Input Class Initialized
INFO - 2016-10-13 15:59:52 --> Language Class Initialized
INFO - 2016-10-13 15:59:52 --> Language Class Initialized
INFO - 2016-10-13 15:59:52 --> Config Class Initialized
INFO - 2016-10-13 15:59:52 --> Loader Class Initialized
INFO - 2016-10-13 15:59:52 --> Helper loaded: common_helper
INFO - 2016-10-13 15:59:52 --> Helper loaded: url_helper
INFO - 2016-10-13 15:59:52 --> Database Driver Class Initialized
INFO - 2016-10-13 15:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:59:52 --> Parser Class Initialized
INFO - 2016-10-13 15:59:52 --> Controller Class Initialized
DEBUG - 2016-10-13 15:59:52 --> User MX_Controller Initialized
INFO - 2016-10-13 15:59:52 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:52 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-13 15:59:52 --> Model Class Initialized
INFO - 2016-10-13 15:59:52 --> Helper loaded: cookie_helper
INFO - 2016-10-13 15:59:52 --> Helper loaded: form_helper
DEBUG - 2016-10-13 15:59:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 15:59:52 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:59:52 --> Model Class Initialized
INFO - 2016-10-13 15:59:52 --> Final output sent to browser
DEBUG - 2016-10-13 15:59:52 --> Total execution time: 0.0455
INFO - 2016-10-13 15:59:54 --> Config Class Initialized
INFO - 2016-10-13 15:59:54 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:54 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:54 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:54 --> URI Class Initialized
DEBUG - 2016-10-13 15:59:54 --> No URI present. Default controller set.
INFO - 2016-10-13 15:59:54 --> Router Class Initialized
INFO - 2016-10-13 15:59:54 --> Output Class Initialized
INFO - 2016-10-13 15:59:54 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:54 --> Input Class Initialized
INFO - 2016-10-13 15:59:54 --> Language Class Initialized
INFO - 2016-10-13 15:59:54 --> Language Class Initialized
INFO - 2016-10-13 15:59:54 --> Config Class Initialized
INFO - 2016-10-13 15:59:54 --> Loader Class Initialized
INFO - 2016-10-13 15:59:54 --> Helper loaded: common_helper
INFO - 2016-10-13 15:59:54 --> Helper loaded: url_helper
INFO - 2016-10-13 15:59:54 --> Database Driver Class Initialized
INFO - 2016-10-13 15:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:59:54 --> Parser Class Initialized
INFO - 2016-10-13 15:59:54 --> Controller Class Initialized
DEBUG - 2016-10-13 15:59:54 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:59:54 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:54 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:59:54 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 15:59:54 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:59:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:59:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:59:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 15:59:54 --> Final output sent to browser
DEBUG - 2016-10-13 15:59:54 --> Total execution time: 0.0556
INFO - 2016-10-13 15:59:56 --> Config Class Initialized
INFO - 2016-10-13 15:59:56 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:56 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:56 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:56 --> URI Class Initialized
INFO - 2016-10-13 15:59:56 --> Router Class Initialized
INFO - 2016-10-13 15:59:56 --> Output Class Initialized
INFO - 2016-10-13 15:59:56 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:56 --> Input Class Initialized
INFO - 2016-10-13 15:59:56 --> Language Class Initialized
INFO - 2016-10-13 15:59:56 --> Language Class Initialized
INFO - 2016-10-13 15:59:56 --> Config Class Initialized
INFO - 2016-10-13 15:59:56 --> Loader Class Initialized
INFO - 2016-10-13 15:59:56 --> Helper loaded: common_helper
INFO - 2016-10-13 15:59:56 --> Helper loaded: url_helper
INFO - 2016-10-13 15:59:56 --> Database Driver Class Initialized
INFO - 2016-10-13 15:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:59:56 --> Parser Class Initialized
INFO - 2016-10-13 15:59:56 --> Controller Class Initialized
DEBUG - 2016-10-13 15:59:56 --> Servers MX_Controller Initialized
INFO - 2016-10-13 15:59:56 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:56 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 15:59:56 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 15:59:56 --> Model Class Initialized
INFO - 2016-10-13 15:59:56 --> Config Class Initialized
INFO - 2016-10-13 15:59:56 --> Hooks Class Initialized
DEBUG - 2016-10-13 15:59:56 --> UTF-8 Support Enabled
INFO - 2016-10-13 15:59:56 --> Utf8 Class Initialized
INFO - 2016-10-13 15:59:56 --> URI Class Initialized
DEBUG - 2016-10-13 15:59:56 --> No URI present. Default controller set.
INFO - 2016-10-13 15:59:56 --> Router Class Initialized
INFO - 2016-10-13 15:59:56 --> Output Class Initialized
INFO - 2016-10-13 15:59:56 --> Security Class Initialized
DEBUG - 2016-10-13 15:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 15:59:56 --> Input Class Initialized
INFO - 2016-10-13 15:59:56 --> Language Class Initialized
INFO - 2016-10-13 15:59:56 --> Language Class Initialized
INFO - 2016-10-13 15:59:56 --> Config Class Initialized
INFO - 2016-10-13 15:59:56 --> Loader Class Initialized
INFO - 2016-10-13 15:59:56 --> Helper loaded: common_helper
INFO - 2016-10-13 15:59:56 --> Helper loaded: url_helper
INFO - 2016-10-13 15:59:56 --> Database Driver Class Initialized
INFO - 2016-10-13 15:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 15:59:56 --> Parser Class Initialized
INFO - 2016-10-13 15:59:56 --> Controller Class Initialized
DEBUG - 2016-10-13 15:59:56 --> Home MX_Controller Initialized
INFO - 2016-10-13 15:59:56 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:56 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 15:59:56 --> Model Class Initialized
DEBUG - 2016-10-13 15:59:56 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 15:59:56 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 15:59:56 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 15:59:56 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 15:59:56 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 15:59:56 --> Final output sent to browser
DEBUG - 2016-10-13 15:59:56 --> Total execution time: 0.0401
INFO - 2016-10-13 16:00:01 --> Config Class Initialized
INFO - 2016-10-13 16:00:01 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:01 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:01 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:01 --> URI Class Initialized
INFO - 2016-10-13 16:00:01 --> Router Class Initialized
INFO - 2016-10-13 16:00:01 --> Output Class Initialized
INFO - 2016-10-13 16:00:01 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:01 --> Input Class Initialized
INFO - 2016-10-13 16:00:01 --> Language Class Initialized
INFO - 2016-10-13 16:00:01 --> Language Class Initialized
INFO - 2016-10-13 16:00:01 --> Config Class Initialized
INFO - 2016-10-13 16:00:01 --> Loader Class Initialized
INFO - 2016-10-13 16:00:01 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:01 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:01 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:01 --> Parser Class Initialized
INFO - 2016-10-13 16:00:01 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:01 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
INFO - 2016-10-13 16:00:01 --> Config Class Initialized
INFO - 2016-10-13 16:00:01 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:01 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:01 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:01 --> URI Class Initialized
DEBUG - 2016-10-13 16:00:01 --> No URI present. Default controller set.
INFO - 2016-10-13 16:00:01 --> Router Class Initialized
INFO - 2016-10-13 16:00:01 --> Output Class Initialized
INFO - 2016-10-13 16:00:01 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:01 --> Input Class Initialized
INFO - 2016-10-13 16:00:01 --> Language Class Initialized
INFO - 2016-10-13 16:00:01 --> Language Class Initialized
INFO - 2016-10-13 16:00:01 --> Config Class Initialized
INFO - 2016-10-13 16:00:01 --> Loader Class Initialized
INFO - 2016-10-13 16:00:01 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:01 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:01 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:01 --> Parser Class Initialized
INFO - 2016-10-13 16:00:01 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:01 --> Home MX_Controller Initialized
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 16:00:01 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 16:00:01 --> Final output sent to browser
DEBUG - 2016-10-13 16:00:01 --> Total execution time: 0.0335
INFO - 2016-10-13 16:00:01 --> Config Class Initialized
INFO - 2016-10-13 16:00:01 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:01 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:01 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:01 --> URI Class Initialized
INFO - 2016-10-13 16:00:01 --> Router Class Initialized
INFO - 2016-10-13 16:00:01 --> Output Class Initialized
INFO - 2016-10-13 16:00:01 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:01 --> Input Class Initialized
INFO - 2016-10-13 16:00:01 --> Language Class Initialized
INFO - 2016-10-13 16:00:01 --> Language Class Initialized
INFO - 2016-10-13 16:00:01 --> Config Class Initialized
INFO - 2016-10-13 16:00:01 --> Loader Class Initialized
INFO - 2016-10-13 16:00:01 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:01 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:01 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:01 --> Parser Class Initialized
INFO - 2016-10-13 16:00:01 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:01 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 16:00:01 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 16:00:01 --> Model Class Initialized
ERROR - 2016-10-13 16:00:01 --> Severity: Notice --> Undefined variable: fileName /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php 133
INFO - 2016-10-13 16:00:03 --> Config Class Initialized
INFO - 2016-10-13 16:00:03 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:03 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:03 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:03 --> URI Class Initialized
INFO - 2016-10-13 16:00:03 --> Router Class Initialized
INFO - 2016-10-13 16:00:03 --> Output Class Initialized
INFO - 2016-10-13 16:00:03 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:03 --> Input Class Initialized
INFO - 2016-10-13 16:00:03 --> Language Class Initialized
INFO - 2016-10-13 16:00:03 --> Language Class Initialized
INFO - 2016-10-13 16:00:03 --> Config Class Initialized
INFO - 2016-10-13 16:00:03 --> Loader Class Initialized
INFO - 2016-10-13 16:00:03 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:03 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:03 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:03 --> Parser Class Initialized
INFO - 2016-10-13 16:00:03 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:03 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:03 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:03 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:03 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 16:00:03 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 16:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 16:00:03 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 16:00:03 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 16:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 16:00:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 16:00:03 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 16:00:03 --> Final output sent to browser
DEBUG - 2016-10-13 16:00:03 --> Total execution time: 0.0420
INFO - 2016-10-13 16:00:06 --> Config Class Initialized
INFO - 2016-10-13 16:00:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:06 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:06 --> URI Class Initialized
INFO - 2016-10-13 16:00:06 --> Router Class Initialized
INFO - 2016-10-13 16:00:06 --> Output Class Initialized
INFO - 2016-10-13 16:00:06 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:06 --> Input Class Initialized
INFO - 2016-10-13 16:00:06 --> Language Class Initialized
INFO - 2016-10-13 16:00:06 --> Language Class Initialized
INFO - 2016-10-13 16:00:06 --> Config Class Initialized
INFO - 2016-10-13 16:00:06 --> Loader Class Initialized
INFO - 2016-10-13 16:00:06 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:06 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:06 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:06 --> Parser Class Initialized
INFO - 2016-10-13 16:00:06 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:06 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:06 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:06 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:06 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 16:00:06 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 16:00:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 16:00:06 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 16:00:06 --> Model Class Initialized
ERROR - 2016-10-13 16:00:06 --> Severity: Notice --> Undefined variable: fileName /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php 133
INFO - 2016-10-13 16:00:15 --> Config Class Initialized
INFO - 2016-10-13 16:00:15 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:15 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:15 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:15 --> URI Class Initialized
INFO - 2016-10-13 16:00:15 --> Router Class Initialized
INFO - 2016-10-13 16:00:15 --> Output Class Initialized
INFO - 2016-10-13 16:00:15 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:16 --> Input Class Initialized
INFO - 2016-10-13 16:00:16 --> Language Class Initialized
INFO - 2016-10-13 16:00:16 --> Language Class Initialized
INFO - 2016-10-13 16:00:16 --> Config Class Initialized
INFO - 2016-10-13 16:00:16 --> Loader Class Initialized
INFO - 2016-10-13 16:00:16 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:16 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:16 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:16 --> Parser Class Initialized
INFO - 2016-10-13 16:00:16 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:16 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:16 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:16 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:16 --> Model Class Initialized
INFO - 2016-10-13 16:00:16 --> Config Class Initialized
INFO - 2016-10-13 16:00:16 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:16 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:16 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:16 --> URI Class Initialized
DEBUG - 2016-10-13 16:00:16 --> No URI present. Default controller set.
INFO - 2016-10-13 16:00:16 --> Router Class Initialized
INFO - 2016-10-13 16:00:16 --> Output Class Initialized
INFO - 2016-10-13 16:00:16 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:16 --> Input Class Initialized
INFO - 2016-10-13 16:00:16 --> Language Class Initialized
INFO - 2016-10-13 16:00:16 --> Language Class Initialized
INFO - 2016-10-13 16:00:16 --> Config Class Initialized
INFO - 2016-10-13 16:00:16 --> Loader Class Initialized
INFO - 2016-10-13 16:00:16 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:16 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:16 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:16 --> Parser Class Initialized
INFO - 2016-10-13 16:00:16 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:16 --> Home MX_Controller Initialized
INFO - 2016-10-13 16:00:16 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:16 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 16:00:16 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 16:00:16 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 16:00:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 16:00:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:00:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 16:00:16 --> Final output sent to browser
DEBUG - 2016-10-13 16:00:16 --> Total execution time: 0.0359
INFO - 2016-10-13 16:00:41 --> Config Class Initialized
INFO - 2016-10-13 16:00:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:41 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:41 --> URI Class Initialized
INFO - 2016-10-13 16:00:41 --> Router Class Initialized
INFO - 2016-10-13 16:00:41 --> Output Class Initialized
INFO - 2016-10-13 16:00:41 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:41 --> Input Class Initialized
INFO - 2016-10-13 16:00:41 --> Language Class Initialized
INFO - 2016-10-13 16:00:41 --> Language Class Initialized
INFO - 2016-10-13 16:00:41 --> Config Class Initialized
INFO - 2016-10-13 16:00:41 --> Loader Class Initialized
INFO - 2016-10-13 16:00:41 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:41 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:41 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:41 --> Parser Class Initialized
INFO - 2016-10-13 16:00:41 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:41 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:41 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 16:00:41 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 16:00:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 16:00:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 16:00:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 16:00:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 16:00:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 16:00:41 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 16:00:41 --> Final output sent to browser
DEBUG - 2016-10-13 16:00:41 --> Total execution time: 0.0691
INFO - 2016-10-13 16:00:47 --> Config Class Initialized
INFO - 2016-10-13 16:00:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:47 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:47 --> URI Class Initialized
INFO - 2016-10-13 16:00:47 --> Router Class Initialized
INFO - 2016-10-13 16:00:47 --> Output Class Initialized
INFO - 2016-10-13 16:00:47 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:47 --> Input Class Initialized
INFO - 2016-10-13 16:00:47 --> Language Class Initialized
INFO - 2016-10-13 16:00:47 --> Language Class Initialized
INFO - 2016-10-13 16:00:47 --> Config Class Initialized
INFO - 2016-10-13 16:00:47 --> Loader Class Initialized
INFO - 2016-10-13 16:00:47 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:47 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:47 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:47 --> Parser Class Initialized
INFO - 2016-10-13 16:00:47 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:47 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 16:00:47 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
INFO - 2016-10-13 16:00:47 --> Config Class Initialized
INFO - 2016-10-13 16:00:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:47 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:47 --> URI Class Initialized
INFO - 2016-10-13 16:00:47 --> Router Class Initialized
INFO - 2016-10-13 16:00:47 --> Output Class Initialized
INFO - 2016-10-13 16:00:47 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:47 --> Input Class Initialized
INFO - 2016-10-13 16:00:47 --> Language Class Initialized
INFO - 2016-10-13 16:00:47 --> Language Class Initialized
INFO - 2016-10-13 16:00:47 --> Config Class Initialized
INFO - 2016-10-13 16:00:47 --> Loader Class Initialized
INFO - 2016-10-13 16:00:47 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:47 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:47 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:47 --> Parser Class Initialized
INFO - 2016-10-13 16:00:47 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:47 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 16:00:47 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 16:00:47 --> Final output sent to browser
DEBUG - 2016-10-13 16:00:47 --> Total execution time: 0.0425
INFO - 2016-10-13 16:00:47 --> Config Class Initialized
INFO - 2016-10-13 16:00:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:47 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:47 --> URI Class Initialized
INFO - 2016-10-13 16:00:47 --> Router Class Initialized
INFO - 2016-10-13 16:00:47 --> Output Class Initialized
INFO - 2016-10-13 16:00:47 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:47 --> Input Class Initialized
INFO - 2016-10-13 16:00:47 --> Language Class Initialized
ERROR - 2016-10-13 16:00:47 --> 404 Page Not Found: /index
INFO - 2016-10-13 16:00:47 --> Config Class Initialized
INFO - 2016-10-13 16:00:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:47 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:47 --> URI Class Initialized
INFO - 2016-10-13 16:00:47 --> Router Class Initialized
INFO - 2016-10-13 16:00:47 --> Output Class Initialized
INFO - 2016-10-13 16:00:47 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:47 --> Input Class Initialized
INFO - 2016-10-13 16:00:47 --> Language Class Initialized
INFO - 2016-10-13 16:00:47 --> Language Class Initialized
INFO - 2016-10-13 16:00:47 --> Config Class Initialized
INFO - 2016-10-13 16:00:47 --> Loader Class Initialized
INFO - 2016-10-13 16:00:47 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:47 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:47 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:47 --> Parser Class Initialized
INFO - 2016-10-13 16:00:47 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:47 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:47 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:47 --> Pagination Class Initialized
DEBUG - 2016-10-13 16:00:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 16:00:47 --> Final output sent to browser
DEBUG - 2016-10-13 16:00:47 --> Total execution time: 0.0474
INFO - 2016-10-13 16:00:50 --> Config Class Initialized
INFO - 2016-10-13 16:00:50 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:50 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:50 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:50 --> URI Class Initialized
INFO - 2016-10-13 16:00:50 --> Router Class Initialized
INFO - 2016-10-13 16:00:50 --> Output Class Initialized
INFO - 2016-10-13 16:00:50 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:50 --> Input Class Initialized
INFO - 2016-10-13 16:00:50 --> Language Class Initialized
INFO - 2016-10-13 16:00:50 --> Language Class Initialized
INFO - 2016-10-13 16:00:50 --> Config Class Initialized
INFO - 2016-10-13 16:00:50 --> Loader Class Initialized
INFO - 2016-10-13 16:00:50 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:50 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:50 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:50 --> Parser Class Initialized
INFO - 2016-10-13 16:00:50 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:50 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:50 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:50 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:50 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:50 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 16:00:50 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 16:00:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 16:00:50 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 16:00:50 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 16:00:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 16:00:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 16:00:50 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 16:00:50 --> Final output sent to browser
DEBUG - 2016-10-13 16:00:50 --> Total execution time: 0.0424
INFO - 2016-10-13 16:00:54 --> Config Class Initialized
INFO - 2016-10-13 16:00:54 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:54 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:54 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:54 --> URI Class Initialized
INFO - 2016-10-13 16:00:54 --> Router Class Initialized
INFO - 2016-10-13 16:00:54 --> Output Class Initialized
INFO - 2016-10-13 16:00:54 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:54 --> Input Class Initialized
INFO - 2016-10-13 16:00:54 --> Language Class Initialized
INFO - 2016-10-13 16:00:54 --> Language Class Initialized
INFO - 2016-10-13 16:00:54 --> Config Class Initialized
INFO - 2016-10-13 16:00:54 --> Loader Class Initialized
INFO - 2016-10-13 16:00:54 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:54 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:54 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:54 --> Parser Class Initialized
INFO - 2016-10-13 16:00:54 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:54 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 16:00:54 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
INFO - 2016-10-13 16:00:54 --> Config Class Initialized
INFO - 2016-10-13 16:00:54 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:54 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:54 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:54 --> URI Class Initialized
INFO - 2016-10-13 16:00:54 --> Router Class Initialized
INFO - 2016-10-13 16:00:54 --> Output Class Initialized
INFO - 2016-10-13 16:00:54 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:54 --> Input Class Initialized
INFO - 2016-10-13 16:00:54 --> Language Class Initialized
INFO - 2016-10-13 16:00:54 --> Language Class Initialized
INFO - 2016-10-13 16:00:54 --> Config Class Initialized
INFO - 2016-10-13 16:00:54 --> Loader Class Initialized
INFO - 2016-10-13 16:00:54 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:54 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:54 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:54 --> Parser Class Initialized
INFO - 2016-10-13 16:00:54 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:54 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 16:00:54 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 16:00:54 --> Final output sent to browser
DEBUG - 2016-10-13 16:00:54 --> Total execution time: 0.0434
INFO - 2016-10-13 16:00:54 --> Config Class Initialized
INFO - 2016-10-13 16:00:54 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:54 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:54 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:54 --> URI Class Initialized
INFO - 2016-10-13 16:00:54 --> Router Class Initialized
INFO - 2016-10-13 16:00:54 --> Output Class Initialized
INFO - 2016-10-13 16:00:54 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:54 --> Input Class Initialized
INFO - 2016-10-13 16:00:54 --> Language Class Initialized
ERROR - 2016-10-13 16:00:54 --> 404 Page Not Found: /index
INFO - 2016-10-13 16:00:54 --> Config Class Initialized
INFO - 2016-10-13 16:00:54 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:00:54 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:00:54 --> Utf8 Class Initialized
INFO - 2016-10-13 16:00:54 --> URI Class Initialized
INFO - 2016-10-13 16:00:54 --> Router Class Initialized
INFO - 2016-10-13 16:00:54 --> Output Class Initialized
INFO - 2016-10-13 16:00:54 --> Security Class Initialized
DEBUG - 2016-10-13 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:00:54 --> Input Class Initialized
INFO - 2016-10-13 16:00:54 --> Language Class Initialized
INFO - 2016-10-13 16:00:54 --> Language Class Initialized
INFO - 2016-10-13 16:00:54 --> Config Class Initialized
INFO - 2016-10-13 16:00:54 --> Loader Class Initialized
INFO - 2016-10-13 16:00:54 --> Helper loaded: common_helper
INFO - 2016-10-13 16:00:54 --> Helper loaded: url_helper
INFO - 2016-10-13 16:00:54 --> Database Driver Class Initialized
INFO - 2016-10-13 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:00:54 --> Parser Class Initialized
INFO - 2016-10-13 16:00:54 --> Controller Class Initialized
DEBUG - 2016-10-13 16:00:54 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:00:54 --> Model Class Initialized
DEBUG - 2016-10-13 16:00:54 --> Pagination Class Initialized
DEBUG - 2016-10-13 16:00:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 16:00:54 --> Final output sent to browser
DEBUG - 2016-10-13 16:00:54 --> Total execution time: 0.0371
INFO - 2016-10-13 16:01:02 --> Config Class Initialized
INFO - 2016-10-13 16:01:02 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:01:02 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:01:02 --> Utf8 Class Initialized
INFO - 2016-10-13 16:01:02 --> URI Class Initialized
INFO - 2016-10-13 16:01:02 --> Router Class Initialized
INFO - 2016-10-13 16:01:02 --> Output Class Initialized
INFO - 2016-10-13 16:01:02 --> Security Class Initialized
DEBUG - 2016-10-13 16:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:01:02 --> Input Class Initialized
INFO - 2016-10-13 16:01:02 --> Language Class Initialized
INFO - 2016-10-13 16:01:02 --> Language Class Initialized
INFO - 2016-10-13 16:01:02 --> Config Class Initialized
INFO - 2016-10-13 16:01:02 --> Loader Class Initialized
INFO - 2016-10-13 16:01:02 --> Helper loaded: common_helper
INFO - 2016-10-13 16:01:02 --> Helper loaded: url_helper
INFO - 2016-10-13 16:01:02 --> Database Driver Class Initialized
INFO - 2016-10-13 16:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:01:02 --> Parser Class Initialized
INFO - 2016-10-13 16:01:02 --> Controller Class Initialized
DEBUG - 2016-10-13 16:01:02 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:01:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:01:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:01:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:01:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:01:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:01:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:01:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:01:02 --> Final output sent to browser
DEBUG - 2016-10-13 16:01:02 --> Total execution time: 0.0478
INFO - 2016-10-13 16:01:02 --> Config Class Initialized
INFO - 2016-10-13 16:01:02 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:01:02 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:01:02 --> Utf8 Class Initialized
INFO - 2016-10-13 16:01:02 --> URI Class Initialized
INFO - 2016-10-13 16:01:02 --> Router Class Initialized
INFO - 2016-10-13 16:01:02 --> Output Class Initialized
INFO - 2016-10-13 16:01:02 --> Security Class Initialized
DEBUG - 2016-10-13 16:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:01:02 --> Input Class Initialized
INFO - 2016-10-13 16:01:02 --> Language Class Initialized
INFO - 2016-10-13 16:01:02 --> Language Class Initialized
INFO - 2016-10-13 16:01:02 --> Config Class Initialized
INFO - 2016-10-13 16:01:02 --> Loader Class Initialized
INFO - 2016-10-13 16:01:02 --> Helper loaded: common_helper
INFO - 2016-10-13 16:01:02 --> Helper loaded: url_helper
INFO - 2016-10-13 16:01:02 --> Database Driver Class Initialized
INFO - 2016-10-13 16:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:01:02 --> Parser Class Initialized
INFO - 2016-10-13 16:01:02 --> Controller Class Initialized
DEBUG - 2016-10-13 16:01:02 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:01:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:01:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:01:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:01:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:01:02 --> Model Class Initialized
INFO - 2016-10-13 16:02:03 --> Config Class Initialized
INFO - 2016-10-13 16:02:03 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:02:03 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:02:03 --> Utf8 Class Initialized
INFO - 2016-10-13 16:02:03 --> URI Class Initialized
INFO - 2016-10-13 16:02:03 --> Router Class Initialized
INFO - 2016-10-13 16:02:03 --> Output Class Initialized
INFO - 2016-10-13 16:02:03 --> Security Class Initialized
DEBUG - 2016-10-13 16:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:02:03 --> Input Class Initialized
INFO - 2016-10-13 16:02:04 --> Language Class Initialized
ERROR - 2016-10-13 16:02:04 --> 404 Page Not Found: /index
INFO - 2016-10-13 16:04:22 --> Config Class Initialized
INFO - 2016-10-13 16:04:22 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:04:22 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:04:22 --> Utf8 Class Initialized
INFO - 2016-10-13 16:04:22 --> URI Class Initialized
INFO - 2016-10-13 16:04:22 --> Router Class Initialized
INFO - 2016-10-13 16:04:22 --> Output Class Initialized
INFO - 2016-10-13 16:04:22 --> Security Class Initialized
DEBUG - 2016-10-13 16:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:04:22 --> Input Class Initialized
INFO - 2016-10-13 16:04:22 --> Language Class Initialized
INFO - 2016-10-13 16:04:22 --> Language Class Initialized
INFO - 2016-10-13 16:04:22 --> Config Class Initialized
INFO - 2016-10-13 16:04:22 --> Loader Class Initialized
INFO - 2016-10-13 16:04:22 --> Helper loaded: common_helper
INFO - 2016-10-13 16:04:22 --> Helper loaded: url_helper
INFO - 2016-10-13 16:04:22 --> Database Driver Class Initialized
INFO - 2016-10-13 16:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:04:22 --> Parser Class Initialized
INFO - 2016-10-13 16:04:22 --> Controller Class Initialized
DEBUG - 2016-10-13 16:04:22 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:04:22 --> Model Class Initialized
DEBUG - 2016-10-13 16:04:22 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:04:22 --> Model Class Initialized
DEBUG - 2016-10-13 16:04:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:04:22 --> Model Class Initialized
INFO - 2016-10-13 16:07:42 --> Config Class Initialized
INFO - 2016-10-13 16:07:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:07:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:07:42 --> Utf8 Class Initialized
INFO - 2016-10-13 16:07:42 --> URI Class Initialized
INFO - 2016-10-13 16:07:42 --> Router Class Initialized
INFO - 2016-10-13 16:07:42 --> Output Class Initialized
INFO - 2016-10-13 16:07:42 --> Security Class Initialized
DEBUG - 2016-10-13 16:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:07:42 --> Input Class Initialized
INFO - 2016-10-13 16:07:42 --> Language Class Initialized
INFO - 2016-10-13 16:07:42 --> Language Class Initialized
INFO - 2016-10-13 16:07:42 --> Config Class Initialized
INFO - 2016-10-13 16:07:42 --> Loader Class Initialized
INFO - 2016-10-13 16:07:42 --> Helper loaded: common_helper
INFO - 2016-10-13 16:07:42 --> Helper loaded: url_helper
INFO - 2016-10-13 16:07:42 --> Database Driver Class Initialized
INFO - 2016-10-13 16:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:07:42 --> Parser Class Initialized
INFO - 2016-10-13 16:07:42 --> Controller Class Initialized
DEBUG - 2016-10-13 16:07:42 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:07:42 --> Model Class Initialized
DEBUG - 2016-10-13 16:07:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:07:42 --> Model Class Initialized
DEBUG - 2016-10-13 16:07:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:07:42 --> Model Class Initialized
INFO - 2016-10-13 16:11:02 --> Config Class Initialized
INFO - 2016-10-13 16:11:02 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:11:02 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:11:02 --> Utf8 Class Initialized
INFO - 2016-10-13 16:11:02 --> URI Class Initialized
INFO - 2016-10-13 16:11:02 --> Router Class Initialized
INFO - 2016-10-13 16:11:02 --> Output Class Initialized
INFO - 2016-10-13 16:11:02 --> Security Class Initialized
DEBUG - 2016-10-13 16:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:11:02 --> Input Class Initialized
INFO - 2016-10-13 16:11:02 --> Language Class Initialized
INFO - 2016-10-13 16:11:02 --> Language Class Initialized
INFO - 2016-10-13 16:11:02 --> Config Class Initialized
INFO - 2016-10-13 16:11:02 --> Loader Class Initialized
INFO - 2016-10-13 16:11:02 --> Helper loaded: common_helper
INFO - 2016-10-13 16:11:02 --> Helper loaded: url_helper
INFO - 2016-10-13 16:11:02 --> Database Driver Class Initialized
INFO - 2016-10-13 16:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:11:02 --> Parser Class Initialized
INFO - 2016-10-13 16:11:02 --> Controller Class Initialized
DEBUG - 2016-10-13 16:11:02 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:11:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:11:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:11:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:11:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:11:02 --> Model Class Initialized
INFO - 2016-10-13 16:14:22 --> Config Class Initialized
INFO - 2016-10-13 16:14:22 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:14:22 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:14:22 --> Utf8 Class Initialized
INFO - 2016-10-13 16:14:22 --> URI Class Initialized
INFO - 2016-10-13 16:14:22 --> Router Class Initialized
INFO - 2016-10-13 16:14:22 --> Output Class Initialized
INFO - 2016-10-13 16:14:22 --> Security Class Initialized
DEBUG - 2016-10-13 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:14:22 --> Input Class Initialized
INFO - 2016-10-13 16:14:22 --> Language Class Initialized
INFO - 2016-10-13 16:14:22 --> Language Class Initialized
INFO - 2016-10-13 16:14:22 --> Config Class Initialized
INFO - 2016-10-13 16:14:22 --> Loader Class Initialized
INFO - 2016-10-13 16:14:22 --> Helper loaded: common_helper
INFO - 2016-10-13 16:14:22 --> Helper loaded: url_helper
INFO - 2016-10-13 16:14:22 --> Database Driver Class Initialized
INFO - 2016-10-13 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:14:22 --> Parser Class Initialized
INFO - 2016-10-13 16:14:22 --> Controller Class Initialized
DEBUG - 2016-10-13 16:14:22 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:14:22 --> Model Class Initialized
DEBUG - 2016-10-13 16:14:22 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:14:22 --> Model Class Initialized
DEBUG - 2016-10-13 16:14:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:14:22 --> Model Class Initialized
INFO - 2016-10-13 16:17:42 --> Config Class Initialized
INFO - 2016-10-13 16:17:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:17:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:17:42 --> Utf8 Class Initialized
INFO - 2016-10-13 16:17:42 --> URI Class Initialized
INFO - 2016-10-13 16:17:42 --> Router Class Initialized
INFO - 2016-10-13 16:17:42 --> Output Class Initialized
INFO - 2016-10-13 16:17:42 --> Security Class Initialized
DEBUG - 2016-10-13 16:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:17:42 --> Input Class Initialized
INFO - 2016-10-13 16:17:42 --> Language Class Initialized
INFO - 2016-10-13 16:17:42 --> Language Class Initialized
INFO - 2016-10-13 16:17:42 --> Config Class Initialized
INFO - 2016-10-13 16:17:42 --> Loader Class Initialized
INFO - 2016-10-13 16:17:42 --> Helper loaded: common_helper
INFO - 2016-10-13 16:17:42 --> Helper loaded: url_helper
INFO - 2016-10-13 16:17:42 --> Database Driver Class Initialized
INFO - 2016-10-13 16:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:17:42 --> Parser Class Initialized
INFO - 2016-10-13 16:17:42 --> Controller Class Initialized
DEBUG - 2016-10-13 16:17:42 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:17:42 --> Model Class Initialized
DEBUG - 2016-10-13 16:17:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:17:42 --> Model Class Initialized
DEBUG - 2016-10-13 16:17:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:17:42 --> Model Class Initialized
INFO - 2016-10-13 16:21:02 --> Config Class Initialized
INFO - 2016-10-13 16:21:02 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:21:02 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:21:02 --> Utf8 Class Initialized
INFO - 2016-10-13 16:21:02 --> URI Class Initialized
INFO - 2016-10-13 16:21:02 --> Router Class Initialized
INFO - 2016-10-13 16:21:02 --> Output Class Initialized
INFO - 2016-10-13 16:21:02 --> Security Class Initialized
DEBUG - 2016-10-13 16:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:21:02 --> Input Class Initialized
INFO - 2016-10-13 16:21:02 --> Language Class Initialized
INFO - 2016-10-13 16:21:02 --> Language Class Initialized
INFO - 2016-10-13 16:21:02 --> Config Class Initialized
INFO - 2016-10-13 16:21:02 --> Loader Class Initialized
INFO - 2016-10-13 16:21:02 --> Helper loaded: common_helper
INFO - 2016-10-13 16:21:02 --> Helper loaded: url_helper
INFO - 2016-10-13 16:21:02 --> Database Driver Class Initialized
INFO - 2016-10-13 16:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:21:02 --> Parser Class Initialized
INFO - 2016-10-13 16:21:02 --> Controller Class Initialized
DEBUG - 2016-10-13 16:21:02 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:21:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:21:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:21:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:21:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:21:02 --> Model Class Initialized
INFO - 2016-10-13 16:21:46 --> Config Class Initialized
INFO - 2016-10-13 16:21:46 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:21:46 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:21:46 --> Utf8 Class Initialized
INFO - 2016-10-13 16:21:46 --> URI Class Initialized
INFO - 2016-10-13 16:21:46 --> Router Class Initialized
INFO - 2016-10-13 16:21:46 --> Output Class Initialized
INFO - 2016-10-13 16:21:46 --> Security Class Initialized
DEBUG - 2016-10-13 16:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:21:46 --> Input Class Initialized
INFO - 2016-10-13 16:21:46 --> Language Class Initialized
INFO - 2016-10-13 16:21:46 --> Language Class Initialized
INFO - 2016-10-13 16:21:46 --> Config Class Initialized
INFO - 2016-10-13 16:21:46 --> Loader Class Initialized
INFO - 2016-10-13 16:21:46 --> Helper loaded: common_helper
INFO - 2016-10-13 16:21:46 --> Helper loaded: url_helper
INFO - 2016-10-13 16:21:46 --> Database Driver Class Initialized
INFO - 2016-10-13 16:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:21:46 --> Parser Class Initialized
INFO - 2016-10-13 16:21:46 --> Controller Class Initialized
DEBUG - 2016-10-13 16:21:46 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:21:46 --> Model Class Initialized
DEBUG - 2016-10-13 16:21:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:21:46 --> Model Class Initialized
DEBUG - 2016-10-13 16:21:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:21:46 --> Model Class Initialized
ERROR - 2016-10-13 16:21:46 --> Severity: Notice --> Undefined variable: sid /home/dolongpk/public_html/application/modules/servers/controllers/Servers.php 271
ERROR - 2016-10-13 16:21:46 --> Severity: Notice --> Undefined variable: sid /home/dolongpk/public_html/application/modules/servers/controllers/Servers.php 273
DEBUG - 2016-10-13 16:21:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:21:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:21:46 --> Final output sent to browser
DEBUG - 2016-10-13 16:21:46 --> Total execution time: 0.0480
INFO - 2016-10-13 16:21:46 --> Config Class Initialized
INFO - 2016-10-13 16:21:46 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:21:46 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:21:46 --> Utf8 Class Initialized
INFO - 2016-10-13 16:21:46 --> URI Class Initialized
INFO - 2016-10-13 16:21:46 --> Router Class Initialized
INFO - 2016-10-13 16:21:46 --> Output Class Initialized
INFO - 2016-10-13 16:21:46 --> Security Class Initialized
DEBUG - 2016-10-13 16:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:21:46 --> Input Class Initialized
INFO - 2016-10-13 16:21:46 --> Language Class Initialized
INFO - 2016-10-13 16:21:46 --> Language Class Initialized
INFO - 2016-10-13 16:21:46 --> Config Class Initialized
INFO - 2016-10-13 16:21:46 --> Loader Class Initialized
INFO - 2016-10-13 16:21:46 --> Helper loaded: common_helper
INFO - 2016-10-13 16:21:46 --> Helper loaded: url_helper
INFO - 2016-10-13 16:21:46 --> Database Driver Class Initialized
INFO - 2016-10-13 16:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:21:46 --> Parser Class Initialized
INFO - 2016-10-13 16:21:46 --> Controller Class Initialized
DEBUG - 2016-10-13 16:21:46 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:21:46 --> Model Class Initialized
DEBUG - 2016-10-13 16:21:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:21:46 --> Model Class Initialized
DEBUG - 2016-10-13 16:21:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:21:46 --> Model Class Initialized
INFO - 2016-10-13 16:22:24 --> Config Class Initialized
INFO - 2016-10-13 16:22:24 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:22:24 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:22:24 --> Utf8 Class Initialized
INFO - 2016-10-13 16:22:24 --> URI Class Initialized
INFO - 2016-10-13 16:22:24 --> Router Class Initialized
INFO - 2016-10-13 16:22:24 --> Output Class Initialized
INFO - 2016-10-13 16:22:24 --> Security Class Initialized
DEBUG - 2016-10-13 16:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:22:24 --> Input Class Initialized
INFO - 2016-10-13 16:22:24 --> Language Class Initialized
INFO - 2016-10-13 16:22:24 --> Language Class Initialized
INFO - 2016-10-13 16:22:24 --> Config Class Initialized
INFO - 2016-10-13 16:22:24 --> Loader Class Initialized
INFO - 2016-10-13 16:22:24 --> Helper loaded: common_helper
INFO - 2016-10-13 16:22:24 --> Helper loaded: url_helper
INFO - 2016-10-13 16:22:24 --> Database Driver Class Initialized
INFO - 2016-10-13 16:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:22:24 --> Parser Class Initialized
INFO - 2016-10-13 16:22:24 --> Controller Class Initialized
DEBUG - 2016-10-13 16:22:24 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:22:24 --> Model Class Initialized
DEBUG - 2016-10-13 16:22:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:22:24 --> Model Class Initialized
DEBUG - 2016-10-13 16:22:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:22:24 --> Model Class Initialized
DEBUG - 2016-10-13 16:22:24 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:22:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:22:24 --> Final output sent to browser
DEBUG - 2016-10-13 16:22:24 --> Total execution time: 0.0472
INFO - 2016-10-13 16:22:24 --> Config Class Initialized
INFO - 2016-10-13 16:22:24 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:22:24 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:22:24 --> Utf8 Class Initialized
INFO - 2016-10-13 16:22:24 --> URI Class Initialized
INFO - 2016-10-13 16:22:24 --> Router Class Initialized
INFO - 2016-10-13 16:22:24 --> Output Class Initialized
INFO - 2016-10-13 16:22:24 --> Security Class Initialized
DEBUG - 2016-10-13 16:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:22:24 --> Input Class Initialized
INFO - 2016-10-13 16:22:24 --> Language Class Initialized
INFO - 2016-10-13 16:22:24 --> Language Class Initialized
INFO - 2016-10-13 16:22:24 --> Config Class Initialized
INFO - 2016-10-13 16:22:24 --> Loader Class Initialized
INFO - 2016-10-13 16:22:24 --> Helper loaded: common_helper
INFO - 2016-10-13 16:22:24 --> Helper loaded: url_helper
INFO - 2016-10-13 16:22:24 --> Database Driver Class Initialized
INFO - 2016-10-13 16:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:22:24 --> Parser Class Initialized
INFO - 2016-10-13 16:22:24 --> Controller Class Initialized
DEBUG - 2016-10-13 16:22:24 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:22:24 --> Model Class Initialized
DEBUG - 2016-10-13 16:22:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:22:24 --> Model Class Initialized
DEBUG - 2016-10-13 16:22:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:22:24 --> Model Class Initialized
INFO - 2016-10-13 16:23:52 --> Config Class Initialized
INFO - 2016-10-13 16:23:52 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:23:52 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:23:52 --> Utf8 Class Initialized
INFO - 2016-10-13 16:23:52 --> URI Class Initialized
INFO - 2016-10-13 16:23:52 --> Router Class Initialized
INFO - 2016-10-13 16:23:52 --> Output Class Initialized
INFO - 2016-10-13 16:23:52 --> Security Class Initialized
DEBUG - 2016-10-13 16:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:23:52 --> Input Class Initialized
INFO - 2016-10-13 16:23:52 --> Language Class Initialized
INFO - 2016-10-13 16:23:52 --> Language Class Initialized
INFO - 2016-10-13 16:23:52 --> Config Class Initialized
INFO - 2016-10-13 16:23:52 --> Loader Class Initialized
INFO - 2016-10-13 16:23:52 --> Helper loaded: common_helper
INFO - 2016-10-13 16:23:52 --> Helper loaded: url_helper
INFO - 2016-10-13 16:23:52 --> Database Driver Class Initialized
INFO - 2016-10-13 16:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:23:52 --> Parser Class Initialized
INFO - 2016-10-13 16:23:52 --> Controller Class Initialized
DEBUG - 2016-10-13 16:23:52 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:23:52 --> Model Class Initialized
DEBUG - 2016-10-13 16:23:52 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:23:52 --> Model Class Initialized
DEBUG - 2016-10-13 16:23:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:23:52 --> Model Class Initialized
DEBUG - 2016-10-13 16:23:52 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:23:52 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:23:52 --> Final output sent to browser
DEBUG - 2016-10-13 16:23:52 --> Total execution time: 0.0462
INFO - 2016-10-13 16:23:53 --> Config Class Initialized
INFO - 2016-10-13 16:23:53 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:23:53 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:23:53 --> Utf8 Class Initialized
INFO - 2016-10-13 16:23:53 --> URI Class Initialized
INFO - 2016-10-13 16:23:53 --> Router Class Initialized
INFO - 2016-10-13 16:23:53 --> Output Class Initialized
INFO - 2016-10-13 16:23:53 --> Security Class Initialized
DEBUG - 2016-10-13 16:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:23:53 --> Input Class Initialized
INFO - 2016-10-13 16:23:53 --> Language Class Initialized
INFO - 2016-10-13 16:23:53 --> Language Class Initialized
INFO - 2016-10-13 16:23:53 --> Config Class Initialized
INFO - 2016-10-13 16:23:53 --> Loader Class Initialized
INFO - 2016-10-13 16:23:53 --> Helper loaded: common_helper
INFO - 2016-10-13 16:23:53 --> Helper loaded: url_helper
INFO - 2016-10-13 16:23:53 --> Database Driver Class Initialized
INFO - 2016-10-13 16:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:23:53 --> Parser Class Initialized
INFO - 2016-10-13 16:23:53 --> Controller Class Initialized
DEBUG - 2016-10-13 16:23:53 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:23:53 --> Model Class Initialized
DEBUG - 2016-10-13 16:23:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:23:53 --> Model Class Initialized
DEBUG - 2016-10-13 16:23:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:23:53 --> Model Class Initialized
INFO - 2016-10-13 16:27:13 --> Config Class Initialized
INFO - 2016-10-13 16:27:13 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:27:13 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:27:13 --> Utf8 Class Initialized
INFO - 2016-10-13 16:27:13 --> URI Class Initialized
INFO - 2016-10-13 16:27:13 --> Router Class Initialized
INFO - 2016-10-13 16:27:13 --> Output Class Initialized
INFO - 2016-10-13 16:27:13 --> Security Class Initialized
DEBUG - 2016-10-13 16:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:27:13 --> Input Class Initialized
INFO - 2016-10-13 16:27:13 --> Language Class Initialized
INFO - 2016-10-13 16:27:13 --> Language Class Initialized
INFO - 2016-10-13 16:27:13 --> Config Class Initialized
INFO - 2016-10-13 16:27:13 --> Loader Class Initialized
INFO - 2016-10-13 16:27:13 --> Helper loaded: common_helper
INFO - 2016-10-13 16:27:13 --> Helper loaded: url_helper
INFO - 2016-10-13 16:27:13 --> Database Driver Class Initialized
INFO - 2016-10-13 16:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:27:13 --> Parser Class Initialized
INFO - 2016-10-13 16:27:13 --> Controller Class Initialized
DEBUG - 2016-10-13 16:27:13 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:27:13 --> Model Class Initialized
DEBUG - 2016-10-13 16:27:13 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:27:13 --> Model Class Initialized
DEBUG - 2016-10-13 16:27:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:27:13 --> Model Class Initialized
INFO - 2016-10-13 16:29:48 --> Config Class Initialized
INFO - 2016-10-13 16:29:48 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:29:48 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:29:48 --> Utf8 Class Initialized
INFO - 2016-10-13 16:29:48 --> URI Class Initialized
INFO - 2016-10-13 16:29:48 --> Router Class Initialized
INFO - 2016-10-13 16:29:48 --> Output Class Initialized
INFO - 2016-10-13 16:29:48 --> Security Class Initialized
DEBUG - 2016-10-13 16:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:29:48 --> Input Class Initialized
INFO - 2016-10-13 16:29:48 --> Language Class Initialized
INFO - 2016-10-13 16:29:48 --> Language Class Initialized
INFO - 2016-10-13 16:29:48 --> Config Class Initialized
INFO - 2016-10-13 16:29:48 --> Loader Class Initialized
INFO - 2016-10-13 16:29:48 --> Helper loaded: common_helper
INFO - 2016-10-13 16:29:48 --> Helper loaded: url_helper
INFO - 2016-10-13 16:29:48 --> Database Driver Class Initialized
INFO - 2016-10-13 16:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:29:48 --> Parser Class Initialized
INFO - 2016-10-13 16:29:48 --> Controller Class Initialized
DEBUG - 2016-10-13 16:29:48 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:29:48 --> Model Class Initialized
DEBUG - 2016-10-13 16:29:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:29:48 --> Model Class Initialized
DEBUG - 2016-10-13 16:29:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:29:48 --> Model Class Initialized
DEBUG - 2016-10-13 16:29:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:29:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:29:48 --> Final output sent to browser
DEBUG - 2016-10-13 16:29:48 --> Total execution time: 0.0467
INFO - 2016-10-13 16:29:49 --> Config Class Initialized
INFO - 2016-10-13 16:29:49 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:29:49 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:29:49 --> Utf8 Class Initialized
INFO - 2016-10-13 16:29:49 --> URI Class Initialized
INFO - 2016-10-13 16:29:49 --> Router Class Initialized
INFO - 2016-10-13 16:29:49 --> Output Class Initialized
INFO - 2016-10-13 16:29:49 --> Security Class Initialized
DEBUG - 2016-10-13 16:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:29:49 --> Input Class Initialized
INFO - 2016-10-13 16:29:49 --> Language Class Initialized
INFO - 2016-10-13 16:29:49 --> Language Class Initialized
INFO - 2016-10-13 16:29:49 --> Config Class Initialized
INFO - 2016-10-13 16:29:49 --> Loader Class Initialized
INFO - 2016-10-13 16:29:49 --> Helper loaded: common_helper
INFO - 2016-10-13 16:29:49 --> Helper loaded: url_helper
INFO - 2016-10-13 16:29:49 --> Database Driver Class Initialized
INFO - 2016-10-13 16:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:29:49 --> Parser Class Initialized
INFO - 2016-10-13 16:29:49 --> Controller Class Initialized
DEBUG - 2016-10-13 16:29:49 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:29:49 --> Model Class Initialized
DEBUG - 2016-10-13 16:29:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:29:49 --> Model Class Initialized
DEBUG - 2016-10-13 16:29:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:29:49 --> Model Class Initialized
INFO - 2016-10-13 16:33:09 --> Config Class Initialized
INFO - 2016-10-13 16:33:09 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:33:09 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:33:09 --> Utf8 Class Initialized
INFO - 2016-10-13 16:33:09 --> URI Class Initialized
INFO - 2016-10-13 16:33:09 --> Router Class Initialized
INFO - 2016-10-13 16:33:09 --> Output Class Initialized
INFO - 2016-10-13 16:33:09 --> Security Class Initialized
DEBUG - 2016-10-13 16:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:33:09 --> Input Class Initialized
INFO - 2016-10-13 16:33:09 --> Language Class Initialized
INFO - 2016-10-13 16:33:09 --> Language Class Initialized
INFO - 2016-10-13 16:33:09 --> Config Class Initialized
INFO - 2016-10-13 16:33:09 --> Loader Class Initialized
INFO - 2016-10-13 16:33:09 --> Helper loaded: common_helper
INFO - 2016-10-13 16:33:09 --> Helper loaded: url_helper
INFO - 2016-10-13 16:33:09 --> Database Driver Class Initialized
INFO - 2016-10-13 16:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:33:09 --> Parser Class Initialized
INFO - 2016-10-13 16:33:09 --> Controller Class Initialized
DEBUG - 2016-10-13 16:33:09 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:33:09 --> Model Class Initialized
DEBUG - 2016-10-13 16:33:09 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:33:09 --> Model Class Initialized
DEBUG - 2016-10-13 16:33:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:33:09 --> Model Class Initialized
INFO - 2016-10-13 16:34:01 --> Config Class Initialized
INFO - 2016-10-13 16:34:01 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:34:01 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:34:01 --> Utf8 Class Initialized
INFO - 2016-10-13 16:34:01 --> URI Class Initialized
INFO - 2016-10-13 16:34:01 --> Router Class Initialized
INFO - 2016-10-13 16:34:01 --> Output Class Initialized
INFO - 2016-10-13 16:34:01 --> Security Class Initialized
DEBUG - 2016-10-13 16:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:34:01 --> Input Class Initialized
INFO - 2016-10-13 16:34:01 --> Language Class Initialized
INFO - 2016-10-13 16:34:01 --> Language Class Initialized
INFO - 2016-10-13 16:34:01 --> Config Class Initialized
INFO - 2016-10-13 16:34:01 --> Loader Class Initialized
INFO - 2016-10-13 16:34:01 --> Helper loaded: common_helper
INFO - 2016-10-13 16:34:01 --> Helper loaded: url_helper
INFO - 2016-10-13 16:34:01 --> Database Driver Class Initialized
INFO - 2016-10-13 16:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:34:01 --> Parser Class Initialized
INFO - 2016-10-13 16:34:01 --> Controller Class Initialized
DEBUG - 2016-10-13 16:34:01 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:34:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:34:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:34:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:34:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:34:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:34:01 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:34:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:34:01 --> Final output sent to browser
DEBUG - 2016-10-13 16:34:01 --> Total execution time: 0.0726
INFO - 2016-10-13 16:34:01 --> Config Class Initialized
INFO - 2016-10-13 16:34:01 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:34:01 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:34:01 --> Utf8 Class Initialized
INFO - 2016-10-13 16:34:01 --> URI Class Initialized
INFO - 2016-10-13 16:34:01 --> Router Class Initialized
INFO - 2016-10-13 16:34:01 --> Output Class Initialized
INFO - 2016-10-13 16:34:01 --> Security Class Initialized
DEBUG - 2016-10-13 16:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:34:01 --> Input Class Initialized
INFO - 2016-10-13 16:34:01 --> Language Class Initialized
INFO - 2016-10-13 16:34:01 --> Language Class Initialized
INFO - 2016-10-13 16:34:01 --> Config Class Initialized
INFO - 2016-10-13 16:34:01 --> Loader Class Initialized
INFO - 2016-10-13 16:34:01 --> Helper loaded: common_helper
INFO - 2016-10-13 16:34:01 --> Helper loaded: url_helper
INFO - 2016-10-13 16:34:01 --> Database Driver Class Initialized
INFO - 2016-10-13 16:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:34:01 --> Parser Class Initialized
INFO - 2016-10-13 16:34:01 --> Controller Class Initialized
DEBUG - 2016-10-13 16:34:01 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:34:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:34:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:34:01 --> Model Class Initialized
DEBUG - 2016-10-13 16:34:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:34:01 --> Model Class Initialized
INFO - 2016-10-13 16:37:22 --> Config Class Initialized
INFO - 2016-10-13 16:37:22 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:37:22 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:37:22 --> Utf8 Class Initialized
INFO - 2016-10-13 16:37:22 --> URI Class Initialized
INFO - 2016-10-13 16:37:22 --> Router Class Initialized
INFO - 2016-10-13 16:37:22 --> Output Class Initialized
INFO - 2016-10-13 16:37:22 --> Security Class Initialized
DEBUG - 2016-10-13 16:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:37:22 --> Input Class Initialized
INFO - 2016-10-13 16:37:22 --> Language Class Initialized
INFO - 2016-10-13 16:37:22 --> Language Class Initialized
INFO - 2016-10-13 16:37:22 --> Config Class Initialized
INFO - 2016-10-13 16:37:22 --> Loader Class Initialized
INFO - 2016-10-13 16:37:22 --> Helper loaded: common_helper
INFO - 2016-10-13 16:37:22 --> Helper loaded: url_helper
INFO - 2016-10-13 16:37:22 --> Database Driver Class Initialized
INFO - 2016-10-13 16:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:37:22 --> Parser Class Initialized
INFO - 2016-10-13 16:37:22 --> Controller Class Initialized
DEBUG - 2016-10-13 16:37:22 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:37:22 --> Model Class Initialized
DEBUG - 2016-10-13 16:37:22 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:37:22 --> Model Class Initialized
DEBUG - 2016-10-13 16:37:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:37:22 --> Model Class Initialized
INFO - 2016-10-13 16:40:42 --> Config Class Initialized
INFO - 2016-10-13 16:40:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:40:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:40:42 --> Utf8 Class Initialized
INFO - 2016-10-13 16:40:42 --> URI Class Initialized
INFO - 2016-10-13 16:40:42 --> Router Class Initialized
INFO - 2016-10-13 16:40:42 --> Output Class Initialized
INFO - 2016-10-13 16:40:42 --> Security Class Initialized
DEBUG - 2016-10-13 16:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:40:42 --> Input Class Initialized
INFO - 2016-10-13 16:40:42 --> Language Class Initialized
INFO - 2016-10-13 16:40:42 --> Language Class Initialized
INFO - 2016-10-13 16:40:42 --> Config Class Initialized
INFO - 2016-10-13 16:40:42 --> Loader Class Initialized
INFO - 2016-10-13 16:40:42 --> Helper loaded: common_helper
INFO - 2016-10-13 16:40:42 --> Helper loaded: url_helper
INFO - 2016-10-13 16:40:42 --> Database Driver Class Initialized
INFO - 2016-10-13 16:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:40:42 --> Parser Class Initialized
INFO - 2016-10-13 16:40:42 --> Controller Class Initialized
DEBUG - 2016-10-13 16:40:42 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:40:42 --> Model Class Initialized
DEBUG - 2016-10-13 16:40:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:40:42 --> Model Class Initialized
DEBUG - 2016-10-13 16:40:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:40:42 --> Model Class Initialized
INFO - 2016-10-13 16:44:02 --> Config Class Initialized
INFO - 2016-10-13 16:44:02 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:44:02 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:44:02 --> Utf8 Class Initialized
INFO - 2016-10-13 16:44:02 --> URI Class Initialized
INFO - 2016-10-13 16:44:02 --> Router Class Initialized
INFO - 2016-10-13 16:44:02 --> Output Class Initialized
INFO - 2016-10-13 16:44:02 --> Security Class Initialized
DEBUG - 2016-10-13 16:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:44:02 --> Input Class Initialized
INFO - 2016-10-13 16:44:02 --> Language Class Initialized
INFO - 2016-10-13 16:44:02 --> Language Class Initialized
INFO - 2016-10-13 16:44:02 --> Config Class Initialized
INFO - 2016-10-13 16:44:02 --> Loader Class Initialized
INFO - 2016-10-13 16:44:02 --> Helper loaded: common_helper
INFO - 2016-10-13 16:44:02 --> Helper loaded: url_helper
INFO - 2016-10-13 16:44:02 --> Database Driver Class Initialized
INFO - 2016-10-13 16:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:44:02 --> Parser Class Initialized
INFO - 2016-10-13 16:44:02 --> Controller Class Initialized
DEBUG - 2016-10-13 16:44:02 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:44:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:44:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:44:02 --> Model Class Initialized
DEBUG - 2016-10-13 16:44:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:44:02 --> Model Class Initialized
INFO - 2016-10-13 16:44:07 --> Config Class Initialized
INFO - 2016-10-13 16:44:07 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:44:07 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:44:07 --> Utf8 Class Initialized
INFO - 2016-10-13 16:44:07 --> URI Class Initialized
INFO - 2016-10-13 16:44:07 --> Router Class Initialized
INFO - 2016-10-13 16:44:07 --> Output Class Initialized
INFO - 2016-10-13 16:44:07 --> Security Class Initialized
DEBUG - 2016-10-13 16:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:44:07 --> Input Class Initialized
INFO - 2016-10-13 16:44:07 --> Language Class Initialized
INFO - 2016-10-13 16:44:07 --> Language Class Initialized
INFO - 2016-10-13 16:44:07 --> Config Class Initialized
INFO - 2016-10-13 16:44:07 --> Loader Class Initialized
INFO - 2016-10-13 16:44:07 --> Helper loaded: common_helper
INFO - 2016-10-13 16:44:07 --> Helper loaded: url_helper
INFO - 2016-10-13 16:44:07 --> Database Driver Class Initialized
INFO - 2016-10-13 16:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:44:07 --> Parser Class Initialized
INFO - 2016-10-13 16:44:07 --> Controller Class Initialized
DEBUG - 2016-10-13 16:44:07 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:44:07 --> Model Class Initialized
DEBUG - 2016-10-13 16:44:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:44:07 --> Model Class Initialized
DEBUG - 2016-10-13 16:44:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:44:07 --> Model Class Initialized
DEBUG - 2016-10-13 16:44:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:44:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:44:07 --> Final output sent to browser
DEBUG - 2016-10-13 16:44:07 --> Total execution time: 0.0475
INFO - 2016-10-13 16:44:07 --> Config Class Initialized
INFO - 2016-10-13 16:44:07 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:44:07 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:44:07 --> Utf8 Class Initialized
INFO - 2016-10-13 16:44:07 --> URI Class Initialized
INFO - 2016-10-13 16:44:07 --> Router Class Initialized
INFO - 2016-10-13 16:44:07 --> Output Class Initialized
INFO - 2016-10-13 16:44:07 --> Security Class Initialized
DEBUG - 2016-10-13 16:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:44:07 --> Input Class Initialized
INFO - 2016-10-13 16:44:07 --> Language Class Initialized
INFO - 2016-10-13 16:44:07 --> Language Class Initialized
INFO - 2016-10-13 16:44:07 --> Config Class Initialized
INFO - 2016-10-13 16:44:07 --> Loader Class Initialized
INFO - 2016-10-13 16:44:07 --> Helper loaded: common_helper
INFO - 2016-10-13 16:44:07 --> Helper loaded: url_helper
INFO - 2016-10-13 16:44:07 --> Database Driver Class Initialized
INFO - 2016-10-13 16:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:44:07 --> Parser Class Initialized
INFO - 2016-10-13 16:44:07 --> Controller Class Initialized
DEBUG - 2016-10-13 16:44:07 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:44:07 --> Model Class Initialized
DEBUG - 2016-10-13 16:44:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:44:07 --> Model Class Initialized
DEBUG - 2016-10-13 16:44:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:44:07 --> Model Class Initialized
INFO - 2016-10-13 16:46:16 --> Config Class Initialized
INFO - 2016-10-13 16:46:16 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:46:16 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:46:16 --> Utf8 Class Initialized
INFO - 2016-10-13 16:46:16 --> URI Class Initialized
INFO - 2016-10-13 16:46:16 --> Router Class Initialized
INFO - 2016-10-13 16:46:16 --> Output Class Initialized
INFO - 2016-10-13 16:46:16 --> Security Class Initialized
DEBUG - 2016-10-13 16:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:46:16 --> Input Class Initialized
INFO - 2016-10-13 16:46:16 --> Language Class Initialized
INFO - 2016-10-13 16:46:16 --> Language Class Initialized
INFO - 2016-10-13 16:46:16 --> Config Class Initialized
INFO - 2016-10-13 16:46:16 --> Loader Class Initialized
INFO - 2016-10-13 16:46:16 --> Helper loaded: common_helper
INFO - 2016-10-13 16:46:16 --> Helper loaded: url_helper
INFO - 2016-10-13 16:46:16 --> Database Driver Class Initialized
INFO - 2016-10-13 16:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:46:16 --> Parser Class Initialized
INFO - 2016-10-13 16:46:16 --> Controller Class Initialized
DEBUG - 2016-10-13 16:46:16 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:46:16 --> Model Class Initialized
DEBUG - 2016-10-13 16:46:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:46:16 --> Model Class Initialized
DEBUG - 2016-10-13 16:46:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:46:16 --> Model Class Initialized
DEBUG - 2016-10-13 16:46:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:46:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:46:16 --> Final output sent to browser
DEBUG - 2016-10-13 16:46:16 --> Total execution time: 0.0717
INFO - 2016-10-13 16:46:17 --> Config Class Initialized
INFO - 2016-10-13 16:46:17 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:46:17 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:46:17 --> Utf8 Class Initialized
INFO - 2016-10-13 16:46:17 --> URI Class Initialized
INFO - 2016-10-13 16:46:17 --> Router Class Initialized
INFO - 2016-10-13 16:46:17 --> Output Class Initialized
INFO - 2016-10-13 16:46:17 --> Security Class Initialized
DEBUG - 2016-10-13 16:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:46:17 --> Input Class Initialized
INFO - 2016-10-13 16:46:17 --> Language Class Initialized
INFO - 2016-10-13 16:46:17 --> Language Class Initialized
INFO - 2016-10-13 16:46:17 --> Config Class Initialized
INFO - 2016-10-13 16:46:17 --> Loader Class Initialized
INFO - 2016-10-13 16:46:17 --> Helper loaded: common_helper
INFO - 2016-10-13 16:46:17 --> Helper loaded: url_helper
INFO - 2016-10-13 16:46:17 --> Database Driver Class Initialized
INFO - 2016-10-13 16:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:46:17 --> Parser Class Initialized
INFO - 2016-10-13 16:46:17 --> Controller Class Initialized
DEBUG - 2016-10-13 16:46:17 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:46:17 --> Model Class Initialized
DEBUG - 2016-10-13 16:46:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:46:17 --> Model Class Initialized
DEBUG - 2016-10-13 16:46:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:46:17 --> Model Class Initialized
INFO - 2016-10-13 16:48:41 --> Config Class Initialized
INFO - 2016-10-13 16:48:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:48:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:48:41 --> Utf8 Class Initialized
INFO - 2016-10-13 16:48:41 --> URI Class Initialized
INFO - 2016-10-13 16:48:41 --> Router Class Initialized
INFO - 2016-10-13 16:48:41 --> Output Class Initialized
INFO - 2016-10-13 16:48:41 --> Security Class Initialized
DEBUG - 2016-10-13 16:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:48:41 --> Input Class Initialized
INFO - 2016-10-13 16:48:41 --> Language Class Initialized
INFO - 2016-10-13 16:48:41 --> Language Class Initialized
INFO - 2016-10-13 16:48:41 --> Config Class Initialized
INFO - 2016-10-13 16:48:41 --> Loader Class Initialized
INFO - 2016-10-13 16:48:41 --> Helper loaded: common_helper
INFO - 2016-10-13 16:48:41 --> Helper loaded: url_helper
INFO - 2016-10-13 16:48:41 --> Database Driver Class Initialized
INFO - 2016-10-13 16:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:48:41 --> Parser Class Initialized
INFO - 2016-10-13 16:48:41 --> Controller Class Initialized
DEBUG - 2016-10-13 16:48:41 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:48:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:48:41 --> Final output sent to browser
DEBUG - 2016-10-13 16:48:41 --> Total execution time: 0.0700
INFO - 2016-10-13 16:48:41 --> Config Class Initialized
INFO - 2016-10-13 16:48:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:48:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:48:41 --> Utf8 Class Initialized
INFO - 2016-10-13 16:48:41 --> URI Class Initialized
INFO - 2016-10-13 16:48:41 --> Router Class Initialized
INFO - 2016-10-13 16:48:41 --> Output Class Initialized
INFO - 2016-10-13 16:48:41 --> Security Class Initialized
DEBUG - 2016-10-13 16:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:48:41 --> Input Class Initialized
INFO - 2016-10-13 16:48:41 --> Language Class Initialized
INFO - 2016-10-13 16:48:41 --> Language Class Initialized
INFO - 2016-10-13 16:48:41 --> Config Class Initialized
INFO - 2016-10-13 16:48:41 --> Loader Class Initialized
INFO - 2016-10-13 16:48:41 --> Helper loaded: common_helper
INFO - 2016-10-13 16:48:41 --> Helper loaded: url_helper
INFO - 2016-10-13 16:48:41 --> Database Driver Class Initialized
INFO - 2016-10-13 16:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:48:41 --> Parser Class Initialized
INFO - 2016-10-13 16:48:41 --> Controller Class Initialized
DEBUG - 2016-10-13 16:48:41 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-13 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:48:41 --> Model Class Initialized
INFO - 2016-10-13 16:49:15 --> Config Class Initialized
INFO - 2016-10-13 16:49:15 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:49:15 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:49:15 --> Utf8 Class Initialized
INFO - 2016-10-13 16:49:15 --> URI Class Initialized
INFO - 2016-10-13 16:49:15 --> Router Class Initialized
INFO - 2016-10-13 16:49:15 --> Output Class Initialized
INFO - 2016-10-13 16:49:15 --> Security Class Initialized
DEBUG - 2016-10-13 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:49:15 --> Input Class Initialized
INFO - 2016-10-13 16:49:15 --> Language Class Initialized
INFO - 2016-10-13 16:49:15 --> Language Class Initialized
INFO - 2016-10-13 16:49:15 --> Config Class Initialized
INFO - 2016-10-13 16:49:15 --> Loader Class Initialized
INFO - 2016-10-13 16:49:15 --> Helper loaded: common_helper
INFO - 2016-10-13 16:49:15 --> Helper loaded: url_helper
INFO - 2016-10-13 16:49:15 --> Database Driver Class Initialized
INFO - 2016-10-13 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:49:15 --> Parser Class Initialized
INFO - 2016-10-13 16:49:15 --> Controller Class Initialized
DEBUG - 2016-10-13 16:49:15 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:49:15 --> Model Class Initialized
DEBUG - 2016-10-13 16:49:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:49:15 --> Model Class Initialized
DEBUG - 2016-10-13 16:49:15 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:49:15 --> Model Class Initialized
DEBUG - 2016-10-13 16:49:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:49:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:49:15 --> Final output sent to browser
DEBUG - 2016-10-13 16:49:15 --> Total execution time: 0.0468
INFO - 2016-10-13 16:49:15 --> Config Class Initialized
INFO - 2016-10-13 16:49:15 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:49:15 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:49:15 --> Utf8 Class Initialized
INFO - 2016-10-13 16:49:15 --> URI Class Initialized
INFO - 2016-10-13 16:49:15 --> Router Class Initialized
INFO - 2016-10-13 16:49:15 --> Output Class Initialized
INFO - 2016-10-13 16:49:15 --> Security Class Initialized
DEBUG - 2016-10-13 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:49:15 --> Input Class Initialized
INFO - 2016-10-13 16:49:15 --> Language Class Initialized
INFO - 2016-10-13 16:49:15 --> Language Class Initialized
INFO - 2016-10-13 16:49:15 --> Config Class Initialized
INFO - 2016-10-13 16:49:15 --> Loader Class Initialized
INFO - 2016-10-13 16:49:15 --> Helper loaded: common_helper
INFO - 2016-10-13 16:49:15 --> Helper loaded: url_helper
INFO - 2016-10-13 16:49:15 --> Database Driver Class Initialized
INFO - 2016-10-13 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:49:15 --> Parser Class Initialized
INFO - 2016-10-13 16:49:15 --> Controller Class Initialized
DEBUG - 2016-10-13 16:49:15 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:49:15 --> Model Class Initialized
DEBUG - 2016-10-13 16:49:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:49:15 --> Model Class Initialized
DEBUG - 2016-10-13 16:49:15 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:49:15 --> Model Class Initialized
INFO - 2016-10-13 16:50:23 --> Config Class Initialized
INFO - 2016-10-13 16:50:23 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:50:23 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:50:23 --> Utf8 Class Initialized
INFO - 2016-10-13 16:50:23 --> URI Class Initialized
INFO - 2016-10-13 16:50:23 --> Router Class Initialized
INFO - 2016-10-13 16:50:23 --> Output Class Initialized
INFO - 2016-10-13 16:50:23 --> Security Class Initialized
DEBUG - 2016-10-13 16:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:50:23 --> Input Class Initialized
INFO - 2016-10-13 16:50:23 --> Language Class Initialized
INFO - 2016-10-13 16:50:23 --> Language Class Initialized
INFO - 2016-10-13 16:50:23 --> Config Class Initialized
INFO - 2016-10-13 16:50:23 --> Loader Class Initialized
INFO - 2016-10-13 16:50:23 --> Helper loaded: common_helper
INFO - 2016-10-13 16:50:23 --> Helper loaded: url_helper
INFO - 2016-10-13 16:50:23 --> Database Driver Class Initialized
INFO - 2016-10-13 16:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:50:23 --> Parser Class Initialized
INFO - 2016-10-13 16:50:23 --> Controller Class Initialized
DEBUG - 2016-10-13 16:50:23 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:50:23 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:50:23 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:50:23 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:50:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:50:23 --> Final output sent to browser
DEBUG - 2016-10-13 16:50:23 --> Total execution time: 0.0470
INFO - 2016-10-13 16:50:23 --> Config Class Initialized
INFO - 2016-10-13 16:50:23 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:50:23 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:50:23 --> Utf8 Class Initialized
INFO - 2016-10-13 16:50:23 --> URI Class Initialized
INFO - 2016-10-13 16:50:23 --> Router Class Initialized
INFO - 2016-10-13 16:50:23 --> Output Class Initialized
INFO - 2016-10-13 16:50:23 --> Security Class Initialized
DEBUG - 2016-10-13 16:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:50:23 --> Input Class Initialized
INFO - 2016-10-13 16:50:23 --> Language Class Initialized
INFO - 2016-10-13 16:50:23 --> Language Class Initialized
INFO - 2016-10-13 16:50:23 --> Config Class Initialized
INFO - 2016-10-13 16:50:23 --> Loader Class Initialized
INFO - 2016-10-13 16:50:23 --> Helper loaded: common_helper
INFO - 2016-10-13 16:50:23 --> Helper loaded: url_helper
INFO - 2016-10-13 16:50:23 --> Database Driver Class Initialized
INFO - 2016-10-13 16:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:50:23 --> Parser Class Initialized
INFO - 2016-10-13 16:50:23 --> Controller Class Initialized
DEBUG - 2016-10-13 16:50:23 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:50:23 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:50:23 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:50:23 --> Model Class Initialized
INFO - 2016-10-13 16:50:32 --> Config Class Initialized
INFO - 2016-10-13 16:50:32 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:50:32 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:50:32 --> Utf8 Class Initialized
INFO - 2016-10-13 16:50:32 --> URI Class Initialized
INFO - 2016-10-13 16:50:32 --> Router Class Initialized
INFO - 2016-10-13 16:50:32 --> Output Class Initialized
INFO - 2016-10-13 16:50:32 --> Security Class Initialized
DEBUG - 2016-10-13 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:50:32 --> Input Class Initialized
INFO - 2016-10-13 16:50:32 --> Language Class Initialized
INFO - 2016-10-13 16:50:32 --> Language Class Initialized
INFO - 2016-10-13 16:50:32 --> Config Class Initialized
INFO - 2016-10-13 16:50:32 --> Loader Class Initialized
INFO - 2016-10-13 16:50:32 --> Helper loaded: common_helper
INFO - 2016-10-13 16:50:32 --> Helper loaded: url_helper
INFO - 2016-10-13 16:50:32 --> Database Driver Class Initialized
INFO - 2016-10-13 16:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:50:32 --> Parser Class Initialized
INFO - 2016-10-13 16:50:32 --> Controller Class Initialized
DEBUG - 2016-10-13 16:50:32 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:50:32 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:50:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:50:32 --> Final output sent to browser
DEBUG - 2016-10-13 16:50:32 --> Total execution time: 0.0434
INFO - 2016-10-13 16:50:32 --> Config Class Initialized
INFO - 2016-10-13 16:50:32 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:50:32 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:50:32 --> Utf8 Class Initialized
INFO - 2016-10-13 16:50:32 --> URI Class Initialized
INFO - 2016-10-13 16:50:32 --> Router Class Initialized
INFO - 2016-10-13 16:50:32 --> Output Class Initialized
INFO - 2016-10-13 16:50:32 --> Security Class Initialized
DEBUG - 2016-10-13 16:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:50:32 --> Input Class Initialized
INFO - 2016-10-13 16:50:32 --> Language Class Initialized
INFO - 2016-10-13 16:50:32 --> Language Class Initialized
INFO - 2016-10-13 16:50:32 --> Config Class Initialized
INFO - 2016-10-13 16:50:33 --> Loader Class Initialized
INFO - 2016-10-13 16:50:33 --> Helper loaded: common_helper
INFO - 2016-10-13 16:50:33 --> Helper loaded: url_helper
INFO - 2016-10-13 16:50:33 --> Database Driver Class Initialized
INFO - 2016-10-13 16:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:50:33 --> Parser Class Initialized
INFO - 2016-10-13 16:50:33 --> Controller Class Initialized
DEBUG - 2016-10-13 16:50:33 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:50:33 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:50:33 --> Model Class Initialized
DEBUG - 2016-10-13 16:50:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:50:33 --> Model Class Initialized
INFO - 2016-10-13 16:51:26 --> Config Class Initialized
INFO - 2016-10-13 16:51:26 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:51:26 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:51:26 --> Utf8 Class Initialized
INFO - 2016-10-13 16:51:26 --> URI Class Initialized
INFO - 2016-10-13 16:51:26 --> Router Class Initialized
INFO - 2016-10-13 16:51:26 --> Output Class Initialized
INFO - 2016-10-13 16:51:26 --> Security Class Initialized
DEBUG - 2016-10-13 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:51:26 --> Input Class Initialized
INFO - 2016-10-13 16:51:26 --> Language Class Initialized
INFO - 2016-10-13 16:51:26 --> Language Class Initialized
INFO - 2016-10-13 16:51:26 --> Config Class Initialized
INFO - 2016-10-13 16:51:26 --> Loader Class Initialized
INFO - 2016-10-13 16:51:26 --> Helper loaded: common_helper
INFO - 2016-10-13 16:51:26 --> Helper loaded: url_helper
INFO - 2016-10-13 16:51:26 --> Database Driver Class Initialized
INFO - 2016-10-13 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:51:26 --> Parser Class Initialized
INFO - 2016-10-13 16:51:26 --> Controller Class Initialized
DEBUG - 2016-10-13 16:51:26 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:51:26 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:51:26 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:51:26 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:51:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:51:26 --> Final output sent to browser
DEBUG - 2016-10-13 16:51:26 --> Total execution time: 0.0724
INFO - 2016-10-13 16:51:26 --> Config Class Initialized
INFO - 2016-10-13 16:51:26 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:51:26 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:51:26 --> Utf8 Class Initialized
INFO - 2016-10-13 16:51:26 --> URI Class Initialized
INFO - 2016-10-13 16:51:26 --> Router Class Initialized
INFO - 2016-10-13 16:51:26 --> Output Class Initialized
INFO - 2016-10-13 16:51:26 --> Security Class Initialized
DEBUG - 2016-10-13 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:51:26 --> Input Class Initialized
INFO - 2016-10-13 16:51:26 --> Language Class Initialized
INFO - 2016-10-13 16:51:26 --> Language Class Initialized
INFO - 2016-10-13 16:51:26 --> Config Class Initialized
INFO - 2016-10-13 16:51:26 --> Loader Class Initialized
INFO - 2016-10-13 16:51:26 --> Helper loaded: common_helper
INFO - 2016-10-13 16:51:26 --> Helper loaded: url_helper
INFO - 2016-10-13 16:51:26 --> Database Driver Class Initialized
INFO - 2016-10-13 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:51:26 --> Parser Class Initialized
INFO - 2016-10-13 16:51:26 --> Controller Class Initialized
DEBUG - 2016-10-13 16:51:26 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:51:26 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:51:26 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:51:26 --> Model Class Initialized
INFO - 2016-10-13 16:51:53 --> Config Class Initialized
INFO - 2016-10-13 16:51:53 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:51:53 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:51:53 --> Utf8 Class Initialized
INFO - 2016-10-13 16:51:53 --> URI Class Initialized
INFO - 2016-10-13 16:51:53 --> Router Class Initialized
INFO - 2016-10-13 16:51:53 --> Output Class Initialized
INFO - 2016-10-13 16:51:53 --> Security Class Initialized
DEBUG - 2016-10-13 16:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:51:53 --> Input Class Initialized
INFO - 2016-10-13 16:51:53 --> Language Class Initialized
INFO - 2016-10-13 16:51:53 --> Language Class Initialized
INFO - 2016-10-13 16:51:53 --> Config Class Initialized
INFO - 2016-10-13 16:51:53 --> Loader Class Initialized
INFO - 2016-10-13 16:51:53 --> Helper loaded: common_helper
INFO - 2016-10-13 16:51:53 --> Helper loaded: url_helper
INFO - 2016-10-13 16:51:53 --> Database Driver Class Initialized
INFO - 2016-10-13 16:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:51:53 --> Parser Class Initialized
INFO - 2016-10-13 16:51:53 --> Controller Class Initialized
DEBUG - 2016-10-13 16:51:53 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:51:53 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:51:53 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:51:53 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:51:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:51:53 --> Final output sent to browser
DEBUG - 2016-10-13 16:51:53 --> Total execution time: 0.0485
INFO - 2016-10-13 16:51:53 --> Config Class Initialized
INFO - 2016-10-13 16:51:53 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:51:53 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:51:53 --> Utf8 Class Initialized
INFO - 2016-10-13 16:51:53 --> URI Class Initialized
INFO - 2016-10-13 16:51:53 --> Router Class Initialized
INFO - 2016-10-13 16:51:53 --> Output Class Initialized
INFO - 2016-10-13 16:51:53 --> Security Class Initialized
DEBUG - 2016-10-13 16:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:51:53 --> Input Class Initialized
INFO - 2016-10-13 16:51:53 --> Language Class Initialized
INFO - 2016-10-13 16:51:53 --> Language Class Initialized
INFO - 2016-10-13 16:51:53 --> Config Class Initialized
INFO - 2016-10-13 16:51:53 --> Loader Class Initialized
INFO - 2016-10-13 16:51:53 --> Helper loaded: common_helper
INFO - 2016-10-13 16:51:53 --> Helper loaded: url_helper
INFO - 2016-10-13 16:51:53 --> Database Driver Class Initialized
INFO - 2016-10-13 16:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:51:53 --> Parser Class Initialized
INFO - 2016-10-13 16:51:53 --> Controller Class Initialized
DEBUG - 2016-10-13 16:51:53 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:51:53 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:51:53 --> Model Class Initialized
DEBUG - 2016-10-13 16:51:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:51:53 --> Model Class Initialized
INFO - 2016-10-13 16:53:06 --> Config Class Initialized
INFO - 2016-10-13 16:53:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:53:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:53:06 --> Utf8 Class Initialized
INFO - 2016-10-13 16:53:06 --> URI Class Initialized
INFO - 2016-10-13 16:53:06 --> Router Class Initialized
INFO - 2016-10-13 16:53:06 --> Output Class Initialized
INFO - 2016-10-13 16:53:06 --> Security Class Initialized
DEBUG - 2016-10-13 16:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:53:06 --> Input Class Initialized
INFO - 2016-10-13 16:53:06 --> Language Class Initialized
INFO - 2016-10-13 16:53:06 --> Language Class Initialized
INFO - 2016-10-13 16:53:06 --> Config Class Initialized
INFO - 2016-10-13 16:53:06 --> Loader Class Initialized
INFO - 2016-10-13 16:53:06 --> Helper loaded: common_helper
INFO - 2016-10-13 16:53:06 --> Helper loaded: url_helper
INFO - 2016-10-13 16:53:06 --> Database Driver Class Initialized
INFO - 2016-10-13 16:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:53:06 --> Parser Class Initialized
INFO - 2016-10-13 16:53:06 --> Controller Class Initialized
DEBUG - 2016-10-13 16:53:06 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:53:06 --> Model Class Initialized
DEBUG - 2016-10-13 16:53:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:53:06 --> Model Class Initialized
DEBUG - 2016-10-13 16:53:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:53:06 --> Model Class Initialized
DEBUG - 2016-10-13 16:53:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:53:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:53:06 --> Final output sent to browser
DEBUG - 2016-10-13 16:53:06 --> Total execution time: 0.0440
INFO - 2016-10-13 16:53:06 --> Config Class Initialized
INFO - 2016-10-13 16:53:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:53:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:53:06 --> Utf8 Class Initialized
INFO - 2016-10-13 16:53:06 --> URI Class Initialized
INFO - 2016-10-13 16:53:06 --> Router Class Initialized
INFO - 2016-10-13 16:53:06 --> Output Class Initialized
INFO - 2016-10-13 16:53:06 --> Security Class Initialized
DEBUG - 2016-10-13 16:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:53:06 --> Input Class Initialized
INFO - 2016-10-13 16:53:06 --> Language Class Initialized
INFO - 2016-10-13 16:53:06 --> Language Class Initialized
INFO - 2016-10-13 16:53:06 --> Config Class Initialized
INFO - 2016-10-13 16:53:06 --> Loader Class Initialized
INFO - 2016-10-13 16:53:06 --> Helper loaded: common_helper
INFO - 2016-10-13 16:53:06 --> Helper loaded: url_helper
INFO - 2016-10-13 16:53:06 --> Database Driver Class Initialized
INFO - 2016-10-13 16:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:53:06 --> Parser Class Initialized
INFO - 2016-10-13 16:53:06 --> Controller Class Initialized
DEBUG - 2016-10-13 16:53:06 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:53:06 --> Model Class Initialized
DEBUG - 2016-10-13 16:53:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:53:06 --> Model Class Initialized
DEBUG - 2016-10-13 16:53:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:53:06 --> Model Class Initialized
INFO - 2016-10-13 16:56:26 --> Config Class Initialized
INFO - 2016-10-13 16:56:26 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:56:26 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:56:26 --> Utf8 Class Initialized
INFO - 2016-10-13 16:56:26 --> URI Class Initialized
INFO - 2016-10-13 16:56:26 --> Router Class Initialized
INFO - 2016-10-13 16:56:26 --> Output Class Initialized
INFO - 2016-10-13 16:56:26 --> Security Class Initialized
DEBUG - 2016-10-13 16:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:56:26 --> Input Class Initialized
INFO - 2016-10-13 16:56:26 --> Language Class Initialized
INFO - 2016-10-13 16:56:26 --> Language Class Initialized
INFO - 2016-10-13 16:56:26 --> Config Class Initialized
INFO - 2016-10-13 16:56:26 --> Loader Class Initialized
INFO - 2016-10-13 16:56:26 --> Helper loaded: common_helper
INFO - 2016-10-13 16:56:26 --> Helper loaded: url_helper
INFO - 2016-10-13 16:56:26 --> Database Driver Class Initialized
INFO - 2016-10-13 16:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:56:26 --> Parser Class Initialized
INFO - 2016-10-13 16:56:26 --> Controller Class Initialized
DEBUG - 2016-10-13 16:56:26 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:56:26 --> Model Class Initialized
DEBUG - 2016-10-13 16:56:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:56:26 --> Model Class Initialized
DEBUG - 2016-10-13 16:56:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:56:26 --> Model Class Initialized
INFO - 2016-10-13 16:56:51 --> Config Class Initialized
INFO - 2016-10-13 16:56:51 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:56:51 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:56:51 --> Utf8 Class Initialized
INFO - 2016-10-13 16:56:51 --> URI Class Initialized
DEBUG - 2016-10-13 16:56:51 --> No URI present. Default controller set.
INFO - 2016-10-13 16:56:51 --> Router Class Initialized
INFO - 2016-10-13 16:56:51 --> Output Class Initialized
INFO - 2016-10-13 16:56:51 --> Security Class Initialized
DEBUG - 2016-10-13 16:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:56:51 --> Input Class Initialized
INFO - 2016-10-13 16:56:51 --> Language Class Initialized
INFO - 2016-10-13 16:56:51 --> Language Class Initialized
INFO - 2016-10-13 16:56:51 --> Config Class Initialized
INFO - 2016-10-13 16:56:51 --> Loader Class Initialized
INFO - 2016-10-13 16:56:51 --> Helper loaded: common_helper
INFO - 2016-10-13 16:56:51 --> Helper loaded: url_helper
INFO - 2016-10-13 16:56:51 --> Database Driver Class Initialized
INFO - 2016-10-13 16:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:56:51 --> Parser Class Initialized
INFO - 2016-10-13 16:56:51 --> Controller Class Initialized
DEBUG - 2016-10-13 16:56:51 --> Home MX_Controller Initialized
INFO - 2016-10-13 16:56:51 --> Model Class Initialized
DEBUG - 2016-10-13 16:56:51 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 16:56:51 --> Model Class Initialized
ERROR - 2016-10-13 16:56:51 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 16:56:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 16:56:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:56:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 16:56:51 --> Final output sent to browser
DEBUG - 2016-10-13 16:56:51 --> Total execution time: 0.0430
INFO - 2016-10-13 16:56:59 --> Config Class Initialized
INFO - 2016-10-13 16:56:59 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:56:59 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:56:59 --> Utf8 Class Initialized
INFO - 2016-10-13 16:56:59 --> URI Class Initialized
INFO - 2016-10-13 16:56:59 --> Router Class Initialized
INFO - 2016-10-13 16:56:59 --> Output Class Initialized
INFO - 2016-10-13 16:56:59 --> Security Class Initialized
DEBUG - 2016-10-13 16:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:56:59 --> Input Class Initialized
INFO - 2016-10-13 16:56:59 --> Language Class Initialized
INFO - 2016-10-13 16:56:59 --> Language Class Initialized
INFO - 2016-10-13 16:56:59 --> Config Class Initialized
INFO - 2016-10-13 16:56:59 --> Loader Class Initialized
INFO - 2016-10-13 16:56:59 --> Helper loaded: common_helper
INFO - 2016-10-13 16:56:59 --> Helper loaded: url_helper
INFO - 2016-10-13 16:56:59 --> Database Driver Class Initialized
INFO - 2016-10-13 16:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:56:59 --> Parser Class Initialized
INFO - 2016-10-13 16:56:59 --> Controller Class Initialized
DEBUG - 2016-10-13 16:56:59 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:56:59 --> Model Class Initialized
DEBUG - 2016-10-13 16:56:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:56:59 --> Model Class Initialized
DEBUG - 2016-10-13 16:56:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:56:59 --> Model Class Initialized
DEBUG - 2016-10-13 16:56:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:56:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:56:59 --> Final output sent to browser
DEBUG - 2016-10-13 16:56:59 --> Total execution time: 0.0463
INFO - 2016-10-13 16:56:59 --> Config Class Initialized
INFO - 2016-10-13 16:56:59 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:56:59 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:56:59 --> Utf8 Class Initialized
INFO - 2016-10-13 16:56:59 --> URI Class Initialized
INFO - 2016-10-13 16:56:59 --> Router Class Initialized
INFO - 2016-10-13 16:56:59 --> Output Class Initialized
INFO - 2016-10-13 16:56:59 --> Security Class Initialized
DEBUG - 2016-10-13 16:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:56:59 --> Input Class Initialized
INFO - 2016-10-13 16:56:59 --> Language Class Initialized
INFO - 2016-10-13 16:56:59 --> Language Class Initialized
INFO - 2016-10-13 16:56:59 --> Config Class Initialized
INFO - 2016-10-13 16:56:59 --> Loader Class Initialized
INFO - 2016-10-13 16:56:59 --> Helper loaded: common_helper
INFO - 2016-10-13 16:56:59 --> Helper loaded: url_helper
INFO - 2016-10-13 16:56:59 --> Database Driver Class Initialized
INFO - 2016-10-13 16:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:56:59 --> Parser Class Initialized
INFO - 2016-10-13 16:56:59 --> Controller Class Initialized
DEBUG - 2016-10-13 16:56:59 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:56:59 --> Model Class Initialized
DEBUG - 2016-10-13 16:56:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:56:59 --> Model Class Initialized
DEBUG - 2016-10-13 16:56:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:56:59 --> Model Class Initialized
INFO - 2016-10-13 16:58:12 --> Config Class Initialized
INFO - 2016-10-13 16:58:12 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:58:12 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:58:12 --> Utf8 Class Initialized
INFO - 2016-10-13 16:58:12 --> URI Class Initialized
INFO - 2016-10-13 16:58:12 --> Router Class Initialized
INFO - 2016-10-13 16:58:12 --> Output Class Initialized
INFO - 2016-10-13 16:58:12 --> Security Class Initialized
DEBUG - 2016-10-13 16:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:58:12 --> Input Class Initialized
INFO - 2016-10-13 16:58:12 --> Language Class Initialized
INFO - 2016-10-13 16:58:12 --> Language Class Initialized
INFO - 2016-10-13 16:58:12 --> Config Class Initialized
INFO - 2016-10-13 16:58:12 --> Loader Class Initialized
INFO - 2016-10-13 16:58:12 --> Helper loaded: common_helper
INFO - 2016-10-13 16:58:12 --> Helper loaded: url_helper
INFO - 2016-10-13 16:58:12 --> Database Driver Class Initialized
INFO - 2016-10-13 16:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:58:12 --> Parser Class Initialized
INFO - 2016-10-13 16:58:12 --> Controller Class Initialized
DEBUG - 2016-10-13 16:58:12 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:58:12 --> Model Class Initialized
DEBUG - 2016-10-13 16:58:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:58:12 --> Model Class Initialized
DEBUG - 2016-10-13 16:58:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:58:12 --> Model Class Initialized
DEBUG - 2016-10-13 16:58:12 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 16:58:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 16:58:12 --> Final output sent to browser
DEBUG - 2016-10-13 16:58:12 --> Total execution time: 0.0558
INFO - 2016-10-13 16:58:12 --> Config Class Initialized
INFO - 2016-10-13 16:58:12 --> Hooks Class Initialized
DEBUG - 2016-10-13 16:58:12 --> UTF-8 Support Enabled
INFO - 2016-10-13 16:58:12 --> Utf8 Class Initialized
INFO - 2016-10-13 16:58:12 --> URI Class Initialized
INFO - 2016-10-13 16:58:12 --> Router Class Initialized
INFO - 2016-10-13 16:58:12 --> Output Class Initialized
INFO - 2016-10-13 16:58:12 --> Security Class Initialized
DEBUG - 2016-10-13 16:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 16:58:12 --> Input Class Initialized
INFO - 2016-10-13 16:58:12 --> Language Class Initialized
INFO - 2016-10-13 16:58:12 --> Language Class Initialized
INFO - 2016-10-13 16:58:12 --> Config Class Initialized
INFO - 2016-10-13 16:58:12 --> Loader Class Initialized
INFO - 2016-10-13 16:58:12 --> Helper loaded: common_helper
INFO - 2016-10-13 16:58:12 --> Helper loaded: url_helper
INFO - 2016-10-13 16:58:12 --> Database Driver Class Initialized
INFO - 2016-10-13 16:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 16:58:12 --> Parser Class Initialized
INFO - 2016-10-13 16:58:12 --> Controller Class Initialized
DEBUG - 2016-10-13 16:58:12 --> Servers MX_Controller Initialized
INFO - 2016-10-13 16:58:12 --> Model Class Initialized
DEBUG - 2016-10-13 16:58:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 16:58:12 --> Model Class Initialized
DEBUG - 2016-10-13 16:58:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 16:58:12 --> Model Class Initialized
INFO - 2016-10-13 17:00:05 --> Config Class Initialized
INFO - 2016-10-13 17:00:05 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:00:05 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:00:05 --> Utf8 Class Initialized
INFO - 2016-10-13 17:00:05 --> URI Class Initialized
INFO - 2016-10-13 17:00:05 --> Router Class Initialized
INFO - 2016-10-13 17:00:05 --> Output Class Initialized
INFO - 2016-10-13 17:00:05 --> Security Class Initialized
DEBUG - 2016-10-13 17:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:00:05 --> Input Class Initialized
INFO - 2016-10-13 17:00:05 --> Language Class Initialized
INFO - 2016-10-13 17:00:05 --> Language Class Initialized
INFO - 2016-10-13 17:00:05 --> Config Class Initialized
INFO - 2016-10-13 17:00:05 --> Loader Class Initialized
INFO - 2016-10-13 17:00:05 --> Helper loaded: common_helper
INFO - 2016-10-13 17:00:05 --> Helper loaded: url_helper
INFO - 2016-10-13 17:00:05 --> Database Driver Class Initialized
INFO - 2016-10-13 17:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:00:05 --> Parser Class Initialized
INFO - 2016-10-13 17:00:05 --> Controller Class Initialized
DEBUG - 2016-10-13 17:00:05 --> Popup MX_Controller Initialized
INFO - 2016-10-13 17:00:05 --> Model Class Initialized
DEBUG - 2016-10-13 17:00:05 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-13 17:00:05 --> Model Class Initialized
DEBUG - 2016-10-13 17:00:05 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-13 17:00:05 --> Final output sent to browser
DEBUG - 2016-10-13 17:00:05 --> Total execution time: 0.0495
INFO - 2016-10-13 17:01:32 --> Config Class Initialized
INFO - 2016-10-13 17:01:32 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:01:32 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:01:32 --> Utf8 Class Initialized
INFO - 2016-10-13 17:01:32 --> URI Class Initialized
INFO - 2016-10-13 17:01:32 --> Router Class Initialized
INFO - 2016-10-13 17:01:32 --> Output Class Initialized
INFO - 2016-10-13 17:01:32 --> Security Class Initialized
DEBUG - 2016-10-13 17:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:01:32 --> Input Class Initialized
INFO - 2016-10-13 17:01:32 --> Language Class Initialized
INFO - 2016-10-13 17:01:32 --> Language Class Initialized
INFO - 2016-10-13 17:01:32 --> Config Class Initialized
INFO - 2016-10-13 17:01:32 --> Loader Class Initialized
INFO - 2016-10-13 17:01:32 --> Helper loaded: common_helper
INFO - 2016-10-13 17:01:32 --> Helper loaded: url_helper
INFO - 2016-10-13 17:01:32 --> Database Driver Class Initialized
INFO - 2016-10-13 17:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:01:32 --> Parser Class Initialized
INFO - 2016-10-13 17:01:32 --> Controller Class Initialized
DEBUG - 2016-10-13 17:01:32 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:01:32 --> Model Class Initialized
DEBUG - 2016-10-13 17:01:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:01:32 --> Model Class Initialized
DEBUG - 2016-10-13 17:01:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:01:32 --> Model Class Initialized
INFO - 2016-10-13 17:01:50 --> Config Class Initialized
INFO - 2016-10-13 17:01:50 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:01:50 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:01:50 --> Utf8 Class Initialized
INFO - 2016-10-13 17:01:50 --> URI Class Initialized
INFO - 2016-10-13 17:01:50 --> Router Class Initialized
INFO - 2016-10-13 17:01:50 --> Output Class Initialized
INFO - 2016-10-13 17:01:50 --> Security Class Initialized
DEBUG - 2016-10-13 17:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:01:50 --> Input Class Initialized
INFO - 2016-10-13 17:01:50 --> Language Class Initialized
INFO - 2016-10-13 17:01:50 --> Language Class Initialized
INFO - 2016-10-13 17:01:50 --> Config Class Initialized
INFO - 2016-10-13 17:01:50 --> Loader Class Initialized
INFO - 2016-10-13 17:01:50 --> Helper loaded: common_helper
INFO - 2016-10-13 17:01:50 --> Helper loaded: url_helper
INFO - 2016-10-13 17:01:50 --> Database Driver Class Initialized
INFO - 2016-10-13 17:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:01:50 --> Parser Class Initialized
INFO - 2016-10-13 17:01:50 --> Controller Class Initialized
DEBUG - 2016-10-13 17:01:50 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:01:50 --> Model Class Initialized
DEBUG - 2016-10-13 17:01:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:01:50 --> Model Class Initialized
DEBUG - 2016-10-13 17:01:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:01:50 --> Model Class Initialized
DEBUG - 2016-10-13 17:01:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:01:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 17:01:50 --> Final output sent to browser
DEBUG - 2016-10-13 17:01:50 --> Total execution time: 0.0477
INFO - 2016-10-13 17:02:50 --> Config Class Initialized
INFO - 2016-10-13 17:02:50 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:02:50 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:02:50 --> Utf8 Class Initialized
INFO - 2016-10-13 17:02:50 --> URI Class Initialized
INFO - 2016-10-13 17:02:50 --> Router Class Initialized
INFO - 2016-10-13 17:02:50 --> Output Class Initialized
INFO - 2016-10-13 17:02:50 --> Security Class Initialized
DEBUG - 2016-10-13 17:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:02:50 --> Input Class Initialized
INFO - 2016-10-13 17:02:50 --> Language Class Initialized
INFO - 2016-10-13 17:02:50 --> Language Class Initialized
INFO - 2016-10-13 17:02:50 --> Config Class Initialized
INFO - 2016-10-13 17:02:50 --> Loader Class Initialized
INFO - 2016-10-13 17:02:50 --> Helper loaded: common_helper
INFO - 2016-10-13 17:02:50 --> Helper loaded: url_helper
INFO - 2016-10-13 17:02:50 --> Database Driver Class Initialized
INFO - 2016-10-13 17:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:02:50 --> Parser Class Initialized
INFO - 2016-10-13 17:02:50 --> Controller Class Initialized
DEBUG - 2016-10-13 17:02:50 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:02:50 --> Model Class Initialized
DEBUG - 2016-10-13 17:02:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:02:50 --> Model Class Initialized
DEBUG - 2016-10-13 17:02:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:02:50 --> Model Class Initialized
DEBUG - 2016-10-13 17:02:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:02:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 17:02:50 --> Final output sent to browser
DEBUG - 2016-10-13 17:02:50 --> Total execution time: 0.0547
INFO - 2016-10-13 17:02:50 --> Config Class Initialized
INFO - 2016-10-13 17:02:50 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:02:50 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:02:50 --> Utf8 Class Initialized
INFO - 2016-10-13 17:02:50 --> URI Class Initialized
INFO - 2016-10-13 17:02:50 --> Router Class Initialized
INFO - 2016-10-13 17:02:50 --> Output Class Initialized
INFO - 2016-10-13 17:02:50 --> Security Class Initialized
DEBUG - 2016-10-13 17:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:02:50 --> Input Class Initialized
INFO - 2016-10-13 17:02:50 --> Language Class Initialized
INFO - 2016-10-13 17:02:50 --> Language Class Initialized
INFO - 2016-10-13 17:02:50 --> Config Class Initialized
INFO - 2016-10-13 17:02:50 --> Loader Class Initialized
INFO - 2016-10-13 17:02:50 --> Helper loaded: common_helper
INFO - 2016-10-13 17:02:50 --> Helper loaded: url_helper
INFO - 2016-10-13 17:02:50 --> Database Driver Class Initialized
INFO - 2016-10-13 17:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:02:50 --> Parser Class Initialized
INFO - 2016-10-13 17:02:50 --> Controller Class Initialized
DEBUG - 2016-10-13 17:02:50 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:02:50 --> Model Class Initialized
DEBUG - 2016-10-13 17:02:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:02:50 --> Model Class Initialized
DEBUG - 2016-10-13 17:02:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:02:50 --> Model Class Initialized
INFO - 2016-10-13 17:03:51 --> Config Class Initialized
INFO - 2016-10-13 17:03:51 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:03:51 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:03:51 --> Utf8 Class Initialized
INFO - 2016-10-13 17:03:51 --> URI Class Initialized
INFO - 2016-10-13 17:03:51 --> Router Class Initialized
INFO - 2016-10-13 17:03:51 --> Output Class Initialized
INFO - 2016-10-13 17:03:51 --> Security Class Initialized
DEBUG - 2016-10-13 17:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:03:51 --> Input Class Initialized
INFO - 2016-10-13 17:03:51 --> Language Class Initialized
INFO - 2016-10-13 17:03:51 --> Language Class Initialized
INFO - 2016-10-13 17:03:51 --> Config Class Initialized
INFO - 2016-10-13 17:03:51 --> Loader Class Initialized
INFO - 2016-10-13 17:03:51 --> Helper loaded: common_helper
INFO - 2016-10-13 17:03:51 --> Helper loaded: url_helper
INFO - 2016-10-13 17:03:51 --> Database Driver Class Initialized
INFO - 2016-10-13 17:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:03:51 --> Parser Class Initialized
INFO - 2016-10-13 17:03:51 --> Controller Class Initialized
DEBUG - 2016-10-13 17:03:51 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:03:51 --> Model Class Initialized
DEBUG - 2016-10-13 17:03:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:03:51 --> Model Class Initialized
DEBUG - 2016-10-13 17:03:51 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:03:51 --> Model Class Initialized
DEBUG - 2016-10-13 17:03:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:03:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 17:03:51 --> Final output sent to browser
DEBUG - 2016-10-13 17:03:51 --> Total execution time: 0.0490
INFO - 2016-10-13 17:03:51 --> Config Class Initialized
INFO - 2016-10-13 17:03:51 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:03:51 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:03:51 --> Utf8 Class Initialized
INFO - 2016-10-13 17:03:51 --> URI Class Initialized
INFO - 2016-10-13 17:03:51 --> Router Class Initialized
INFO - 2016-10-13 17:03:51 --> Output Class Initialized
INFO - 2016-10-13 17:03:51 --> Security Class Initialized
DEBUG - 2016-10-13 17:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:03:51 --> Input Class Initialized
INFO - 2016-10-13 17:03:51 --> Language Class Initialized
INFO - 2016-10-13 17:03:51 --> Language Class Initialized
INFO - 2016-10-13 17:03:51 --> Config Class Initialized
INFO - 2016-10-13 17:03:51 --> Loader Class Initialized
INFO - 2016-10-13 17:03:51 --> Helper loaded: common_helper
INFO - 2016-10-13 17:03:51 --> Helper loaded: url_helper
INFO - 2016-10-13 17:03:51 --> Database Driver Class Initialized
INFO - 2016-10-13 17:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:03:51 --> Parser Class Initialized
INFO - 2016-10-13 17:03:51 --> Controller Class Initialized
DEBUG - 2016-10-13 17:03:51 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:03:51 --> Model Class Initialized
DEBUG - 2016-10-13 17:03:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:03:51 --> Model Class Initialized
DEBUG - 2016-10-13 17:03:51 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:03:51 --> Model Class Initialized
INFO - 2016-10-13 17:05:00 --> Config Class Initialized
INFO - 2016-10-13 17:05:00 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:05:00 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:05:00 --> Utf8 Class Initialized
INFO - 2016-10-13 17:05:00 --> URI Class Initialized
INFO - 2016-10-13 17:05:00 --> Router Class Initialized
INFO - 2016-10-13 17:05:00 --> Output Class Initialized
INFO - 2016-10-13 17:05:00 --> Security Class Initialized
DEBUG - 2016-10-13 17:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:05:00 --> Input Class Initialized
INFO - 2016-10-13 17:05:00 --> Language Class Initialized
INFO - 2016-10-13 17:05:00 --> Language Class Initialized
INFO - 2016-10-13 17:05:00 --> Config Class Initialized
INFO - 2016-10-13 17:05:00 --> Loader Class Initialized
INFO - 2016-10-13 17:05:00 --> Helper loaded: common_helper
INFO - 2016-10-13 17:05:00 --> Helper loaded: url_helper
INFO - 2016-10-13 17:05:00 --> Database Driver Class Initialized
INFO - 2016-10-13 17:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:05:00 --> Parser Class Initialized
INFO - 2016-10-13 17:05:00 --> Controller Class Initialized
DEBUG - 2016-10-13 17:05:00 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:05:00 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:05:00 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:05:00 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:05:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 17:05:00 --> Final output sent to browser
DEBUG - 2016-10-13 17:05:00 --> Total execution time: 0.0450
INFO - 2016-10-13 17:05:01 --> Config Class Initialized
INFO - 2016-10-13 17:05:01 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:05:01 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:05:01 --> Utf8 Class Initialized
INFO - 2016-10-13 17:05:01 --> URI Class Initialized
INFO - 2016-10-13 17:05:01 --> Router Class Initialized
INFO - 2016-10-13 17:05:01 --> Output Class Initialized
INFO - 2016-10-13 17:05:01 --> Security Class Initialized
DEBUG - 2016-10-13 17:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:05:01 --> Input Class Initialized
INFO - 2016-10-13 17:05:01 --> Language Class Initialized
INFO - 2016-10-13 17:05:01 --> Language Class Initialized
INFO - 2016-10-13 17:05:01 --> Config Class Initialized
INFO - 2016-10-13 17:05:01 --> Loader Class Initialized
INFO - 2016-10-13 17:05:01 --> Helper loaded: common_helper
INFO - 2016-10-13 17:05:01 --> Helper loaded: url_helper
INFO - 2016-10-13 17:05:01 --> Database Driver Class Initialized
INFO - 2016-10-13 17:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:05:01 --> Parser Class Initialized
INFO - 2016-10-13 17:05:01 --> Controller Class Initialized
DEBUG - 2016-10-13 17:05:01 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:05:01 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:01 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:05:01 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:01 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:05:01 --> Model Class Initialized
INFO - 2016-10-13 17:05:32 --> Config Class Initialized
INFO - 2016-10-13 17:05:32 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:05:32 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:05:32 --> Utf8 Class Initialized
INFO - 2016-10-13 17:05:32 --> URI Class Initialized
INFO - 2016-10-13 17:05:32 --> Router Class Initialized
INFO - 2016-10-13 17:05:32 --> Output Class Initialized
INFO - 2016-10-13 17:05:32 --> Security Class Initialized
DEBUG - 2016-10-13 17:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:05:32 --> Input Class Initialized
INFO - 2016-10-13 17:05:32 --> Language Class Initialized
INFO - 2016-10-13 17:05:32 --> Language Class Initialized
INFO - 2016-10-13 17:05:32 --> Config Class Initialized
INFO - 2016-10-13 17:05:32 --> Loader Class Initialized
INFO - 2016-10-13 17:05:32 --> Helper loaded: common_helper
INFO - 2016-10-13 17:05:32 --> Helper loaded: url_helper
INFO - 2016-10-13 17:05:32 --> Database Driver Class Initialized
INFO - 2016-10-13 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:05:33 --> Parser Class Initialized
INFO - 2016-10-13 17:05:33 --> Controller Class Initialized
DEBUG - 2016-10-13 17:05:33 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:05:33 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:05:33 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:05:33 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:05:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 17:05:33 --> Final output sent to browser
DEBUG - 2016-10-13 17:05:33 --> Total execution time: 0.0629
INFO - 2016-10-13 17:05:33 --> Config Class Initialized
INFO - 2016-10-13 17:05:33 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:05:33 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:05:33 --> Utf8 Class Initialized
INFO - 2016-10-13 17:05:33 --> URI Class Initialized
INFO - 2016-10-13 17:05:33 --> Router Class Initialized
INFO - 2016-10-13 17:05:33 --> Output Class Initialized
INFO - 2016-10-13 17:05:33 --> Security Class Initialized
DEBUG - 2016-10-13 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:05:33 --> Input Class Initialized
INFO - 2016-10-13 17:05:33 --> Language Class Initialized
INFO - 2016-10-13 17:05:33 --> Language Class Initialized
INFO - 2016-10-13 17:05:33 --> Config Class Initialized
INFO - 2016-10-13 17:05:33 --> Loader Class Initialized
INFO - 2016-10-13 17:05:33 --> Helper loaded: common_helper
INFO - 2016-10-13 17:05:33 --> Helper loaded: url_helper
INFO - 2016-10-13 17:05:33 --> Database Driver Class Initialized
INFO - 2016-10-13 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:05:33 --> Parser Class Initialized
INFO - 2016-10-13 17:05:33 --> Controller Class Initialized
DEBUG - 2016-10-13 17:05:33 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:05:33 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:05:33 --> Model Class Initialized
DEBUG - 2016-10-13 17:05:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:05:33 --> Model Class Initialized
INFO - 2016-10-13 17:06:11 --> Config Class Initialized
INFO - 2016-10-13 17:06:11 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:06:11 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:06:11 --> Utf8 Class Initialized
INFO - 2016-10-13 17:06:11 --> URI Class Initialized
INFO - 2016-10-13 17:06:11 --> Router Class Initialized
INFO - 2016-10-13 17:06:11 --> Output Class Initialized
INFO - 2016-10-13 17:06:11 --> Security Class Initialized
DEBUG - 2016-10-13 17:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:06:11 --> Input Class Initialized
INFO - 2016-10-13 17:06:11 --> Language Class Initialized
INFO - 2016-10-13 17:06:11 --> Language Class Initialized
INFO - 2016-10-13 17:06:11 --> Config Class Initialized
INFO - 2016-10-13 17:06:11 --> Loader Class Initialized
INFO - 2016-10-13 17:06:11 --> Helper loaded: common_helper
INFO - 2016-10-13 17:06:11 --> Helper loaded: url_helper
INFO - 2016-10-13 17:06:11 --> Database Driver Class Initialized
INFO - 2016-10-13 17:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:06:11 --> Parser Class Initialized
INFO - 2016-10-13 17:06:11 --> Controller Class Initialized
DEBUG - 2016-10-13 17:06:11 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:06:11 --> Model Class Initialized
DEBUG - 2016-10-13 17:06:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:06:11 --> Model Class Initialized
DEBUG - 2016-10-13 17:06:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:06:11 --> Model Class Initialized
DEBUG - 2016-10-13 17:06:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:06:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 17:06:11 --> Final output sent to browser
DEBUG - 2016-10-13 17:06:11 --> Total execution time: 0.0454
INFO - 2016-10-13 17:06:12 --> Config Class Initialized
INFO - 2016-10-13 17:06:12 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:06:12 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:06:12 --> Utf8 Class Initialized
INFO - 2016-10-13 17:06:12 --> URI Class Initialized
INFO - 2016-10-13 17:06:12 --> Router Class Initialized
INFO - 2016-10-13 17:06:12 --> Output Class Initialized
INFO - 2016-10-13 17:06:12 --> Security Class Initialized
DEBUG - 2016-10-13 17:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:06:12 --> Input Class Initialized
INFO - 2016-10-13 17:06:12 --> Language Class Initialized
INFO - 2016-10-13 17:06:12 --> Language Class Initialized
INFO - 2016-10-13 17:06:12 --> Config Class Initialized
INFO - 2016-10-13 17:06:12 --> Loader Class Initialized
INFO - 2016-10-13 17:06:12 --> Helper loaded: common_helper
INFO - 2016-10-13 17:06:12 --> Helper loaded: url_helper
INFO - 2016-10-13 17:06:12 --> Database Driver Class Initialized
INFO - 2016-10-13 17:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:06:12 --> Parser Class Initialized
INFO - 2016-10-13 17:06:12 --> Controller Class Initialized
DEBUG - 2016-10-13 17:06:12 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:06:12 --> Model Class Initialized
DEBUG - 2016-10-13 17:06:12 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:06:12 --> Model Class Initialized
DEBUG - 2016-10-13 17:06:12 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:06:12 --> Model Class Initialized
INFO - 2016-10-13 17:07:14 --> Config Class Initialized
INFO - 2016-10-13 17:07:14 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:07:14 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:07:14 --> Utf8 Class Initialized
INFO - 2016-10-13 17:07:14 --> URI Class Initialized
INFO - 2016-10-13 17:07:14 --> Router Class Initialized
INFO - 2016-10-13 17:07:14 --> Output Class Initialized
INFO - 2016-10-13 17:07:14 --> Security Class Initialized
DEBUG - 2016-10-13 17:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:07:14 --> Input Class Initialized
INFO - 2016-10-13 17:07:14 --> Language Class Initialized
INFO - 2016-10-13 17:07:14 --> Language Class Initialized
INFO - 2016-10-13 17:07:14 --> Config Class Initialized
INFO - 2016-10-13 17:07:14 --> Loader Class Initialized
INFO - 2016-10-13 17:07:14 --> Helper loaded: common_helper
INFO - 2016-10-13 17:07:14 --> Helper loaded: url_helper
INFO - 2016-10-13 17:07:14 --> Database Driver Class Initialized
INFO - 2016-10-13 17:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:07:14 --> Parser Class Initialized
INFO - 2016-10-13 17:07:14 --> Controller Class Initialized
DEBUG - 2016-10-13 17:07:14 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:07:14 --> Model Class Initialized
DEBUG - 2016-10-13 17:07:14 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:07:14 --> Model Class Initialized
DEBUG - 2016-10-13 17:07:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:07:14 --> Model Class Initialized
DEBUG - 2016-10-13 17:07:14 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:07:14 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 17:07:14 --> Final output sent to browser
DEBUG - 2016-10-13 17:07:14 --> Total execution time: 0.0470
INFO - 2016-10-13 17:07:15 --> Config Class Initialized
INFO - 2016-10-13 17:07:15 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:07:15 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:07:15 --> Utf8 Class Initialized
INFO - 2016-10-13 17:07:15 --> URI Class Initialized
INFO - 2016-10-13 17:07:15 --> Router Class Initialized
INFO - 2016-10-13 17:07:15 --> Output Class Initialized
INFO - 2016-10-13 17:07:15 --> Security Class Initialized
DEBUG - 2016-10-13 17:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:07:15 --> Input Class Initialized
INFO - 2016-10-13 17:07:15 --> Language Class Initialized
INFO - 2016-10-13 17:07:15 --> Language Class Initialized
INFO - 2016-10-13 17:07:15 --> Config Class Initialized
INFO - 2016-10-13 17:07:15 --> Loader Class Initialized
INFO - 2016-10-13 17:07:15 --> Helper loaded: common_helper
INFO - 2016-10-13 17:07:15 --> Helper loaded: url_helper
INFO - 2016-10-13 17:07:15 --> Database Driver Class Initialized
INFO - 2016-10-13 17:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:07:15 --> Parser Class Initialized
INFO - 2016-10-13 17:07:15 --> Controller Class Initialized
DEBUG - 2016-10-13 17:07:15 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:07:15 --> Model Class Initialized
DEBUG - 2016-10-13 17:07:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:07:15 --> Model Class Initialized
DEBUG - 2016-10-13 17:07:15 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:07:15 --> Model Class Initialized
INFO - 2016-10-13 17:08:10 --> Config Class Initialized
INFO - 2016-10-13 17:08:10 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:08:10 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:08:10 --> Utf8 Class Initialized
INFO - 2016-10-13 17:08:10 --> URI Class Initialized
INFO - 2016-10-13 17:08:10 --> Router Class Initialized
INFO - 2016-10-13 17:08:10 --> Output Class Initialized
INFO - 2016-10-13 17:08:10 --> Security Class Initialized
DEBUG - 2016-10-13 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:08:10 --> Input Class Initialized
INFO - 2016-10-13 17:08:10 --> Language Class Initialized
INFO - 2016-10-13 17:08:10 --> Language Class Initialized
INFO - 2016-10-13 17:08:10 --> Config Class Initialized
INFO - 2016-10-13 17:08:10 --> Loader Class Initialized
INFO - 2016-10-13 17:08:10 --> Helper loaded: common_helper
INFO - 2016-10-13 17:08:10 --> Helper loaded: url_helper
INFO - 2016-10-13 17:08:10 --> Database Driver Class Initialized
INFO - 2016-10-13 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:08:10 --> Parser Class Initialized
INFO - 2016-10-13 17:08:10 --> Controller Class Initialized
DEBUG - 2016-10-13 17:08:10 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:08:10 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:10 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:08:10 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:08:10 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:10 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:08:10 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 17:08:10 --> Final output sent to browser
DEBUG - 2016-10-13 17:08:10 --> Total execution time: 0.0483
INFO - 2016-10-13 17:08:10 --> Config Class Initialized
INFO - 2016-10-13 17:08:10 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:08:10 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:08:10 --> Utf8 Class Initialized
INFO - 2016-10-13 17:08:10 --> URI Class Initialized
INFO - 2016-10-13 17:08:10 --> Router Class Initialized
INFO - 2016-10-13 17:08:10 --> Output Class Initialized
INFO - 2016-10-13 17:08:10 --> Security Class Initialized
DEBUG - 2016-10-13 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:08:10 --> Input Class Initialized
INFO - 2016-10-13 17:08:10 --> Language Class Initialized
INFO - 2016-10-13 17:08:10 --> Language Class Initialized
INFO - 2016-10-13 17:08:10 --> Config Class Initialized
INFO - 2016-10-13 17:08:10 --> Loader Class Initialized
INFO - 2016-10-13 17:08:10 --> Helper loaded: common_helper
INFO - 2016-10-13 17:08:10 --> Helper loaded: url_helper
INFO - 2016-10-13 17:08:10 --> Database Driver Class Initialized
INFO - 2016-10-13 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:08:10 --> Parser Class Initialized
INFO - 2016-10-13 17:08:10 --> Controller Class Initialized
DEBUG - 2016-10-13 17:08:10 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:08:10 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:10 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:08:10 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:08:10 --> Model Class Initialized
INFO - 2016-10-13 17:08:19 --> Config Class Initialized
INFO - 2016-10-13 17:08:19 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:08:19 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:08:19 --> Utf8 Class Initialized
INFO - 2016-10-13 17:08:19 --> URI Class Initialized
INFO - 2016-10-13 17:08:19 --> Router Class Initialized
INFO - 2016-10-13 17:08:19 --> Output Class Initialized
INFO - 2016-10-13 17:08:19 --> Security Class Initialized
DEBUG - 2016-10-13 17:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:08:19 --> Input Class Initialized
INFO - 2016-10-13 17:08:19 --> Language Class Initialized
INFO - 2016-10-13 17:08:19 --> Language Class Initialized
INFO - 2016-10-13 17:08:19 --> Config Class Initialized
INFO - 2016-10-13 17:08:19 --> Loader Class Initialized
INFO - 2016-10-13 17:08:19 --> Helper loaded: common_helper
INFO - 2016-10-13 17:08:19 --> Helper loaded: url_helper
INFO - 2016-10-13 17:08:19 --> Database Driver Class Initialized
INFO - 2016-10-13 17:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:08:19 --> Parser Class Initialized
INFO - 2016-10-13 17:08:19 --> Controller Class Initialized
DEBUG - 2016-10-13 17:08:19 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:08:19 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:08:19 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:08:19 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:08:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 17:08:19 --> Final output sent to browser
DEBUG - 2016-10-13 17:08:19 --> Total execution time: 0.0456
INFO - 2016-10-13 17:08:19 --> Config Class Initialized
INFO - 2016-10-13 17:08:19 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:08:19 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:08:19 --> Utf8 Class Initialized
INFO - 2016-10-13 17:08:19 --> URI Class Initialized
INFO - 2016-10-13 17:08:19 --> Router Class Initialized
INFO - 2016-10-13 17:08:19 --> Output Class Initialized
INFO - 2016-10-13 17:08:19 --> Security Class Initialized
DEBUG - 2016-10-13 17:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:08:19 --> Input Class Initialized
INFO - 2016-10-13 17:08:19 --> Language Class Initialized
INFO - 2016-10-13 17:08:19 --> Language Class Initialized
INFO - 2016-10-13 17:08:19 --> Config Class Initialized
INFO - 2016-10-13 17:08:19 --> Loader Class Initialized
INFO - 2016-10-13 17:08:19 --> Helper loaded: common_helper
INFO - 2016-10-13 17:08:19 --> Helper loaded: url_helper
INFO - 2016-10-13 17:08:19 --> Database Driver Class Initialized
INFO - 2016-10-13 17:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:08:19 --> Parser Class Initialized
INFO - 2016-10-13 17:08:19 --> Controller Class Initialized
DEBUG - 2016-10-13 17:08:19 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:08:19 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:08:19 --> Model Class Initialized
DEBUG - 2016-10-13 17:08:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:08:19 --> Model Class Initialized
INFO - 2016-10-13 17:08:44 --> Config Class Initialized
INFO - 2016-10-13 17:08:44 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:08:44 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:08:44 --> Utf8 Class Initialized
INFO - 2016-10-13 17:08:44 --> URI Class Initialized
INFO - 2016-10-13 17:08:44 --> Router Class Initialized
INFO - 2016-10-13 17:08:44 --> Output Class Initialized
INFO - 2016-10-13 17:08:44 --> Security Class Initialized
DEBUG - 2016-10-13 17:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:08:44 --> Input Class Initialized
INFO - 2016-10-13 17:08:44 --> Language Class Initialized
ERROR - 2016-10-13 17:08:44 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:13:09 --> Config Class Initialized
INFO - 2016-10-13 17:13:09 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:13:09 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:13:09 --> Utf8 Class Initialized
INFO - 2016-10-13 17:13:09 --> URI Class Initialized
INFO - 2016-10-13 17:13:09 --> Router Class Initialized
INFO - 2016-10-13 17:13:09 --> Output Class Initialized
INFO - 2016-10-13 17:13:09 --> Security Class Initialized
DEBUG - 2016-10-13 17:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:13:09 --> Input Class Initialized
INFO - 2016-10-13 17:13:09 --> Language Class Initialized
ERROR - 2016-10-13 17:13:09 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:13:16 --> Config Class Initialized
INFO - 2016-10-13 17:13:16 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:13:16 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:13:16 --> Utf8 Class Initialized
INFO - 2016-10-13 17:13:16 --> URI Class Initialized
INFO - 2016-10-13 17:13:16 --> Router Class Initialized
INFO - 2016-10-13 17:13:16 --> Output Class Initialized
INFO - 2016-10-13 17:13:16 --> Security Class Initialized
DEBUG - 2016-10-13 17:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:13:16 --> Input Class Initialized
INFO - 2016-10-13 17:13:16 --> Language Class Initialized
ERROR - 2016-10-13 17:13:16 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:13:23 --> Config Class Initialized
INFO - 2016-10-13 17:13:23 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:13:23 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:13:23 --> Utf8 Class Initialized
INFO - 2016-10-13 17:13:23 --> URI Class Initialized
INFO - 2016-10-13 17:13:23 --> Router Class Initialized
INFO - 2016-10-13 17:13:23 --> Output Class Initialized
INFO - 2016-10-13 17:13:23 --> Security Class Initialized
DEBUG - 2016-10-13 17:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:13:23 --> Input Class Initialized
INFO - 2016-10-13 17:13:23 --> Language Class Initialized
ERROR - 2016-10-13 17:13:23 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:13:27 --> Config Class Initialized
INFO - 2016-10-13 17:13:27 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:13:27 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:13:27 --> Utf8 Class Initialized
INFO - 2016-10-13 17:13:27 --> URI Class Initialized
INFO - 2016-10-13 17:13:27 --> Router Class Initialized
INFO - 2016-10-13 17:13:27 --> Output Class Initialized
INFO - 2016-10-13 17:13:27 --> Security Class Initialized
DEBUG - 2016-10-13 17:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:13:27 --> Input Class Initialized
INFO - 2016-10-13 17:13:27 --> Language Class Initialized
ERROR - 2016-10-13 17:13:27 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:13:37 --> Config Class Initialized
INFO - 2016-10-13 17:13:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:13:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:13:37 --> Utf8 Class Initialized
INFO - 2016-10-13 17:13:37 --> URI Class Initialized
INFO - 2016-10-13 17:13:37 --> Router Class Initialized
INFO - 2016-10-13 17:13:37 --> Output Class Initialized
INFO - 2016-10-13 17:13:37 --> Security Class Initialized
DEBUG - 2016-10-13 17:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:13:37 --> Input Class Initialized
INFO - 2016-10-13 17:13:37 --> Language Class Initialized
INFO - 2016-10-13 17:13:37 --> Language Class Initialized
INFO - 2016-10-13 17:13:37 --> Config Class Initialized
INFO - 2016-10-13 17:13:37 --> Loader Class Initialized
INFO - 2016-10-13 17:13:37 --> Helper loaded: common_helper
INFO - 2016-10-13 17:13:37 --> Helper loaded: url_helper
INFO - 2016-10-13 17:13:38 --> Database Driver Class Initialized
INFO - 2016-10-13 17:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:13:38 --> Parser Class Initialized
INFO - 2016-10-13 17:13:38 --> Controller Class Initialized
DEBUG - 2016-10-13 17:13:38 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:13:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:13:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:13:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 17:13:38 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:13:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:13:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:13:38 --> Final output sent to browser
DEBUG - 2016-10-13 17:13:38 --> Total execution time: 0.0543
INFO - 2016-10-13 17:13:38 --> Config Class Initialized
INFO - 2016-10-13 17:13:38 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:13:38 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:13:38 --> Utf8 Class Initialized
INFO - 2016-10-13 17:13:38 --> URI Class Initialized
INFO - 2016-10-13 17:13:38 --> Router Class Initialized
INFO - 2016-10-13 17:13:38 --> Output Class Initialized
INFO - 2016-10-13 17:13:38 --> Security Class Initialized
DEBUG - 2016-10-13 17:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:13:38 --> Input Class Initialized
INFO - 2016-10-13 17:13:38 --> Language Class Initialized
INFO - 2016-10-13 17:13:38 --> Language Class Initialized
INFO - 2016-10-13 17:13:38 --> Config Class Initialized
INFO - 2016-10-13 17:13:38 --> Loader Class Initialized
INFO - 2016-10-13 17:13:38 --> Helper loaded: common_helper
INFO - 2016-10-13 17:13:38 --> Helper loaded: url_helper
INFO - 2016-10-13 17:13:38 --> Database Driver Class Initialized
INFO - 2016-10-13 17:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:13:38 --> Parser Class Initialized
INFO - 2016-10-13 17:13:38 --> Controller Class Initialized
DEBUG - 2016-10-13 17:13:38 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:13:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:13:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:13:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:38 --> Pagination Class Initialized
DEBUG - 2016-10-13 17:13:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 17:13:38 --> Final output sent to browser
DEBUG - 2016-10-13 17:13:38 --> Total execution time: 0.0449
INFO - 2016-10-13 17:13:40 --> Config Class Initialized
INFO - 2016-10-13 17:13:40 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:13:40 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:13:40 --> Utf8 Class Initialized
INFO - 2016-10-13 17:13:40 --> URI Class Initialized
INFO - 2016-10-13 17:13:40 --> Router Class Initialized
INFO - 2016-10-13 17:13:40 --> Output Class Initialized
INFO - 2016-10-13 17:13:40 --> Security Class Initialized
DEBUG - 2016-10-13 17:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:13:40 --> Input Class Initialized
INFO - 2016-10-13 17:13:40 --> Language Class Initialized
ERROR - 2016-10-13 17:13:40 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:13:42 --> Config Class Initialized
INFO - 2016-10-13 17:13:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:13:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:13:42 --> Utf8 Class Initialized
INFO - 2016-10-13 17:13:42 --> URI Class Initialized
INFO - 2016-10-13 17:13:42 --> Router Class Initialized
INFO - 2016-10-13 17:13:42 --> Output Class Initialized
INFO - 2016-10-13 17:13:42 --> Security Class Initialized
DEBUG - 2016-10-13 17:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:13:42 --> Input Class Initialized
INFO - 2016-10-13 17:13:42 --> Language Class Initialized
INFO - 2016-10-13 17:13:42 --> Language Class Initialized
INFO - 2016-10-13 17:13:42 --> Config Class Initialized
INFO - 2016-10-13 17:13:42 --> Loader Class Initialized
INFO - 2016-10-13 17:13:42 --> Helper loaded: common_helper
INFO - 2016-10-13 17:13:42 --> Helper loaded: url_helper
INFO - 2016-10-13 17:13:42 --> Database Driver Class Initialized
INFO - 2016-10-13 17:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:13:42 --> Parser Class Initialized
INFO - 2016-10-13 17:13:42 --> Controller Class Initialized
DEBUG - 2016-10-13 17:13:42 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:13:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:13:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:13:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 17:13:42 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:13:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:13:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:13:42 --> Final output sent to browser
DEBUG - 2016-10-13 17:13:42 --> Total execution time: 0.0425
INFO - 2016-10-13 17:13:42 --> Config Class Initialized
INFO - 2016-10-13 17:13:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:13:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:13:42 --> Utf8 Class Initialized
INFO - 2016-10-13 17:13:42 --> URI Class Initialized
INFO - 2016-10-13 17:13:42 --> Router Class Initialized
INFO - 2016-10-13 17:13:42 --> Output Class Initialized
INFO - 2016-10-13 17:13:42 --> Security Class Initialized
DEBUG - 2016-10-13 17:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:13:42 --> Input Class Initialized
INFO - 2016-10-13 17:13:42 --> Language Class Initialized
INFO - 2016-10-13 17:13:42 --> Language Class Initialized
INFO - 2016-10-13 17:13:42 --> Config Class Initialized
INFO - 2016-10-13 17:13:42 --> Loader Class Initialized
INFO - 2016-10-13 17:13:42 --> Helper loaded: common_helper
INFO - 2016-10-13 17:13:42 --> Helper loaded: url_helper
INFO - 2016-10-13 17:13:42 --> Database Driver Class Initialized
INFO - 2016-10-13 17:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:13:42 --> Parser Class Initialized
INFO - 2016-10-13 17:13:42 --> Controller Class Initialized
DEBUG - 2016-10-13 17:13:42 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:13:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:13:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:13:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:13:42 --> Pagination Class Initialized
DEBUG - 2016-10-13 17:13:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 17:13:42 --> Final output sent to browser
DEBUG - 2016-10-13 17:13:42 --> Total execution time: 0.0380
INFO - 2016-10-13 17:14:31 --> Config Class Initialized
INFO - 2016-10-13 17:14:31 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:31 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:31 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:31 --> URI Class Initialized
INFO - 2016-10-13 17:14:31 --> Router Class Initialized
INFO - 2016-10-13 17:14:31 --> Output Class Initialized
INFO - 2016-10-13 17:14:31 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:31 --> Input Class Initialized
INFO - 2016-10-13 17:14:31 --> Language Class Initialized
INFO - 2016-10-13 17:14:31 --> Language Class Initialized
INFO - 2016-10-13 17:14:31 --> Config Class Initialized
INFO - 2016-10-13 17:14:31 --> Loader Class Initialized
INFO - 2016-10-13 17:14:31 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:31 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:31 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:31 --> Parser Class Initialized
INFO - 2016-10-13 17:14:31 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:31 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:14:31 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:14:31 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:31 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 17:14:31 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 17:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:14:31 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:14:31 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 17:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:14:31 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:14:31 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:31 --> Total execution time: 0.0520
INFO - 2016-10-13 17:14:33 --> Config Class Initialized
INFO - 2016-10-13 17:14:33 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:33 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:33 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:33 --> URI Class Initialized
INFO - 2016-10-13 17:14:33 --> Router Class Initialized
INFO - 2016-10-13 17:14:33 --> Output Class Initialized
INFO - 2016-10-13 17:14:33 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:33 --> Input Class Initialized
INFO - 2016-10-13 17:14:33 --> Language Class Initialized
INFO - 2016-10-13 17:14:33 --> Language Class Initialized
INFO - 2016-10-13 17:14:33 --> Config Class Initialized
INFO - 2016-10-13 17:14:33 --> Loader Class Initialized
INFO - 2016-10-13 17:14:33 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:33 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:33 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:33 --> Parser Class Initialized
INFO - 2016-10-13 17:14:33 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:33 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:14:33 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:14:33 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:33 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:33 --> Pagination Class Initialized
DEBUG - 2016-10-13 17:14:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 17:14:33 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:33 --> Total execution time: 0.0439
INFO - 2016-10-13 17:14:33 --> Config Class Initialized
INFO - 2016-10-13 17:14:33 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:33 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:33 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:33 --> URI Class Initialized
INFO - 2016-10-13 17:14:33 --> Router Class Initialized
INFO - 2016-10-13 17:14:33 --> Output Class Initialized
INFO - 2016-10-13 17:14:33 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:33 --> Input Class Initialized
INFO - 2016-10-13 17:14:33 --> Language Class Initialized
ERROR - 2016-10-13 17:14:33 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:14:34 --> Config Class Initialized
INFO - 2016-10-13 17:14:34 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:34 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:34 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:34 --> URI Class Initialized
INFO - 2016-10-13 17:14:34 --> Router Class Initialized
INFO - 2016-10-13 17:14:34 --> Output Class Initialized
INFO - 2016-10-13 17:14:34 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:34 --> Input Class Initialized
INFO - 2016-10-13 17:14:34 --> Language Class Initialized
ERROR - 2016-10-13 17:14:34 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:14:37 --> Config Class Initialized
INFO - 2016-10-13 17:14:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:37 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:37 --> URI Class Initialized
INFO - 2016-10-13 17:14:37 --> Router Class Initialized
INFO - 2016-10-13 17:14:37 --> Output Class Initialized
INFO - 2016-10-13 17:14:37 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:37 --> Input Class Initialized
INFO - 2016-10-13 17:14:37 --> Language Class Initialized
INFO - 2016-10-13 17:14:37 --> Language Class Initialized
INFO - 2016-10-13 17:14:37 --> Config Class Initialized
INFO - 2016-10-13 17:14:37 --> Loader Class Initialized
INFO - 2016-10-13 17:14:37 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:37 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:37 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:37 --> Parser Class Initialized
INFO - 2016-10-13 17:14:37 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:37 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:14:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:14:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 17:14:37 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:14:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:14:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:14:37 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:37 --> Total execution time: 0.0423
INFO - 2016-10-13 17:14:37 --> Config Class Initialized
INFO - 2016-10-13 17:14:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:37 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:37 --> URI Class Initialized
INFO - 2016-10-13 17:14:37 --> Router Class Initialized
INFO - 2016-10-13 17:14:37 --> Output Class Initialized
INFO - 2016-10-13 17:14:37 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:37 --> Input Class Initialized
INFO - 2016-10-13 17:14:37 --> Language Class Initialized
INFO - 2016-10-13 17:14:37 --> Language Class Initialized
INFO - 2016-10-13 17:14:37 --> Config Class Initialized
INFO - 2016-10-13 17:14:37 --> Loader Class Initialized
INFO - 2016-10-13 17:14:37 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:37 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:37 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:37 --> Parser Class Initialized
INFO - 2016-10-13 17:14:37 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:37 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:14:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:14:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:37 --> Pagination Class Initialized
DEBUG - 2016-10-13 17:14:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 17:14:37 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:37 --> Total execution time: 0.0383
INFO - 2016-10-13 17:14:41 --> Config Class Initialized
INFO - 2016-10-13 17:14:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:41 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:41 --> URI Class Initialized
INFO - 2016-10-13 17:14:41 --> Router Class Initialized
INFO - 2016-10-13 17:14:41 --> Output Class Initialized
INFO - 2016-10-13 17:14:41 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:41 --> Input Class Initialized
INFO - 2016-10-13 17:14:41 --> Language Class Initialized
ERROR - 2016-10-13 17:14:41 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:14:42 --> Config Class Initialized
INFO - 2016-10-13 17:14:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:42 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:42 --> URI Class Initialized
INFO - 2016-10-13 17:14:42 --> Router Class Initialized
INFO - 2016-10-13 17:14:42 --> Output Class Initialized
INFO - 2016-10-13 17:14:42 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:42 --> Input Class Initialized
INFO - 2016-10-13 17:14:42 --> Language Class Initialized
INFO - 2016-10-13 17:14:42 --> Language Class Initialized
INFO - 2016-10-13 17:14:42 --> Config Class Initialized
INFO - 2016-10-13 17:14:42 --> Loader Class Initialized
INFO - 2016-10-13 17:14:42 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:42 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:42 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:42 --> Parser Class Initialized
INFO - 2016-10-13 17:14:42 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:42 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:14:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:14:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 17:14:42 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 17:14:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:14:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:14:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 17:14:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:14:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:14:42 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:14:42 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:42 --> Total execution time: 0.0433
INFO - 2016-10-13 17:14:43 --> Config Class Initialized
INFO - 2016-10-13 17:14:43 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:43 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:43 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:43 --> URI Class Initialized
INFO - 2016-10-13 17:14:43 --> Router Class Initialized
INFO - 2016-10-13 17:14:43 --> Output Class Initialized
INFO - 2016-10-13 17:14:43 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:43 --> Input Class Initialized
INFO - 2016-10-13 17:14:43 --> Language Class Initialized
INFO - 2016-10-13 17:14:43 --> Language Class Initialized
INFO - 2016-10-13 17:14:43 --> Config Class Initialized
INFO - 2016-10-13 17:14:43 --> Loader Class Initialized
INFO - 2016-10-13 17:14:43 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:43 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:43 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:43 --> Parser Class Initialized
INFO - 2016-10-13 17:14:43 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:43 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:14:43 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:14:43 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:43 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:43 --> Pagination Class Initialized
DEBUG - 2016-10-13 17:14:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 17:14:43 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:43 --> Total execution time: 0.0369
INFO - 2016-10-13 17:14:45 --> Config Class Initialized
INFO - 2016-10-13 17:14:45 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:45 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:45 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:45 --> URI Class Initialized
INFO - 2016-10-13 17:14:45 --> Router Class Initialized
INFO - 2016-10-13 17:14:45 --> Output Class Initialized
INFO - 2016-10-13 17:14:45 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:45 --> Input Class Initialized
INFO - 2016-10-13 17:14:45 --> Language Class Initialized
INFO - 2016-10-13 17:14:45 --> Language Class Initialized
INFO - 2016-10-13 17:14:45 --> Config Class Initialized
INFO - 2016-10-13 17:14:45 --> Loader Class Initialized
INFO - 2016-10-13 17:14:45 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:45 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:45 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:45 --> Parser Class Initialized
INFO - 2016-10-13 17:14:45 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:45 --> Slider MX_Controller Initialized
INFO - 2016-10-13 17:14:45 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:45 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 17:14:45 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:45 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:45 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 17:14:45 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 17:14:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:14:45 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:14:45 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:45 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/BACKEND/index.php
DEBUG - 2016-10-13 17:14:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:14:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:14:45 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:14:45 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:45 --> Total execution time: 0.0424
INFO - 2016-10-13 17:14:46 --> Config Class Initialized
INFO - 2016-10-13 17:14:46 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:46 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:46 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:46 --> URI Class Initialized
INFO - 2016-10-13 17:14:46 --> Router Class Initialized
INFO - 2016-10-13 17:14:46 --> Output Class Initialized
INFO - 2016-10-13 17:14:46 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:46 --> Input Class Initialized
INFO - 2016-10-13 17:14:46 --> Language Class Initialized
ERROR - 2016-10-13 17:14:46 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:14:46 --> Config Class Initialized
INFO - 2016-10-13 17:14:46 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:46 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:46 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:46 --> URI Class Initialized
INFO - 2016-10-13 17:14:46 --> Router Class Initialized
INFO - 2016-10-13 17:14:46 --> Output Class Initialized
INFO - 2016-10-13 17:14:46 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:46 --> Input Class Initialized
INFO - 2016-10-13 17:14:46 --> Language Class Initialized
INFO - 2016-10-13 17:14:46 --> Language Class Initialized
INFO - 2016-10-13 17:14:46 --> Config Class Initialized
INFO - 2016-10-13 17:14:46 --> Loader Class Initialized
INFO - 2016-10-13 17:14:46 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:46 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:46 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:46 --> Parser Class Initialized
INFO - 2016-10-13 17:14:46 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:46 --> Slider MX_Controller Initialized
INFO - 2016-10-13 17:14:46 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 17:14:46 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:46 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:46 --> Pagination Class Initialized
DEBUG - 2016-10-13 17:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 17:14:46 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:46 --> Total execution time: 0.0471
INFO - 2016-10-13 17:14:48 --> Config Class Initialized
INFO - 2016-10-13 17:14:48 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:48 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:48 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:48 --> URI Class Initialized
INFO - 2016-10-13 17:14:48 --> Router Class Initialized
INFO - 2016-10-13 17:14:48 --> Output Class Initialized
INFO - 2016-10-13 17:14:48 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:48 --> Input Class Initialized
INFO - 2016-10-13 17:14:48 --> Language Class Initialized
INFO - 2016-10-13 17:14:48 --> Language Class Initialized
INFO - 2016-10-13 17:14:48 --> Config Class Initialized
INFO - 2016-10-13 17:14:48 --> Loader Class Initialized
INFO - 2016-10-13 17:14:48 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:48 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:48 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:48 --> Parser Class Initialized
INFO - 2016-10-13 17:14:48 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:48 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:14:48 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:14:48 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:48 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:48 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 17:14:48 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 17:14:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:14:48 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:14:48 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 17:14:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:14:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:14:48 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:14:48 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:48 --> Total execution time: 0.0491
INFO - 2016-10-13 17:14:49 --> Config Class Initialized
INFO - 2016-10-13 17:14:49 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:49 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:49 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:49 --> URI Class Initialized
INFO - 2016-10-13 17:14:49 --> Router Class Initialized
INFO - 2016-10-13 17:14:49 --> Output Class Initialized
INFO - 2016-10-13 17:14:49 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:49 --> Input Class Initialized
INFO - 2016-10-13 17:14:49 --> Language Class Initialized
INFO - 2016-10-13 17:14:49 --> Language Class Initialized
INFO - 2016-10-13 17:14:49 --> Config Class Initialized
INFO - 2016-10-13 17:14:49 --> Loader Class Initialized
INFO - 2016-10-13 17:14:49 --> Helper loaded: common_helper
INFO - 2016-10-13 17:14:49 --> Helper loaded: url_helper
INFO - 2016-10-13 17:14:49 --> Database Driver Class Initialized
INFO - 2016-10-13 17:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:14:49 --> Parser Class Initialized
INFO - 2016-10-13 17:14:49 --> Controller Class Initialized
DEBUG - 2016-10-13 17:14:49 --> Servers MX_Controller Initialized
INFO - 2016-10-13 17:14:49 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:14:49 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:14:49 --> Model Class Initialized
DEBUG - 2016-10-13 17:14:49 --> Pagination Class Initialized
DEBUG - 2016-10-13 17:14:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 17:14:49 --> Final output sent to browser
DEBUG - 2016-10-13 17:14:49 --> Total execution time: 0.0362
INFO - 2016-10-13 17:14:56 --> Config Class Initialized
INFO - 2016-10-13 17:14:56 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:14:56 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:14:56 --> Utf8 Class Initialized
INFO - 2016-10-13 17:14:56 --> URI Class Initialized
INFO - 2016-10-13 17:14:56 --> Router Class Initialized
INFO - 2016-10-13 17:14:56 --> Output Class Initialized
INFO - 2016-10-13 17:14:56 --> Security Class Initialized
DEBUG - 2016-10-13 17:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:14:56 --> Input Class Initialized
INFO - 2016-10-13 17:14:56 --> Language Class Initialized
ERROR - 2016-10-13 17:14:56 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:15:04 --> Config Class Initialized
INFO - 2016-10-13 17:15:04 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:04 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:04 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:04 --> URI Class Initialized
INFO - 2016-10-13 17:15:04 --> Router Class Initialized
INFO - 2016-10-13 17:15:04 --> Output Class Initialized
INFO - 2016-10-13 17:15:04 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:04 --> Input Class Initialized
INFO - 2016-10-13 17:15:04 --> Language Class Initialized
INFO - 2016-10-13 17:15:04 --> Language Class Initialized
INFO - 2016-10-13 17:15:04 --> Config Class Initialized
INFO - 2016-10-13 17:15:04 --> Loader Class Initialized
INFO - 2016-10-13 17:15:04 --> Helper loaded: common_helper
INFO - 2016-10-13 17:15:04 --> Helper loaded: url_helper
INFO - 2016-10-13 17:15:04 --> Database Driver Class Initialized
INFO - 2016-10-13 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:15:04 --> Parser Class Initialized
INFO - 2016-10-13 17:15:04 --> Controller Class Initialized
DEBUG - 2016-10-13 17:15:04 --> Home MX_Controller Initialized
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 17:15:04 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 17:15:04 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 17:15:04 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 17:15:04 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 17:15:04 --> Final output sent to browser
DEBUG - 2016-10-13 17:15:04 --> Total execution time: 0.0785
INFO - 2016-10-13 17:15:04 --> Config Class Initialized
INFO - 2016-10-13 17:15:04 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:04 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:04 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:04 --> URI Class Initialized
INFO - 2016-10-13 17:15:04 --> Router Class Initialized
INFO - 2016-10-13 17:15:04 --> Output Class Initialized
INFO - 2016-10-13 17:15:04 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:04 --> Input Class Initialized
INFO - 2016-10-13 17:15:04 --> Language Class Initialized
INFO - 2016-10-13 17:15:04 --> Language Class Initialized
INFO - 2016-10-13 17:15:04 --> Config Class Initialized
INFO - 2016-10-13 17:15:04 --> Loader Class Initialized
INFO - 2016-10-13 17:15:04 --> Helper loaded: common_helper
INFO - 2016-10-13 17:15:04 --> Helper loaded: url_helper
INFO - 2016-10-13 17:15:04 --> Database Driver Class Initialized
INFO - 2016-10-13 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:15:04 --> Parser Class Initialized
INFO - 2016-10-13 17:15:04 --> Controller Class Initialized
DEBUG - 2016-10-13 17:15:04 --> Home MX_Controller Initialized
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 17:15:04 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 17:15:04 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 17:15:04 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 17:15:04 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:15:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 17:15:04 --> Final output sent to browser
DEBUG - 2016-10-13 17:15:04 --> Total execution time: 0.0620
INFO - 2016-10-13 17:15:04 --> Config Class Initialized
INFO - 2016-10-13 17:15:04 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:04 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:04 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:04 --> URI Class Initialized
INFO - 2016-10-13 17:15:04 --> Router Class Initialized
INFO - 2016-10-13 17:15:04 --> Output Class Initialized
INFO - 2016-10-13 17:15:04 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:04 --> Input Class Initialized
INFO - 2016-10-13 17:15:04 --> Language Class Initialized
ERROR - 2016-10-13 17:15:04 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:15:08 --> Config Class Initialized
INFO - 2016-10-13 17:15:08 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:08 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:08 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:08 --> URI Class Initialized
INFO - 2016-10-13 17:15:08 --> Router Class Initialized
INFO - 2016-10-13 17:15:08 --> Output Class Initialized
INFO - 2016-10-13 17:15:08 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:08 --> Input Class Initialized
INFO - 2016-10-13 17:15:08 --> Language Class Initialized
ERROR - 2016-10-13 17:15:08 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:15:35 --> Config Class Initialized
INFO - 2016-10-13 17:15:35 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:35 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:35 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:35 --> URI Class Initialized
INFO - 2016-10-13 17:15:35 --> Router Class Initialized
INFO - 2016-10-13 17:15:35 --> Output Class Initialized
INFO - 2016-10-13 17:15:35 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:35 --> Input Class Initialized
INFO - 2016-10-13 17:15:35 --> Language Class Initialized
ERROR - 2016-10-13 17:15:35 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:15:37 --> Config Class Initialized
INFO - 2016-10-13 17:15:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:37 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:37 --> URI Class Initialized
INFO - 2016-10-13 17:15:37 --> Router Class Initialized
INFO - 2016-10-13 17:15:37 --> Output Class Initialized
INFO - 2016-10-13 17:15:37 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:37 --> Input Class Initialized
INFO - 2016-10-13 17:15:37 --> Language Class Initialized
ERROR - 2016-10-13 17:15:37 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:15:38 --> Config Class Initialized
INFO - 2016-10-13 17:15:38 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:38 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:38 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:38 --> URI Class Initialized
INFO - 2016-10-13 17:15:38 --> Router Class Initialized
INFO - 2016-10-13 17:15:38 --> Output Class Initialized
INFO - 2016-10-13 17:15:38 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:38 --> Input Class Initialized
INFO - 2016-10-13 17:15:38 --> Language Class Initialized
ERROR - 2016-10-13 17:15:38 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:15:38 --> Config Class Initialized
INFO - 2016-10-13 17:15:38 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:38 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:38 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:38 --> URI Class Initialized
INFO - 2016-10-13 17:15:38 --> Router Class Initialized
INFO - 2016-10-13 17:15:38 --> Output Class Initialized
INFO - 2016-10-13 17:15:38 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:38 --> Input Class Initialized
INFO - 2016-10-13 17:15:38 --> Language Class Initialized
ERROR - 2016-10-13 17:15:38 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:15:38 --> Config Class Initialized
INFO - 2016-10-13 17:15:38 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:38 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:38 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:38 --> URI Class Initialized
INFO - 2016-10-13 17:15:38 --> Router Class Initialized
INFO - 2016-10-13 17:15:38 --> Output Class Initialized
INFO - 2016-10-13 17:15:38 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:38 --> Input Class Initialized
INFO - 2016-10-13 17:15:38 --> Language Class Initialized
ERROR - 2016-10-13 17:15:38 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:15:38 --> Config Class Initialized
INFO - 2016-10-13 17:15:38 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:15:38 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:15:38 --> Utf8 Class Initialized
INFO - 2016-10-13 17:15:38 --> URI Class Initialized
INFO - 2016-10-13 17:15:38 --> Router Class Initialized
INFO - 2016-10-13 17:15:38 --> Output Class Initialized
INFO - 2016-10-13 17:15:38 --> Security Class Initialized
DEBUG - 2016-10-13 17:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:15:38 --> Input Class Initialized
INFO - 2016-10-13 17:15:38 --> Language Class Initialized
ERROR - 2016-10-13 17:15:38 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:16:53 --> Config Class Initialized
INFO - 2016-10-13 17:16:53 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:16:53 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:16:53 --> Utf8 Class Initialized
INFO - 2016-10-13 17:16:53 --> URI Class Initialized
INFO - 2016-10-13 17:16:53 --> Router Class Initialized
INFO - 2016-10-13 17:16:53 --> Output Class Initialized
INFO - 2016-10-13 17:16:53 --> Security Class Initialized
DEBUG - 2016-10-13 17:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:16:53 --> Input Class Initialized
INFO - 2016-10-13 17:16:53 --> Language Class Initialized
INFO - 2016-10-13 17:16:53 --> Language Class Initialized
INFO - 2016-10-13 17:16:53 --> Config Class Initialized
INFO - 2016-10-13 17:16:53 --> Loader Class Initialized
INFO - 2016-10-13 17:16:53 --> Helper loaded: common_helper
INFO - 2016-10-13 17:16:53 --> Helper loaded: url_helper
INFO - 2016-10-13 17:16:53 --> Database Driver Class Initialized
INFO - 2016-10-13 17:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:16:53 --> Parser Class Initialized
INFO - 2016-10-13 17:16:53 --> Controller Class Initialized
DEBUG - 2016-10-13 17:16:53 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 17:16:53 --> Model Class Initialized
DEBUG - 2016-10-13 17:16:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:16:53 --> Model Class Initialized
DEBUG - 2016-10-13 17:16:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-13 17:16:53 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:16:53 --> Model Class Initialized
DEBUG - 2016-10-13 17:16:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:16:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:16:53 --> Model Class Initialized
DEBUG - 2016-10-13 17:16:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:16:53 --> Model Class Initialized
DEBUG - 2016-10-13 17:16:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:16:53 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:16:53 --> Final output sent to browser
DEBUG - 2016-10-13 17:16:53 --> Total execution time: 0.0560
INFO - 2016-10-13 17:16:53 --> Config Class Initialized
INFO - 2016-10-13 17:16:53 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:16:53 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:16:53 --> Utf8 Class Initialized
INFO - 2016-10-13 17:16:53 --> URI Class Initialized
INFO - 2016-10-13 17:16:53 --> Router Class Initialized
INFO - 2016-10-13 17:16:53 --> Output Class Initialized
INFO - 2016-10-13 17:16:53 --> Security Class Initialized
DEBUG - 2016-10-13 17:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:16:53 --> Input Class Initialized
INFO - 2016-10-13 17:16:53 --> Language Class Initialized
ERROR - 2016-10-13 17:16:53 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:16:55 --> Config Class Initialized
INFO - 2016-10-13 17:16:55 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:16:55 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:16:55 --> Utf8 Class Initialized
INFO - 2016-10-13 17:16:55 --> URI Class Initialized
INFO - 2016-10-13 17:16:55 --> Router Class Initialized
INFO - 2016-10-13 17:16:55 --> Output Class Initialized
INFO - 2016-10-13 17:16:55 --> Security Class Initialized
DEBUG - 2016-10-13 17:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:16:55 --> Input Class Initialized
INFO - 2016-10-13 17:16:55 --> Language Class Initialized
INFO - 2016-10-13 17:16:55 --> Language Class Initialized
INFO - 2016-10-13 17:16:55 --> Config Class Initialized
INFO - 2016-10-13 17:16:55 --> Loader Class Initialized
INFO - 2016-10-13 17:16:55 --> Helper loaded: common_helper
INFO - 2016-10-13 17:16:55 --> Helper loaded: url_helper
INFO - 2016-10-13 17:16:55 --> Database Driver Class Initialized
INFO - 2016-10-13 17:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:16:55 --> Parser Class Initialized
INFO - 2016-10-13 17:16:55 --> Controller Class Initialized
DEBUG - 2016-10-13 17:16:55 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 17:16:55 --> Model Class Initialized
DEBUG - 2016-10-13 17:16:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:16:55 --> Model Class Initialized
DEBUG - 2016-10-13 17:16:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/security_gt.php
INFO - 2016-10-13 17:16:55 --> Final output sent to browser
DEBUG - 2016-10-13 17:16:55 --> Total execution time: 0.0421
INFO - 2016-10-13 17:19:38 --> Config Class Initialized
INFO - 2016-10-13 17:19:38 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:19:38 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:19:38 --> Utf8 Class Initialized
INFO - 2016-10-13 17:19:38 --> URI Class Initialized
INFO - 2016-10-13 17:19:38 --> Router Class Initialized
INFO - 2016-10-13 17:19:38 --> Output Class Initialized
INFO - 2016-10-13 17:19:38 --> Security Class Initialized
DEBUG - 2016-10-13 17:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:19:38 --> Input Class Initialized
INFO - 2016-10-13 17:19:38 --> Language Class Initialized
INFO - 2016-10-13 17:19:38 --> Language Class Initialized
INFO - 2016-10-13 17:19:38 --> Config Class Initialized
INFO - 2016-10-13 17:19:38 --> Loader Class Initialized
INFO - 2016-10-13 17:19:38 --> Helper loaded: common_helper
INFO - 2016-10-13 17:19:38 --> Helper loaded: url_helper
INFO - 2016-10-13 17:19:38 --> Database Driver Class Initialized
INFO - 2016-10-13 17:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:19:38 --> Parser Class Initialized
INFO - 2016-10-13 17:19:38 --> Controller Class Initialized
DEBUG - 2016-10-13 17:19:38 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:19:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:19:38 --> Model Class Initialized
INFO - 2016-10-13 17:19:38 --> Config Class Initialized
INFO - 2016-10-13 17:19:38 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:19:38 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:19:38 --> Utf8 Class Initialized
INFO - 2016-10-13 17:19:38 --> URI Class Initialized
INFO - 2016-10-13 17:19:38 --> Router Class Initialized
INFO - 2016-10-13 17:19:38 --> Output Class Initialized
INFO - 2016-10-13 17:19:38 --> Security Class Initialized
DEBUG - 2016-10-13 17:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:19:38 --> Input Class Initialized
INFO - 2016-10-13 17:19:38 --> Language Class Initialized
INFO - 2016-10-13 17:19:38 --> Language Class Initialized
INFO - 2016-10-13 17:19:38 --> Config Class Initialized
INFO - 2016-10-13 17:19:38 --> Loader Class Initialized
INFO - 2016-10-13 17:19:38 --> Helper loaded: common_helper
INFO - 2016-10-13 17:19:38 --> Helper loaded: url_helper
INFO - 2016-10-13 17:19:38 --> Database Driver Class Initialized
INFO - 2016-10-13 17:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:19:38 --> Parser Class Initialized
INFO - 2016-10-13 17:19:38 --> Controller Class Initialized
DEBUG - 2016-10-13 17:19:38 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:19:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:19:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/setting.php
ERROR - 2016-10-13 17:19:38 --> Severity: Notice --> Undefined variable: module /home/dolongpk/public_html/application/views/BACKEND/template.php 11
DEBUG - 2016-10-13 17:19:38 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:19:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:19:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:19:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-13 17:19:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:19:38 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:19:38 --> Final output sent to browser
DEBUG - 2016-10-13 17:19:38 --> Total execution time: 0.0443
INFO - 2016-10-13 17:19:40 --> Config Class Initialized
INFO - 2016-10-13 17:19:40 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:19:40 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:19:40 --> Utf8 Class Initialized
INFO - 2016-10-13 17:19:40 --> URI Class Initialized
INFO - 2016-10-13 17:19:40 --> Router Class Initialized
INFO - 2016-10-13 17:19:40 --> Output Class Initialized
INFO - 2016-10-13 17:19:40 --> Security Class Initialized
DEBUG - 2016-10-13 17:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:19:40 --> Input Class Initialized
INFO - 2016-10-13 17:19:40 --> Language Class Initialized
ERROR - 2016-10-13 17:19:40 --> 404 Page Not Found: ../modules/gametool/controllers//index
INFO - 2016-10-13 17:20:44 --> Config Class Initialized
INFO - 2016-10-13 17:20:44 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:20:44 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:20:44 --> Utf8 Class Initialized
INFO - 2016-10-13 17:20:44 --> URI Class Initialized
INFO - 2016-10-13 17:20:44 --> Router Class Initialized
INFO - 2016-10-13 17:20:44 --> Output Class Initialized
INFO - 2016-10-13 17:20:44 --> Security Class Initialized
DEBUG - 2016-10-13 17:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:20:44 --> Input Class Initialized
INFO - 2016-10-13 17:20:44 --> Language Class Initialized
INFO - 2016-10-13 17:20:44 --> Language Class Initialized
INFO - 2016-10-13 17:20:44 --> Config Class Initialized
INFO - 2016-10-13 17:20:44 --> Loader Class Initialized
INFO - 2016-10-13 17:20:44 --> Helper loaded: common_helper
INFO - 2016-10-13 17:20:44 --> Helper loaded: url_helper
INFO - 2016-10-13 17:20:44 --> Database Driver Class Initialized
INFO - 2016-10-13 17:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:20:44 --> Parser Class Initialized
INFO - 2016-10-13 17:20:44 --> Controller Class Initialized
DEBUG - 2016-10-13 17:20:44 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:20:44 --> Model Class Initialized
DEBUG - 2016-10-13 17:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:20:44 --> Model Class Initialized
DEBUG - 2016-10-13 17:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:20:44 --> Model Class Initialized
DEBUG - 2016-10-13 17:20:44 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:20:44 --> Model Class Initialized
DEBUG - 2016-10-13 17:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/index.php
ERROR - 2016-10-13 17:20:44 --> Severity: Warning --> mysql_query(): Access denied for user 'root'@'localhost' (using password: NO) /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/thongke.php 7
ERROR - 2016-10-13 17:20:44 --> Severity: Warning --> mysql_query(): A link to the server could not be established /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/thongke.php 7
ERROR - 2016-10-13 17:20:44 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/thongke.php 9
ERROR - 2016-10-13 17:20:44 --> Severity: Warning --> mysql_query(): Access denied for user 'root'@'localhost' (using password: NO) /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/thongke.php 84
ERROR - 2016-10-13 17:20:44 --> Severity: Warning --> mysql_query(): A link to the server could not be established /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/thongke.php 84
ERROR - 2016-10-13 17:20:44 --> Severity: Warning --> mysql_query(): Access denied for user 'root'@'localhost' (using password: NO) /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/thongke.php 7
ERROR - 2016-10-13 17:20:44 --> Severity: Warning --> mysql_query(): A link to the server could not be established /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/thongke.php 7
ERROR - 2016-10-13 17:20:44 --> Severity: Warning --> mysql_fetch_array() expects parameter 1 to be resource, boolean given /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/thongke.php 9
DEBUG - 2016-10-13 17:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/thongke.php
DEBUG - 2016-10-13 17:20:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:20:44 --> Final output sent to browser
DEBUG - 2016-10-13 17:20:44 --> Total execution time: 0.0561
INFO - 2016-10-13 17:20:44 --> Config Class Initialized
INFO - 2016-10-13 17:20:44 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:20:44 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:20:44 --> Utf8 Class Initialized
INFO - 2016-10-13 17:20:44 --> URI Class Initialized
INFO - 2016-10-13 17:20:44 --> Router Class Initialized
INFO - 2016-10-13 17:20:44 --> Output Class Initialized
INFO - 2016-10-13 17:20:44 --> Security Class Initialized
DEBUG - 2016-10-13 17:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:20:44 --> Input Class Initialized
INFO - 2016-10-13 17:20:44 --> Language Class Initialized
ERROR - 2016-10-13 17:20:44 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:20:44 --> Config Class Initialized
INFO - 2016-10-13 17:20:44 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:20:44 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:20:44 --> Utf8 Class Initialized
INFO - 2016-10-13 17:20:44 --> URI Class Initialized
INFO - 2016-10-13 17:20:44 --> Router Class Initialized
INFO - 2016-10-13 17:20:44 --> Output Class Initialized
INFO - 2016-10-13 17:20:44 --> Security Class Initialized
DEBUG - 2016-10-13 17:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:20:44 --> Input Class Initialized
INFO - 2016-10-13 17:20:44 --> Language Class Initialized
ERROR - 2016-10-13 17:20:44 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:22:13 --> Config Class Initialized
INFO - 2016-10-13 17:22:13 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:22:13 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:22:13 --> Utf8 Class Initialized
INFO - 2016-10-13 17:22:13 --> URI Class Initialized
INFO - 2016-10-13 17:22:13 --> Router Class Initialized
INFO - 2016-10-13 17:22:13 --> Output Class Initialized
INFO - 2016-10-13 17:22:13 --> Security Class Initialized
DEBUG - 2016-10-13 17:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:22:13 --> Input Class Initialized
INFO - 2016-10-13 17:22:13 --> Language Class Initialized
INFO - 2016-10-13 17:22:13 --> Language Class Initialized
INFO - 2016-10-13 17:22:13 --> Config Class Initialized
INFO - 2016-10-13 17:22:13 --> Loader Class Initialized
INFO - 2016-10-13 17:22:13 --> Helper loaded: common_helper
INFO - 2016-10-13 17:22:13 --> Helper loaded: url_helper
INFO - 2016-10-13 17:22:13 --> Database Driver Class Initialized
INFO - 2016-10-13 17:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:22:13 --> Parser Class Initialized
INFO - 2016-10-13 17:22:13 --> Controller Class Initialized
DEBUG - 2016-10-13 17:22:13 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:22:13 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:13 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:22:13 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:22:13 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:13 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:22:13 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:13 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/index.php
INFO - 2016-10-13 17:22:13 --> Config Class Initialized
INFO - 2016-10-13 17:22:13 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:22:13 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:22:13 --> Utf8 Class Initialized
INFO - 2016-10-13 17:22:13 --> URI Class Initialized
INFO - 2016-10-13 17:22:13 --> Router Class Initialized
INFO - 2016-10-13 17:22:13 --> Output Class Initialized
INFO - 2016-10-13 17:22:13 --> Security Class Initialized
DEBUG - 2016-10-13 17:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:22:13 --> Input Class Initialized
INFO - 2016-10-13 17:22:13 --> Language Class Initialized
ERROR - 2016-10-13 17:22:13 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:22:13 --> Config Class Initialized
INFO - 2016-10-13 17:22:13 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:22:13 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:22:13 --> Utf8 Class Initialized
INFO - 2016-10-13 17:22:13 --> URI Class Initialized
INFO - 2016-10-13 17:22:13 --> Router Class Initialized
INFO - 2016-10-13 17:22:13 --> Output Class Initialized
INFO - 2016-10-13 17:22:13 --> Security Class Initialized
DEBUG - 2016-10-13 17:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:22:13 --> Input Class Initialized
INFO - 2016-10-13 17:22:13 --> Language Class Initialized
ERROR - 2016-10-13 17:22:13 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:22:37 --> Config Class Initialized
INFO - 2016-10-13 17:22:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:22:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:22:37 --> Utf8 Class Initialized
INFO - 2016-10-13 17:22:37 --> URI Class Initialized
INFO - 2016-10-13 17:22:37 --> Router Class Initialized
INFO - 2016-10-13 17:22:37 --> Output Class Initialized
INFO - 2016-10-13 17:22:37 --> Security Class Initialized
DEBUG - 2016-10-13 17:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:22:37 --> Input Class Initialized
INFO - 2016-10-13 17:22:37 --> Language Class Initialized
INFO - 2016-10-13 17:22:37 --> Language Class Initialized
INFO - 2016-10-13 17:22:37 --> Config Class Initialized
INFO - 2016-10-13 17:22:37 --> Loader Class Initialized
INFO - 2016-10-13 17:22:37 --> Helper loaded: common_helper
INFO - 2016-10-13 17:22:37 --> Helper loaded: url_helper
INFO - 2016-10-13 17:22:37 --> Database Driver Class Initialized
INFO - 2016-10-13 17:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:22:37 --> Parser Class Initialized
INFO - 2016-10-13 17:22:37 --> Controller Class Initialized
DEBUG - 2016-10-13 17:22:37 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:22:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:37 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:22:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:22:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:37 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:22:37 --> Model Class Initialized
ERROR - 2016-10-13 17:22:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php 46
DEBUG - 2016-10-13 17:22:37 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-13 17:22:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:22:37 --> Final output sent to browser
DEBUG - 2016-10-13 17:22:37 --> Total execution time: 0.0509
INFO - 2016-10-13 17:22:37 --> Config Class Initialized
INFO - 2016-10-13 17:22:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:22:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:22:37 --> Utf8 Class Initialized
INFO - 2016-10-13 17:22:37 --> URI Class Initialized
INFO - 2016-10-13 17:22:37 --> Router Class Initialized
INFO - 2016-10-13 17:22:37 --> Output Class Initialized
INFO - 2016-10-13 17:22:37 --> Security Class Initialized
DEBUG - 2016-10-13 17:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:22:37 --> Input Class Initialized
INFO - 2016-10-13 17:22:37 --> Language Class Initialized
ERROR - 2016-10-13 17:22:37 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:22:37 --> Config Class Initialized
INFO - 2016-10-13 17:22:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:22:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:22:37 --> Utf8 Class Initialized
INFO - 2016-10-13 17:22:37 --> URI Class Initialized
INFO - 2016-10-13 17:22:37 --> Router Class Initialized
INFO - 2016-10-13 17:22:37 --> Output Class Initialized
INFO - 2016-10-13 17:22:37 --> Security Class Initialized
DEBUG - 2016-10-13 17:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:22:37 --> Input Class Initialized
INFO - 2016-10-13 17:22:37 --> Language Class Initialized
ERROR - 2016-10-13 17:22:37 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:22:43 --> Config Class Initialized
INFO - 2016-10-13 17:22:43 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:22:43 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:22:43 --> Utf8 Class Initialized
INFO - 2016-10-13 17:22:43 --> URI Class Initialized
INFO - 2016-10-13 17:22:43 --> Router Class Initialized
INFO - 2016-10-13 17:22:43 --> Output Class Initialized
INFO - 2016-10-13 17:22:43 --> Security Class Initialized
DEBUG - 2016-10-13 17:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:22:43 --> Input Class Initialized
INFO - 2016-10-13 17:22:43 --> Language Class Initialized
INFO - 2016-10-13 17:22:43 --> Language Class Initialized
INFO - 2016-10-13 17:22:43 --> Config Class Initialized
INFO - 2016-10-13 17:22:43 --> Loader Class Initialized
INFO - 2016-10-13 17:22:43 --> Helper loaded: common_helper
INFO - 2016-10-13 17:22:43 --> Helper loaded: url_helper
INFO - 2016-10-13 17:22:43 --> Database Driver Class Initialized
INFO - 2016-10-13 17:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:22:43 --> Parser Class Initialized
INFO - 2016-10-13 17:22:43 --> Controller Class Initialized
DEBUG - 2016-10-13 17:22:43 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:22:43 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:43 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:22:43 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:22:43 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:43 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:22:43 --> Model Class Initialized
DEBUG - 2016-10-13 17:22:43 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/index.php
INFO - 2016-10-13 17:22:44 --> Config Class Initialized
INFO - 2016-10-13 17:22:44 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:22:44 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:22:44 --> Utf8 Class Initialized
INFO - 2016-10-13 17:22:44 --> URI Class Initialized
INFO - 2016-10-13 17:22:44 --> Router Class Initialized
INFO - 2016-10-13 17:22:44 --> Output Class Initialized
INFO - 2016-10-13 17:22:44 --> Security Class Initialized
DEBUG - 2016-10-13 17:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:22:44 --> Input Class Initialized
INFO - 2016-10-13 17:22:44 --> Language Class Initialized
ERROR - 2016-10-13 17:22:44 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:22:44 --> Config Class Initialized
INFO - 2016-10-13 17:22:44 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:22:44 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:22:44 --> Utf8 Class Initialized
INFO - 2016-10-13 17:22:44 --> URI Class Initialized
INFO - 2016-10-13 17:22:44 --> Router Class Initialized
INFO - 2016-10-13 17:22:44 --> Output Class Initialized
INFO - 2016-10-13 17:22:44 --> Security Class Initialized
DEBUG - 2016-10-13 17:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:22:44 --> Input Class Initialized
INFO - 2016-10-13 17:22:44 --> Language Class Initialized
ERROR - 2016-10-13 17:22:44 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:24:37 --> Config Class Initialized
INFO - 2016-10-13 17:24:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:24:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:24:37 --> Utf8 Class Initialized
INFO - 2016-10-13 17:24:37 --> URI Class Initialized
INFO - 2016-10-13 17:24:37 --> Router Class Initialized
INFO - 2016-10-13 17:24:37 --> Output Class Initialized
INFO - 2016-10-13 17:24:37 --> Security Class Initialized
DEBUG - 2016-10-13 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:24:37 --> Input Class Initialized
INFO - 2016-10-13 17:24:37 --> Language Class Initialized
INFO - 2016-10-13 17:24:37 --> Language Class Initialized
INFO - 2016-10-13 17:24:37 --> Config Class Initialized
INFO - 2016-10-13 17:24:37 --> Loader Class Initialized
INFO - 2016-10-13 17:24:37 --> Helper loaded: common_helper
INFO - 2016-10-13 17:24:37 --> Helper loaded: url_helper
INFO - 2016-10-13 17:24:37 --> Database Driver Class Initialized
INFO - 2016-10-13 17:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:24:37 --> Parser Class Initialized
INFO - 2016-10-13 17:24:37 --> Controller Class Initialized
DEBUG - 2016-10-13 17:24:37 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:24:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:24:37 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:24:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:24:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:24:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:24:37 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:24:37 --> Model Class Initialized
DEBUG - 2016-10-13 17:24:37 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/index.php
INFO - 2016-10-13 17:24:37 --> Config Class Initialized
INFO - 2016-10-13 17:24:37 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:24:37 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:24:37 --> Utf8 Class Initialized
INFO - 2016-10-13 17:24:37 --> URI Class Initialized
INFO - 2016-10-13 17:24:37 --> Router Class Initialized
INFO - 2016-10-13 17:24:37 --> Output Class Initialized
INFO - 2016-10-13 17:24:37 --> Security Class Initialized
DEBUG - 2016-10-13 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:24:37 --> Input Class Initialized
INFO - 2016-10-13 17:24:37 --> Language Class Initialized
ERROR - 2016-10-13 17:24:37 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:26:11 --> Config Class Initialized
INFO - 2016-10-13 17:26:11 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:26:11 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:26:11 --> Utf8 Class Initialized
INFO - 2016-10-13 17:26:11 --> URI Class Initialized
INFO - 2016-10-13 17:26:11 --> Router Class Initialized
INFO - 2016-10-13 17:26:11 --> Output Class Initialized
INFO - 2016-10-13 17:26:11 --> Security Class Initialized
DEBUG - 2016-10-13 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:26:11 --> Input Class Initialized
INFO - 2016-10-13 17:26:11 --> Language Class Initialized
INFO - 2016-10-13 17:26:11 --> Language Class Initialized
INFO - 2016-10-13 17:26:11 --> Config Class Initialized
INFO - 2016-10-13 17:26:11 --> Loader Class Initialized
INFO - 2016-10-13 17:26:11 --> Helper loaded: common_helper
INFO - 2016-10-13 17:26:11 --> Helper loaded: url_helper
INFO - 2016-10-13 17:26:11 --> Database Driver Class Initialized
INFO - 2016-10-13 17:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:26:11 --> Parser Class Initialized
INFO - 2016-10-13 17:26:11 --> Controller Class Initialized
DEBUG - 2016-10-13 17:26:11 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:26:11 --> Model Class Initialized
DEBUG - 2016-10-13 17:26:11 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:26:11 --> Model Class Initialized
DEBUG - 2016-10-13 17:26:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:26:11 --> Model Class Initialized
DEBUG - 2016-10-13 17:26:11 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:26:11 --> Model Class Initialized
DEBUG - 2016-10-13 17:26:11 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:26:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:26:11 --> Final output sent to browser
DEBUG - 2016-10-13 17:26:11 --> Total execution time: 0.0462
INFO - 2016-10-13 17:26:11 --> Config Class Initialized
INFO - 2016-10-13 17:26:11 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:26:11 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:26:11 --> Utf8 Class Initialized
INFO - 2016-10-13 17:26:11 --> URI Class Initialized
INFO - 2016-10-13 17:26:11 --> Router Class Initialized
INFO - 2016-10-13 17:26:11 --> Output Class Initialized
INFO - 2016-10-13 17:26:11 --> Security Class Initialized
DEBUG - 2016-10-13 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:26:11 --> Input Class Initialized
INFO - 2016-10-13 17:26:11 --> Language Class Initialized
ERROR - 2016-10-13 17:26:11 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:26:11 --> Config Class Initialized
INFO - 2016-10-13 17:26:11 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:26:11 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:26:11 --> Utf8 Class Initialized
INFO - 2016-10-13 17:26:11 --> URI Class Initialized
INFO - 2016-10-13 17:26:11 --> Router Class Initialized
INFO - 2016-10-13 17:26:11 --> Output Class Initialized
INFO - 2016-10-13 17:26:11 --> Security Class Initialized
DEBUG - 2016-10-13 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:26:11 --> Input Class Initialized
INFO - 2016-10-13 17:26:11 --> Language Class Initialized
ERROR - 2016-10-13 17:26:11 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:26:16 --> Config Class Initialized
INFO - 2016-10-13 17:26:16 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:26:16 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:26:16 --> Utf8 Class Initialized
INFO - 2016-10-13 17:26:16 --> URI Class Initialized
INFO - 2016-10-13 17:26:16 --> Router Class Initialized
INFO - 2016-10-13 17:26:16 --> Output Class Initialized
INFO - 2016-10-13 17:26:16 --> Security Class Initialized
DEBUG - 2016-10-13 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:26:16 --> Input Class Initialized
INFO - 2016-10-13 17:26:16 --> Language Class Initialized
INFO - 2016-10-13 17:26:16 --> Language Class Initialized
INFO - 2016-10-13 17:26:16 --> Config Class Initialized
INFO - 2016-10-13 17:26:16 --> Loader Class Initialized
INFO - 2016-10-13 17:26:16 --> Helper loaded: common_helper
INFO - 2016-10-13 17:26:16 --> Helper loaded: url_helper
INFO - 2016-10-13 17:26:16 --> Database Driver Class Initialized
INFO - 2016-10-13 17:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:26:16 --> Parser Class Initialized
INFO - 2016-10-13 17:26:16 --> Controller Class Initialized
DEBUG - 2016-10-13 17:26:16 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2016-10-13 17:26:16 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2016-10-13 17:26:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:26:16 --> Model Class Initialized
DEBUG - 2016-10-13 17:26:16 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:26:16 --> Model Class Initialized
ERROR - 2016-10-13 17:26:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php 46
DEBUG - 2016-10-13 17:26:16 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-13 17:26:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:26:16 --> Final output sent to browser
DEBUG - 2016-10-13 17:26:16 --> Total execution time: 0.0489
INFO - 2016-10-13 17:26:16 --> Config Class Initialized
INFO - 2016-10-13 17:26:16 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:26:16 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:26:16 --> Utf8 Class Initialized
INFO - 2016-10-13 17:26:16 --> URI Class Initialized
INFO - 2016-10-13 17:26:16 --> Router Class Initialized
INFO - 2016-10-13 17:26:16 --> Output Class Initialized
INFO - 2016-10-13 17:26:16 --> Security Class Initialized
DEBUG - 2016-10-13 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:26:16 --> Input Class Initialized
INFO - 2016-10-13 17:26:16 --> Language Class Initialized
ERROR - 2016-10-13 17:26:16 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:26:16 --> Config Class Initialized
INFO - 2016-10-13 17:26:16 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:26:16 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:26:16 --> Utf8 Class Initialized
INFO - 2016-10-13 17:26:16 --> URI Class Initialized
INFO - 2016-10-13 17:26:16 --> Router Class Initialized
INFO - 2016-10-13 17:26:16 --> Output Class Initialized
INFO - 2016-10-13 17:26:16 --> Security Class Initialized
DEBUG - 2016-10-13 17:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:26:16 --> Input Class Initialized
INFO - 2016-10-13 17:26:16 --> Language Class Initialized
ERROR - 2016-10-13 17:26:16 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:05 --> Config Class Initialized
INFO - 2016-10-13 17:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:05 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:05 --> URI Class Initialized
INFO - 2016-10-13 17:27:05 --> Router Class Initialized
INFO - 2016-10-13 17:27:05 --> Output Class Initialized
INFO - 2016-10-13 17:27:05 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:05 --> Input Class Initialized
INFO - 2016-10-13 17:27:05 --> Language Class Initialized
INFO - 2016-10-13 17:27:05 --> Language Class Initialized
INFO - 2016-10-13 17:27:05 --> Config Class Initialized
INFO - 2016-10-13 17:27:05 --> Loader Class Initialized
INFO - 2016-10-13 17:27:05 --> Helper loaded: common_helper
INFO - 2016-10-13 17:27:05 --> Helper loaded: url_helper
INFO - 2016-10-13 17:27:05 --> Database Driver Class Initialized
INFO - 2016-10-13 17:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:27:05 --> Parser Class Initialized
INFO - 2016-10-13 17:27:05 --> Controller Class Initialized
DEBUG - 2016-10-13 17:27:05 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:27:05 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:05 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:05 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:27:05 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:05 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:05 --> Model Class Initialized
ERROR - 2016-10-13 17:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php 46
DEBUG - 2016-10-13 17:27:05 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-13 17:27:05 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:27:05 --> Final output sent to browser
DEBUG - 2016-10-13 17:27:05 --> Total execution time: 0.0505
INFO - 2016-10-13 17:27:05 --> Config Class Initialized
INFO - 2016-10-13 17:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:05 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:05 --> URI Class Initialized
INFO - 2016-10-13 17:27:05 --> Router Class Initialized
INFO - 2016-10-13 17:27:05 --> Output Class Initialized
INFO - 2016-10-13 17:27:05 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:05 --> Input Class Initialized
INFO - 2016-10-13 17:27:05 --> Language Class Initialized
ERROR - 2016-10-13 17:27:05 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:05 --> Config Class Initialized
INFO - 2016-10-13 17:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:05 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:05 --> URI Class Initialized
INFO - 2016-10-13 17:27:05 --> Router Class Initialized
INFO - 2016-10-13 17:27:05 --> Output Class Initialized
INFO - 2016-10-13 17:27:05 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:05 --> Input Class Initialized
INFO - 2016-10-13 17:27:05 --> Language Class Initialized
INFO - 2016-10-13 17:27:05 --> Language Class Initialized
INFO - 2016-10-13 17:27:05 --> Config Class Initialized
INFO - 2016-10-13 17:27:05 --> Loader Class Initialized
INFO - 2016-10-13 17:27:05 --> Helper loaded: common_helper
INFO - 2016-10-13 17:27:05 --> Helper loaded: url_helper
INFO - 2016-10-13 17:27:05 --> Database Driver Class Initialized
INFO - 2016-10-13 17:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:27:05 --> Parser Class Initialized
INFO - 2016-10-13 17:27:05 --> Controller Class Initialized
DEBUG - 2016-10-13 17:27:05 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:27:05 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:05 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:05 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:27:05 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:05 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:05 --> Model Class Initialized
ERROR - 2016-10-13 17:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php 46
DEBUG - 2016-10-13 17:27:05 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-13 17:27:05 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:27:05 --> Final output sent to browser
DEBUG - 2016-10-13 17:27:05 --> Total execution time: 0.0487
INFO - 2016-10-13 17:27:05 --> Config Class Initialized
INFO - 2016-10-13 17:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:05 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:05 --> URI Class Initialized
INFO - 2016-10-13 17:27:05 --> Router Class Initialized
INFO - 2016-10-13 17:27:05 --> Output Class Initialized
INFO - 2016-10-13 17:27:05 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:05 --> Input Class Initialized
INFO - 2016-10-13 17:27:05 --> Language Class Initialized
ERROR - 2016-10-13 17:27:05 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:05 --> Config Class Initialized
INFO - 2016-10-13 17:27:05 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:05 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:05 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:05 --> URI Class Initialized
INFO - 2016-10-13 17:27:05 --> Router Class Initialized
INFO - 2016-10-13 17:27:05 --> Output Class Initialized
INFO - 2016-10-13 17:27:05 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:05 --> Input Class Initialized
INFO - 2016-10-13 17:27:05 --> Language Class Initialized
ERROR - 2016-10-13 17:27:05 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:06 --> Config Class Initialized
INFO - 2016-10-13 17:27:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:06 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:06 --> URI Class Initialized
INFO - 2016-10-13 17:27:06 --> Router Class Initialized
INFO - 2016-10-13 17:27:06 --> Output Class Initialized
INFO - 2016-10-13 17:27:06 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:06 --> Input Class Initialized
INFO - 2016-10-13 17:27:06 --> Language Class Initialized
INFO - 2016-10-13 17:27:06 --> Language Class Initialized
INFO - 2016-10-13 17:27:06 --> Config Class Initialized
INFO - 2016-10-13 17:27:06 --> Loader Class Initialized
INFO - 2016-10-13 17:27:06 --> Helper loaded: common_helper
INFO - 2016-10-13 17:27:06 --> Helper loaded: url_helper
INFO - 2016-10-13 17:27:06 --> Database Driver Class Initialized
INFO - 2016-10-13 17:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:27:06 --> Parser Class Initialized
INFO - 2016-10-13 17:27:06 --> Controller Class Initialized
DEBUG - 2016-10-13 17:27:06 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:27:06 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:06 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:06 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:27:06 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:06 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:06 --> Model Class Initialized
ERROR - 2016-10-13 17:27:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php 46
DEBUG - 2016-10-13 17:27:06 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-13 17:27:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:27:06 --> Final output sent to browser
DEBUG - 2016-10-13 17:27:06 --> Total execution time: 0.0423
INFO - 2016-10-13 17:27:06 --> Config Class Initialized
INFO - 2016-10-13 17:27:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:06 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:06 --> URI Class Initialized
INFO - 2016-10-13 17:27:06 --> Router Class Initialized
INFO - 2016-10-13 17:27:06 --> Output Class Initialized
INFO - 2016-10-13 17:27:06 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:06 --> Input Class Initialized
INFO - 2016-10-13 17:27:06 --> Language Class Initialized
ERROR - 2016-10-13 17:27:06 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:06 --> Config Class Initialized
INFO - 2016-10-13 17:27:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:06 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:06 --> URI Class Initialized
INFO - 2016-10-13 17:27:06 --> Router Class Initialized
INFO - 2016-10-13 17:27:06 --> Output Class Initialized
INFO - 2016-10-13 17:27:06 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:06 --> Input Class Initialized
INFO - 2016-10-13 17:27:06 --> Language Class Initialized
ERROR - 2016-10-13 17:27:06 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:41 --> Config Class Initialized
INFO - 2016-10-13 17:27:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:41 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:41 --> URI Class Initialized
INFO - 2016-10-13 17:27:41 --> Router Class Initialized
INFO - 2016-10-13 17:27:41 --> Output Class Initialized
INFO - 2016-10-13 17:27:41 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:41 --> Input Class Initialized
INFO - 2016-10-13 17:27:41 --> Language Class Initialized
INFO - 2016-10-13 17:27:41 --> Language Class Initialized
INFO - 2016-10-13 17:27:41 --> Config Class Initialized
INFO - 2016-10-13 17:27:41 --> Loader Class Initialized
INFO - 2016-10-13 17:27:41 --> Helper loaded: common_helper
INFO - 2016-10-13 17:27:41 --> Helper loaded: url_helper
INFO - 2016-10-13 17:27:41 --> Database Driver Class Initialized
INFO - 2016-10-13 17:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:27:41 --> Parser Class Initialized
INFO - 2016-10-13 17:27:41 --> Controller Class Initialized
DEBUG - 2016-10-13 17:27:41 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:27:41 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:41 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:41 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:27:41 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:41 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:41 --> Model Class Initialized
ERROR - 2016-10-13 17:27:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php 46
DEBUG - 2016-10-13 17:27:41 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-13 17:27:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:27:41 --> Final output sent to browser
DEBUG - 2016-10-13 17:27:41 --> Total execution time: 0.0508
INFO - 2016-10-13 17:27:41 --> Config Class Initialized
INFO - 2016-10-13 17:27:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:41 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:41 --> URI Class Initialized
INFO - 2016-10-13 17:27:41 --> Router Class Initialized
INFO - 2016-10-13 17:27:41 --> Output Class Initialized
INFO - 2016-10-13 17:27:41 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:41 --> Input Class Initialized
INFO - 2016-10-13 17:27:41 --> Language Class Initialized
ERROR - 2016-10-13 17:27:41 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:41 --> Config Class Initialized
INFO - 2016-10-13 17:27:41 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:41 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:41 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:41 --> URI Class Initialized
INFO - 2016-10-13 17:27:41 --> Router Class Initialized
INFO - 2016-10-13 17:27:41 --> Output Class Initialized
INFO - 2016-10-13 17:27:41 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:41 --> Input Class Initialized
INFO - 2016-10-13 17:27:41 --> Language Class Initialized
ERROR - 2016-10-13 17:27:41 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:57 --> Config Class Initialized
INFO - 2016-10-13 17:27:57 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:57 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:57 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:57 --> URI Class Initialized
INFO - 2016-10-13 17:27:57 --> Router Class Initialized
INFO - 2016-10-13 17:27:57 --> Output Class Initialized
INFO - 2016-10-13 17:27:57 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:57 --> Input Class Initialized
INFO - 2016-10-13 17:27:57 --> Language Class Initialized
INFO - 2016-10-13 17:27:57 --> Language Class Initialized
INFO - 2016-10-13 17:27:57 --> Config Class Initialized
INFO - 2016-10-13 17:27:57 --> Loader Class Initialized
INFO - 2016-10-13 17:27:57 --> Helper loaded: common_helper
INFO - 2016-10-13 17:27:57 --> Helper loaded: url_helper
INFO - 2016-10-13 17:27:57 --> Database Driver Class Initialized
INFO - 2016-10-13 17:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:27:57 --> Parser Class Initialized
INFO - 2016-10-13 17:27:57 --> Controller Class Initialized
DEBUG - 2016-10-13 17:27:57 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:27:57 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:57 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:57 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:27:57 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:57 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:57 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:57 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-13 17:27:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:27:57 --> Final output sent to browser
DEBUG - 2016-10-13 17:27:57 --> Total execution time: 0.0472
INFO - 2016-10-13 17:27:57 --> Config Class Initialized
INFO - 2016-10-13 17:27:57 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:57 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:57 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:57 --> URI Class Initialized
INFO - 2016-10-13 17:27:57 --> Router Class Initialized
INFO - 2016-10-13 17:27:57 --> Output Class Initialized
INFO - 2016-10-13 17:27:57 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:57 --> Input Class Initialized
INFO - 2016-10-13 17:27:57 --> Language Class Initialized
ERROR - 2016-10-13 17:27:57 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:57 --> Config Class Initialized
INFO - 2016-10-13 17:27:57 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:57 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:57 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:57 --> URI Class Initialized
INFO - 2016-10-13 17:27:57 --> Router Class Initialized
INFO - 2016-10-13 17:27:57 --> Output Class Initialized
INFO - 2016-10-13 17:27:57 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:57 --> Input Class Initialized
INFO - 2016-10-13 17:27:57 --> Language Class Initialized
ERROR - 2016-10-13 17:27:57 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:59 --> Config Class Initialized
INFO - 2016-10-13 17:27:59 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:59 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:59 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:59 --> URI Class Initialized
INFO - 2016-10-13 17:27:59 --> Router Class Initialized
INFO - 2016-10-13 17:27:59 --> Output Class Initialized
INFO - 2016-10-13 17:27:59 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:59 --> Input Class Initialized
INFO - 2016-10-13 17:27:59 --> Language Class Initialized
INFO - 2016-10-13 17:27:59 --> Language Class Initialized
INFO - 2016-10-13 17:27:59 --> Config Class Initialized
INFO - 2016-10-13 17:27:59 --> Loader Class Initialized
INFO - 2016-10-13 17:27:59 --> Helper loaded: common_helper
INFO - 2016-10-13 17:27:59 --> Helper loaded: url_helper
INFO - 2016-10-13 17:27:59 --> Database Driver Class Initialized
INFO - 2016-10-13 17:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:27:59 --> Parser Class Initialized
INFO - 2016-10-13 17:27:59 --> Controller Class Initialized
DEBUG - 2016-10-13 17:27:59 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:27:59 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:59 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:59 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:27:59 --> Model Class Initialized
DEBUG - 2016-10-13 17:27:59 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:27:59 --> Model Class Initialized
ERROR - 2016-10-13 17:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/themvatpham.php 52
DEBUG - 2016-10-13 17:27:59 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/themvatpham.php
DEBUG - 2016-10-13 17:27:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:27:59 --> Final output sent to browser
DEBUG - 2016-10-13 17:27:59 --> Total execution time: 0.0440
INFO - 2016-10-13 17:27:59 --> Config Class Initialized
INFO - 2016-10-13 17:27:59 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:59 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:59 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:59 --> URI Class Initialized
INFO - 2016-10-13 17:27:59 --> Router Class Initialized
INFO - 2016-10-13 17:27:59 --> Output Class Initialized
INFO - 2016-10-13 17:27:59 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:59 --> Input Class Initialized
INFO - 2016-10-13 17:27:59 --> Language Class Initialized
ERROR - 2016-10-13 17:27:59 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:27:59 --> Config Class Initialized
INFO - 2016-10-13 17:27:59 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:27:59 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:27:59 --> Utf8 Class Initialized
INFO - 2016-10-13 17:27:59 --> URI Class Initialized
INFO - 2016-10-13 17:27:59 --> Router Class Initialized
INFO - 2016-10-13 17:27:59 --> Output Class Initialized
INFO - 2016-10-13 17:27:59 --> Security Class Initialized
DEBUG - 2016-10-13 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:27:59 --> Input Class Initialized
INFO - 2016-10-13 17:27:59 --> Language Class Initialized
ERROR - 2016-10-13 17:27:59 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:28:18 --> Config Class Initialized
INFO - 2016-10-13 17:28:18 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:28:18 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:28:18 --> Utf8 Class Initialized
INFO - 2016-10-13 17:28:18 --> URI Class Initialized
INFO - 2016-10-13 17:28:18 --> Router Class Initialized
INFO - 2016-10-13 17:28:18 --> Output Class Initialized
INFO - 2016-10-13 17:28:18 --> Security Class Initialized
DEBUG - 2016-10-13 17:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:28:18 --> Input Class Initialized
INFO - 2016-10-13 17:28:18 --> Language Class Initialized
INFO - 2016-10-13 17:28:18 --> Language Class Initialized
INFO - 2016-10-13 17:28:18 --> Config Class Initialized
INFO - 2016-10-13 17:28:18 --> Loader Class Initialized
INFO - 2016-10-13 17:28:18 --> Helper loaded: common_helper
INFO - 2016-10-13 17:28:18 --> Helper loaded: url_helper
INFO - 2016-10-13 17:28:18 --> Database Driver Class Initialized
INFO - 2016-10-13 17:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:28:18 --> Parser Class Initialized
INFO - 2016-10-13 17:28:18 --> Controller Class Initialized
DEBUG - 2016-10-13 17:28:18 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:28:18 --> Model Class Initialized
DEBUG - 2016-10-13 17:28:18 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:28:18 --> Model Class Initialized
DEBUG - 2016-10-13 17:28:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:28:18 --> Model Class Initialized
DEBUG - 2016-10-13 17:28:18 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:28:18 --> Model Class Initialized
DEBUG - 2016-10-13 17:28:18 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/themvatpham.php
DEBUG - 2016-10-13 17:28:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:28:18 --> Final output sent to browser
DEBUG - 2016-10-13 17:28:18 --> Total execution time: 0.0522
INFO - 2016-10-13 17:28:18 --> Config Class Initialized
INFO - 2016-10-13 17:28:18 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:28:18 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:28:18 --> Utf8 Class Initialized
INFO - 2016-10-13 17:28:18 --> URI Class Initialized
INFO - 2016-10-13 17:28:18 --> Router Class Initialized
INFO - 2016-10-13 17:28:18 --> Output Class Initialized
INFO - 2016-10-13 17:28:18 --> Security Class Initialized
DEBUG - 2016-10-13 17:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:28:18 --> Input Class Initialized
INFO - 2016-10-13 17:28:18 --> Language Class Initialized
ERROR - 2016-10-13 17:28:18 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:28:19 --> Config Class Initialized
INFO - 2016-10-13 17:28:19 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:28:19 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:28:19 --> Utf8 Class Initialized
INFO - 2016-10-13 17:28:19 --> URI Class Initialized
INFO - 2016-10-13 17:28:19 --> Router Class Initialized
INFO - 2016-10-13 17:28:19 --> Output Class Initialized
INFO - 2016-10-13 17:28:19 --> Security Class Initialized
DEBUG - 2016-10-13 17:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:28:19 --> Input Class Initialized
INFO - 2016-10-13 17:28:19 --> Language Class Initialized
INFO - 2016-10-13 17:28:19 --> Language Class Initialized
INFO - 2016-10-13 17:28:19 --> Config Class Initialized
INFO - 2016-10-13 17:28:19 --> Loader Class Initialized
INFO - 2016-10-13 17:28:19 --> Helper loaded: common_helper
INFO - 2016-10-13 17:28:19 --> Helper loaded: url_helper
INFO - 2016-10-13 17:28:20 --> Database Driver Class Initialized
INFO - 2016-10-13 17:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:28:20 --> Parser Class Initialized
INFO - 2016-10-13 17:28:20 --> Controller Class Initialized
DEBUG - 2016-10-13 17:28:20 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 17:28:20 --> Model Class Initialized
DEBUG - 2016-10-13 17:28:20 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:28:20 --> Model Class Initialized
DEBUG - 2016-10-13 17:28:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:28:20 --> Model Class Initialized
DEBUG - 2016-10-13 17:28:20 --> File already loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-13 17:28:20 --> Model Class Initialized
DEBUG - 2016-10-13 17:28:20 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-13 17:28:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-13 17:28:20 --> Final output sent to browser
DEBUG - 2016-10-13 17:28:20 --> Total execution time: 0.0558
INFO - 2016-10-13 17:28:20 --> Config Class Initialized
INFO - 2016-10-13 17:28:20 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:28:20 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:28:20 --> Utf8 Class Initialized
INFO - 2016-10-13 17:28:20 --> URI Class Initialized
INFO - 2016-10-13 17:28:20 --> Router Class Initialized
INFO - 2016-10-13 17:28:20 --> Output Class Initialized
INFO - 2016-10-13 17:28:20 --> Security Class Initialized
DEBUG - 2016-10-13 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:28:20 --> Input Class Initialized
INFO - 2016-10-13 17:28:20 --> Language Class Initialized
ERROR - 2016-10-13 17:28:20 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:28:20 --> Config Class Initialized
INFO - 2016-10-13 17:28:20 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:28:20 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:28:20 --> Utf8 Class Initialized
INFO - 2016-10-13 17:28:20 --> URI Class Initialized
INFO - 2016-10-13 17:28:20 --> Router Class Initialized
INFO - 2016-10-13 17:28:20 --> Output Class Initialized
INFO - 2016-10-13 17:28:20 --> Security Class Initialized
DEBUG - 2016-10-13 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:28:20 --> Input Class Initialized
INFO - 2016-10-13 17:28:20 --> Language Class Initialized
ERROR - 2016-10-13 17:28:20 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:29:06 --> Config Class Initialized
INFO - 2016-10-13 17:29:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:29:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:29:06 --> Utf8 Class Initialized
INFO - 2016-10-13 17:29:06 --> URI Class Initialized
INFO - 2016-10-13 17:29:06 --> Router Class Initialized
INFO - 2016-10-13 17:29:06 --> Output Class Initialized
INFO - 2016-10-13 17:29:06 --> Security Class Initialized
DEBUG - 2016-10-13 17:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:29:06 --> Input Class Initialized
INFO - 2016-10-13 17:29:06 --> Language Class Initialized
INFO - 2016-10-13 17:29:06 --> Language Class Initialized
INFO - 2016-10-13 17:29:06 --> Config Class Initialized
INFO - 2016-10-13 17:29:06 --> Loader Class Initialized
INFO - 2016-10-13 17:29:06 --> Helper loaded: common_helper
INFO - 2016-10-13 17:29:06 --> Helper loaded: url_helper
INFO - 2016-10-13 17:29:06 --> Database Driver Class Initialized
INFO - 2016-10-13 17:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:29:06 --> Parser Class Initialized
INFO - 2016-10-13 17:29:06 --> Controller Class Initialized
DEBUG - 2016-10-13 17:29:06 --> Home MX_Controller Initialized
INFO - 2016-10-13 17:29:06 --> Model Class Initialized
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 17:29:06 --> Model Class Initialized
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 17:29:06 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:29:06 --> Model Class Initialized
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 17:29:06 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 17:29:06 --> Model Class Initialized
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 17:29:06 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:29:06 --> Model Class Initialized
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 17:29:06 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:29:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 17:29:06 --> Final output sent to browser
DEBUG - 2016-10-13 17:29:06 --> Total execution time: 0.0754
INFO - 2016-10-13 17:29:06 --> Config Class Initialized
INFO - 2016-10-13 17:29:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:29:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:29:06 --> Utf8 Class Initialized
INFO - 2016-10-13 17:29:06 --> URI Class Initialized
INFO - 2016-10-13 17:29:06 --> Router Class Initialized
INFO - 2016-10-13 17:29:06 --> Output Class Initialized
INFO - 2016-10-13 17:29:06 --> Security Class Initialized
DEBUG - 2016-10-13 17:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:29:06 --> Input Class Initialized
INFO - 2016-10-13 17:29:06 --> Language Class Initialized
ERROR - 2016-10-13 17:29:06 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:37:42 --> Config Class Initialized
INFO - 2016-10-13 17:37:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:37:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:37:42 --> Utf8 Class Initialized
INFO - 2016-10-13 17:37:42 --> URI Class Initialized
INFO - 2016-10-13 17:37:42 --> Router Class Initialized
INFO - 2016-10-13 17:37:42 --> Output Class Initialized
INFO - 2016-10-13 17:37:42 --> Security Class Initialized
DEBUG - 2016-10-13 17:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:37:42 --> Input Class Initialized
INFO - 2016-10-13 17:37:42 --> Language Class Initialized
INFO - 2016-10-13 17:37:42 --> Language Class Initialized
INFO - 2016-10-13 17:37:42 --> Config Class Initialized
INFO - 2016-10-13 17:37:42 --> Loader Class Initialized
INFO - 2016-10-13 17:37:42 --> Helper loaded: common_helper
INFO - 2016-10-13 17:37:42 --> Helper loaded: url_helper
INFO - 2016-10-13 17:37:42 --> Database Driver Class Initialized
INFO - 2016-10-13 17:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:37:42 --> Parser Class Initialized
INFO - 2016-10-13 17:37:42 --> Controller Class Initialized
DEBUG - 2016-10-13 17:37:42 --> User MX_Controller Initialized
INFO - 2016-10-13 17:37:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-13 17:37:42 --> Model Class Initialized
INFO - 2016-10-13 17:37:42 --> Helper loaded: cookie_helper
INFO - 2016-10-13 17:37:42 --> Helper loaded: form_helper
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:37:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:37:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/FRONTEND/change_password.php
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 17:37:42 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 17:37:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 17:37:42 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:37:42 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 17:37:42 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:37:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 17:37:42 --> Final output sent to browser
DEBUG - 2016-10-13 17:37:42 --> Total execution time: 0.0613
INFO - 2016-10-13 17:37:42 --> Config Class Initialized
INFO - 2016-10-13 17:37:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:37:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:37:42 --> Utf8 Class Initialized
INFO - 2016-10-13 17:37:42 --> URI Class Initialized
INFO - 2016-10-13 17:37:42 --> Router Class Initialized
INFO - 2016-10-13 17:37:42 --> Output Class Initialized
INFO - 2016-10-13 17:37:42 --> Security Class Initialized
DEBUG - 2016-10-13 17:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:37:42 --> Input Class Initialized
INFO - 2016-10-13 17:37:42 --> Language Class Initialized
ERROR - 2016-10-13 17:37:42 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:37:42 --> Config Class Initialized
INFO - 2016-10-13 17:37:42 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:37:42 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:37:42 --> Utf8 Class Initialized
INFO - 2016-10-13 17:37:42 --> URI Class Initialized
INFO - 2016-10-13 17:37:42 --> Router Class Initialized
INFO - 2016-10-13 17:37:42 --> Output Class Initialized
INFO - 2016-10-13 17:37:42 --> Security Class Initialized
DEBUG - 2016-10-13 17:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:37:42 --> Input Class Initialized
INFO - 2016-10-13 17:37:42 --> Language Class Initialized
ERROR - 2016-10-13 17:37:42 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:37:45 --> Config Class Initialized
INFO - 2016-10-13 17:37:45 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:37:45 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:37:45 --> Utf8 Class Initialized
INFO - 2016-10-13 17:37:45 --> URI Class Initialized
INFO - 2016-10-13 17:37:45 --> Router Class Initialized
INFO - 2016-10-13 17:37:45 --> Output Class Initialized
INFO - 2016-10-13 17:37:45 --> Security Class Initialized
DEBUG - 2016-10-13 17:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:37:45 --> Input Class Initialized
INFO - 2016-10-13 17:37:45 --> Language Class Initialized
INFO - 2016-10-13 17:37:45 --> Language Class Initialized
INFO - 2016-10-13 17:37:45 --> Config Class Initialized
INFO - 2016-10-13 17:37:45 --> Loader Class Initialized
INFO - 2016-10-13 17:37:45 --> Helper loaded: common_helper
INFO - 2016-10-13 17:37:45 --> Helper loaded: url_helper
INFO - 2016-10-13 17:37:45 --> Database Driver Class Initialized
INFO - 2016-10-13 17:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:37:45 --> Parser Class Initialized
INFO - 2016-10-13 17:37:45 --> Controller Class Initialized
DEBUG - 2016-10-13 17:37:45 --> User MX_Controller Initialized
INFO - 2016-10-13 17:37:45 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:45 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-13 17:37:45 --> Model Class Initialized
INFO - 2016-10-13 17:37:45 --> Helper loaded: cookie_helper
INFO - 2016-10-13 17:37:45 --> Helper loaded: form_helper
DEBUG - 2016-10-13 17:37:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:37:45 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:37:45 --> Model Class Initialized
INFO - 2016-10-13 17:37:45 --> Config Class Initialized
INFO - 2016-10-13 17:37:45 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:37:45 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:37:45 --> Utf8 Class Initialized
INFO - 2016-10-13 17:37:45 --> URI Class Initialized
DEBUG - 2016-10-13 17:37:45 --> No URI present. Default controller set.
INFO - 2016-10-13 17:37:45 --> Router Class Initialized
INFO - 2016-10-13 17:37:45 --> Output Class Initialized
INFO - 2016-10-13 17:37:45 --> Security Class Initialized
DEBUG - 2016-10-13 17:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:37:45 --> Input Class Initialized
INFO - 2016-10-13 17:37:45 --> Language Class Initialized
INFO - 2016-10-13 17:37:45 --> Language Class Initialized
INFO - 2016-10-13 17:37:45 --> Config Class Initialized
INFO - 2016-10-13 17:37:45 --> Loader Class Initialized
INFO - 2016-10-13 17:37:45 --> Helper loaded: common_helper
INFO - 2016-10-13 17:37:45 --> Helper loaded: url_helper
INFO - 2016-10-13 17:37:45 --> Database Driver Class Initialized
INFO - 2016-10-13 17:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:37:45 --> Parser Class Initialized
INFO - 2016-10-13 17:37:45 --> Controller Class Initialized
DEBUG - 2016-10-13 17:37:45 --> Home MX_Controller Initialized
INFO - 2016-10-13 17:37:45 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:45 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 17:37:45 --> Model Class Initialized
ERROR - 2016-10-13 17:37:45 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 17:37:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 17:37:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:37:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 17:37:45 --> Final output sent to browser
DEBUG - 2016-10-13 17:37:45 --> Total execution time: 0.0376
INFO - 2016-10-13 17:37:47 --> Config Class Initialized
INFO - 2016-10-13 17:37:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:37:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:37:47 --> Utf8 Class Initialized
INFO - 2016-10-13 17:37:47 --> URI Class Initialized
INFO - 2016-10-13 17:37:47 --> Router Class Initialized
INFO - 2016-10-13 17:37:47 --> Output Class Initialized
INFO - 2016-10-13 17:37:47 --> Security Class Initialized
DEBUG - 2016-10-13 17:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:37:47 --> Input Class Initialized
INFO - 2016-10-13 17:37:47 --> Language Class Initialized
INFO - 2016-10-13 17:37:47 --> Language Class Initialized
INFO - 2016-10-13 17:37:47 --> Config Class Initialized
INFO - 2016-10-13 17:37:47 --> Loader Class Initialized
INFO - 2016-10-13 17:37:47 --> Helper loaded: common_helper
INFO - 2016-10-13 17:37:47 --> Helper loaded: url_helper
INFO - 2016-10-13 17:37:47 --> Database Driver Class Initialized
INFO - 2016-10-13 17:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:37:47 --> Parser Class Initialized
INFO - 2016-10-13 17:37:47 --> Controller Class Initialized
DEBUG - 2016-10-13 17:37:47 --> Home MX_Controller Initialized
INFO - 2016-10-13 17:37:47 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 17:37:47 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 17:37:47 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:37:47 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 17:37:47 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 17:37:47 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 17:37:47 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 17:37:47 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-13 17:37:47 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:37:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 17:37:47 --> Final output sent to browser
DEBUG - 2016-10-13 17:37:47 --> Total execution time: 0.0918
INFO - 2016-10-13 17:37:47 --> Config Class Initialized
INFO - 2016-10-13 17:37:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:37:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:37:47 --> Utf8 Class Initialized
INFO - 2016-10-13 17:37:47 --> URI Class Initialized
INFO - 2016-10-13 17:37:47 --> Router Class Initialized
INFO - 2016-10-13 17:37:47 --> Output Class Initialized
INFO - 2016-10-13 17:37:47 --> Security Class Initialized
DEBUG - 2016-10-13 17:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:37:47 --> Input Class Initialized
INFO - 2016-10-13 17:37:47 --> Language Class Initialized
ERROR - 2016-10-13 17:37:47 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:37:55 --> Config Class Initialized
INFO - 2016-10-13 17:37:55 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:37:55 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:37:55 --> Utf8 Class Initialized
INFO - 2016-10-13 17:37:55 --> URI Class Initialized
INFO - 2016-10-13 17:37:55 --> Router Class Initialized
INFO - 2016-10-13 17:37:55 --> Output Class Initialized
INFO - 2016-10-13 17:37:55 --> Security Class Initialized
DEBUG - 2016-10-13 17:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:37:55 --> Input Class Initialized
INFO - 2016-10-13 17:37:55 --> Language Class Initialized
INFO - 2016-10-13 17:37:55 --> Language Class Initialized
INFO - 2016-10-13 17:37:55 --> Config Class Initialized
INFO - 2016-10-13 17:37:55 --> Loader Class Initialized
INFO - 2016-10-13 17:37:55 --> Helper loaded: common_helper
INFO - 2016-10-13 17:37:55 --> Helper loaded: url_helper
INFO - 2016-10-13 17:37:55 --> Database Driver Class Initialized
INFO - 2016-10-13 17:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:37:55 --> Parser Class Initialized
INFO - 2016-10-13 17:37:55 --> Controller Class Initialized
DEBUG - 2016-10-13 17:37:55 --> User MX_Controller Initialized
INFO - 2016-10-13 17:37:55 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:55 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-13 17:37:55 --> Model Class Initialized
INFO - 2016-10-13 17:37:55 --> Helper loaded: cookie_helper
INFO - 2016-10-13 17:37:55 --> Helper loaded: form_helper
DEBUG - 2016-10-13 17:37:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:37:55 --> Model Class Initialized
DEBUG - 2016-10-13 17:37:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:37:55 --> Model Class Initialized
INFO - 2016-10-13 17:37:55 --> Final output sent to browser
DEBUG - 2016-10-13 17:37:55 --> Total execution time: 0.0469
INFO - 2016-10-13 17:38:16 --> Config Class Initialized
INFO - 2016-10-13 17:38:16 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:38:16 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:38:16 --> Utf8 Class Initialized
INFO - 2016-10-13 17:38:16 --> URI Class Initialized
INFO - 2016-10-13 17:38:16 --> Router Class Initialized
INFO - 2016-10-13 17:38:16 --> Output Class Initialized
INFO - 2016-10-13 17:38:16 --> Security Class Initialized
DEBUG - 2016-10-13 17:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:38:16 --> Input Class Initialized
INFO - 2016-10-13 17:38:16 --> Language Class Initialized
INFO - 2016-10-13 17:38:16 --> Language Class Initialized
INFO - 2016-10-13 17:38:16 --> Config Class Initialized
INFO - 2016-10-13 17:38:16 --> Loader Class Initialized
INFO - 2016-10-13 17:38:16 --> Helper loaded: common_helper
INFO - 2016-10-13 17:38:16 --> Helper loaded: url_helper
INFO - 2016-10-13 17:38:16 --> Database Driver Class Initialized
INFO - 2016-10-13 17:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:38:16 --> Parser Class Initialized
INFO - 2016-10-13 17:38:16 --> Controller Class Initialized
DEBUG - 2016-10-13 17:38:16 --> User MX_Controller Initialized
INFO - 2016-10-13 17:38:16 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:16 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-13 17:38:16 --> Model Class Initialized
INFO - 2016-10-13 17:38:16 --> Helper loaded: cookie_helper
INFO - 2016-10-13 17:38:16 --> Helper loaded: form_helper
DEBUG - 2016-10-13 17:38:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:38:16 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:38:16 --> Model Class Initialized
INFO - 2016-10-13 17:38:16 --> Final output sent to browser
DEBUG - 2016-10-13 17:38:16 --> Total execution time: 0.0788
INFO - 2016-10-13 17:38:18 --> Config Class Initialized
INFO - 2016-10-13 17:38:18 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:38:18 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:38:18 --> Utf8 Class Initialized
INFO - 2016-10-13 17:38:18 --> URI Class Initialized
DEBUG - 2016-10-13 17:38:18 --> No URI present. Default controller set.
INFO - 2016-10-13 17:38:18 --> Router Class Initialized
INFO - 2016-10-13 17:38:18 --> Output Class Initialized
INFO - 2016-10-13 17:38:18 --> Security Class Initialized
DEBUG - 2016-10-13 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:38:18 --> Input Class Initialized
INFO - 2016-10-13 17:38:18 --> Language Class Initialized
INFO - 2016-10-13 17:38:18 --> Language Class Initialized
INFO - 2016-10-13 17:38:18 --> Config Class Initialized
INFO - 2016-10-13 17:38:18 --> Loader Class Initialized
INFO - 2016-10-13 17:38:18 --> Helper loaded: common_helper
INFO - 2016-10-13 17:38:18 --> Helper loaded: url_helper
INFO - 2016-10-13 17:38:18 --> Database Driver Class Initialized
INFO - 2016-10-13 17:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:38:18 --> Parser Class Initialized
INFO - 2016-10-13 17:38:18 --> Controller Class Initialized
DEBUG - 2016-10-13 17:38:18 --> Home MX_Controller Initialized
INFO - 2016-10-13 17:38:18 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 17:38:18 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 17:38:18 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 17:38:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 17:38:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 17:38:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 17:38:18 --> Final output sent to browser
DEBUG - 2016-10-13 17:38:18 --> Total execution time: 0.0387
INFO - 2016-10-13 17:38:27 --> Config Class Initialized
INFO - 2016-10-13 17:38:27 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:38:27 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:38:27 --> Utf8 Class Initialized
INFO - 2016-10-13 17:38:27 --> URI Class Initialized
INFO - 2016-10-13 17:38:27 --> Router Class Initialized
INFO - 2016-10-13 17:38:27 --> Output Class Initialized
INFO - 2016-10-13 17:38:27 --> Security Class Initialized
DEBUG - 2016-10-13 17:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:38:27 --> Input Class Initialized
INFO - 2016-10-13 17:38:27 --> Language Class Initialized
INFO - 2016-10-13 17:38:27 --> Language Class Initialized
INFO - 2016-10-13 17:38:27 --> Config Class Initialized
INFO - 2016-10-13 17:38:27 --> Loader Class Initialized
INFO - 2016-10-13 17:38:27 --> Helper loaded: common_helper
INFO - 2016-10-13 17:38:27 --> Helper loaded: url_helper
INFO - 2016-10-13 17:38:27 --> Database Driver Class Initialized
INFO - 2016-10-13 17:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:38:27 --> Parser Class Initialized
INFO - 2016-10-13 17:38:27 --> Controller Class Initialized
DEBUG - 2016-10-13 17:38:27 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 17:38:27 --> Config Class Initialized
INFO - 2016-10-13 17:38:27 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:38:27 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:38:27 --> Utf8 Class Initialized
INFO - 2016-10-13 17:38:27 --> URI Class Initialized
INFO - 2016-10-13 17:38:27 --> Router Class Initialized
INFO - 2016-10-13 17:38:27 --> Output Class Initialized
INFO - 2016-10-13 17:38:27 --> Security Class Initialized
DEBUG - 2016-10-13 17:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:38:27 --> Input Class Initialized
INFO - 2016-10-13 17:38:27 --> Language Class Initialized
INFO - 2016-10-13 17:38:27 --> Language Class Initialized
INFO - 2016-10-13 17:38:27 --> Config Class Initialized
INFO - 2016-10-13 17:38:27 --> Loader Class Initialized
INFO - 2016-10-13 17:38:27 --> Helper loaded: common_helper
INFO - 2016-10-13 17:38:27 --> Helper loaded: url_helper
INFO - 2016-10-13 17:38:27 --> Database Driver Class Initialized
INFO - 2016-10-13 17:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:38:27 --> Parser Class Initialized
INFO - 2016-10-13 17:38:27 --> Controller Class Initialized
DEBUG - 2016-10-13 17:38:27 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 17:38:27 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:38:27 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:27 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-13 17:38:27 --> Final output sent to browser
DEBUG - 2016-10-13 17:38:27 --> Total execution time: 0.0397
INFO - 2016-10-13 17:38:32 --> Config Class Initialized
INFO - 2016-10-13 17:38:32 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:38:32 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:38:32 --> Utf8 Class Initialized
INFO - 2016-10-13 17:38:32 --> URI Class Initialized
INFO - 2016-10-13 17:38:32 --> Router Class Initialized
INFO - 2016-10-13 17:38:32 --> Output Class Initialized
INFO - 2016-10-13 17:38:32 --> Security Class Initialized
DEBUG - 2016-10-13 17:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:38:32 --> Input Class Initialized
INFO - 2016-10-13 17:38:32 --> Language Class Initialized
INFO - 2016-10-13 17:38:32 --> Language Class Initialized
INFO - 2016-10-13 17:38:32 --> Config Class Initialized
INFO - 2016-10-13 17:38:32 --> Loader Class Initialized
INFO - 2016-10-13 17:38:32 --> Helper loaded: common_helper
INFO - 2016-10-13 17:38:32 --> Helper loaded: url_helper
INFO - 2016-10-13 17:38:32 --> Database Driver Class Initialized
INFO - 2016-10-13 17:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:38:32 --> Parser Class Initialized
INFO - 2016-10-13 17:38:32 --> Controller Class Initialized
DEBUG - 2016-10-13 17:38:32 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 17:38:32 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:38:32 --> Model Class Initialized
INFO - 2016-10-13 17:38:32 --> Final output sent to browser
DEBUG - 2016-10-13 17:38:32 --> Total execution time: 0.0417
INFO - 2016-10-13 17:38:32 --> Config Class Initialized
INFO - 2016-10-13 17:38:32 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:38:32 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:38:32 --> Utf8 Class Initialized
INFO - 2016-10-13 17:38:32 --> URI Class Initialized
INFO - 2016-10-13 17:38:32 --> Router Class Initialized
INFO - 2016-10-13 17:38:32 --> Output Class Initialized
INFO - 2016-10-13 17:38:32 --> Security Class Initialized
DEBUG - 2016-10-13 17:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:38:32 --> Input Class Initialized
INFO - 2016-10-13 17:38:32 --> Language Class Initialized
INFO - 2016-10-13 17:38:32 --> Language Class Initialized
INFO - 2016-10-13 17:38:32 --> Config Class Initialized
INFO - 2016-10-13 17:38:32 --> Loader Class Initialized
INFO - 2016-10-13 17:38:32 --> Helper loaded: common_helper
INFO - 2016-10-13 17:38:32 --> Helper loaded: url_helper
INFO - 2016-10-13 17:38:32 --> Database Driver Class Initialized
INFO - 2016-10-13 17:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:38:32 --> Parser Class Initialized
INFO - 2016-10-13 17:38:32 --> Controller Class Initialized
DEBUG - 2016-10-13 17:38:32 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 17:38:32 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:38:32 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-13 17:38:32 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:38:32 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:38:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:38:32 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:38:32 --> Model Class Initialized
DEBUG - 2016-10-13 17:38:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:38:32 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:38:32 --> Final output sent to browser
DEBUG - 2016-10-13 17:38:32 --> Total execution time: 0.0470
INFO - 2016-10-13 17:38:33 --> Config Class Initialized
INFO - 2016-10-13 17:38:33 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:38:33 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:38:33 --> Utf8 Class Initialized
INFO - 2016-10-13 17:38:33 --> URI Class Initialized
INFO - 2016-10-13 17:38:33 --> Router Class Initialized
INFO - 2016-10-13 17:38:33 --> Output Class Initialized
INFO - 2016-10-13 17:38:33 --> Security Class Initialized
DEBUG - 2016-10-13 17:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:38:33 --> Input Class Initialized
INFO - 2016-10-13 17:38:33 --> Language Class Initialized
ERROR - 2016-10-13 17:38:33 --> 404 Page Not Found: /index
INFO - 2016-10-13 17:39:14 --> Config Class Initialized
INFO - 2016-10-13 17:39:14 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:39:14 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:39:14 --> Utf8 Class Initialized
INFO - 2016-10-13 17:39:14 --> URI Class Initialized
INFO - 2016-10-13 17:39:14 --> Router Class Initialized
INFO - 2016-10-13 17:39:14 --> Output Class Initialized
INFO - 2016-10-13 17:39:14 --> Security Class Initialized
DEBUG - 2016-10-13 17:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:39:14 --> Input Class Initialized
INFO - 2016-10-13 17:39:14 --> Language Class Initialized
INFO - 2016-10-13 17:39:14 --> Language Class Initialized
INFO - 2016-10-13 17:39:14 --> Config Class Initialized
INFO - 2016-10-13 17:39:14 --> Loader Class Initialized
INFO - 2016-10-13 17:39:14 --> Helper loaded: common_helper
INFO - 2016-10-13 17:39:14 --> Helper loaded: url_helper
INFO - 2016-10-13 17:39:14 --> Database Driver Class Initialized
INFO - 2016-10-13 17:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 17:39:14 --> Parser Class Initialized
INFO - 2016-10-13 17:39:14 --> Controller Class Initialized
DEBUG - 2016-10-13 17:39:14 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 17:39:14 --> Model Class Initialized
DEBUG - 2016-10-13 17:39:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:39:14 --> Model Class Initialized
DEBUG - 2016-10-13 17:39:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-13 17:39:14 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 17:39:14 --> Model Class Initialized
DEBUG - 2016-10-13 17:39:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 17:39:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 17:39:14 --> Model Class Initialized
DEBUG - 2016-10-13 17:39:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 17:39:14 --> Model Class Initialized
DEBUG - 2016-10-13 17:39:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 17:39:14 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 17:39:14 --> Final output sent to browser
DEBUG - 2016-10-13 17:39:14 --> Total execution time: 0.0494
INFO - 2016-10-13 17:39:16 --> Config Class Initialized
INFO - 2016-10-13 17:39:16 --> Hooks Class Initialized
DEBUG - 2016-10-13 17:39:16 --> UTF-8 Support Enabled
INFO - 2016-10-13 17:39:16 --> Utf8 Class Initialized
INFO - 2016-10-13 17:39:16 --> URI Class Initialized
INFO - 2016-10-13 17:39:16 --> Router Class Initialized
INFO - 2016-10-13 17:39:16 --> Output Class Initialized
INFO - 2016-10-13 17:39:16 --> Security Class Initialized
DEBUG - 2016-10-13 17:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 17:39:16 --> Input Class Initialized
INFO - 2016-10-13 17:39:16 --> Language Class Initialized
ERROR - 2016-10-13 17:39:16 --> 404 Page Not Found: /index
INFO - 2016-10-13 18:44:31 --> Config Class Initialized
INFO - 2016-10-13 18:44:31 --> Hooks Class Initialized
DEBUG - 2016-10-13 18:44:31 --> UTF-8 Support Enabled
INFO - 2016-10-13 18:44:31 --> Utf8 Class Initialized
INFO - 2016-10-13 18:44:31 --> URI Class Initialized
DEBUG - 2016-10-13 18:44:31 --> No URI present. Default controller set.
INFO - 2016-10-13 18:44:31 --> Router Class Initialized
INFO - 2016-10-13 18:44:31 --> Output Class Initialized
INFO - 2016-10-13 18:44:31 --> Security Class Initialized
DEBUG - 2016-10-13 18:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 18:44:31 --> Input Class Initialized
INFO - 2016-10-13 18:44:31 --> Language Class Initialized
INFO - 2016-10-13 18:44:31 --> Language Class Initialized
INFO - 2016-10-13 18:44:31 --> Config Class Initialized
INFO - 2016-10-13 18:44:31 --> Loader Class Initialized
INFO - 2016-10-13 18:44:31 --> Helper loaded: common_helper
INFO - 2016-10-13 18:44:31 --> Helper loaded: url_helper
INFO - 2016-10-13 18:44:31 --> Database Driver Class Initialized
INFO - 2016-10-13 18:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 18:44:31 --> Parser Class Initialized
INFO - 2016-10-13 18:44:31 --> Controller Class Initialized
DEBUG - 2016-10-13 18:44:31 --> Home MX_Controller Initialized
INFO - 2016-10-13 18:44:31 --> Model Class Initialized
DEBUG - 2016-10-13 18:44:31 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 18:44:31 --> Model Class Initialized
ERROR - 2016-10-13 18:44:31 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 18:44:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 18:44:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 18:44:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 18:44:31 --> Final output sent to browser
DEBUG - 2016-10-13 18:44:31 --> Total execution time: 0.0633
INFO - 2016-10-13 18:44:44 --> Config Class Initialized
INFO - 2016-10-13 18:44:44 --> Hooks Class Initialized
DEBUG - 2016-10-13 18:44:44 --> UTF-8 Support Enabled
INFO - 2016-10-13 18:44:44 --> Utf8 Class Initialized
INFO - 2016-10-13 18:44:44 --> URI Class Initialized
INFO - 2016-10-13 18:44:44 --> Router Class Initialized
INFO - 2016-10-13 18:44:44 --> Output Class Initialized
INFO - 2016-10-13 18:44:44 --> Security Class Initialized
DEBUG - 2016-10-13 18:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 18:44:44 --> Input Class Initialized
INFO - 2016-10-13 18:44:44 --> Language Class Initialized
ERROR - 2016-10-13 18:44:44 --> 404 Page Not Found: /index
INFO - 2016-10-13 18:44:46 --> Config Class Initialized
INFO - 2016-10-13 18:44:46 --> Hooks Class Initialized
DEBUG - 2016-10-13 18:44:46 --> UTF-8 Support Enabled
INFO - 2016-10-13 18:44:46 --> Utf8 Class Initialized
INFO - 2016-10-13 18:44:46 --> URI Class Initialized
INFO - 2016-10-13 18:44:46 --> Router Class Initialized
INFO - 2016-10-13 18:44:46 --> Output Class Initialized
INFO - 2016-10-13 18:44:46 --> Security Class Initialized
DEBUG - 2016-10-13 18:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 18:44:46 --> Input Class Initialized
INFO - 2016-10-13 18:44:46 --> Language Class Initialized
ERROR - 2016-10-13 18:44:46 --> 404 Page Not Found: /index
INFO - 2016-10-13 18:44:47 --> Config Class Initialized
INFO - 2016-10-13 18:44:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 18:44:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 18:44:47 --> Utf8 Class Initialized
INFO - 2016-10-13 18:44:47 --> URI Class Initialized
INFO - 2016-10-13 18:44:47 --> Router Class Initialized
INFO - 2016-10-13 18:44:47 --> Output Class Initialized
INFO - 2016-10-13 18:44:47 --> Security Class Initialized
DEBUG - 2016-10-13 18:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 18:44:47 --> Input Class Initialized
INFO - 2016-10-13 18:44:47 --> Language Class Initialized
ERROR - 2016-10-13 18:44:47 --> 404 Page Not Found: /index
INFO - 2016-10-13 18:44:49 --> Config Class Initialized
INFO - 2016-10-13 18:44:49 --> Hooks Class Initialized
DEBUG - 2016-10-13 18:44:49 --> UTF-8 Support Enabled
INFO - 2016-10-13 18:44:49 --> Utf8 Class Initialized
INFO - 2016-10-13 18:44:49 --> URI Class Initialized
INFO - 2016-10-13 18:44:49 --> Router Class Initialized
INFO - 2016-10-13 18:44:49 --> Output Class Initialized
INFO - 2016-10-13 18:44:49 --> Security Class Initialized
DEBUG - 2016-10-13 18:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 18:44:49 --> Input Class Initialized
INFO - 2016-10-13 18:44:49 --> Language Class Initialized
ERROR - 2016-10-13 18:44:49 --> 404 Page Not Found: /index
INFO - 2016-10-13 18:44:51 --> Config Class Initialized
INFO - 2016-10-13 18:44:51 --> Hooks Class Initialized
DEBUG - 2016-10-13 18:44:51 --> UTF-8 Support Enabled
INFO - 2016-10-13 18:44:51 --> Utf8 Class Initialized
INFO - 2016-10-13 18:44:51 --> URI Class Initialized
INFO - 2016-10-13 18:44:51 --> Router Class Initialized
INFO - 2016-10-13 18:44:51 --> Output Class Initialized
INFO - 2016-10-13 18:44:51 --> Security Class Initialized
DEBUG - 2016-10-13 18:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 18:44:51 --> Input Class Initialized
INFO - 2016-10-13 18:44:51 --> Language Class Initialized
ERROR - 2016-10-13 18:44:51 --> 404 Page Not Found: /index
INFO - 2016-10-13 21:36:07 --> Config Class Initialized
INFO - 2016-10-13 21:36:07 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:07 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:07 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:07 --> URI Class Initialized
INFO - 2016-10-13 21:36:07 --> Router Class Initialized
INFO - 2016-10-13 21:36:07 --> Output Class Initialized
INFO - 2016-10-13 21:36:07 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:07 --> Input Class Initialized
INFO - 2016-10-13 21:36:07 --> Language Class Initialized
INFO - 2016-10-13 21:36:07 --> Language Class Initialized
INFO - 2016-10-13 21:36:07 --> Config Class Initialized
INFO - 2016-10-13 21:36:07 --> Loader Class Initialized
INFO - 2016-10-13 21:36:07 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:07 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:07 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:07 --> Parser Class Initialized
INFO - 2016-10-13 21:36:07 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:07 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 21:36:07 --> Config Class Initialized
INFO - 2016-10-13 21:36:07 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:07 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:07 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:07 --> URI Class Initialized
INFO - 2016-10-13 21:36:07 --> Router Class Initialized
INFO - 2016-10-13 21:36:07 --> Output Class Initialized
INFO - 2016-10-13 21:36:07 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:07 --> Input Class Initialized
INFO - 2016-10-13 21:36:07 --> Language Class Initialized
INFO - 2016-10-13 21:36:07 --> Language Class Initialized
INFO - 2016-10-13 21:36:07 --> Config Class Initialized
INFO - 2016-10-13 21:36:07 --> Loader Class Initialized
INFO - 2016-10-13 21:36:07 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:07 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:07 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:07 --> Parser Class Initialized
INFO - 2016-10-13 21:36:07 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:07 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 21:36:07 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:36:07 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:07 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-13 21:36:07 --> Final output sent to browser
DEBUG - 2016-10-13 21:36:07 --> Total execution time: 0.0502
INFO - 2016-10-13 21:36:11 --> Config Class Initialized
INFO - 2016-10-13 21:36:11 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:11 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:11 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:11 --> URI Class Initialized
INFO - 2016-10-13 21:36:11 --> Router Class Initialized
INFO - 2016-10-13 21:36:11 --> Output Class Initialized
INFO - 2016-10-13 21:36:11 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:11 --> Input Class Initialized
INFO - 2016-10-13 21:36:11 --> Language Class Initialized
INFO - 2016-10-13 21:36:11 --> Language Class Initialized
INFO - 2016-10-13 21:36:11 --> Config Class Initialized
INFO - 2016-10-13 21:36:11 --> Loader Class Initialized
INFO - 2016-10-13 21:36:11 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:11 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:11 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:11 --> Parser Class Initialized
INFO - 2016-10-13 21:36:11 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:11 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 21:36:11 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:36:11 --> Model Class Initialized
INFO - 2016-10-13 21:36:11 --> Final output sent to browser
DEBUG - 2016-10-13 21:36:11 --> Total execution time: 0.0341
INFO - 2016-10-13 21:36:11 --> Config Class Initialized
INFO - 2016-10-13 21:36:11 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:11 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:11 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:11 --> URI Class Initialized
INFO - 2016-10-13 21:36:11 --> Router Class Initialized
INFO - 2016-10-13 21:36:11 --> Output Class Initialized
INFO - 2016-10-13 21:36:11 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:11 --> Input Class Initialized
INFO - 2016-10-13 21:36:11 --> Language Class Initialized
INFO - 2016-10-13 21:36:11 --> Language Class Initialized
INFO - 2016-10-13 21:36:11 --> Config Class Initialized
INFO - 2016-10-13 21:36:11 --> Loader Class Initialized
INFO - 2016-10-13 21:36:11 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:11 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:11 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:11 --> Parser Class Initialized
INFO - 2016-10-13 21:36:11 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:11 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 21:36:11 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:36:11 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-13 21:36:11 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:36:11 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 21:36:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:36:11 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 21:36:11 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 21:36:11 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 21:36:11 --> Final output sent to browser
DEBUG - 2016-10-13 21:36:11 --> Total execution time: 0.0582
INFO - 2016-10-13 21:36:12 --> Config Class Initialized
INFO - 2016-10-13 21:36:12 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:12 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:12 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:12 --> URI Class Initialized
INFO - 2016-10-13 21:36:12 --> Router Class Initialized
INFO - 2016-10-13 21:36:12 --> Output Class Initialized
INFO - 2016-10-13 21:36:12 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:12 --> Input Class Initialized
INFO - 2016-10-13 21:36:12 --> Language Class Initialized
ERROR - 2016-10-13 21:36:12 --> 404 Page Not Found: /index
INFO - 2016-10-13 21:36:17 --> Config Class Initialized
INFO - 2016-10-13 21:36:17 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:17 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:17 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:17 --> URI Class Initialized
INFO - 2016-10-13 21:36:17 --> Router Class Initialized
INFO - 2016-10-13 21:36:17 --> Output Class Initialized
INFO - 2016-10-13 21:36:17 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:17 --> Input Class Initialized
INFO - 2016-10-13 21:36:17 --> Language Class Initialized
INFO - 2016-10-13 21:36:17 --> Language Class Initialized
INFO - 2016-10-13 21:36:17 --> Config Class Initialized
INFO - 2016-10-13 21:36:17 --> Loader Class Initialized
INFO - 2016-10-13 21:36:17 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:17 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:17 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:17 --> Parser Class Initialized
INFO - 2016-10-13 21:36:17 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:17 --> Servers MX_Controller Initialized
INFO - 2016-10-13 21:36:17 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 21:36:17 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:36:17 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:17 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 21:36:17 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 21:36:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 21:36:17 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:36:17 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-13 21:36:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 21:36:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 21:36:17 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 21:36:17 --> Final output sent to browser
DEBUG - 2016-10-13 21:36:17 --> Total execution time: 0.0603
INFO - 2016-10-13 21:36:17 --> Config Class Initialized
INFO - 2016-10-13 21:36:17 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:17 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:17 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:17 --> URI Class Initialized
INFO - 2016-10-13 21:36:17 --> Router Class Initialized
INFO - 2016-10-13 21:36:17 --> Output Class Initialized
INFO - 2016-10-13 21:36:17 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:17 --> Input Class Initialized
INFO - 2016-10-13 21:36:17 --> Language Class Initialized
INFO - 2016-10-13 21:36:17 --> Language Class Initialized
INFO - 2016-10-13 21:36:17 --> Config Class Initialized
INFO - 2016-10-13 21:36:17 --> Loader Class Initialized
INFO - 2016-10-13 21:36:17 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:17 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:17 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:17 --> Parser Class Initialized
INFO - 2016-10-13 21:36:17 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:17 --> Servers MX_Controller Initialized
INFO - 2016-10-13 21:36:17 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 21:36:18 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:36:18 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:18 --> Pagination Class Initialized
DEBUG - 2016-10-13 21:36:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-13 21:36:18 --> Final output sent to browser
DEBUG - 2016-10-13 21:36:18 --> Total execution time: 0.0558
INFO - 2016-10-13 21:36:18 --> Config Class Initialized
INFO - 2016-10-13 21:36:18 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:18 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:18 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:18 --> URI Class Initialized
INFO - 2016-10-13 21:36:18 --> Router Class Initialized
INFO - 2016-10-13 21:36:18 --> Output Class Initialized
INFO - 2016-10-13 21:36:18 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:18 --> Input Class Initialized
INFO - 2016-10-13 21:36:18 --> Language Class Initialized
ERROR - 2016-10-13 21:36:18 --> 404 Page Not Found: /index
INFO - 2016-10-13 21:36:20 --> Config Class Initialized
INFO - 2016-10-13 21:36:20 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:20 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:20 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:20 --> URI Class Initialized
INFO - 2016-10-13 21:36:20 --> Router Class Initialized
INFO - 2016-10-13 21:36:20 --> Output Class Initialized
INFO - 2016-10-13 21:36:20 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:20 --> Input Class Initialized
INFO - 2016-10-13 21:36:20 --> Language Class Initialized
INFO - 2016-10-13 21:36:20 --> Language Class Initialized
INFO - 2016-10-13 21:36:20 --> Config Class Initialized
INFO - 2016-10-13 21:36:20 --> Loader Class Initialized
INFO - 2016-10-13 21:36:20 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:20 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:20 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:20 --> Parser Class Initialized
INFO - 2016-10-13 21:36:20 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:20 --> Servers MX_Controller Initialized
INFO - 2016-10-13 21:36:20 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 21:36:20 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:36:20 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 21:36:20 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 21:36:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 21:36:20 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:36:20 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 21:36:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 21:36:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 21:36:20 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 21:36:20 --> Final output sent to browser
DEBUG - 2016-10-13 21:36:20 --> Total execution time: 0.0694
INFO - 2016-10-13 21:36:50 --> Config Class Initialized
INFO - 2016-10-13 21:36:50 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:50 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:50 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:50 --> URI Class Initialized
INFO - 2016-10-13 21:36:50 --> Router Class Initialized
INFO - 2016-10-13 21:36:50 --> Output Class Initialized
INFO - 2016-10-13 21:36:50 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:50 --> Input Class Initialized
INFO - 2016-10-13 21:36:50 --> Language Class Initialized
INFO - 2016-10-13 21:36:50 --> Language Class Initialized
INFO - 2016-10-13 21:36:50 --> Config Class Initialized
INFO - 2016-10-13 21:36:50 --> Loader Class Initialized
INFO - 2016-10-13 21:36:50 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:50 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:50 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:50 --> Parser Class Initialized
INFO - 2016-10-13 21:36:50 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:50 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 21:36:50 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:36:50 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-13 21:36:50 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:36:50 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 21:36:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:36:50 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 21:36:50 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 21:36:50 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 21:36:50 --> Final output sent to browser
DEBUG - 2016-10-13 21:36:50 --> Total execution time: 0.0644
INFO - 2016-10-13 21:36:51 --> Config Class Initialized
INFO - 2016-10-13 21:36:51 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:51 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:51 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:51 --> URI Class Initialized
INFO - 2016-10-13 21:36:51 --> Router Class Initialized
INFO - 2016-10-13 21:36:51 --> Output Class Initialized
INFO - 2016-10-13 21:36:51 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:51 --> Input Class Initialized
INFO - 2016-10-13 21:36:51 --> Language Class Initialized
ERROR - 2016-10-13 21:36:51 --> 404 Page Not Found: /index
INFO - 2016-10-13 21:36:53 --> Config Class Initialized
INFO - 2016-10-13 21:36:53 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:53 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:53 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:53 --> URI Class Initialized
INFO - 2016-10-13 21:36:53 --> Router Class Initialized
INFO - 2016-10-13 21:36:53 --> Output Class Initialized
INFO - 2016-10-13 21:36:53 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:53 --> Input Class Initialized
INFO - 2016-10-13 21:36:53 --> Language Class Initialized
INFO - 2016-10-13 21:36:53 --> Language Class Initialized
INFO - 2016-10-13 21:36:53 --> Config Class Initialized
INFO - 2016-10-13 21:36:53 --> Loader Class Initialized
INFO - 2016-10-13 21:36:53 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:53 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:53 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:53 --> Parser Class Initialized
INFO - 2016-10-13 21:36:53 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:53 --> Servers MX_Controller Initialized
INFO - 2016-10-13 21:36:53 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 21:36:53 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:36:53 --> Model Class Initialized
INFO - 2016-10-13 21:36:53 --> Config Class Initialized
INFO - 2016-10-13 21:36:53 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:53 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:53 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:53 --> URI Class Initialized
INFO - 2016-10-13 21:36:53 --> Router Class Initialized
INFO - 2016-10-13 21:36:53 --> Output Class Initialized
INFO - 2016-10-13 21:36:53 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:53 --> Input Class Initialized
INFO - 2016-10-13 21:36:53 --> Language Class Initialized
INFO - 2016-10-13 21:36:53 --> Language Class Initialized
INFO - 2016-10-13 21:36:53 --> Config Class Initialized
INFO - 2016-10-13 21:36:53 --> Loader Class Initialized
INFO - 2016-10-13 21:36:53 --> Helper loaded: common_helper
INFO - 2016-10-13 21:36:53 --> Helper loaded: url_helper
INFO - 2016-10-13 21:36:53 --> Database Driver Class Initialized
INFO - 2016-10-13 21:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:36:53 --> Parser Class Initialized
INFO - 2016-10-13 21:36:53 --> Controller Class Initialized
DEBUG - 2016-10-13 21:36:53 --> Home MX_Controller Initialized
INFO - 2016-10-13 21:36:53 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 21:36:53 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 21:36:53 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:36:53 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 21:36:53 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 21:36:53 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 21:36:53 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 21:36:53 --> Model Class Initialized
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-13 21:36:53 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 21:36:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 21:36:53 --> Final output sent to browser
DEBUG - 2016-10-13 21:36:53 --> Total execution time: 0.0663
INFO - 2016-10-13 21:36:54 --> Config Class Initialized
INFO - 2016-10-13 21:36:54 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:36:54 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:36:54 --> Utf8 Class Initialized
INFO - 2016-10-13 21:36:54 --> URI Class Initialized
INFO - 2016-10-13 21:36:54 --> Router Class Initialized
INFO - 2016-10-13 21:36:54 --> Output Class Initialized
INFO - 2016-10-13 21:36:54 --> Security Class Initialized
DEBUG - 2016-10-13 21:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:36:54 --> Input Class Initialized
INFO - 2016-10-13 21:36:54 --> Language Class Initialized
ERROR - 2016-10-13 21:36:54 --> 404 Page Not Found: /index
INFO - 2016-10-13 21:37:06 --> Config Class Initialized
INFO - 2016-10-13 21:37:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:37:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:37:06 --> Utf8 Class Initialized
INFO - 2016-10-13 21:37:06 --> URI Class Initialized
INFO - 2016-10-13 21:37:06 --> Router Class Initialized
INFO - 2016-10-13 21:37:06 --> Output Class Initialized
INFO - 2016-10-13 21:37:06 --> Security Class Initialized
DEBUG - 2016-10-13 21:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:37:06 --> Input Class Initialized
INFO - 2016-10-13 21:37:06 --> Language Class Initialized
INFO - 2016-10-13 21:37:06 --> Language Class Initialized
INFO - 2016-10-13 21:37:06 --> Config Class Initialized
INFO - 2016-10-13 21:37:06 --> Loader Class Initialized
INFO - 2016-10-13 21:37:06 --> Helper loaded: common_helper
INFO - 2016-10-13 21:37:06 --> Helper loaded: url_helper
INFO - 2016-10-13 21:37:06 --> Database Driver Class Initialized
INFO - 2016-10-13 21:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:37:06 --> Parser Class Initialized
INFO - 2016-10-13 21:37:06 --> Controller Class Initialized
DEBUG - 2016-10-13 21:37:06 --> User MX_Controller Initialized
INFO - 2016-10-13 21:37:06 --> Model Class Initialized
DEBUG - 2016-10-13 21:37:06 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-13 21:37:06 --> Model Class Initialized
INFO - 2016-10-13 21:37:06 --> Helper loaded: cookie_helper
INFO - 2016-10-13 21:37:06 --> Helper loaded: form_helper
DEBUG - 2016-10-13 21:37:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:37:06 --> Model Class Initialized
DEBUG - 2016-10-13 21:37:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:37:06 --> Model Class Initialized
INFO - 2016-10-13 21:37:06 --> Final output sent to browser
DEBUG - 2016-10-13 21:37:06 --> Total execution time: 0.0469
INFO - 2016-10-13 21:37:08 --> Config Class Initialized
INFO - 2016-10-13 21:37:08 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:37:08 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:37:08 --> Utf8 Class Initialized
INFO - 2016-10-13 21:37:08 --> URI Class Initialized
DEBUG - 2016-10-13 21:37:08 --> No URI present. Default controller set.
INFO - 2016-10-13 21:37:08 --> Router Class Initialized
INFO - 2016-10-13 21:37:08 --> Output Class Initialized
INFO - 2016-10-13 21:37:08 --> Security Class Initialized
DEBUG - 2016-10-13 21:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:37:08 --> Input Class Initialized
INFO - 2016-10-13 21:37:08 --> Language Class Initialized
INFO - 2016-10-13 21:37:08 --> Language Class Initialized
INFO - 2016-10-13 21:37:08 --> Config Class Initialized
INFO - 2016-10-13 21:37:08 --> Loader Class Initialized
INFO - 2016-10-13 21:37:08 --> Helper loaded: common_helper
INFO - 2016-10-13 21:37:08 --> Helper loaded: url_helper
INFO - 2016-10-13 21:37:08 --> Database Driver Class Initialized
INFO - 2016-10-13 21:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:37:08 --> Parser Class Initialized
INFO - 2016-10-13 21:37:08 --> Controller Class Initialized
DEBUG - 2016-10-13 21:37:08 --> Home MX_Controller Initialized
INFO - 2016-10-13 21:37:08 --> Model Class Initialized
DEBUG - 2016-10-13 21:37:08 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 21:37:08 --> Model Class Initialized
DEBUG - 2016-10-13 21:37:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 21:37:08 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 21:37:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 21:37:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 21:37:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 21:37:08 --> Final output sent to browser
DEBUG - 2016-10-13 21:37:08 --> Total execution time: 0.0368
INFO - 2016-10-13 21:37:14 --> Config Class Initialized
INFO - 2016-10-13 21:37:14 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:37:14 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:37:14 --> Utf8 Class Initialized
INFO - 2016-10-13 21:37:14 --> URI Class Initialized
INFO - 2016-10-13 21:37:14 --> Router Class Initialized
INFO - 2016-10-13 21:37:14 --> Output Class Initialized
INFO - 2016-10-13 21:37:14 --> Security Class Initialized
DEBUG - 2016-10-13 21:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:37:14 --> Input Class Initialized
INFO - 2016-10-13 21:37:14 --> Language Class Initialized
INFO - 2016-10-13 21:37:14 --> Language Class Initialized
INFO - 2016-10-13 21:37:14 --> Config Class Initialized
INFO - 2016-10-13 21:37:14 --> Loader Class Initialized
INFO - 2016-10-13 21:37:14 --> Helper loaded: common_helper
INFO - 2016-10-13 21:37:14 --> Helper loaded: url_helper
INFO - 2016-10-13 21:37:14 --> Database Driver Class Initialized
INFO - 2016-10-13 21:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:37:14 --> Parser Class Initialized
INFO - 2016-10-13 21:37:14 --> Controller Class Initialized
DEBUG - 2016-10-13 21:37:14 --> Servers MX_Controller Initialized
INFO - 2016-10-13 21:37:14 --> Model Class Initialized
DEBUG - 2016-10-13 21:37:14 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 21:37:14 --> Model Class Initialized
DEBUG - 2016-10-13 21:37:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:37:14 --> Model Class Initialized
DEBUG - 2016-10-13 21:37:14 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 21:37:14 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-13 21:37:14 --> Final output sent to browser
DEBUG - 2016-10-13 21:37:14 --> Total execution time: 0.0675
INFO - 2016-10-13 21:37:47 --> Config Class Initialized
INFO - 2016-10-13 21:37:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:37:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:37:47 --> Utf8 Class Initialized
INFO - 2016-10-13 21:37:47 --> URI Class Initialized
INFO - 2016-10-13 21:37:47 --> Router Class Initialized
INFO - 2016-10-13 21:37:47 --> Output Class Initialized
INFO - 2016-10-13 21:37:47 --> Security Class Initialized
DEBUG - 2016-10-13 21:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:37:47 --> Input Class Initialized
INFO - 2016-10-13 21:37:47 --> Language Class Initialized
INFO - 2016-10-13 21:37:47 --> Language Class Initialized
INFO - 2016-10-13 21:37:47 --> Config Class Initialized
INFO - 2016-10-13 21:37:47 --> Loader Class Initialized
INFO - 2016-10-13 21:37:47 --> Helper loaded: common_helper
INFO - 2016-10-13 21:37:47 --> Helper loaded: url_helper
INFO - 2016-10-13 21:37:47 --> Database Driver Class Initialized
INFO - 2016-10-13 21:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:37:47 --> Parser Class Initialized
INFO - 2016-10-13 21:37:47 --> Controller Class Initialized
DEBUG - 2016-10-13 21:37:47 --> Gametool MX_Controller Initialized
INFO - 2016-10-13 21:37:47 --> Config Class Initialized
INFO - 2016-10-13 21:37:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:37:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:37:47 --> Utf8 Class Initialized
INFO - 2016-10-13 21:37:47 --> URI Class Initialized
INFO - 2016-10-13 21:37:47 --> Router Class Initialized
INFO - 2016-10-13 21:37:47 --> Output Class Initialized
INFO - 2016-10-13 21:37:47 --> Security Class Initialized
DEBUG - 2016-10-13 21:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:37:47 --> Input Class Initialized
INFO - 2016-10-13 21:37:47 --> Language Class Initialized
INFO - 2016-10-13 21:37:47 --> Language Class Initialized
INFO - 2016-10-13 21:37:47 --> Config Class Initialized
INFO - 2016-10-13 21:37:47 --> Loader Class Initialized
INFO - 2016-10-13 21:37:47 --> Helper loaded: common_helper
INFO - 2016-10-13 21:37:47 --> Helper loaded: url_helper
INFO - 2016-10-13 21:37:47 --> Database Driver Class Initialized
INFO - 2016-10-13 21:37:47 --> Config Class Initialized
INFO - 2016-10-13 21:37:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:37:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:37:47 --> Utf8 Class Initialized
INFO - 2016-10-13 21:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:37:47 --> Parser Class Initialized
INFO - 2016-10-13 21:37:47 --> Controller Class Initialized
DEBUG - 2016-10-13 21:37:47 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 21:37:47 --> Model Class Initialized
DEBUG - 2016-10-13 21:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:37:47 --> Model Class Initialized
INFO - 2016-10-13 21:37:47 --> URI Class Initialized
INFO - 2016-10-13 21:37:47 --> Router Class Initialized
INFO - 2016-10-13 21:37:47 --> Output Class Initialized
INFO - 2016-10-13 21:37:47 --> Security Class Initialized
DEBUG - 2016-10-13 21:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:37:47 --> Input Class Initialized
INFO - 2016-10-13 21:37:47 --> Language Class Initialized
ERROR - 2016-10-13 21:37:47 --> 404 Page Not Found: /index
DEBUG - 2016-10-13 21:37:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/security_gt.php
INFO - 2016-10-13 21:37:47 --> Final output sent to browser
DEBUG - 2016-10-13 21:37:47 --> Total execution time: 0.0722
INFO - 2016-10-13 21:37:47 --> Config Class Initialized
INFO - 2016-10-13 21:37:47 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:37:47 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:37:47 --> Utf8 Class Initialized
INFO - 2016-10-13 21:37:47 --> URI Class Initialized
INFO - 2016-10-13 21:37:47 --> Router Class Initialized
INFO - 2016-10-13 21:37:47 --> Output Class Initialized
INFO - 2016-10-13 21:37:47 --> Security Class Initialized
DEBUG - 2016-10-13 21:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:37:47 --> Input Class Initialized
INFO - 2016-10-13 21:37:47 --> Language Class Initialized
ERROR - 2016-10-13 21:37:47 --> 404 Page Not Found: /index
INFO - 2016-10-13 21:38:05 --> Config Class Initialized
INFO - 2016-10-13 21:38:05 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:38:05 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:38:05 --> Utf8 Class Initialized
INFO - 2016-10-13 21:38:05 --> URI Class Initialized
INFO - 2016-10-13 21:38:05 --> Router Class Initialized
INFO - 2016-10-13 21:38:05 --> Output Class Initialized
INFO - 2016-10-13 21:38:05 --> Security Class Initialized
DEBUG - 2016-10-13 21:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:38:05 --> Input Class Initialized
INFO - 2016-10-13 21:38:05 --> Language Class Initialized
INFO - 2016-10-13 21:38:05 --> Language Class Initialized
INFO - 2016-10-13 21:38:05 --> Config Class Initialized
INFO - 2016-10-13 21:38:05 --> Loader Class Initialized
INFO - 2016-10-13 21:38:05 --> Helper loaded: common_helper
INFO - 2016-10-13 21:38:05 --> Helper loaded: url_helper
INFO - 2016-10-13 21:38:05 --> Database Driver Class Initialized
INFO - 2016-10-13 21:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:38:05 --> Parser Class Initialized
INFO - 2016-10-13 21:38:05 --> Controller Class Initialized
DEBUG - 2016-10-13 21:38:05 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 21:38:05 --> Model Class Initialized
DEBUG - 2016-10-13 21:38:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:38:05 --> Model Class Initialized
DEBUG - 2016-10-13 21:38:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/security_gt.php
INFO - 2016-10-13 21:38:05 --> Final output sent to browser
DEBUG - 2016-10-13 21:38:05 --> Total execution time: 0.0427
INFO - 2016-10-13 21:40:06 --> Config Class Initialized
INFO - 2016-10-13 21:40:06 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:40:06 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:40:06 --> Utf8 Class Initialized
INFO - 2016-10-13 21:40:06 --> URI Class Initialized
INFO - 2016-10-13 21:40:06 --> Router Class Initialized
INFO - 2016-10-13 21:40:06 --> Output Class Initialized
INFO - 2016-10-13 21:40:06 --> Security Class Initialized
DEBUG - 2016-10-13 21:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:40:06 --> Input Class Initialized
INFO - 2016-10-13 21:40:06 --> Language Class Initialized
INFO - 2016-10-13 21:40:06 --> Language Class Initialized
INFO - 2016-10-13 21:40:06 --> Config Class Initialized
INFO - 2016-10-13 21:40:06 --> Loader Class Initialized
INFO - 2016-10-13 21:40:06 --> Helper loaded: common_helper
INFO - 2016-10-13 21:40:06 --> Helper loaded: url_helper
INFO - 2016-10-13 21:40:06 --> Database Driver Class Initialized
INFO - 2016-10-13 21:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:40:06 --> Parser Class Initialized
INFO - 2016-10-13 21:40:06 --> Controller Class Initialized
DEBUG - 2016-10-13 21:40:06 --> Admincp MX_Controller Initialized
INFO - 2016-10-13 21:40:06 --> Model Class Initialized
DEBUG - 2016-10-13 21:40:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:40:06 --> Model Class Initialized
DEBUG - 2016-10-13 21:40:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/security_gt.php
INFO - 2016-10-13 21:40:06 --> Final output sent to browser
DEBUG - 2016-10-13 21:40:06 --> Total execution time: 0.0428
INFO - 2016-10-13 21:40:07 --> Config Class Initialized
INFO - 2016-10-13 21:40:07 --> Hooks Class Initialized
DEBUG - 2016-10-13 21:40:07 --> UTF-8 Support Enabled
INFO - 2016-10-13 21:40:07 --> Utf8 Class Initialized
INFO - 2016-10-13 21:40:07 --> URI Class Initialized
INFO - 2016-10-13 21:40:07 --> Router Class Initialized
INFO - 2016-10-13 21:40:07 --> Output Class Initialized
INFO - 2016-10-13 21:40:07 --> Security Class Initialized
DEBUG - 2016-10-13 21:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 21:40:07 --> Input Class Initialized
INFO - 2016-10-13 21:40:07 --> Language Class Initialized
INFO - 2016-10-13 21:40:07 --> Language Class Initialized
INFO - 2016-10-13 21:40:07 --> Config Class Initialized
INFO - 2016-10-13 21:40:07 --> Loader Class Initialized
INFO - 2016-10-13 21:40:07 --> Helper loaded: common_helper
INFO - 2016-10-13 21:40:07 --> Helper loaded: url_helper
INFO - 2016-10-13 21:40:07 --> Database Driver Class Initialized
INFO - 2016-10-13 21:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 21:40:07 --> Parser Class Initialized
INFO - 2016-10-13 21:40:07 --> Controller Class Initialized
DEBUG - 2016-10-13 21:40:07 --> Servers MX_Controller Initialized
INFO - 2016-10-13 21:40:07 --> Model Class Initialized
DEBUG - 2016-10-13 21:40:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 21:40:07 --> Model Class Initialized
DEBUG - 2016-10-13 21:40:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 21:40:07 --> Model Class Initialized
DEBUG - 2016-10-13 21:40:07 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-13 21:40:07 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-13 21:40:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-13 21:40:07 --> Model Class Initialized
DEBUG - 2016-10-13 21:40:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-13 21:40:07 --> Model Class Initialized
DEBUG - 2016-10-13 21:40:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-13 21:40:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-13 21:40:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-13 21:40:07 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-13 21:40:07 --> Final output sent to browser
DEBUG - 2016-10-13 21:40:07 --> Total execution time: 0.0444
INFO - 2016-10-13 22:15:28 --> Config Class Initialized
INFO - 2016-10-13 22:15:28 --> Hooks Class Initialized
DEBUG - 2016-10-13 22:15:28 --> UTF-8 Support Enabled
INFO - 2016-10-13 22:15:28 --> Utf8 Class Initialized
INFO - 2016-10-13 22:15:28 --> URI Class Initialized
DEBUG - 2016-10-13 22:15:28 --> No URI present. Default controller set.
INFO - 2016-10-13 22:15:28 --> Router Class Initialized
INFO - 2016-10-13 22:15:28 --> Output Class Initialized
INFO - 2016-10-13 22:15:28 --> Security Class Initialized
DEBUG - 2016-10-13 22:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 22:15:28 --> Input Class Initialized
INFO - 2016-10-13 22:15:28 --> Language Class Initialized
INFO - 2016-10-13 22:15:28 --> Language Class Initialized
INFO - 2016-10-13 22:15:28 --> Config Class Initialized
INFO - 2016-10-13 22:15:28 --> Loader Class Initialized
INFO - 2016-10-13 22:15:28 --> Helper loaded: common_helper
INFO - 2016-10-13 22:15:28 --> Helper loaded: url_helper
INFO - 2016-10-13 22:15:28 --> Database Driver Class Initialized
INFO - 2016-10-13 22:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 22:15:28 --> Parser Class Initialized
INFO - 2016-10-13 22:15:28 --> Controller Class Initialized
DEBUG - 2016-10-13 22:15:28 --> Home MX_Controller Initialized
INFO - 2016-10-13 22:15:28 --> Model Class Initialized
DEBUG - 2016-10-13 22:15:28 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 22:15:28 --> Model Class Initialized
DEBUG - 2016-10-13 22:15:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 22:15:28 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 22:15:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 22:15:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 22:15:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 22:15:28 --> Final output sent to browser
DEBUG - 2016-10-13 22:15:28 --> Total execution time: 0.0446
INFO - 2016-10-13 22:15:34 --> Config Class Initialized
INFO - 2016-10-13 22:15:34 --> Hooks Class Initialized
DEBUG - 2016-10-13 22:15:34 --> UTF-8 Support Enabled
INFO - 2016-10-13 22:15:34 --> Utf8 Class Initialized
INFO - 2016-10-13 22:15:34 --> URI Class Initialized
INFO - 2016-10-13 22:15:34 --> Router Class Initialized
INFO - 2016-10-13 22:15:34 --> Output Class Initialized
INFO - 2016-10-13 22:15:34 --> Security Class Initialized
DEBUG - 2016-10-13 22:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 22:15:34 --> Input Class Initialized
INFO - 2016-10-13 22:15:34 --> Language Class Initialized
INFO - 2016-10-13 22:15:34 --> Language Class Initialized
INFO - 2016-10-13 22:15:34 --> Config Class Initialized
INFO - 2016-10-13 22:15:34 --> Loader Class Initialized
INFO - 2016-10-13 22:15:34 --> Helper loaded: common_helper
INFO - 2016-10-13 22:15:34 --> Helper loaded: url_helper
INFO - 2016-10-13 22:15:34 --> Database Driver Class Initialized
INFO - 2016-10-13 22:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 22:15:34 --> Parser Class Initialized
INFO - 2016-10-13 22:15:34 --> Controller Class Initialized
DEBUG - 2016-10-13 22:15:34 --> Home MX_Controller Initialized
INFO - 2016-10-13 22:15:34 --> Model Class Initialized
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 22:15:34 --> Model Class Initialized
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-13 22:15:34 --> Content MX_Controller Initialized
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-13 22:15:34 --> Model Class Initialized
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-13 22:15:34 --> Slider MX_Controller Initialized
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-13 22:15:34 --> Model Class Initialized
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-13 22:15:34 --> Servers MX_Controller Initialized
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-13 22:15:34 --> Model Class Initialized
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-13 22:15:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 22:15:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-13 22:15:34 --> Final output sent to browser
DEBUG - 2016-10-13 22:15:34 --> Total execution time: 0.0585
INFO - 2016-10-13 22:15:35 --> Config Class Initialized
INFO - 2016-10-13 22:15:35 --> Hooks Class Initialized
DEBUG - 2016-10-13 22:15:35 --> UTF-8 Support Enabled
INFO - 2016-10-13 22:15:35 --> Utf8 Class Initialized
INFO - 2016-10-13 22:15:35 --> URI Class Initialized
INFO - 2016-10-13 22:15:35 --> Router Class Initialized
INFO - 2016-10-13 22:15:35 --> Output Class Initialized
INFO - 2016-10-13 22:15:35 --> Security Class Initialized
DEBUG - 2016-10-13 22:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 22:15:35 --> Input Class Initialized
INFO - 2016-10-13 22:15:35 --> Language Class Initialized
ERROR - 2016-10-13 22:15:35 --> 404 Page Not Found: /index
INFO - 2016-10-13 23:47:55 --> Config Class Initialized
INFO - 2016-10-13 23:47:55 --> Hooks Class Initialized
DEBUG - 2016-10-13 23:47:55 --> UTF-8 Support Enabled
INFO - 2016-10-13 23:47:55 --> Utf8 Class Initialized
INFO - 2016-10-13 23:47:55 --> URI Class Initialized
DEBUG - 2016-10-13 23:47:55 --> No URI present. Default controller set.
INFO - 2016-10-13 23:47:55 --> Router Class Initialized
INFO - 2016-10-13 23:47:55 --> Output Class Initialized
INFO - 2016-10-13 23:47:55 --> Security Class Initialized
DEBUG - 2016-10-13 23:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-13 23:47:55 --> Input Class Initialized
INFO - 2016-10-13 23:47:55 --> Language Class Initialized
INFO - 2016-10-13 23:47:55 --> Language Class Initialized
INFO - 2016-10-13 23:47:55 --> Config Class Initialized
INFO - 2016-10-13 23:47:55 --> Loader Class Initialized
INFO - 2016-10-13 23:47:55 --> Helper loaded: common_helper
INFO - 2016-10-13 23:47:55 --> Helper loaded: url_helper
INFO - 2016-10-13 23:47:55 --> Database Driver Class Initialized
INFO - 2016-10-13 23:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-13 23:47:55 --> Parser Class Initialized
INFO - 2016-10-13 23:47:55 --> Controller Class Initialized
DEBUG - 2016-10-13 23:47:55 --> Home MX_Controller Initialized
INFO - 2016-10-13 23:47:55 --> Model Class Initialized
DEBUG - 2016-10-13 23:47:55 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-13 23:47:55 --> Model Class Initialized
ERROR - 2016-10-13 23:47:55 --> Module controller failed to run: banner/index
DEBUG - 2016-10-13 23:47:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-13 23:47:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-13 23:47:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-13 23:47:55 --> Final output sent to browser
DEBUG - 2016-10-13 23:47:55 --> Total execution time: 0.0449
