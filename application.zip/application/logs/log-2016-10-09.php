<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-09 00:52:43 --> Config Class Initialized
INFO - 2016-10-09 00:52:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 00:52:43 --> UTF-8 Support Enabled
INFO - 2016-10-09 00:52:43 --> Utf8 Class Initialized
INFO - 2016-10-09 00:52:43 --> URI Class Initialized
INFO - 2016-10-09 00:52:43 --> Router Class Initialized
INFO - 2016-10-09 00:52:43 --> Output Class Initialized
INFO - 2016-10-09 00:52:43 --> Security Class Initialized
DEBUG - 2016-10-09 00:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 00:52:43 --> Input Class Initialized
INFO - 2016-10-09 00:52:43 --> Language Class Initialized
INFO - 2016-10-09 00:52:43 --> Language Class Initialized
INFO - 2016-10-09 00:52:43 --> Config Class Initialized
INFO - 2016-10-09 00:52:43 --> Loader Class Initialized
INFO - 2016-10-09 00:52:43 --> Helper loaded: common_helper
INFO - 2016-10-09 00:52:43 --> Helper loaded: url_helper
INFO - 2016-10-09 00:52:43 --> Database Driver Class Initialized
INFO - 2016-10-09 00:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 00:52:43 --> Parser Class Initialized
INFO - 2016-10-09 00:52:43 --> Controller Class Initialized
DEBUG - 2016-10-09 00:52:43 --> Content MX_Controller Initialized
INFO - 2016-10-09 00:52:43 --> Model Class Initialized
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 00:52:43 --> Model Class Initialized
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 00:52:43 --> Model Class Initialized
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 00:52:43 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 00:52:43 --> Model Class Initialized
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 00:52:43 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 00:52:43 --> Model Class Initialized
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 00:52:43 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 00:52:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 00:52:43 --> Final output sent to browser
DEBUG - 2016-10-09 00:52:43 --> Total execution time: 0.0587
INFO - 2016-10-09 02:08:30 --> Config Class Initialized
INFO - 2016-10-09 02:08:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 02:08:30 --> UTF-8 Support Enabled
INFO - 2016-10-09 02:08:30 --> Utf8 Class Initialized
INFO - 2016-10-09 02:08:30 --> URI Class Initialized
INFO - 2016-10-09 02:08:30 --> Router Class Initialized
INFO - 2016-10-09 02:08:30 --> Output Class Initialized
INFO - 2016-10-09 02:08:30 --> Security Class Initialized
DEBUG - 2016-10-09 02:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 02:08:30 --> Input Class Initialized
INFO - 2016-10-09 02:08:30 --> Language Class Initialized
INFO - 2016-10-09 02:08:30 --> Language Class Initialized
INFO - 2016-10-09 02:08:30 --> Config Class Initialized
INFO - 2016-10-09 02:08:30 --> Loader Class Initialized
INFO - 2016-10-09 02:08:30 --> Helper loaded: common_helper
INFO - 2016-10-09 02:08:30 --> Helper loaded: url_helper
INFO - 2016-10-09 02:08:30 --> Database Driver Class Initialized
INFO - 2016-10-09 02:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 02:08:30 --> Parser Class Initialized
INFO - 2016-10-09 02:08:30 --> Controller Class Initialized
DEBUG - 2016-10-09 02:08:30 --> Content MX_Controller Initialized
INFO - 2016-10-09 02:08:30 --> Model Class Initialized
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 02:08:30 --> Model Class Initialized
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 02:08:30 --> Model Class Initialized
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 02:08:30 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 02:08:30 --> Model Class Initialized
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 02:08:30 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 02:08:30 --> Model Class Initialized
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 02:08:30 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 02:08:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 02:08:30 --> Final output sent to browser
DEBUG - 2016-10-09 02:08:30 --> Total execution time: 0.0599
INFO - 2016-10-09 03:24:17 --> Config Class Initialized
INFO - 2016-10-09 03:24:17 --> Hooks Class Initialized
DEBUG - 2016-10-09 03:24:17 --> UTF-8 Support Enabled
INFO - 2016-10-09 03:24:17 --> Utf8 Class Initialized
INFO - 2016-10-09 03:24:17 --> URI Class Initialized
INFO - 2016-10-09 03:24:17 --> Router Class Initialized
INFO - 2016-10-09 03:24:17 --> Output Class Initialized
INFO - 2016-10-09 03:24:17 --> Security Class Initialized
DEBUG - 2016-10-09 03:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 03:24:17 --> Input Class Initialized
INFO - 2016-10-09 03:24:17 --> Language Class Initialized
INFO - 2016-10-09 03:24:17 --> Language Class Initialized
INFO - 2016-10-09 03:24:17 --> Config Class Initialized
INFO - 2016-10-09 03:24:17 --> Loader Class Initialized
INFO - 2016-10-09 03:24:17 --> Helper loaded: common_helper
INFO - 2016-10-09 03:24:17 --> Helper loaded: url_helper
INFO - 2016-10-09 03:24:17 --> Database Driver Class Initialized
INFO - 2016-10-09 03:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 03:24:17 --> Parser Class Initialized
INFO - 2016-10-09 03:24:17 --> Controller Class Initialized
DEBUG - 2016-10-09 03:24:17 --> Content MX_Controller Initialized
INFO - 2016-10-09 03:24:17 --> Model Class Initialized
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 03:24:17 --> Model Class Initialized
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 03:24:17 --> Model Class Initialized
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/list.php
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 03:24:17 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 03:24:17 --> Model Class Initialized
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 03:24:17 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 03:24:17 --> Model Class Initialized
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 03:24:17 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 03:24:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 03:24:17 --> Final output sent to browser
DEBUG - 2016-10-09 03:24:17 --> Total execution time: 0.0667
INFO - 2016-10-09 03:29:11 --> Config Class Initialized
INFO - 2016-10-09 03:29:11 --> Hooks Class Initialized
DEBUG - 2016-10-09 03:29:11 --> UTF-8 Support Enabled
INFO - 2016-10-09 03:29:11 --> Utf8 Class Initialized
INFO - 2016-10-09 03:29:11 --> URI Class Initialized
INFO - 2016-10-09 03:29:11 --> Router Class Initialized
INFO - 2016-10-09 03:29:11 --> Output Class Initialized
INFO - 2016-10-09 03:29:11 --> Security Class Initialized
DEBUG - 2016-10-09 03:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 03:29:11 --> Input Class Initialized
INFO - 2016-10-09 03:29:11 --> Language Class Initialized
INFO - 2016-10-09 03:29:11 --> Language Class Initialized
INFO - 2016-10-09 03:29:11 --> Config Class Initialized
INFO - 2016-10-09 03:29:11 --> Loader Class Initialized
INFO - 2016-10-09 03:29:11 --> Helper loaded: common_helper
INFO - 2016-10-09 03:29:11 --> Helper loaded: url_helper
INFO - 2016-10-09 03:29:11 --> Database Driver Class Initialized
INFO - 2016-10-09 03:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 03:29:11 --> Parser Class Initialized
INFO - 2016-10-09 03:29:11 --> Controller Class Initialized
DEBUG - 2016-10-09 03:29:11 --> Content MX_Controller Initialized
INFO - 2016-10-09 03:29:11 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 03:29:11 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 03:29:11 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 03:29:11 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 03:29:11 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 03:29:11 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 03:29:11 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 03:29:11 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 03:29:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 03:29:11 --> Final output sent to browser
DEBUG - 2016-10-09 03:29:11 --> Total execution time: 0.0565
INFO - 2016-10-09 03:29:41 --> Config Class Initialized
INFO - 2016-10-09 03:29:41 --> Hooks Class Initialized
DEBUG - 2016-10-09 03:29:41 --> UTF-8 Support Enabled
INFO - 2016-10-09 03:29:41 --> Utf8 Class Initialized
INFO - 2016-10-09 03:29:41 --> URI Class Initialized
INFO - 2016-10-09 03:29:41 --> Router Class Initialized
INFO - 2016-10-09 03:29:41 --> Output Class Initialized
INFO - 2016-10-09 03:29:41 --> Security Class Initialized
DEBUG - 2016-10-09 03:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 03:29:41 --> Input Class Initialized
INFO - 2016-10-09 03:29:41 --> Language Class Initialized
INFO - 2016-10-09 03:29:41 --> Language Class Initialized
INFO - 2016-10-09 03:29:41 --> Config Class Initialized
INFO - 2016-10-09 03:29:41 --> Loader Class Initialized
INFO - 2016-10-09 03:29:41 --> Helper loaded: common_helper
INFO - 2016-10-09 03:29:41 --> Helper loaded: url_helper
INFO - 2016-10-09 03:29:41 --> Database Driver Class Initialized
INFO - 2016-10-09 03:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 03:29:41 --> Parser Class Initialized
INFO - 2016-10-09 03:29:41 --> Controller Class Initialized
DEBUG - 2016-10-09 03:29:41 --> Content MX_Controller Initialized
INFO - 2016-10-09 03:29:41 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 03:29:41 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 03:29:41 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/list.php
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 03:29:41 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 03:29:41 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 03:29:41 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 03:29:41 --> Model Class Initialized
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 03:29:41 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 03:29:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 03:29:41 --> Final output sent to browser
DEBUG - 2016-10-09 03:29:41 --> Total execution time: 0.0597
INFO - 2016-10-09 03:30:38 --> Config Class Initialized
INFO - 2016-10-09 03:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-09 03:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-09 03:30:38 --> Utf8 Class Initialized
INFO - 2016-10-09 03:30:38 --> URI Class Initialized
INFO - 2016-10-09 03:30:38 --> Router Class Initialized
INFO - 2016-10-09 03:30:38 --> Output Class Initialized
INFO - 2016-10-09 03:30:38 --> Security Class Initialized
DEBUG - 2016-10-09 03:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 03:30:38 --> Input Class Initialized
INFO - 2016-10-09 03:30:38 --> Language Class Initialized
INFO - 2016-10-09 03:30:38 --> Language Class Initialized
INFO - 2016-10-09 03:30:38 --> Config Class Initialized
INFO - 2016-10-09 03:30:38 --> Loader Class Initialized
INFO - 2016-10-09 03:30:38 --> Helper loaded: common_helper
INFO - 2016-10-09 03:30:38 --> Helper loaded: url_helper
INFO - 2016-10-09 03:30:38 --> Database Driver Class Initialized
INFO - 2016-10-09 03:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 03:30:38 --> Parser Class Initialized
INFO - 2016-10-09 03:30:38 --> Controller Class Initialized
DEBUG - 2016-10-09 03:30:38 --> Content MX_Controller Initialized
INFO - 2016-10-09 03:30:38 --> Model Class Initialized
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 03:30:38 --> Model Class Initialized
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 03:30:38 --> Model Class Initialized
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/list.php
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 03:30:38 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 03:30:38 --> Model Class Initialized
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 03:30:38 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 03:30:38 --> Model Class Initialized
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 03:30:38 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 03:30:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 03:30:38 --> Final output sent to browser
DEBUG - 2016-10-09 03:30:38 --> Total execution time: 0.0545
INFO - 2016-10-09 03:32:21 --> Config Class Initialized
INFO - 2016-10-09 03:32:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 03:32:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 03:32:21 --> Utf8 Class Initialized
INFO - 2016-10-09 03:32:21 --> URI Class Initialized
INFO - 2016-10-09 03:32:21 --> Router Class Initialized
INFO - 2016-10-09 03:32:21 --> Output Class Initialized
INFO - 2016-10-09 03:32:21 --> Security Class Initialized
DEBUG - 2016-10-09 03:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 03:32:21 --> Input Class Initialized
INFO - 2016-10-09 03:32:21 --> Language Class Initialized
INFO - 2016-10-09 03:32:21 --> Language Class Initialized
INFO - 2016-10-09 03:32:21 --> Config Class Initialized
INFO - 2016-10-09 03:32:21 --> Loader Class Initialized
INFO - 2016-10-09 03:32:21 --> Helper loaded: common_helper
INFO - 2016-10-09 03:32:21 --> Helper loaded: url_helper
INFO - 2016-10-09 03:32:21 --> Database Driver Class Initialized
INFO - 2016-10-09 03:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 03:32:21 --> Parser Class Initialized
INFO - 2016-10-09 03:32:21 --> Controller Class Initialized
DEBUG - 2016-10-09 03:32:21 --> Content MX_Controller Initialized
INFO - 2016-10-09 03:32:21 --> Model Class Initialized
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 03:32:21 --> Model Class Initialized
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 03:32:21 --> Model Class Initialized
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 03:32:21 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 03:32:21 --> Model Class Initialized
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 03:32:21 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 03:32:21 --> Model Class Initialized
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 03:32:21 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 03:32:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 03:32:21 --> Final output sent to browser
DEBUG - 2016-10-09 03:32:21 --> Total execution time: 0.0575
INFO - 2016-10-09 04:40:04 --> Config Class Initialized
INFO - 2016-10-09 04:40:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:40:04 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:40:04 --> Utf8 Class Initialized
INFO - 2016-10-09 04:40:04 --> URI Class Initialized
INFO - 2016-10-09 04:40:04 --> Router Class Initialized
INFO - 2016-10-09 04:40:04 --> Output Class Initialized
INFO - 2016-10-09 04:40:04 --> Security Class Initialized
DEBUG - 2016-10-09 04:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:40:04 --> Input Class Initialized
INFO - 2016-10-09 04:40:04 --> Language Class Initialized
ERROR - 2016-10-09 04:40:04 --> 404 Page Not Found: /index
INFO - 2016-10-09 04:40:05 --> Config Class Initialized
INFO - 2016-10-09 04:40:05 --> Hooks Class Initialized
DEBUG - 2016-10-09 04:40:05 --> UTF-8 Support Enabled
INFO - 2016-10-09 04:40:05 --> Utf8 Class Initialized
INFO - 2016-10-09 04:40:05 --> URI Class Initialized
INFO - 2016-10-09 04:40:05 --> Router Class Initialized
INFO - 2016-10-09 04:40:05 --> Output Class Initialized
INFO - 2016-10-09 04:40:05 --> Security Class Initialized
DEBUG - 2016-10-09 04:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 04:40:05 --> Input Class Initialized
INFO - 2016-10-09 04:40:05 --> Language Class Initialized
INFO - 2016-10-09 04:40:05 --> Language Class Initialized
INFO - 2016-10-09 04:40:05 --> Config Class Initialized
INFO - 2016-10-09 04:40:05 --> Loader Class Initialized
INFO - 2016-10-09 04:40:05 --> Helper loaded: common_helper
INFO - 2016-10-09 04:40:05 --> Helper loaded: url_helper
INFO - 2016-10-09 04:40:05 --> Database Driver Class Initialized
INFO - 2016-10-09 04:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 04:40:05 --> Parser Class Initialized
INFO - 2016-10-09 04:40:05 --> Controller Class Initialized
DEBUG - 2016-10-09 04:40:05 --> Content MX_Controller Initialized
INFO - 2016-10-09 04:40:05 --> Model Class Initialized
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 04:40:05 --> Model Class Initialized
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 04:40:05 --> Model Class Initialized
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 04:40:05 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 04:40:05 --> Model Class Initialized
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 04:40:05 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 04:40:05 --> Model Class Initialized
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 04:40:05 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 04:40:05 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 04:40:05 --> Final output sent to browser
DEBUG - 2016-10-09 04:40:05 --> Total execution time: 0.0578
INFO - 2016-10-09 05:22:44 --> Config Class Initialized
INFO - 2016-10-09 05:22:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 05:22:44 --> UTF-8 Support Enabled
INFO - 2016-10-09 05:22:44 --> Utf8 Class Initialized
INFO - 2016-10-09 05:22:44 --> URI Class Initialized
INFO - 2016-10-09 05:22:44 --> Router Class Initialized
INFO - 2016-10-09 05:22:44 --> Output Class Initialized
INFO - 2016-10-09 05:22:44 --> Security Class Initialized
DEBUG - 2016-10-09 05:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 05:22:44 --> Input Class Initialized
INFO - 2016-10-09 05:22:44 --> Language Class Initialized
ERROR - 2016-10-09 05:22:44 --> 404 Page Not Found: /index
INFO - 2016-10-09 05:22:44 --> Config Class Initialized
INFO - 2016-10-09 05:22:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 05:22:44 --> UTF-8 Support Enabled
INFO - 2016-10-09 05:22:44 --> Utf8 Class Initialized
INFO - 2016-10-09 05:22:44 --> URI Class Initialized
DEBUG - 2016-10-09 05:22:44 --> No URI present. Default controller set.
INFO - 2016-10-09 05:22:44 --> Router Class Initialized
INFO - 2016-10-09 05:22:44 --> Output Class Initialized
INFO - 2016-10-09 05:22:44 --> Security Class Initialized
DEBUG - 2016-10-09 05:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 05:22:44 --> Input Class Initialized
INFO - 2016-10-09 05:22:44 --> Language Class Initialized
INFO - 2016-10-09 05:22:44 --> Language Class Initialized
INFO - 2016-10-09 05:22:44 --> Config Class Initialized
INFO - 2016-10-09 05:22:44 --> Loader Class Initialized
INFO - 2016-10-09 05:22:44 --> Helper loaded: common_helper
INFO - 2016-10-09 05:22:44 --> Helper loaded: url_helper
INFO - 2016-10-09 05:22:44 --> Database Driver Class Initialized
INFO - 2016-10-09 05:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 05:22:44 --> Parser Class Initialized
INFO - 2016-10-09 05:22:44 --> Controller Class Initialized
DEBUG - 2016-10-09 05:22:44 --> Home MX_Controller Initialized
INFO - 2016-10-09 05:22:44 --> Model Class Initialized
DEBUG - 2016-10-09 05:22:44 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-09 05:22:44 --> Model Class Initialized
ERROR - 2016-10-09 05:22:44 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 05:22:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 05:22:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 05:22:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-09 05:22:44 --> Final output sent to browser
DEBUG - 2016-10-09 05:22:44 --> Total execution time: 0.0455
INFO - 2016-10-09 05:55:51 --> Config Class Initialized
INFO - 2016-10-09 05:55:51 --> Hooks Class Initialized
DEBUG - 2016-10-09 05:55:51 --> UTF-8 Support Enabled
INFO - 2016-10-09 05:55:51 --> Utf8 Class Initialized
INFO - 2016-10-09 05:55:51 --> URI Class Initialized
INFO - 2016-10-09 05:55:51 --> Router Class Initialized
INFO - 2016-10-09 05:55:51 --> Output Class Initialized
INFO - 2016-10-09 05:55:51 --> Security Class Initialized
DEBUG - 2016-10-09 05:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 05:55:51 --> Input Class Initialized
INFO - 2016-10-09 05:55:51 --> Language Class Initialized
INFO - 2016-10-09 05:55:51 --> Language Class Initialized
INFO - 2016-10-09 05:55:51 --> Config Class Initialized
INFO - 2016-10-09 05:55:51 --> Loader Class Initialized
INFO - 2016-10-09 05:55:51 --> Helper loaded: common_helper
INFO - 2016-10-09 05:55:51 --> Helper loaded: url_helper
INFO - 2016-10-09 05:55:51 --> Database Driver Class Initialized
INFO - 2016-10-09 05:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 05:55:51 --> Parser Class Initialized
INFO - 2016-10-09 05:55:51 --> Controller Class Initialized
DEBUG - 2016-10-09 05:55:51 --> Content MX_Controller Initialized
INFO - 2016-10-09 05:55:51 --> Model Class Initialized
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 05:55:51 --> Model Class Initialized
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 05:55:51 --> Model Class Initialized
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 05:55:51 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 05:55:51 --> Model Class Initialized
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 05:55:51 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 05:55:51 --> Model Class Initialized
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 05:55:51 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 05:55:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 05:55:51 --> Final output sent to browser
DEBUG - 2016-10-09 05:55:51 --> Total execution time: 0.0577
INFO - 2016-10-09 07:11:38 --> Config Class Initialized
INFO - 2016-10-09 07:11:38 --> Hooks Class Initialized
DEBUG - 2016-10-09 07:11:38 --> UTF-8 Support Enabled
INFO - 2016-10-09 07:11:38 --> Utf8 Class Initialized
INFO - 2016-10-09 07:11:38 --> URI Class Initialized
INFO - 2016-10-09 07:11:38 --> Router Class Initialized
INFO - 2016-10-09 07:11:38 --> Output Class Initialized
INFO - 2016-10-09 07:11:38 --> Security Class Initialized
DEBUG - 2016-10-09 07:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 07:11:38 --> Input Class Initialized
INFO - 2016-10-09 07:11:38 --> Language Class Initialized
INFO - 2016-10-09 07:11:38 --> Language Class Initialized
INFO - 2016-10-09 07:11:38 --> Config Class Initialized
INFO - 2016-10-09 07:11:38 --> Loader Class Initialized
INFO - 2016-10-09 07:11:38 --> Helper loaded: common_helper
INFO - 2016-10-09 07:11:38 --> Helper loaded: url_helper
INFO - 2016-10-09 07:11:38 --> Database Driver Class Initialized
INFO - 2016-10-09 07:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 07:11:38 --> Parser Class Initialized
INFO - 2016-10-09 07:11:38 --> Controller Class Initialized
DEBUG - 2016-10-09 07:11:38 --> Content MX_Controller Initialized
INFO - 2016-10-09 07:11:38 --> Model Class Initialized
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 07:11:38 --> Model Class Initialized
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 07:11:38 --> Model Class Initialized
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 07:11:38 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 07:11:38 --> Model Class Initialized
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 07:11:38 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 07:11:38 --> Model Class Initialized
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 07:11:38 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 07:11:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 07:11:38 --> Final output sent to browser
DEBUG - 2016-10-09 07:11:38 --> Total execution time: 0.0620
INFO - 2016-10-09 07:47:24 --> Config Class Initialized
INFO - 2016-10-09 07:47:24 --> Hooks Class Initialized
DEBUG - 2016-10-09 07:47:24 --> UTF-8 Support Enabled
INFO - 2016-10-09 07:47:24 --> Utf8 Class Initialized
INFO - 2016-10-09 07:47:24 --> URI Class Initialized
DEBUG - 2016-10-09 07:47:24 --> No URI present. Default controller set.
INFO - 2016-10-09 07:47:24 --> Router Class Initialized
INFO - 2016-10-09 07:47:24 --> Output Class Initialized
INFO - 2016-10-09 07:47:24 --> Security Class Initialized
DEBUG - 2016-10-09 07:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 07:47:24 --> Input Class Initialized
INFO - 2016-10-09 07:47:24 --> Language Class Initialized
INFO - 2016-10-09 07:47:24 --> Language Class Initialized
INFO - 2016-10-09 07:47:24 --> Config Class Initialized
INFO - 2016-10-09 07:47:24 --> Loader Class Initialized
INFO - 2016-10-09 07:47:24 --> Helper loaded: common_helper
INFO - 2016-10-09 07:47:24 --> Helper loaded: url_helper
INFO - 2016-10-09 07:47:24 --> Database Driver Class Initialized
INFO - 2016-10-09 07:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 07:47:24 --> Parser Class Initialized
INFO - 2016-10-09 07:47:24 --> Controller Class Initialized
DEBUG - 2016-10-09 07:47:24 --> Home MX_Controller Initialized
INFO - 2016-10-09 07:47:24 --> Model Class Initialized
DEBUG - 2016-10-09 07:47:24 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-09 07:47:24 --> Model Class Initialized
ERROR - 2016-10-09 07:47:24 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 07:47:24 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 07:47:24 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 07:47:24 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-09 07:47:24 --> Final output sent to browser
DEBUG - 2016-10-09 07:47:24 --> Total execution time: 0.0456
INFO - 2016-10-09 08:27:25 --> Config Class Initialized
INFO - 2016-10-09 08:27:25 --> Hooks Class Initialized
DEBUG - 2016-10-09 08:27:25 --> UTF-8 Support Enabled
INFO - 2016-10-09 08:27:25 --> Utf8 Class Initialized
INFO - 2016-10-09 08:27:25 --> URI Class Initialized
INFO - 2016-10-09 08:27:25 --> Router Class Initialized
INFO - 2016-10-09 08:27:25 --> Output Class Initialized
INFO - 2016-10-09 08:27:25 --> Security Class Initialized
DEBUG - 2016-10-09 08:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 08:27:25 --> Input Class Initialized
INFO - 2016-10-09 08:27:25 --> Language Class Initialized
INFO - 2016-10-09 08:27:25 --> Language Class Initialized
INFO - 2016-10-09 08:27:25 --> Config Class Initialized
INFO - 2016-10-09 08:27:25 --> Loader Class Initialized
INFO - 2016-10-09 08:27:25 --> Helper loaded: common_helper
INFO - 2016-10-09 08:27:25 --> Helper loaded: url_helper
INFO - 2016-10-09 08:27:25 --> Database Driver Class Initialized
INFO - 2016-10-09 08:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 08:27:25 --> Parser Class Initialized
INFO - 2016-10-09 08:27:25 --> Controller Class Initialized
DEBUG - 2016-10-09 08:27:25 --> Content MX_Controller Initialized
INFO - 2016-10-09 08:27:25 --> Model Class Initialized
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 08:27:25 --> Model Class Initialized
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 08:27:25 --> Model Class Initialized
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 08:27:25 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 08:27:25 --> Model Class Initialized
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 08:27:25 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 08:27:25 --> Model Class Initialized
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 08:27:25 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 08:27:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 08:27:25 --> Final output sent to browser
DEBUG - 2016-10-09 08:27:25 --> Total execution time: 0.1136
INFO - 2016-10-09 09:43:20 --> Config Class Initialized
INFO - 2016-10-09 09:43:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 09:43:20 --> UTF-8 Support Enabled
INFO - 2016-10-09 09:43:20 --> Utf8 Class Initialized
INFO - 2016-10-09 09:43:20 --> URI Class Initialized
INFO - 2016-10-09 09:43:20 --> Router Class Initialized
INFO - 2016-10-09 09:43:20 --> Output Class Initialized
INFO - 2016-10-09 09:43:20 --> Security Class Initialized
DEBUG - 2016-10-09 09:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 09:43:20 --> Input Class Initialized
INFO - 2016-10-09 09:43:20 --> Language Class Initialized
INFO - 2016-10-09 09:43:20 --> Language Class Initialized
INFO - 2016-10-09 09:43:20 --> Config Class Initialized
INFO - 2016-10-09 09:43:20 --> Loader Class Initialized
INFO - 2016-10-09 09:43:20 --> Helper loaded: common_helper
INFO - 2016-10-09 09:43:20 --> Helper loaded: url_helper
INFO - 2016-10-09 09:43:20 --> Database Driver Class Initialized
INFO - 2016-10-09 09:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 09:43:20 --> Parser Class Initialized
INFO - 2016-10-09 09:43:20 --> Controller Class Initialized
DEBUG - 2016-10-09 09:43:20 --> Content MX_Controller Initialized
INFO - 2016-10-09 09:43:20 --> Model Class Initialized
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 09:43:20 --> Model Class Initialized
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 09:43:20 --> Model Class Initialized
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 09:43:20 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 09:43:20 --> Model Class Initialized
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 09:43:20 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 09:43:20 --> Model Class Initialized
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 09:43:20 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 09:43:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 09:43:20 --> Final output sent to browser
DEBUG - 2016-10-09 09:43:20 --> Total execution time: 0.0563
INFO - 2016-10-09 10:07:32 --> Config Class Initialized
INFO - 2016-10-09 10:07:32 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:07:32 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:07:32 --> Utf8 Class Initialized
INFO - 2016-10-09 10:07:32 --> URI Class Initialized
DEBUG - 2016-10-09 10:07:32 --> No URI present. Default controller set.
INFO - 2016-10-09 10:07:32 --> Router Class Initialized
INFO - 2016-10-09 10:07:32 --> Output Class Initialized
INFO - 2016-10-09 10:07:32 --> Security Class Initialized
DEBUG - 2016-10-09 10:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:07:32 --> Input Class Initialized
INFO - 2016-10-09 10:07:32 --> Language Class Initialized
INFO - 2016-10-09 10:07:32 --> Language Class Initialized
INFO - 2016-10-09 10:07:32 --> Config Class Initialized
INFO - 2016-10-09 10:07:32 --> Loader Class Initialized
INFO - 2016-10-09 10:07:32 --> Helper loaded: common_helper
INFO - 2016-10-09 10:07:32 --> Helper loaded: url_helper
INFO - 2016-10-09 10:07:32 --> Database Driver Class Initialized
INFO - 2016-10-09 10:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:07:32 --> Parser Class Initialized
INFO - 2016-10-09 10:07:32 --> Controller Class Initialized
DEBUG - 2016-10-09 10:07:32 --> Home MX_Controller Initialized
INFO - 2016-10-09 10:07:32 --> Model Class Initialized
DEBUG - 2016-10-09 10:07:32 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-09 10:07:32 --> Model Class Initialized
ERROR - 2016-10-09 10:07:32 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 10:07:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 10:07:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 10:07:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-09 10:07:32 --> Final output sent to browser
DEBUG - 2016-10-09 10:07:32 --> Total execution time: 0.0442
INFO - 2016-10-09 10:16:48 --> Config Class Initialized
INFO - 2016-10-09 10:16:48 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:16:48 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:16:48 --> Utf8 Class Initialized
INFO - 2016-10-09 10:16:48 --> URI Class Initialized
INFO - 2016-10-09 10:16:48 --> Router Class Initialized
INFO - 2016-10-09 10:16:48 --> Output Class Initialized
INFO - 2016-10-09 10:16:48 --> Security Class Initialized
DEBUG - 2016-10-09 10:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:16:48 --> Input Class Initialized
INFO - 2016-10-09 10:16:48 --> Language Class Initialized
INFO - 2016-10-09 10:16:48 --> Language Class Initialized
INFO - 2016-10-09 10:16:48 --> Config Class Initialized
INFO - 2016-10-09 10:16:48 --> Loader Class Initialized
INFO - 2016-10-09 10:16:48 --> Helper loaded: common_helper
INFO - 2016-10-09 10:16:48 --> Helper loaded: url_helper
INFO - 2016-10-09 10:16:48 --> Database Driver Class Initialized
INFO - 2016-10-09 10:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:16:48 --> Parser Class Initialized
INFO - 2016-10-09 10:16:48 --> Controller Class Initialized
DEBUG - 2016-10-09 10:16:48 --> Content MX_Controller Initialized
INFO - 2016-10-09 10:16:48 --> Model Class Initialized
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 10:16:48 --> Model Class Initialized
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 10:16:48 --> Model Class Initialized
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 10:16:48 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 10:16:48 --> Model Class Initialized
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 10:16:48 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 10:16:48 --> Model Class Initialized
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 10:16:48 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 10:16:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 10:16:48 --> Final output sent to browser
DEBUG - 2016-10-09 10:16:48 --> Total execution time: 0.0846
INFO - 2016-10-09 10:18:08 --> Config Class Initialized
INFO - 2016-10-09 10:18:08 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:18:08 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:18:08 --> Utf8 Class Initialized
INFO - 2016-10-09 10:18:08 --> URI Class Initialized
INFO - 2016-10-09 10:18:08 --> Router Class Initialized
INFO - 2016-10-09 10:18:08 --> Output Class Initialized
INFO - 2016-10-09 10:18:08 --> Security Class Initialized
DEBUG - 2016-10-09 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:18:08 --> Input Class Initialized
INFO - 2016-10-09 10:18:08 --> Language Class Initialized
INFO - 2016-10-09 10:18:08 --> Language Class Initialized
INFO - 2016-10-09 10:18:08 --> Config Class Initialized
INFO - 2016-10-09 10:18:08 --> Loader Class Initialized
INFO - 2016-10-09 10:18:08 --> Helper loaded: common_helper
INFO - 2016-10-09 10:18:08 --> Helper loaded: url_helper
INFO - 2016-10-09 10:18:08 --> Database Driver Class Initialized
INFO - 2016-10-09 10:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:18:08 --> Parser Class Initialized
INFO - 2016-10-09 10:18:08 --> Controller Class Initialized
DEBUG - 2016-10-09 10:18:08 --> Content MX_Controller Initialized
INFO - 2016-10-09 10:18:08 --> Model Class Initialized
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 10:18:08 --> Model Class Initialized
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 10:18:08 --> Model Class Initialized
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 10:18:08 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 10:18:08 --> Model Class Initialized
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 10:18:08 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 10:18:08 --> Model Class Initialized
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 10:18:08 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 10:18:08 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 10:18:08 --> Final output sent to browser
DEBUG - 2016-10-09 10:18:08 --> Total execution time: 0.0575
INFO - 2016-10-09 10:19:26 --> Config Class Initialized
INFO - 2016-10-09 10:19:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:19:26 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:19:26 --> Utf8 Class Initialized
INFO - 2016-10-09 10:19:26 --> URI Class Initialized
INFO - 2016-10-09 10:19:26 --> Router Class Initialized
INFO - 2016-10-09 10:19:26 --> Output Class Initialized
INFO - 2016-10-09 10:19:26 --> Security Class Initialized
DEBUG - 2016-10-09 10:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:19:26 --> Input Class Initialized
INFO - 2016-10-09 10:19:26 --> Language Class Initialized
INFO - 2016-10-09 10:19:26 --> Language Class Initialized
INFO - 2016-10-09 10:19:26 --> Config Class Initialized
INFO - 2016-10-09 10:19:26 --> Loader Class Initialized
INFO - 2016-10-09 10:19:26 --> Helper loaded: common_helper
INFO - 2016-10-09 10:19:26 --> Helper loaded: url_helper
INFO - 2016-10-09 10:19:26 --> Database Driver Class Initialized
INFO - 2016-10-09 10:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:19:26 --> Parser Class Initialized
INFO - 2016-10-09 10:19:26 --> Controller Class Initialized
DEBUG - 2016-10-09 10:19:26 --> Content MX_Controller Initialized
INFO - 2016-10-09 10:19:26 --> Model Class Initialized
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 10:19:26 --> Model Class Initialized
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 10:19:26 --> Model Class Initialized
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 10:19:26 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 10:19:26 --> Model Class Initialized
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 10:19:26 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 10:19:26 --> Model Class Initialized
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 10:19:26 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 10:19:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 10:19:26 --> Final output sent to browser
DEBUG - 2016-10-09 10:19:26 --> Total execution time: 0.0587
INFO - 2016-10-09 10:20:55 --> Config Class Initialized
INFO - 2016-10-09 10:20:55 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:20:55 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:20:55 --> Utf8 Class Initialized
INFO - 2016-10-09 10:20:55 --> URI Class Initialized
INFO - 2016-10-09 10:20:55 --> Router Class Initialized
INFO - 2016-10-09 10:20:55 --> Output Class Initialized
INFO - 2016-10-09 10:20:55 --> Security Class Initialized
DEBUG - 2016-10-09 10:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:20:55 --> Input Class Initialized
INFO - 2016-10-09 10:20:55 --> Language Class Initialized
INFO - 2016-10-09 10:20:55 --> Language Class Initialized
INFO - 2016-10-09 10:20:55 --> Config Class Initialized
INFO - 2016-10-09 10:20:55 --> Loader Class Initialized
INFO - 2016-10-09 10:20:55 --> Helper loaded: common_helper
INFO - 2016-10-09 10:20:55 --> Helper loaded: url_helper
INFO - 2016-10-09 10:20:55 --> Database Driver Class Initialized
INFO - 2016-10-09 10:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:20:55 --> Parser Class Initialized
INFO - 2016-10-09 10:20:55 --> Controller Class Initialized
DEBUG - 2016-10-09 10:20:55 --> Content MX_Controller Initialized
INFO - 2016-10-09 10:20:55 --> Model Class Initialized
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 10:20:55 --> Model Class Initialized
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 10:20:55 --> Model Class Initialized
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 10:20:55 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 10:20:55 --> Model Class Initialized
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 10:20:55 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 10:20:55 --> Model Class Initialized
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 10:20:55 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 10:20:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 10:20:55 --> Final output sent to browser
DEBUG - 2016-10-09 10:20:55 --> Total execution time: 0.0591
INFO - 2016-10-09 10:25:18 --> Config Class Initialized
INFO - 2016-10-09 10:25:18 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:25:18 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:25:18 --> Utf8 Class Initialized
INFO - 2016-10-09 10:25:18 --> URI Class Initialized
INFO - 2016-10-09 10:25:18 --> Router Class Initialized
INFO - 2016-10-09 10:25:18 --> Output Class Initialized
INFO - 2016-10-09 10:25:18 --> Security Class Initialized
DEBUG - 2016-10-09 10:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:25:18 --> Input Class Initialized
INFO - 2016-10-09 10:25:18 --> Language Class Initialized
INFO - 2016-10-09 10:25:18 --> Language Class Initialized
INFO - 2016-10-09 10:25:18 --> Config Class Initialized
INFO - 2016-10-09 10:25:18 --> Loader Class Initialized
INFO - 2016-10-09 10:25:18 --> Helper loaded: common_helper
INFO - 2016-10-09 10:25:18 --> Helper loaded: url_helper
INFO - 2016-10-09 10:25:18 --> Database Driver Class Initialized
INFO - 2016-10-09 10:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:25:18 --> Parser Class Initialized
INFO - 2016-10-09 10:25:18 --> Controller Class Initialized
DEBUG - 2016-10-09 10:25:18 --> Content MX_Controller Initialized
INFO - 2016-10-09 10:25:18 --> Model Class Initialized
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 10:25:18 --> Model Class Initialized
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 10:25:18 --> Model Class Initialized
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 10:25:18 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 10:25:18 --> Model Class Initialized
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 10:25:18 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 10:25:18 --> Model Class Initialized
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 10:25:18 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 10:25:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 10:25:18 --> Final output sent to browser
DEBUG - 2016-10-09 10:25:18 --> Total execution time: 0.0592
INFO - 2016-10-09 10:30:57 --> Config Class Initialized
INFO - 2016-10-09 10:30:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:30:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:30:57 --> Utf8 Class Initialized
INFO - 2016-10-09 10:30:57 --> URI Class Initialized
INFO - 2016-10-09 10:30:57 --> Router Class Initialized
INFO - 2016-10-09 10:30:57 --> Output Class Initialized
INFO - 2016-10-09 10:30:57 --> Security Class Initialized
DEBUG - 2016-10-09 10:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:30:57 --> Input Class Initialized
INFO - 2016-10-09 10:30:57 --> Language Class Initialized
INFO - 2016-10-09 10:30:57 --> Language Class Initialized
INFO - 2016-10-09 10:30:57 --> Config Class Initialized
INFO - 2016-10-09 10:30:57 --> Loader Class Initialized
INFO - 2016-10-09 10:30:57 --> Helper loaded: common_helper
INFO - 2016-10-09 10:30:57 --> Helper loaded: url_helper
INFO - 2016-10-09 10:30:57 --> Database Driver Class Initialized
INFO - 2016-10-09 10:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:30:57 --> Parser Class Initialized
INFO - 2016-10-09 10:30:57 --> Controller Class Initialized
DEBUG - 2016-10-09 10:30:57 --> Content MX_Controller Initialized
INFO - 2016-10-09 10:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 10:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 10:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 10:30:57 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 10:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 10:30:57 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 10:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 10:30:57 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 10:30:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 10:30:57 --> Final output sent to browser
DEBUG - 2016-10-09 10:30:57 --> Total execution time: 0.0704
INFO - 2016-10-09 10:36:19 --> Config Class Initialized
INFO - 2016-10-09 10:36:19 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:36:19 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:36:19 --> Utf8 Class Initialized
INFO - 2016-10-09 10:36:19 --> URI Class Initialized
INFO - 2016-10-09 10:36:19 --> Router Class Initialized
INFO - 2016-10-09 10:36:19 --> Output Class Initialized
INFO - 2016-10-09 10:36:19 --> Security Class Initialized
DEBUG - 2016-10-09 10:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:36:19 --> Input Class Initialized
INFO - 2016-10-09 10:36:19 --> Language Class Initialized
ERROR - 2016-10-09 10:36:19 --> 404 Page Not Found: /index
INFO - 2016-10-09 10:36:21 --> Config Class Initialized
INFO - 2016-10-09 10:36:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:36:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:36:21 --> Utf8 Class Initialized
INFO - 2016-10-09 10:36:21 --> URI Class Initialized
INFO - 2016-10-09 10:36:21 --> Router Class Initialized
INFO - 2016-10-09 10:36:21 --> Output Class Initialized
INFO - 2016-10-09 10:36:21 --> Security Class Initialized
DEBUG - 2016-10-09 10:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:36:21 --> Input Class Initialized
INFO - 2016-10-09 10:36:21 --> Language Class Initialized
INFO - 2016-10-09 10:36:21 --> Language Class Initialized
INFO - 2016-10-09 10:36:21 --> Config Class Initialized
INFO - 2016-10-09 10:36:21 --> Loader Class Initialized
INFO - 2016-10-09 10:36:21 --> Helper loaded: common_helper
INFO - 2016-10-09 10:36:21 --> Helper loaded: url_helper
INFO - 2016-10-09 10:36:21 --> Database Driver Class Initialized
INFO - 2016-10-09 10:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:36:21 --> Parser Class Initialized
INFO - 2016-10-09 10:36:21 --> Controller Class Initialized
DEBUG - 2016-10-09 10:36:21 --> Servers MX_Controller Initialized
INFO - 2016-10-09 10:36:21 --> Model Class Initialized
DEBUG - 2016-10-09 10:36:21 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 10:36:21 --> Model Class Initialized
DEBUG - 2016-10-09 10:36:21 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 10:36:21 --> Model Class Initialized
INFO - 2016-10-09 10:57:58 --> Config Class Initialized
INFO - 2016-10-09 10:57:58 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:57:58 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:57:58 --> Utf8 Class Initialized
INFO - 2016-10-09 10:57:58 --> URI Class Initialized
INFO - 2016-10-09 10:57:58 --> Router Class Initialized
INFO - 2016-10-09 10:57:58 --> Output Class Initialized
INFO - 2016-10-09 10:57:58 --> Security Class Initialized
DEBUG - 2016-10-09 10:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:57:58 --> Input Class Initialized
INFO - 2016-10-09 10:57:58 --> Language Class Initialized
INFO - 2016-10-09 10:57:58 --> Language Class Initialized
INFO - 2016-10-09 10:57:58 --> Config Class Initialized
INFO - 2016-10-09 10:57:58 --> Loader Class Initialized
INFO - 2016-10-09 10:57:58 --> Helper loaded: common_helper
INFO - 2016-10-09 10:57:58 --> Helper loaded: url_helper
INFO - 2016-10-09 10:57:58 --> Database Driver Class Initialized
INFO - 2016-10-09 10:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:57:58 --> Parser Class Initialized
INFO - 2016-10-09 10:57:58 --> Controller Class Initialized
DEBUG - 2016-10-09 10:57:58 --> Servers MX_Controller Initialized
INFO - 2016-10-09 10:57:58 --> Model Class Initialized
DEBUG - 2016-10-09 10:57:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 10:57:58 --> Model Class Initialized
DEBUG - 2016-10-09 10:57:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 10:57:58 --> Model Class Initialized
INFO - 2016-10-09 10:58:59 --> Config Class Initialized
INFO - 2016-10-09 10:58:59 --> Hooks Class Initialized
DEBUG - 2016-10-09 10:58:59 --> UTF-8 Support Enabled
INFO - 2016-10-09 10:58:59 --> Utf8 Class Initialized
INFO - 2016-10-09 10:58:59 --> URI Class Initialized
INFO - 2016-10-09 10:58:59 --> Router Class Initialized
INFO - 2016-10-09 10:58:59 --> Output Class Initialized
INFO - 2016-10-09 10:58:59 --> Security Class Initialized
DEBUG - 2016-10-09 10:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 10:58:59 --> Input Class Initialized
INFO - 2016-10-09 10:58:59 --> Language Class Initialized
INFO - 2016-10-09 10:58:59 --> Language Class Initialized
INFO - 2016-10-09 10:58:59 --> Config Class Initialized
INFO - 2016-10-09 10:58:59 --> Loader Class Initialized
INFO - 2016-10-09 10:58:59 --> Helper loaded: common_helper
INFO - 2016-10-09 10:58:59 --> Helper loaded: url_helper
INFO - 2016-10-09 10:58:59 --> Database Driver Class Initialized
INFO - 2016-10-09 10:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 10:58:59 --> Parser Class Initialized
INFO - 2016-10-09 10:58:59 --> Controller Class Initialized
DEBUG - 2016-10-09 10:58:59 --> Content MX_Controller Initialized
INFO - 2016-10-09 10:58:59 --> Model Class Initialized
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 10:58:59 --> Model Class Initialized
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 10:58:59 --> Model Class Initialized
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 10:58:59 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 10:58:59 --> Model Class Initialized
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 10:58:59 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 10:58:59 --> Model Class Initialized
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 10:58:59 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 10:58:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 10:58:59 --> Final output sent to browser
DEBUG - 2016-10-09 10:58:59 --> Total execution time: 0.0548
INFO - 2016-10-09 11:01:33 --> Config Class Initialized
INFO - 2016-10-09 11:01:33 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:01:33 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:01:33 --> Utf8 Class Initialized
INFO - 2016-10-09 11:01:33 --> URI Class Initialized
INFO - 2016-10-09 11:01:33 --> Router Class Initialized
INFO - 2016-10-09 11:01:33 --> Output Class Initialized
INFO - 2016-10-09 11:01:33 --> Security Class Initialized
DEBUG - 2016-10-09 11:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:01:33 --> Input Class Initialized
INFO - 2016-10-09 11:01:33 --> Language Class Initialized
INFO - 2016-10-09 11:01:33 --> Language Class Initialized
INFO - 2016-10-09 11:01:33 --> Config Class Initialized
INFO - 2016-10-09 11:01:33 --> Loader Class Initialized
INFO - 2016-10-09 11:01:33 --> Helper loaded: common_helper
INFO - 2016-10-09 11:01:33 --> Helper loaded: url_helper
INFO - 2016-10-09 11:01:33 --> Database Driver Class Initialized
INFO - 2016-10-09 11:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 11:01:33 --> Parser Class Initialized
INFO - 2016-10-09 11:01:33 --> Controller Class Initialized
DEBUG - 2016-10-09 11:01:33 --> Servers MX_Controller Initialized
INFO - 2016-10-09 11:01:33 --> Model Class Initialized
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 11:01:33 --> Model Class Initialized
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 11:01:33 --> Model Class Initialized
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/index.php
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 11:01:33 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 11:01:33 --> Model Class Initialized
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 11:01:33 --> File already loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 11:01:33 --> Model Class Initialized
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 11:01:33 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 11:01:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 11:01:33 --> Final output sent to browser
DEBUG - 2016-10-09 11:01:33 --> Total execution time: 0.0564
INFO - 2016-10-09 11:01:43 --> Config Class Initialized
INFO - 2016-10-09 11:01:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:01:43 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:01:43 --> Utf8 Class Initialized
INFO - 2016-10-09 11:01:43 --> URI Class Initialized
INFO - 2016-10-09 11:01:43 --> Router Class Initialized
INFO - 2016-10-09 11:01:43 --> Output Class Initialized
INFO - 2016-10-09 11:01:43 --> Security Class Initialized
DEBUG - 2016-10-09 11:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:01:43 --> Input Class Initialized
INFO - 2016-10-09 11:01:43 --> Language Class Initialized
ERROR - 2016-10-09 11:01:43 --> 404 Page Not Found: /index
INFO - 2016-10-09 11:01:44 --> Config Class Initialized
INFO - 2016-10-09 11:01:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:01:44 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:01:44 --> Utf8 Class Initialized
INFO - 2016-10-09 11:01:44 --> URI Class Initialized
INFO - 2016-10-09 11:01:44 --> Router Class Initialized
INFO - 2016-10-09 11:01:44 --> Output Class Initialized
INFO - 2016-10-09 11:01:44 --> Security Class Initialized
DEBUG - 2016-10-09 11:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:01:44 --> Input Class Initialized
INFO - 2016-10-09 11:01:44 --> Language Class Initialized
ERROR - 2016-10-09 11:01:44 --> 404 Page Not Found: /index
INFO - 2016-10-09 11:01:44 --> Config Class Initialized
INFO - 2016-10-09 11:01:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:01:44 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:01:44 --> Utf8 Class Initialized
INFO - 2016-10-09 11:01:44 --> URI Class Initialized
INFO - 2016-10-09 11:01:44 --> Router Class Initialized
INFO - 2016-10-09 11:01:44 --> Output Class Initialized
INFO - 2016-10-09 11:01:44 --> Security Class Initialized
DEBUG - 2016-10-09 11:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:01:44 --> Input Class Initialized
INFO - 2016-10-09 11:01:44 --> Language Class Initialized
ERROR - 2016-10-09 11:01:44 --> 404 Page Not Found: /index
INFO - 2016-10-09 11:01:45 --> Config Class Initialized
INFO - 2016-10-09 11:01:45 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:01:45 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:01:45 --> Utf8 Class Initialized
INFO - 2016-10-09 11:01:45 --> URI Class Initialized
INFO - 2016-10-09 11:01:45 --> Router Class Initialized
INFO - 2016-10-09 11:01:45 --> Output Class Initialized
INFO - 2016-10-09 11:01:45 --> Security Class Initialized
DEBUG - 2016-10-09 11:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:01:45 --> Input Class Initialized
INFO - 2016-10-09 11:01:45 --> Language Class Initialized
ERROR - 2016-10-09 11:01:45 --> 404 Page Not Found: /index
INFO - 2016-10-09 11:14:31 --> Config Class Initialized
INFO - 2016-10-09 11:14:31 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:14:31 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:14:31 --> Utf8 Class Initialized
INFO - 2016-10-09 11:14:31 --> URI Class Initialized
INFO - 2016-10-09 11:14:31 --> Router Class Initialized
INFO - 2016-10-09 11:14:31 --> Output Class Initialized
INFO - 2016-10-09 11:14:31 --> Security Class Initialized
DEBUG - 2016-10-09 11:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:14:31 --> Input Class Initialized
INFO - 2016-10-09 11:14:31 --> Language Class Initialized
INFO - 2016-10-09 11:14:31 --> Language Class Initialized
INFO - 2016-10-09 11:14:31 --> Config Class Initialized
INFO - 2016-10-09 11:14:31 --> Loader Class Initialized
INFO - 2016-10-09 11:14:31 --> Helper loaded: common_helper
INFO - 2016-10-09 11:14:31 --> Helper loaded: url_helper
INFO - 2016-10-09 11:14:31 --> Database Driver Class Initialized
INFO - 2016-10-09 11:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 11:14:31 --> Parser Class Initialized
INFO - 2016-10-09 11:14:31 --> Controller Class Initialized
DEBUG - 2016-10-09 11:14:31 --> Servers MX_Controller Initialized
INFO - 2016-10-09 11:14:31 --> Model Class Initialized
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 11:14:31 --> Model Class Initialized
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 11:14:31 --> Model Class Initialized
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/index.php
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 11:14:31 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 11:14:31 --> Model Class Initialized
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 11:14:31 --> File already loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 11:14:31 --> Model Class Initialized
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 11:14:31 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 11:14:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 11:14:31 --> Final output sent to browser
DEBUG - 2016-10-09 11:14:31 --> Total execution time: 0.0571
INFO - 2016-10-09 11:14:34 --> Config Class Initialized
INFO - 2016-10-09 11:14:34 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:14:34 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:14:34 --> Utf8 Class Initialized
INFO - 2016-10-09 11:14:34 --> URI Class Initialized
INFO - 2016-10-09 11:14:34 --> Router Class Initialized
INFO - 2016-10-09 11:14:34 --> Output Class Initialized
INFO - 2016-10-09 11:14:34 --> Security Class Initialized
DEBUG - 2016-10-09 11:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:14:34 --> Input Class Initialized
INFO - 2016-10-09 11:14:34 --> Language Class Initialized
ERROR - 2016-10-09 11:14:34 --> 404 Page Not Found: /index
INFO - 2016-10-09 11:14:35 --> Config Class Initialized
INFO - 2016-10-09 11:14:35 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:14:35 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:14:35 --> Utf8 Class Initialized
INFO - 2016-10-09 11:14:35 --> URI Class Initialized
INFO - 2016-10-09 11:14:35 --> Router Class Initialized
INFO - 2016-10-09 11:14:35 --> Output Class Initialized
INFO - 2016-10-09 11:14:35 --> Security Class Initialized
DEBUG - 2016-10-09 11:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:14:35 --> Input Class Initialized
INFO - 2016-10-09 11:14:35 --> Language Class Initialized
ERROR - 2016-10-09 11:14:35 --> 404 Page Not Found: /index
INFO - 2016-10-09 11:14:35 --> Config Class Initialized
INFO - 2016-10-09 11:14:35 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:14:35 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:14:35 --> Utf8 Class Initialized
INFO - 2016-10-09 11:14:35 --> URI Class Initialized
INFO - 2016-10-09 11:14:35 --> Router Class Initialized
INFO - 2016-10-09 11:14:35 --> Output Class Initialized
INFO - 2016-10-09 11:14:35 --> Security Class Initialized
DEBUG - 2016-10-09 11:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:14:35 --> Input Class Initialized
INFO - 2016-10-09 11:14:35 --> Language Class Initialized
ERROR - 2016-10-09 11:14:35 --> 404 Page Not Found: /index
INFO - 2016-10-09 11:14:36 --> Config Class Initialized
INFO - 2016-10-09 11:14:36 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:14:36 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:14:36 --> Utf8 Class Initialized
INFO - 2016-10-09 11:14:36 --> URI Class Initialized
INFO - 2016-10-09 11:14:36 --> Router Class Initialized
INFO - 2016-10-09 11:14:36 --> Output Class Initialized
INFO - 2016-10-09 11:14:36 --> Security Class Initialized
DEBUG - 2016-10-09 11:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:14:36 --> Input Class Initialized
INFO - 2016-10-09 11:14:36 --> Language Class Initialized
ERROR - 2016-10-09 11:14:36 --> 404 Page Not Found: /index
INFO - 2016-10-09 11:17:21 --> Config Class Initialized
INFO - 2016-10-09 11:17:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:17:21 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:17:21 --> Utf8 Class Initialized
INFO - 2016-10-09 11:17:21 --> URI Class Initialized
INFO - 2016-10-09 11:17:21 --> Router Class Initialized
INFO - 2016-10-09 11:17:21 --> Output Class Initialized
INFO - 2016-10-09 11:17:21 --> Security Class Initialized
DEBUG - 2016-10-09 11:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:17:21 --> Input Class Initialized
INFO - 2016-10-09 11:17:21 --> Language Class Initialized
ERROR - 2016-10-09 11:17:21 --> 404 Page Not Found: /index
INFO - 2016-10-09 11:17:22 --> Config Class Initialized
INFO - 2016-10-09 11:17:22 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:17:22 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:17:22 --> Utf8 Class Initialized
INFO - 2016-10-09 11:17:22 --> URI Class Initialized
INFO - 2016-10-09 11:17:22 --> Router Class Initialized
INFO - 2016-10-09 11:17:22 --> Output Class Initialized
INFO - 2016-10-09 11:17:22 --> Security Class Initialized
DEBUG - 2016-10-09 11:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:17:22 --> Input Class Initialized
INFO - 2016-10-09 11:17:22 --> Language Class Initialized
INFO - 2016-10-09 11:17:22 --> Language Class Initialized
INFO - 2016-10-09 11:17:22 --> Config Class Initialized
INFO - 2016-10-09 11:17:22 --> Loader Class Initialized
INFO - 2016-10-09 11:17:22 --> Helper loaded: common_helper
INFO - 2016-10-09 11:17:22 --> Helper loaded: url_helper
INFO - 2016-10-09 11:17:22 --> Database Driver Class Initialized
INFO - 2016-10-09 11:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 11:17:22 --> Parser Class Initialized
INFO - 2016-10-09 11:17:22 --> Controller Class Initialized
DEBUG - 2016-10-09 11:17:22 --> Servers MX_Controller Initialized
INFO - 2016-10-09 11:17:22 --> Model Class Initialized
DEBUG - 2016-10-09 11:17:22 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 11:17:22 --> Model Class Initialized
DEBUG - 2016-10-09 11:17:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 11:17:22 --> Model Class Initialized
INFO - 2016-10-09 11:19:53 --> Config Class Initialized
INFO - 2016-10-09 11:19:53 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:19:53 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:19:53 --> Utf8 Class Initialized
INFO - 2016-10-09 11:19:53 --> URI Class Initialized
DEBUG - 2016-10-09 11:19:53 --> No URI present. Default controller set.
INFO - 2016-10-09 11:19:53 --> Router Class Initialized
INFO - 2016-10-09 11:19:53 --> Output Class Initialized
INFO - 2016-10-09 11:19:53 --> Security Class Initialized
DEBUG - 2016-10-09 11:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:19:53 --> Input Class Initialized
INFO - 2016-10-09 11:19:53 --> Language Class Initialized
INFO - 2016-10-09 11:19:53 --> Language Class Initialized
INFO - 2016-10-09 11:19:53 --> Config Class Initialized
INFO - 2016-10-09 11:19:53 --> Loader Class Initialized
INFO - 2016-10-09 11:19:53 --> Helper loaded: common_helper
INFO - 2016-10-09 11:19:53 --> Helper loaded: url_helper
INFO - 2016-10-09 11:19:53 --> Database Driver Class Initialized
INFO - 2016-10-09 11:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 11:19:53 --> Parser Class Initialized
INFO - 2016-10-09 11:19:53 --> Controller Class Initialized
DEBUG - 2016-10-09 11:19:53 --> Home MX_Controller Initialized
INFO - 2016-10-09 11:19:53 --> Model Class Initialized
DEBUG - 2016-10-09 11:19:53 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-09 11:19:53 --> Model Class Initialized
ERROR - 2016-10-09 11:19:53 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 11:19:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 11:19:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 11:19:53 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-09 11:19:53 --> Final output sent to browser
DEBUG - 2016-10-09 11:19:53 --> Total execution time: 0.0450
INFO - 2016-10-09 11:36:27 --> Config Class Initialized
INFO - 2016-10-09 11:36:27 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:36:27 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:36:27 --> Utf8 Class Initialized
INFO - 2016-10-09 11:36:27 --> URI Class Initialized
INFO - 2016-10-09 11:36:27 --> Router Class Initialized
INFO - 2016-10-09 11:36:27 --> Output Class Initialized
INFO - 2016-10-09 11:36:27 --> Security Class Initialized
DEBUG - 2016-10-09 11:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:36:27 --> Input Class Initialized
INFO - 2016-10-09 11:36:27 --> Language Class Initialized
INFO - 2016-10-09 11:36:27 --> Language Class Initialized
INFO - 2016-10-09 11:36:27 --> Config Class Initialized
INFO - 2016-10-09 11:36:27 --> Loader Class Initialized
INFO - 2016-10-09 11:36:27 --> Helper loaded: common_helper
INFO - 2016-10-09 11:36:27 --> Helper loaded: url_helper
INFO - 2016-10-09 11:36:27 --> Database Driver Class Initialized
INFO - 2016-10-09 11:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 11:36:27 --> Parser Class Initialized
INFO - 2016-10-09 11:36:27 --> Controller Class Initialized
DEBUG - 2016-10-09 11:36:27 --> Content MX_Controller Initialized
INFO - 2016-10-09 11:36:27 --> Model Class Initialized
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 11:36:27 --> Model Class Initialized
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 11:36:27 --> Model Class Initialized
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 11:36:27 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 11:36:27 --> Model Class Initialized
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 11:36:27 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 11:36:27 --> Model Class Initialized
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 11:36:27 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 11:36:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 11:36:27 --> Final output sent to browser
DEBUG - 2016-10-09 11:36:27 --> Total execution time: 0.0601
INFO - 2016-10-09 11:41:04 --> Config Class Initialized
INFO - 2016-10-09 11:41:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 11:41:04 --> UTF-8 Support Enabled
INFO - 2016-10-09 11:41:04 --> Utf8 Class Initialized
INFO - 2016-10-09 11:41:04 --> URI Class Initialized
INFO - 2016-10-09 11:41:04 --> Router Class Initialized
INFO - 2016-10-09 11:41:04 --> Output Class Initialized
INFO - 2016-10-09 11:41:04 --> Security Class Initialized
DEBUG - 2016-10-09 11:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 11:41:04 --> Input Class Initialized
INFO - 2016-10-09 11:41:04 --> Language Class Initialized
INFO - 2016-10-09 11:41:04 --> Language Class Initialized
INFO - 2016-10-09 11:41:04 --> Config Class Initialized
INFO - 2016-10-09 11:41:04 --> Loader Class Initialized
INFO - 2016-10-09 11:41:04 --> Helper loaded: common_helper
INFO - 2016-10-09 11:41:04 --> Helper loaded: url_helper
INFO - 2016-10-09 11:41:04 --> Database Driver Class Initialized
INFO - 2016-10-09 11:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 11:41:04 --> Parser Class Initialized
INFO - 2016-10-09 11:41:04 --> Controller Class Initialized
DEBUG - 2016-10-09 11:41:04 --> Content MX_Controller Initialized
INFO - 2016-10-09 11:41:04 --> Model Class Initialized
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 11:41:04 --> Model Class Initialized
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 11:41:04 --> Model Class Initialized
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 11:41:04 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 11:41:04 --> Model Class Initialized
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 11:41:04 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 11:41:04 --> Model Class Initialized
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 11:41:04 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 11:41:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 11:41:04 --> Final output sent to browser
DEBUG - 2016-10-09 11:41:04 --> Total execution time: 0.0568
INFO - 2016-10-09 12:14:46 --> Config Class Initialized
INFO - 2016-10-09 12:14:46 --> Hooks Class Initialized
DEBUG - 2016-10-09 12:14:46 --> UTF-8 Support Enabled
INFO - 2016-10-09 12:14:46 --> Utf8 Class Initialized
INFO - 2016-10-09 12:14:46 --> URI Class Initialized
INFO - 2016-10-09 12:14:46 --> Router Class Initialized
INFO - 2016-10-09 12:14:46 --> Output Class Initialized
INFO - 2016-10-09 12:14:46 --> Security Class Initialized
DEBUG - 2016-10-09 12:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 12:14:46 --> Input Class Initialized
INFO - 2016-10-09 12:14:46 --> Language Class Initialized
INFO - 2016-10-09 12:14:46 --> Language Class Initialized
INFO - 2016-10-09 12:14:46 --> Config Class Initialized
INFO - 2016-10-09 12:14:46 --> Loader Class Initialized
INFO - 2016-10-09 12:14:46 --> Helper loaded: common_helper
INFO - 2016-10-09 12:14:46 --> Helper loaded: url_helper
INFO - 2016-10-09 12:14:46 --> Database Driver Class Initialized
INFO - 2016-10-09 12:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 12:14:46 --> Parser Class Initialized
INFO - 2016-10-09 12:14:46 --> Controller Class Initialized
DEBUG - 2016-10-09 12:14:46 --> Content MX_Controller Initialized
INFO - 2016-10-09 12:14:46 --> Model Class Initialized
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 12:14:46 --> Model Class Initialized
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 12:14:46 --> Model Class Initialized
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 12:14:46 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 12:14:46 --> Model Class Initialized
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 12:14:46 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 12:14:46 --> Model Class Initialized
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 12:14:46 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 12:14:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 12:14:46 --> Final output sent to browser
DEBUG - 2016-10-09 12:14:46 --> Total execution time: 0.0566
INFO - 2016-10-09 12:47:32 --> Config Class Initialized
INFO - 2016-10-09 12:47:32 --> Hooks Class Initialized
DEBUG - 2016-10-09 12:47:32 --> UTF-8 Support Enabled
INFO - 2016-10-09 12:47:32 --> Utf8 Class Initialized
INFO - 2016-10-09 12:47:32 --> URI Class Initialized
INFO - 2016-10-09 12:47:32 --> Router Class Initialized
INFO - 2016-10-09 12:47:32 --> Output Class Initialized
INFO - 2016-10-09 12:47:32 --> Security Class Initialized
DEBUG - 2016-10-09 12:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 12:47:32 --> Input Class Initialized
INFO - 2016-10-09 12:47:32 --> Language Class Initialized
INFO - 2016-10-09 12:47:32 --> Language Class Initialized
INFO - 2016-10-09 12:47:32 --> Config Class Initialized
INFO - 2016-10-09 12:47:32 --> Loader Class Initialized
INFO - 2016-10-09 12:47:32 --> Helper loaded: common_helper
INFO - 2016-10-09 12:47:32 --> Helper loaded: url_helper
INFO - 2016-10-09 12:47:32 --> Database Driver Class Initialized
INFO - 2016-10-09 12:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 12:47:32 --> Parser Class Initialized
INFO - 2016-10-09 12:47:32 --> Controller Class Initialized
DEBUG - 2016-10-09 12:47:32 --> Content MX_Controller Initialized
INFO - 2016-10-09 12:47:32 --> Model Class Initialized
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 12:47:32 --> Model Class Initialized
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 12:47:32 --> Model Class Initialized
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 12:47:32 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 12:47:32 --> Model Class Initialized
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 12:47:32 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 12:47:32 --> Model Class Initialized
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 12:47:32 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 12:47:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 12:47:32 --> Final output sent to browser
DEBUG - 2016-10-09 12:47:32 --> Total execution time: 0.0571
INFO - 2016-10-09 12:56:51 --> Config Class Initialized
INFO - 2016-10-09 12:56:51 --> Hooks Class Initialized
DEBUG - 2016-10-09 12:56:51 --> UTF-8 Support Enabled
INFO - 2016-10-09 12:56:51 --> Utf8 Class Initialized
INFO - 2016-10-09 12:56:51 --> URI Class Initialized
INFO - 2016-10-09 12:56:51 --> Router Class Initialized
INFO - 2016-10-09 12:56:51 --> Output Class Initialized
INFO - 2016-10-09 12:56:51 --> Security Class Initialized
DEBUG - 2016-10-09 12:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 12:56:51 --> Input Class Initialized
INFO - 2016-10-09 12:56:51 --> Language Class Initialized
INFO - 2016-10-09 12:56:51 --> Language Class Initialized
INFO - 2016-10-09 12:56:51 --> Config Class Initialized
INFO - 2016-10-09 12:56:51 --> Loader Class Initialized
INFO - 2016-10-09 12:56:51 --> Helper loaded: common_helper
INFO - 2016-10-09 12:56:51 --> Helper loaded: url_helper
INFO - 2016-10-09 12:56:51 --> Database Driver Class Initialized
INFO - 2016-10-09 12:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 12:56:51 --> Parser Class Initialized
INFO - 2016-10-09 12:56:51 --> Controller Class Initialized
DEBUG - 2016-10-09 12:56:51 --> Content MX_Controller Initialized
INFO - 2016-10-09 12:56:51 --> Model Class Initialized
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 12:56:51 --> Model Class Initialized
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 12:56:51 --> Model Class Initialized
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 12:56:51 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 12:56:51 --> Model Class Initialized
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 12:56:51 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 12:56:51 --> Model Class Initialized
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 12:56:51 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 12:56:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 12:56:51 --> Final output sent to browser
DEBUG - 2016-10-09 12:56:51 --> Total execution time: 0.0776
INFO - 2016-10-09 13:30:33 --> Config Class Initialized
INFO - 2016-10-09 13:30:33 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:30:33 --> UTF-8 Support Enabled
INFO - 2016-10-09 13:30:33 --> Utf8 Class Initialized
INFO - 2016-10-09 13:30:33 --> URI Class Initialized
INFO - 2016-10-09 13:30:33 --> Router Class Initialized
INFO - 2016-10-09 13:30:33 --> Output Class Initialized
INFO - 2016-10-09 13:30:33 --> Security Class Initialized
DEBUG - 2016-10-09 13:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 13:30:33 --> Input Class Initialized
INFO - 2016-10-09 13:30:33 --> Language Class Initialized
INFO - 2016-10-09 13:30:33 --> Language Class Initialized
INFO - 2016-10-09 13:30:33 --> Config Class Initialized
INFO - 2016-10-09 13:30:33 --> Loader Class Initialized
INFO - 2016-10-09 13:30:33 --> Helper loaded: common_helper
INFO - 2016-10-09 13:30:33 --> Helper loaded: url_helper
INFO - 2016-10-09 13:30:33 --> Database Driver Class Initialized
INFO - 2016-10-09 13:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 13:30:33 --> Parser Class Initialized
INFO - 2016-10-09 13:30:33 --> Controller Class Initialized
DEBUG - 2016-10-09 13:30:33 --> Content MX_Controller Initialized
INFO - 2016-10-09 13:30:33 --> Model Class Initialized
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 13:30:33 --> Model Class Initialized
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 13:30:33 --> Model Class Initialized
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 13:30:33 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 13:30:33 --> Model Class Initialized
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 13:30:33 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 13:30:33 --> Model Class Initialized
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 13:30:33 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 13:30:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 13:30:33 --> Final output sent to browser
DEBUG - 2016-10-09 13:30:33 --> Total execution time: 0.0682
INFO - 2016-10-09 13:58:38 --> Config Class Initialized
INFO - 2016-10-09 13:58:38 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:58:38 --> UTF-8 Support Enabled
INFO - 2016-10-09 13:58:38 --> Utf8 Class Initialized
INFO - 2016-10-09 13:58:38 --> URI Class Initialized
INFO - 2016-10-09 13:58:38 --> Router Class Initialized
INFO - 2016-10-09 13:58:38 --> Output Class Initialized
INFO - 2016-10-09 13:58:38 --> Security Class Initialized
DEBUG - 2016-10-09 13:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 13:58:38 --> Input Class Initialized
INFO - 2016-10-09 13:58:38 --> Language Class Initialized
ERROR - 2016-10-09 13:58:38 --> 404 Page Not Found: /index
INFO - 2016-10-09 14:12:38 --> Config Class Initialized
INFO - 2016-10-09 14:12:38 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:12:38 --> UTF-8 Support Enabled
INFO - 2016-10-09 14:12:38 --> Utf8 Class Initialized
INFO - 2016-10-09 14:12:38 --> URI Class Initialized
INFO - 2016-10-09 14:12:38 --> Router Class Initialized
INFO - 2016-10-09 14:12:38 --> Output Class Initialized
INFO - 2016-10-09 14:12:38 --> Security Class Initialized
DEBUG - 2016-10-09 14:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 14:12:38 --> Input Class Initialized
INFO - 2016-10-09 14:12:38 --> Language Class Initialized
INFO - 2016-10-09 14:12:38 --> Language Class Initialized
INFO - 2016-10-09 14:12:38 --> Config Class Initialized
INFO - 2016-10-09 14:12:38 --> Loader Class Initialized
INFO - 2016-10-09 14:12:38 --> Helper loaded: common_helper
INFO - 2016-10-09 14:12:38 --> Helper loaded: url_helper
INFO - 2016-10-09 14:12:38 --> Database Driver Class Initialized
INFO - 2016-10-09 14:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 14:12:38 --> Parser Class Initialized
INFO - 2016-10-09 14:12:38 --> Controller Class Initialized
DEBUG - 2016-10-09 14:12:38 --> Content MX_Controller Initialized
INFO - 2016-10-09 14:12:38 --> Model Class Initialized
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 14:12:38 --> Model Class Initialized
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 14:12:38 --> Model Class Initialized
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 14:12:38 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 14:12:38 --> Model Class Initialized
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 14:12:38 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 14:12:38 --> Model Class Initialized
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 14:12:38 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 14:12:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 14:12:38 --> Final output sent to browser
DEBUG - 2016-10-09 14:12:38 --> Total execution time: 0.0568
INFO - 2016-10-09 14:46:20 --> Config Class Initialized
INFO - 2016-10-09 14:46:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:46:20 --> UTF-8 Support Enabled
INFO - 2016-10-09 14:46:20 --> Utf8 Class Initialized
INFO - 2016-10-09 14:46:20 --> URI Class Initialized
INFO - 2016-10-09 14:46:20 --> Router Class Initialized
INFO - 2016-10-09 14:46:20 --> Output Class Initialized
INFO - 2016-10-09 14:46:20 --> Security Class Initialized
DEBUG - 2016-10-09 14:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 14:46:20 --> Input Class Initialized
INFO - 2016-10-09 14:46:20 --> Language Class Initialized
INFO - 2016-10-09 14:46:20 --> Language Class Initialized
INFO - 2016-10-09 14:46:20 --> Config Class Initialized
INFO - 2016-10-09 14:46:20 --> Loader Class Initialized
INFO - 2016-10-09 14:46:20 --> Helper loaded: common_helper
INFO - 2016-10-09 14:46:20 --> Helper loaded: url_helper
INFO - 2016-10-09 14:46:20 --> Database Driver Class Initialized
INFO - 2016-10-09 14:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 14:46:20 --> Parser Class Initialized
INFO - 2016-10-09 14:46:20 --> Controller Class Initialized
DEBUG - 2016-10-09 14:46:20 --> Content MX_Controller Initialized
INFO - 2016-10-09 14:46:20 --> Model Class Initialized
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 14:46:20 --> Model Class Initialized
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 14:46:20 --> Model Class Initialized
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 14:46:20 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 14:46:20 --> Model Class Initialized
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 14:46:20 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 14:46:20 --> Model Class Initialized
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 14:46:20 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 14:46:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 14:46:20 --> Final output sent to browser
DEBUG - 2016-10-09 14:46:20 --> Total execution time: 0.0586
INFO - 2016-10-09 15:09:45 --> Config Class Initialized
INFO - 2016-10-09 15:09:45 --> Hooks Class Initialized
DEBUG - 2016-10-09 15:09:45 --> UTF-8 Support Enabled
INFO - 2016-10-09 15:09:45 --> Utf8 Class Initialized
INFO - 2016-10-09 15:09:45 --> URI Class Initialized
INFO - 2016-10-09 15:09:45 --> Router Class Initialized
INFO - 2016-10-09 15:09:45 --> Output Class Initialized
INFO - 2016-10-09 15:09:45 --> Security Class Initialized
DEBUG - 2016-10-09 15:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 15:09:45 --> Input Class Initialized
INFO - 2016-10-09 15:09:45 --> Language Class Initialized
INFO - 2016-10-09 15:09:45 --> Language Class Initialized
INFO - 2016-10-09 15:09:45 --> Config Class Initialized
INFO - 2016-10-09 15:09:45 --> Loader Class Initialized
INFO - 2016-10-09 15:09:45 --> Helper loaded: common_helper
INFO - 2016-10-09 15:09:45 --> Helper loaded: url_helper
INFO - 2016-10-09 15:09:45 --> Database Driver Class Initialized
INFO - 2016-10-09 15:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 15:09:45 --> Parser Class Initialized
INFO - 2016-10-09 15:09:45 --> Controller Class Initialized
DEBUG - 2016-10-09 15:09:45 --> Content MX_Controller Initialized
INFO - 2016-10-09 15:09:45 --> Model Class Initialized
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 15:09:45 --> Model Class Initialized
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 15:09:45 --> Model Class Initialized
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 15:09:45 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 15:09:45 --> Model Class Initialized
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 15:09:45 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 15:09:45 --> Model Class Initialized
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 15:09:45 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 15:09:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 15:09:45 --> Final output sent to browser
DEBUG - 2016-10-09 15:09:45 --> Total execution time: 0.0702
INFO - 2016-10-09 15:28:25 --> Config Class Initialized
INFO - 2016-10-09 15:28:25 --> Hooks Class Initialized
DEBUG - 2016-10-09 15:28:25 --> UTF-8 Support Enabled
INFO - 2016-10-09 15:28:25 --> Utf8 Class Initialized
INFO - 2016-10-09 15:28:25 --> URI Class Initialized
INFO - 2016-10-09 15:28:25 --> Router Class Initialized
INFO - 2016-10-09 15:28:25 --> Output Class Initialized
INFO - 2016-10-09 15:28:25 --> Security Class Initialized
DEBUG - 2016-10-09 15:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 15:28:25 --> Input Class Initialized
INFO - 2016-10-09 15:28:25 --> Language Class Initialized
INFO - 2016-10-09 15:28:25 --> Language Class Initialized
INFO - 2016-10-09 15:28:25 --> Config Class Initialized
INFO - 2016-10-09 15:28:25 --> Loader Class Initialized
INFO - 2016-10-09 15:28:25 --> Helper loaded: common_helper
INFO - 2016-10-09 15:28:25 --> Helper loaded: url_helper
INFO - 2016-10-09 15:28:25 --> Database Driver Class Initialized
INFO - 2016-10-09 15:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 15:28:25 --> Parser Class Initialized
INFO - 2016-10-09 15:28:25 --> Controller Class Initialized
DEBUG - 2016-10-09 15:28:25 --> Content MX_Controller Initialized
INFO - 2016-10-09 15:28:25 --> Model Class Initialized
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 15:28:25 --> Model Class Initialized
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 15:28:25 --> Model Class Initialized
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 15:28:25 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 15:28:25 --> Model Class Initialized
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 15:28:25 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 15:28:25 --> Model Class Initialized
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 15:28:25 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 15:28:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 15:28:25 --> Final output sent to browser
DEBUG - 2016-10-09 15:28:25 --> Total execution time: 0.0587
INFO - 2016-10-09 16:02:07 --> Config Class Initialized
INFO - 2016-10-09 16:02:07 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:02:07 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:02:07 --> Utf8 Class Initialized
INFO - 2016-10-09 16:02:07 --> URI Class Initialized
INFO - 2016-10-09 16:02:07 --> Router Class Initialized
INFO - 2016-10-09 16:02:07 --> Output Class Initialized
INFO - 2016-10-09 16:02:07 --> Security Class Initialized
DEBUG - 2016-10-09 16:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:02:07 --> Input Class Initialized
INFO - 2016-10-09 16:02:07 --> Language Class Initialized
INFO - 2016-10-09 16:02:07 --> Language Class Initialized
INFO - 2016-10-09 16:02:07 --> Config Class Initialized
INFO - 2016-10-09 16:02:07 --> Loader Class Initialized
INFO - 2016-10-09 16:02:07 --> Helper loaded: common_helper
INFO - 2016-10-09 16:02:07 --> Helper loaded: url_helper
INFO - 2016-10-09 16:02:07 --> Database Driver Class Initialized
INFO - 2016-10-09 16:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:02:07 --> Parser Class Initialized
INFO - 2016-10-09 16:02:07 --> Controller Class Initialized
DEBUG - 2016-10-09 16:02:07 --> Content MX_Controller Initialized
INFO - 2016-10-09 16:02:07 --> Model Class Initialized
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 16:02:07 --> Model Class Initialized
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 16:02:07 --> Model Class Initialized
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 16:02:07 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 16:02:07 --> Model Class Initialized
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 16:02:07 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 16:02:07 --> Model Class Initialized
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 16:02:07 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 16:02:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 16:02:07 --> Final output sent to browser
DEBUG - 2016-10-09 16:02:07 --> Total execution time: 0.0606
INFO - 2016-10-09 16:20:44 --> Config Class Initialized
INFO - 2016-10-09 16:20:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:20:44 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:20:44 --> Utf8 Class Initialized
INFO - 2016-10-09 16:20:44 --> URI Class Initialized
INFO - 2016-10-09 16:20:44 --> Router Class Initialized
INFO - 2016-10-09 16:20:44 --> Output Class Initialized
INFO - 2016-10-09 16:20:44 --> Security Class Initialized
DEBUG - 2016-10-09 16:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:20:44 --> Input Class Initialized
INFO - 2016-10-09 16:20:44 --> Language Class Initialized
INFO - 2016-10-09 16:20:44 --> Language Class Initialized
INFO - 2016-10-09 16:20:44 --> Config Class Initialized
INFO - 2016-10-09 16:20:44 --> Loader Class Initialized
INFO - 2016-10-09 16:20:44 --> Helper loaded: common_helper
INFO - 2016-10-09 16:20:44 --> Helper loaded: url_helper
INFO - 2016-10-09 16:20:44 --> Database Driver Class Initialized
INFO - 2016-10-09 16:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:20:44 --> Parser Class Initialized
INFO - 2016-10-09 16:20:44 --> Controller Class Initialized
DEBUG - 2016-10-09 16:20:44 --> Content MX_Controller Initialized
INFO - 2016-10-09 16:20:44 --> Model Class Initialized
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 16:20:44 --> Model Class Initialized
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 16:20:44 --> Model Class Initialized
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 16:20:44 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 16:20:44 --> Model Class Initialized
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 16:20:44 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 16:20:44 --> Model Class Initialized
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 16:20:44 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 16:20:44 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 16:20:44 --> Final output sent to browser
DEBUG - 2016-10-09 16:20:44 --> Total execution time: 0.0586
INFO - 2016-10-09 16:44:12 --> Config Class Initialized
INFO - 2016-10-09 16:44:12 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:44:12 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:44:12 --> Utf8 Class Initialized
INFO - 2016-10-09 16:44:12 --> URI Class Initialized
INFO - 2016-10-09 16:44:12 --> Router Class Initialized
INFO - 2016-10-09 16:44:12 --> Output Class Initialized
INFO - 2016-10-09 16:44:12 --> Security Class Initialized
DEBUG - 2016-10-09 16:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:44:12 --> Input Class Initialized
INFO - 2016-10-09 16:44:12 --> Language Class Initialized
INFO - 2016-10-09 16:44:12 --> Language Class Initialized
INFO - 2016-10-09 16:44:12 --> Config Class Initialized
INFO - 2016-10-09 16:44:12 --> Loader Class Initialized
INFO - 2016-10-09 16:44:12 --> Helper loaded: common_helper
INFO - 2016-10-09 16:44:13 --> Helper loaded: url_helper
INFO - 2016-10-09 16:44:13 --> Database Driver Class Initialized
INFO - 2016-10-09 16:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 16:44:13 --> Parser Class Initialized
INFO - 2016-10-09 16:44:13 --> Controller Class Initialized
DEBUG - 2016-10-09 16:44:13 --> Content MX_Controller Initialized
INFO - 2016-10-09 16:44:13 --> Model Class Initialized
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 16:44:13 --> Model Class Initialized
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 16:44:13 --> Model Class Initialized
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 16:44:13 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 16:44:13 --> Model Class Initialized
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 16:44:13 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 16:44:13 --> Model Class Initialized
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 16:44:13 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 16:44:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 16:44:13 --> Final output sent to browser
DEBUG - 2016-10-09 16:44:13 --> Total execution time: 0.0553
INFO - 2016-10-09 16:44:13 --> Config Class Initialized
INFO - 2016-10-09 16:44:13 --> Hooks Class Initialized
DEBUG - 2016-10-09 16:44:13 --> UTF-8 Support Enabled
INFO - 2016-10-09 16:44:13 --> Utf8 Class Initialized
INFO - 2016-10-09 16:44:13 --> URI Class Initialized
INFO - 2016-10-09 16:44:13 --> Router Class Initialized
INFO - 2016-10-09 16:44:13 --> Output Class Initialized
INFO - 2016-10-09 16:44:13 --> Security Class Initialized
DEBUG - 2016-10-09 16:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 16:44:13 --> Input Class Initialized
INFO - 2016-10-09 16:44:13 --> Language Class Initialized
ERROR - 2016-10-09 16:44:13 --> 404 Page Not Found: /index
INFO - 2016-10-09 17:30:57 --> Config Class Initialized
INFO - 2016-10-09 17:30:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:30:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:30:57 --> Utf8 Class Initialized
INFO - 2016-10-09 17:30:57 --> URI Class Initialized
INFO - 2016-10-09 17:30:57 --> Router Class Initialized
INFO - 2016-10-09 17:30:57 --> Output Class Initialized
INFO - 2016-10-09 17:30:57 --> Security Class Initialized
DEBUG - 2016-10-09 17:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:30:57 --> Input Class Initialized
INFO - 2016-10-09 17:30:57 --> Language Class Initialized
INFO - 2016-10-09 17:30:57 --> Language Class Initialized
INFO - 2016-10-09 17:30:57 --> Config Class Initialized
INFO - 2016-10-09 17:30:57 --> Loader Class Initialized
INFO - 2016-10-09 17:30:57 --> Helper loaded: common_helper
INFO - 2016-10-09 17:30:57 --> Helper loaded: url_helper
INFO - 2016-10-09 17:30:57 --> Database Driver Class Initialized
INFO - 2016-10-09 17:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:30:57 --> Parser Class Initialized
INFO - 2016-10-09 17:30:57 --> Controller Class Initialized
DEBUG - 2016-10-09 17:30:57 --> Content MX_Controller Initialized
INFO - 2016-10-09 17:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 17:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 17:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 17:30:57 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 17:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 17:30:57 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 17:30:57 --> Model Class Initialized
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 17:30:57 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 17:30:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 17:30:57 --> Final output sent to browser
DEBUG - 2016-10-09 17:30:57 --> Total execution time: 0.0555
INFO - 2016-10-09 17:59:59 --> Config Class Initialized
INFO - 2016-10-09 17:59:59 --> Hooks Class Initialized
DEBUG - 2016-10-09 17:59:59 --> UTF-8 Support Enabled
INFO - 2016-10-09 17:59:59 --> Utf8 Class Initialized
INFO - 2016-10-09 17:59:59 --> URI Class Initialized
INFO - 2016-10-09 17:59:59 --> Router Class Initialized
INFO - 2016-10-09 17:59:59 --> Output Class Initialized
INFO - 2016-10-09 17:59:59 --> Security Class Initialized
DEBUG - 2016-10-09 17:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 17:59:59 --> Input Class Initialized
INFO - 2016-10-09 17:59:59 --> Language Class Initialized
INFO - 2016-10-09 17:59:59 --> Language Class Initialized
INFO - 2016-10-09 17:59:59 --> Config Class Initialized
INFO - 2016-10-09 17:59:59 --> Loader Class Initialized
INFO - 2016-10-09 17:59:59 --> Helper loaded: common_helper
INFO - 2016-10-09 17:59:59 --> Helper loaded: url_helper
INFO - 2016-10-09 17:59:59 --> Database Driver Class Initialized
INFO - 2016-10-09 17:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 17:59:59 --> Parser Class Initialized
INFO - 2016-10-09 17:59:59 --> Controller Class Initialized
DEBUG - 2016-10-09 17:59:59 --> Content MX_Controller Initialized
INFO - 2016-10-09 17:59:59 --> Model Class Initialized
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 17:59:59 --> Model Class Initialized
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 17:59:59 --> Model Class Initialized
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 17:59:59 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 17:59:59 --> Model Class Initialized
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 17:59:59 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 17:59:59 --> Model Class Initialized
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 17:59:59 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 17:59:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 17:59:59 --> Final output sent to browser
DEBUG - 2016-10-09 17:59:59 --> Total execution time: 0.0850
INFO - 2016-10-09 18:32:04 --> Config Class Initialized
INFO - 2016-10-09 18:32:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:04 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:04 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:04 --> URI Class Initialized
INFO - 2016-10-09 18:32:04 --> Router Class Initialized
INFO - 2016-10-09 18:32:04 --> Output Class Initialized
INFO - 2016-10-09 18:32:04 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:04 --> Input Class Initialized
INFO - 2016-10-09 18:32:04 --> Language Class Initialized
INFO - 2016-10-09 18:32:04 --> Language Class Initialized
INFO - 2016-10-09 18:32:04 --> Config Class Initialized
INFO - 2016-10-09 18:32:04 --> Loader Class Initialized
INFO - 2016-10-09 18:32:04 --> Helper loaded: common_helper
INFO - 2016-10-09 18:32:04 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:04 --> Parser Class Initialized
INFO - 2016-10-09 18:32:04 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:04 --> Admincp MX_Controller Initialized
INFO - 2016-10-09 18:32:04 --> Config Class Initialized
INFO - 2016-10-09 18:32:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:04 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:04 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:04 --> URI Class Initialized
INFO - 2016-10-09 18:32:04 --> Router Class Initialized
INFO - 2016-10-09 18:32:04 --> Output Class Initialized
INFO - 2016-10-09 18:32:04 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:04 --> Input Class Initialized
INFO - 2016-10-09 18:32:04 --> Language Class Initialized
INFO - 2016-10-09 18:32:04 --> Language Class Initialized
INFO - 2016-10-09 18:32:04 --> Config Class Initialized
INFO - 2016-10-09 18:32:04 --> Loader Class Initialized
INFO - 2016-10-09 18:32:04 --> Helper loaded: common_helper
INFO - 2016-10-09 18:32:04 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:04 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:04 --> Parser Class Initialized
INFO - 2016-10-09 18:32:04 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:04 --> Admincp MX_Controller Initialized
INFO - 2016-10-09 18:32:04 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:04 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-09 18:32:04 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:04 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-09 18:32:04 --> Final output sent to browser
DEBUG - 2016-10-09 18:32:04 --> Total execution time: 0.0362
INFO - 2016-10-09 18:32:10 --> Config Class Initialized
INFO - 2016-10-09 18:32:10 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:10 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:10 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:10 --> URI Class Initialized
INFO - 2016-10-09 18:32:10 --> Router Class Initialized
INFO - 2016-10-09 18:32:10 --> Output Class Initialized
INFO - 2016-10-09 18:32:10 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:10 --> Input Class Initialized
INFO - 2016-10-09 18:32:10 --> Language Class Initialized
INFO - 2016-10-09 18:32:10 --> Language Class Initialized
INFO - 2016-10-09 18:32:10 --> Config Class Initialized
INFO - 2016-10-09 18:32:10 --> Loader Class Initialized
INFO - 2016-10-09 18:32:10 --> Helper loaded: common_helper
INFO - 2016-10-09 18:32:10 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:10 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:10 --> Parser Class Initialized
INFO - 2016-10-09 18:32:10 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:10 --> Admincp MX_Controller Initialized
INFO - 2016-10-09 18:32:10 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-09 18:32:10 --> Model Class Initialized
INFO - 2016-10-09 18:32:10 --> Final output sent to browser
DEBUG - 2016-10-09 18:32:10 --> Total execution time: 0.0437
INFO - 2016-10-09 18:32:10 --> Config Class Initialized
INFO - 2016-10-09 18:32:10 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:10 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:10 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:10 --> URI Class Initialized
INFO - 2016-10-09 18:32:10 --> Router Class Initialized
INFO - 2016-10-09 18:32:10 --> Output Class Initialized
INFO - 2016-10-09 18:32:10 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:10 --> Input Class Initialized
INFO - 2016-10-09 18:32:10 --> Language Class Initialized
INFO - 2016-10-09 18:32:10 --> Language Class Initialized
INFO - 2016-10-09 18:32:10 --> Config Class Initialized
INFO - 2016-10-09 18:32:10 --> Loader Class Initialized
INFO - 2016-10-09 18:32:10 --> Helper loaded: common_helper
INFO - 2016-10-09 18:32:10 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:10 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:10 --> Parser Class Initialized
INFO - 2016-10-09 18:32:10 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:10 --> Admincp MX_Controller Initialized
INFO - 2016-10-09 18:32:10 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-09 18:32:10 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-09 18:32:10 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-09 18:32:10 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-09 18:32:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 18:32:10 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-09 18:32:10 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:10 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-09 18:32:10 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-09 18:32:10 --> Final output sent to browser
DEBUG - 2016-10-09 18:32:10 --> Total execution time: 0.0681
INFO - 2016-10-09 18:32:13 --> Config Class Initialized
INFO - 2016-10-09 18:32:13 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:13 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:13 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:13 --> URI Class Initialized
INFO - 2016-10-09 18:32:13 --> Router Class Initialized
INFO - 2016-10-09 18:32:13 --> Output Class Initialized
INFO - 2016-10-09 18:32:13 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:13 --> Input Class Initialized
INFO - 2016-10-09 18:32:13 --> Language Class Initialized
ERROR - 2016-10-09 18:32:13 --> 404 Page Not Found: /index
INFO - 2016-10-09 18:32:16 --> Config Class Initialized
INFO - 2016-10-09 18:32:16 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:16 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:16 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:16 --> URI Class Initialized
DEBUG - 2016-10-09 18:32:16 --> No URI present. Default controller set.
INFO - 2016-10-09 18:32:16 --> Router Class Initialized
INFO - 2016-10-09 18:32:16 --> Output Class Initialized
INFO - 2016-10-09 18:32:16 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:16 --> Input Class Initialized
INFO - 2016-10-09 18:32:16 --> Language Class Initialized
INFO - 2016-10-09 18:32:16 --> Language Class Initialized
INFO - 2016-10-09 18:32:16 --> Config Class Initialized
INFO - 2016-10-09 18:32:16 --> Loader Class Initialized
INFO - 2016-10-09 18:32:16 --> Helper loaded: common_helper
INFO - 2016-10-09 18:32:16 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:16 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:16 --> Parser Class Initialized
INFO - 2016-10-09 18:32:16 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:16 --> Home MX_Controller Initialized
INFO - 2016-10-09 18:32:16 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:16 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-09 18:32:16 --> Model Class Initialized
ERROR - 2016-10-09 18:32:16 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 18:32:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 18:32:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 18:32:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-09 18:32:16 --> Final output sent to browser
DEBUG - 2016-10-09 18:32:16 --> Total execution time: 0.0347
INFO - 2016-10-09 18:32:25 --> Config Class Initialized
INFO - 2016-10-09 18:32:25 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:25 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:25 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:25 --> URI Class Initialized
INFO - 2016-10-09 18:32:25 --> Router Class Initialized
INFO - 2016-10-09 18:32:25 --> Output Class Initialized
INFO - 2016-10-09 18:32:25 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:25 --> Input Class Initialized
INFO - 2016-10-09 18:32:25 --> Language Class Initialized
INFO - 2016-10-09 18:32:25 --> Language Class Initialized
INFO - 2016-10-09 18:32:25 --> Config Class Initialized
INFO - 2016-10-09 18:32:25 --> Loader Class Initialized
INFO - 2016-10-09 18:32:25 --> Helper loaded: common_helper
INFO - 2016-10-09 18:32:25 --> Helper loaded: url_helper
INFO - 2016-10-09 18:32:25 --> Database Driver Class Initialized
INFO - 2016-10-09 18:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:32:25 --> Parser Class Initialized
INFO - 2016-10-09 18:32:25 --> Controller Class Initialized
DEBUG - 2016-10-09 18:32:25 --> Home MX_Controller Initialized
INFO - 2016-10-09 18:32:25 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-09 18:32:25 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-09 18:32:25 --> Content MX_Controller Initialized
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 18:32:25 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 18:32:25 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 18:32:25 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 18:32:25 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 18:32:25 --> Model Class Initialized
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 18:32:25 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 18:32:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 18:32:25 --> Final output sent to browser
DEBUG - 2016-10-09 18:32:25 --> Total execution time: 0.0581
INFO - 2016-10-09 18:32:26 --> Config Class Initialized
INFO - 2016-10-09 18:32:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:32:26 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:32:26 --> Utf8 Class Initialized
INFO - 2016-10-09 18:32:26 --> URI Class Initialized
INFO - 2016-10-09 18:32:26 --> Router Class Initialized
INFO - 2016-10-09 18:32:26 --> Output Class Initialized
INFO - 2016-10-09 18:32:26 --> Security Class Initialized
DEBUG - 2016-10-09 18:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:32:26 --> Input Class Initialized
INFO - 2016-10-09 18:32:26 --> Language Class Initialized
ERROR - 2016-10-09 18:32:26 --> 404 Page Not Found: /index
INFO - 2016-10-09 18:42:17 --> Config Class Initialized
INFO - 2016-10-09 18:42:17 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:42:17 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:42:17 --> Utf8 Class Initialized
INFO - 2016-10-09 18:42:17 --> URI Class Initialized
INFO - 2016-10-09 18:42:17 --> Router Class Initialized
INFO - 2016-10-09 18:42:17 --> Output Class Initialized
INFO - 2016-10-09 18:42:17 --> Security Class Initialized
DEBUG - 2016-10-09 18:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:42:17 --> Input Class Initialized
INFO - 2016-10-09 18:42:17 --> Language Class Initialized
ERROR - 2016-10-09 18:42:17 --> 404 Page Not Found: /index
INFO - 2016-10-09 18:42:18 --> Config Class Initialized
INFO - 2016-10-09 18:42:18 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:42:18 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:42:18 --> Utf8 Class Initialized
INFO - 2016-10-09 18:42:18 --> URI Class Initialized
DEBUG - 2016-10-09 18:42:18 --> No URI present. Default controller set.
INFO - 2016-10-09 18:42:18 --> Router Class Initialized
INFO - 2016-10-09 18:42:18 --> Output Class Initialized
INFO - 2016-10-09 18:42:18 --> Security Class Initialized
DEBUG - 2016-10-09 18:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:42:18 --> Input Class Initialized
INFO - 2016-10-09 18:42:18 --> Language Class Initialized
INFO - 2016-10-09 18:42:18 --> Language Class Initialized
INFO - 2016-10-09 18:42:18 --> Config Class Initialized
INFO - 2016-10-09 18:42:18 --> Loader Class Initialized
INFO - 2016-10-09 18:42:18 --> Helper loaded: common_helper
INFO - 2016-10-09 18:42:18 --> Helper loaded: url_helper
INFO - 2016-10-09 18:42:18 --> Database Driver Class Initialized
INFO - 2016-10-09 18:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:42:18 --> Parser Class Initialized
INFO - 2016-10-09 18:42:18 --> Controller Class Initialized
DEBUG - 2016-10-09 18:42:18 --> Home MX_Controller Initialized
INFO - 2016-10-09 18:42:18 --> Model Class Initialized
DEBUG - 2016-10-09 18:42:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-09 18:42:18 --> Model Class Initialized
ERROR - 2016-10-09 18:42:18 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 18:42:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 18:42:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 18:42:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-09 18:42:18 --> Final output sent to browser
DEBUG - 2016-10-09 18:42:18 --> Total execution time: 0.0443
INFO - 2016-10-09 18:42:32 --> Config Class Initialized
INFO - 2016-10-09 18:42:32 --> Hooks Class Initialized
DEBUG - 2016-10-09 18:42:32 --> UTF-8 Support Enabled
INFO - 2016-10-09 18:42:32 --> Utf8 Class Initialized
INFO - 2016-10-09 18:42:32 --> URI Class Initialized
INFO - 2016-10-09 18:42:32 --> Router Class Initialized
INFO - 2016-10-09 18:42:32 --> Output Class Initialized
INFO - 2016-10-09 18:42:32 --> Security Class Initialized
DEBUG - 2016-10-09 18:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 18:42:32 --> Input Class Initialized
INFO - 2016-10-09 18:42:32 --> Language Class Initialized
INFO - 2016-10-09 18:42:32 --> Language Class Initialized
INFO - 2016-10-09 18:42:32 --> Config Class Initialized
INFO - 2016-10-09 18:42:32 --> Loader Class Initialized
INFO - 2016-10-09 18:42:32 --> Helper loaded: common_helper
INFO - 2016-10-09 18:42:32 --> Helper loaded: url_helper
INFO - 2016-10-09 18:42:32 --> Database Driver Class Initialized
INFO - 2016-10-09 18:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 18:42:32 --> Parser Class Initialized
INFO - 2016-10-09 18:42:32 --> Controller Class Initialized
DEBUG - 2016-10-09 18:42:32 --> Popup MX_Controller Initialized
INFO - 2016-10-09 18:42:32 --> Model Class Initialized
DEBUG - 2016-10-09 18:42:32 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-09 18:42:32 --> Model Class Initialized
DEBUG - 2016-10-09 18:42:32 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-09 18:42:32 --> Final output sent to browser
DEBUG - 2016-10-09 18:42:32 --> Total execution time: 0.0407
INFO - 2016-10-09 19:15:46 --> Config Class Initialized
INFO - 2016-10-09 19:15:46 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:15:46 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:15:46 --> Utf8 Class Initialized
INFO - 2016-10-09 19:15:46 --> URI Class Initialized
INFO - 2016-10-09 19:15:46 --> Router Class Initialized
INFO - 2016-10-09 19:15:46 --> Output Class Initialized
INFO - 2016-10-09 19:15:46 --> Security Class Initialized
DEBUG - 2016-10-09 19:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:15:46 --> Input Class Initialized
INFO - 2016-10-09 19:15:46 --> Language Class Initialized
INFO - 2016-10-09 19:15:46 --> Language Class Initialized
INFO - 2016-10-09 19:15:46 --> Config Class Initialized
INFO - 2016-10-09 19:15:46 --> Loader Class Initialized
INFO - 2016-10-09 19:15:46 --> Helper loaded: common_helper
INFO - 2016-10-09 19:15:46 --> Helper loaded: url_helper
INFO - 2016-10-09 19:15:46 --> Database Driver Class Initialized
INFO - 2016-10-09 19:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 19:15:46 --> Parser Class Initialized
INFO - 2016-10-09 19:15:46 --> Controller Class Initialized
DEBUG - 2016-10-09 19:15:46 --> Content MX_Controller Initialized
INFO - 2016-10-09 19:15:46 --> Model Class Initialized
DEBUG - 2016-10-09 19:15:46 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 19:15:46 --> Model Class Initialized
DEBUG - 2016-10-09 19:15:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 19:15:46 --> Model Class Initialized
DEBUG - 2016-10-09 19:15:46 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 19:15:46 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 19:15:46 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 19:15:46 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 19:15:46 --> Model Class Initialized
DEBUG - 2016-10-09 19:15:46 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 19:15:46 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 19:15:46 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 19:15:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 19:15:47 --> Model Class Initialized
DEBUG - 2016-10-09 19:15:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 19:15:47 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 19:15:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 19:15:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 19:15:47 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 19:15:47 --> Final output sent to browser
DEBUG - 2016-10-09 19:15:47 --> Total execution time: 0.0769
INFO - 2016-10-09 19:53:49 --> Config Class Initialized
INFO - 2016-10-09 19:53:49 --> Hooks Class Initialized
DEBUG - 2016-10-09 19:53:49 --> UTF-8 Support Enabled
INFO - 2016-10-09 19:53:49 --> Utf8 Class Initialized
INFO - 2016-10-09 19:53:49 --> URI Class Initialized
INFO - 2016-10-09 19:53:49 --> Router Class Initialized
INFO - 2016-10-09 19:53:49 --> Output Class Initialized
INFO - 2016-10-09 19:53:49 --> Security Class Initialized
DEBUG - 2016-10-09 19:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 19:53:49 --> Input Class Initialized
INFO - 2016-10-09 19:53:49 --> Language Class Initialized
ERROR - 2016-10-09 19:53:49 --> 404 Page Not Found: /index
INFO - 2016-10-09 20:31:33 --> Config Class Initialized
INFO - 2016-10-09 20:31:33 --> Hooks Class Initialized
DEBUG - 2016-10-09 20:31:33 --> UTF-8 Support Enabled
INFO - 2016-10-09 20:31:33 --> Utf8 Class Initialized
INFO - 2016-10-09 20:31:33 --> URI Class Initialized
INFO - 2016-10-09 20:31:33 --> Router Class Initialized
INFO - 2016-10-09 20:31:33 --> Output Class Initialized
INFO - 2016-10-09 20:31:33 --> Security Class Initialized
DEBUG - 2016-10-09 20:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 20:31:33 --> Input Class Initialized
INFO - 2016-10-09 20:31:33 --> Language Class Initialized
INFO - 2016-10-09 20:31:33 --> Language Class Initialized
INFO - 2016-10-09 20:31:33 --> Config Class Initialized
INFO - 2016-10-09 20:31:33 --> Loader Class Initialized
INFO - 2016-10-09 20:31:33 --> Helper loaded: common_helper
INFO - 2016-10-09 20:31:33 --> Helper loaded: url_helper
INFO - 2016-10-09 20:31:33 --> Database Driver Class Initialized
INFO - 2016-10-09 20:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 20:31:33 --> Parser Class Initialized
INFO - 2016-10-09 20:31:33 --> Controller Class Initialized
DEBUG - 2016-10-09 20:31:33 --> Content MX_Controller Initialized
INFO - 2016-10-09 20:31:33 --> Model Class Initialized
DEBUG - 2016-10-09 20:31:33 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 20:31:33 --> Model Class Initialized
DEBUG - 2016-10-09 20:31:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 20:31:33 --> Model Class Initialized
DEBUG - 2016-10-09 20:31:33 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 20:31:33 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 20:31:33 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 20:31:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 20:31:33 --> Model Class Initialized
DEBUG - 2016-10-09 20:31:33 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 20:31:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 20:31:34 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 20:31:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 20:31:34 --> Model Class Initialized
DEBUG - 2016-10-09 20:31:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 20:31:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 20:31:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 20:31:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 20:31:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 20:31:34 --> Final output sent to browser
DEBUG - 2016-10-09 20:31:34 --> Total execution time: 0.0583
INFO - 2016-10-09 21:04:02 --> Config Class Initialized
INFO - 2016-10-09 21:04:02 --> Hooks Class Initialized
DEBUG - 2016-10-09 21:04:02 --> UTF-8 Support Enabled
INFO - 2016-10-09 21:04:02 --> Utf8 Class Initialized
INFO - 2016-10-09 21:04:02 --> URI Class Initialized
INFO - 2016-10-09 21:04:02 --> Router Class Initialized
INFO - 2016-10-09 21:04:02 --> Output Class Initialized
INFO - 2016-10-09 21:04:02 --> Security Class Initialized
DEBUG - 2016-10-09 21:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 21:04:02 --> Input Class Initialized
INFO - 2016-10-09 21:04:02 --> Language Class Initialized
INFO - 2016-10-09 21:04:02 --> Language Class Initialized
INFO - 2016-10-09 21:04:02 --> Config Class Initialized
INFO - 2016-10-09 21:04:02 --> Loader Class Initialized
INFO - 2016-10-09 21:04:02 --> Helper loaded: common_helper
INFO - 2016-10-09 21:04:02 --> Helper loaded: url_helper
INFO - 2016-10-09 21:04:02 --> Database Driver Class Initialized
INFO - 2016-10-09 21:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 21:04:02 --> Parser Class Initialized
INFO - 2016-10-09 21:04:02 --> Controller Class Initialized
DEBUG - 2016-10-09 21:04:02 --> Content MX_Controller Initialized
INFO - 2016-10-09 21:04:02 --> Model Class Initialized
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 21:04:02 --> Model Class Initialized
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 21:04:02 --> Model Class Initialized
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 21:04:02 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 21:04:02 --> Model Class Initialized
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 21:04:02 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 21:04:02 --> Model Class Initialized
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 21:04:02 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 21:04:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 21:04:02 --> Final output sent to browser
DEBUG - 2016-10-09 21:04:02 --> Total execution time: 0.0593
INFO - 2016-10-09 21:47:20 --> Config Class Initialized
INFO - 2016-10-09 21:47:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 21:47:20 --> UTF-8 Support Enabled
INFO - 2016-10-09 21:47:20 --> Utf8 Class Initialized
INFO - 2016-10-09 21:47:20 --> URI Class Initialized
INFO - 2016-10-09 21:47:20 --> Router Class Initialized
INFO - 2016-10-09 21:47:20 --> Output Class Initialized
INFO - 2016-10-09 21:47:20 --> Security Class Initialized
DEBUG - 2016-10-09 21:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 21:47:20 --> Input Class Initialized
INFO - 2016-10-09 21:47:20 --> Language Class Initialized
INFO - 2016-10-09 21:47:20 --> Language Class Initialized
INFO - 2016-10-09 21:47:20 --> Config Class Initialized
INFO - 2016-10-09 21:47:20 --> Loader Class Initialized
INFO - 2016-10-09 21:47:20 --> Helper loaded: common_helper
INFO - 2016-10-09 21:47:20 --> Helper loaded: url_helper
INFO - 2016-10-09 21:47:20 --> Database Driver Class Initialized
INFO - 2016-10-09 21:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 21:47:20 --> Parser Class Initialized
INFO - 2016-10-09 21:47:20 --> Controller Class Initialized
DEBUG - 2016-10-09 21:47:20 --> Content MX_Controller Initialized
INFO - 2016-10-09 21:47:20 --> Model Class Initialized
DEBUG - 2016-10-09 21:47:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 21:47:20 --> Model Class Initialized
DEBUG - 2016-10-09 21:47:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 21:47:20 --> Model Class Initialized
DEBUG - 2016-10-09 21:47:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 21:47:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 21:47:20 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 21:47:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 21:47:20 --> Model Class Initialized
DEBUG - 2016-10-09 21:47:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 21:47:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 21:47:20 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 21:47:21 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 21:47:21 --> Model Class Initialized
DEBUG - 2016-10-09 21:47:21 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 21:47:21 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 21:47:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 21:47:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 21:47:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 21:47:21 --> Final output sent to browser
DEBUG - 2016-10-09 21:47:21 --> Total execution time: 0.0655
INFO - 2016-10-09 22:22:12 --> Config Class Initialized
INFO - 2016-10-09 22:22:12 --> Hooks Class Initialized
DEBUG - 2016-10-09 22:22:13 --> UTF-8 Support Enabled
INFO - 2016-10-09 22:22:13 --> Utf8 Class Initialized
INFO - 2016-10-09 22:22:13 --> URI Class Initialized
DEBUG - 2016-10-09 22:22:13 --> No URI present. Default controller set.
INFO - 2016-10-09 22:22:13 --> Router Class Initialized
INFO - 2016-10-09 22:22:13 --> Output Class Initialized
INFO - 2016-10-09 22:22:13 --> Security Class Initialized
DEBUG - 2016-10-09 22:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 22:22:13 --> Input Class Initialized
INFO - 2016-10-09 22:22:13 --> Language Class Initialized
INFO - 2016-10-09 22:22:13 --> Language Class Initialized
INFO - 2016-10-09 22:22:13 --> Config Class Initialized
INFO - 2016-10-09 22:22:13 --> Loader Class Initialized
INFO - 2016-10-09 22:22:13 --> Helper loaded: common_helper
INFO - 2016-10-09 22:22:13 --> Helper loaded: url_helper
INFO - 2016-10-09 22:22:13 --> Database Driver Class Initialized
INFO - 2016-10-09 22:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 22:22:13 --> Parser Class Initialized
INFO - 2016-10-09 22:22:13 --> Controller Class Initialized
DEBUG - 2016-10-09 22:22:13 --> Home MX_Controller Initialized
INFO - 2016-10-09 22:22:13 --> Model Class Initialized
DEBUG - 2016-10-09 22:22:13 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-09 22:22:13 --> Model Class Initialized
ERROR - 2016-10-09 22:22:13 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 22:22:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 22:22:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 22:22:13 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-09 22:22:13 --> Final output sent to browser
DEBUG - 2016-10-09 22:22:13 --> Total execution time: 0.2735
INFO - 2016-10-09 22:22:26 --> Config Class Initialized
INFO - 2016-10-09 22:22:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 22:22:26 --> UTF-8 Support Enabled
INFO - 2016-10-09 22:22:26 --> Utf8 Class Initialized
INFO - 2016-10-09 22:22:26 --> URI Class Initialized
INFO - 2016-10-09 22:22:26 --> Router Class Initialized
INFO - 2016-10-09 22:22:26 --> Output Class Initialized
INFO - 2016-10-09 22:22:26 --> Security Class Initialized
DEBUG - 2016-10-09 22:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 22:22:26 --> Input Class Initialized
INFO - 2016-10-09 22:22:26 --> Language Class Initialized
INFO - 2016-10-09 22:22:26 --> Language Class Initialized
INFO - 2016-10-09 22:22:26 --> Config Class Initialized
INFO - 2016-10-09 22:22:26 --> Loader Class Initialized
INFO - 2016-10-09 22:22:26 --> Helper loaded: common_helper
INFO - 2016-10-09 22:22:26 --> Helper loaded: url_helper
INFO - 2016-10-09 22:22:26 --> Database Driver Class Initialized
INFO - 2016-10-09 22:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 22:22:26 --> Parser Class Initialized
INFO - 2016-10-09 22:22:26 --> Controller Class Initialized
DEBUG - 2016-10-09 22:22:26 --> Popup MX_Controller Initialized
INFO - 2016-10-09 22:22:26 --> Model Class Initialized
DEBUG - 2016-10-09 22:22:26 --> File loaded: /home/dolongpk/public_html/application/modules/popup/models/Popup_model.php
INFO - 2016-10-09 22:22:26 --> Model Class Initialized
DEBUG - 2016-10-09 22:22:26 --> File loaded: /home/dolongpk/public_html/application/modules/popup/views/FRONTEND/popup_video.php
INFO - 2016-10-09 22:22:26 --> Final output sent to browser
DEBUG - 2016-10-09 22:22:26 --> Total execution time: 0.0390
INFO - 2016-10-09 23:03:07 --> Config Class Initialized
INFO - 2016-10-09 23:03:07 --> Hooks Class Initialized
DEBUG - 2016-10-09 23:03:07 --> UTF-8 Support Enabled
INFO - 2016-10-09 23:03:07 --> Utf8 Class Initialized
INFO - 2016-10-09 23:03:07 --> URI Class Initialized
INFO - 2016-10-09 23:03:07 --> Router Class Initialized
INFO - 2016-10-09 23:03:07 --> Output Class Initialized
INFO - 2016-10-09 23:03:07 --> Security Class Initialized
DEBUG - 2016-10-09 23:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 23:03:07 --> Input Class Initialized
INFO - 2016-10-09 23:03:07 --> Language Class Initialized
INFO - 2016-10-09 23:03:07 --> Language Class Initialized
INFO - 2016-10-09 23:03:07 --> Config Class Initialized
INFO - 2016-10-09 23:03:07 --> Loader Class Initialized
INFO - 2016-10-09 23:03:07 --> Helper loaded: common_helper
INFO - 2016-10-09 23:03:07 --> Helper loaded: url_helper
INFO - 2016-10-09 23:03:07 --> Database Driver Class Initialized
INFO - 2016-10-09 23:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 23:03:07 --> Parser Class Initialized
INFO - 2016-10-09 23:03:07 --> Controller Class Initialized
DEBUG - 2016-10-09 23:03:07 --> Content MX_Controller Initialized
INFO - 2016-10-09 23:03:07 --> Model Class Initialized
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 23:03:07 --> Model Class Initialized
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 23:03:07 --> Model Class Initialized
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/list.php
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 23:03:07 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 23:03:07 --> Model Class Initialized
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 23:03:07 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 23:03:07 --> Model Class Initialized
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 23:03:07 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 23:03:07 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 23:03:07 --> Final output sent to browser
DEBUG - 2016-10-09 23:03:07 --> Total execution time: 0.0590
INFO - 2016-10-09 23:25:57 --> Config Class Initialized
INFO - 2016-10-09 23:25:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 23:25:57 --> UTF-8 Support Enabled
INFO - 2016-10-09 23:25:57 --> Utf8 Class Initialized
INFO - 2016-10-09 23:25:57 --> URI Class Initialized
INFO - 2016-10-09 23:25:57 --> Router Class Initialized
INFO - 2016-10-09 23:25:57 --> Output Class Initialized
INFO - 2016-10-09 23:25:57 --> Security Class Initialized
DEBUG - 2016-10-09 23:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-09 23:25:57 --> Input Class Initialized
INFO - 2016-10-09 23:25:57 --> Language Class Initialized
INFO - 2016-10-09 23:25:57 --> Language Class Initialized
INFO - 2016-10-09 23:25:57 --> Config Class Initialized
INFO - 2016-10-09 23:25:57 --> Loader Class Initialized
INFO - 2016-10-09 23:25:57 --> Helper loaded: common_helper
INFO - 2016-10-09 23:25:57 --> Helper loaded: url_helper
INFO - 2016-10-09 23:25:57 --> Database Driver Class Initialized
INFO - 2016-10-09 23:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-09 23:25:57 --> Parser Class Initialized
INFO - 2016-10-09 23:25:57 --> Controller Class Initialized
DEBUG - 2016-10-09 23:25:57 --> Content MX_Controller Initialized
INFO - 2016-10-09 23:25:57 --> Model Class Initialized
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-09 23:25:57 --> Model Class Initialized
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-09 23:25:57 --> Model Class Initialized
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-09 23:25:57 --> Slider MX_Controller Initialized
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-09 23:25:57 --> Model Class Initialized
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-09 23:25:57 --> Servers MX_Controller Initialized
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-09 23:25:57 --> Model Class Initialized
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-09 23:25:57 --> Module controller failed to run: banner/index
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-09 23:25:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-09 23:25:57 --> Final output sent to browser
DEBUG - 2016-10-09 23:25:57 --> Total execution time: 0.0546
