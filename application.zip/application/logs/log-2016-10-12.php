<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-12 00:46:59 --> Config Class Initialized
INFO - 2016-10-12 00:46:59 --> Hooks Class Initialized
DEBUG - 2016-10-12 00:46:59 --> UTF-8 Support Enabled
INFO - 2016-10-12 00:46:59 --> Utf8 Class Initialized
INFO - 2016-10-12 00:46:59 --> URI Class Initialized
DEBUG - 2016-10-12 00:46:59 --> No URI present. Default controller set.
INFO - 2016-10-12 00:46:59 --> Router Class Initialized
INFO - 2016-10-12 00:46:59 --> Output Class Initialized
INFO - 2016-10-12 00:46:59 --> Security Class Initialized
DEBUG - 2016-10-12 00:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 00:46:59 --> Input Class Initialized
INFO - 2016-10-12 00:46:59 --> Language Class Initialized
INFO - 2016-10-12 00:46:59 --> Language Class Initialized
INFO - 2016-10-12 00:46:59 --> Config Class Initialized
INFO - 2016-10-12 00:46:59 --> Loader Class Initialized
INFO - 2016-10-12 00:46:59 --> Helper loaded: common_helper
INFO - 2016-10-12 00:46:59 --> Helper loaded: url_helper
INFO - 2016-10-12 00:46:59 --> Database Driver Class Initialized
INFO - 2016-10-12 00:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 00:46:59 --> Parser Class Initialized
INFO - 2016-10-12 00:46:59 --> Controller Class Initialized
DEBUG - 2016-10-12 00:46:59 --> Home MX_Controller Initialized
INFO - 2016-10-12 00:46:59 --> Model Class Initialized
DEBUG - 2016-10-12 00:46:59 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 00:46:59 --> Model Class Initialized
ERROR - 2016-10-12 00:46:59 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 00:46:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 00:46:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 00:46:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 00:46:59 --> Final output sent to browser
DEBUG - 2016-10-12 00:46:59 --> Total execution time: 0.0455
INFO - 2016-10-12 00:58:49 --> Config Class Initialized
INFO - 2016-10-12 00:58:49 --> Hooks Class Initialized
DEBUG - 2016-10-12 00:58:49 --> UTF-8 Support Enabled
INFO - 2016-10-12 00:58:49 --> Utf8 Class Initialized
INFO - 2016-10-12 00:58:49 --> URI Class Initialized
INFO - 2016-10-12 00:58:49 --> Router Class Initialized
INFO - 2016-10-12 00:58:49 --> Output Class Initialized
INFO - 2016-10-12 00:58:49 --> Security Class Initialized
DEBUG - 2016-10-12 00:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 00:58:49 --> Input Class Initialized
INFO - 2016-10-12 00:58:49 --> Language Class Initialized
ERROR - 2016-10-12 00:58:49 --> 404 Page Not Found: /index
INFO - 2016-10-12 05:22:43 --> Config Class Initialized
INFO - 2016-10-12 05:22:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 05:22:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 05:22:43 --> Utf8 Class Initialized
INFO - 2016-10-12 05:22:43 --> URI Class Initialized
DEBUG - 2016-10-12 05:22:43 --> No URI present. Default controller set.
INFO - 2016-10-12 05:22:43 --> Router Class Initialized
INFO - 2016-10-12 05:22:43 --> Output Class Initialized
INFO - 2016-10-12 05:22:43 --> Security Class Initialized
DEBUG - 2016-10-12 05:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 05:22:43 --> Input Class Initialized
INFO - 2016-10-12 05:22:43 --> Language Class Initialized
INFO - 2016-10-12 05:22:43 --> Language Class Initialized
INFO - 2016-10-12 05:22:43 --> Config Class Initialized
INFO - 2016-10-12 05:22:43 --> Loader Class Initialized
INFO - 2016-10-12 05:22:43 --> Helper loaded: common_helper
INFO - 2016-10-12 05:22:43 --> Helper loaded: url_helper
INFO - 2016-10-12 05:22:43 --> Database Driver Class Initialized
INFO - 2016-10-12 05:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 05:22:43 --> Parser Class Initialized
INFO - 2016-10-12 05:22:43 --> Controller Class Initialized
DEBUG - 2016-10-12 05:22:43 --> Home MX_Controller Initialized
INFO - 2016-10-12 05:22:43 --> Model Class Initialized
DEBUG - 2016-10-12 05:22:43 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 05:22:43 --> Model Class Initialized
ERROR - 2016-10-12 05:22:43 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 05:22:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 05:22:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 05:22:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 05:22:43 --> Final output sent to browser
DEBUG - 2016-10-12 05:22:43 --> Total execution time: 0.0469
INFO - 2016-10-12 06:18:53 --> Config Class Initialized
INFO - 2016-10-12 06:18:53 --> Hooks Class Initialized
DEBUG - 2016-10-12 06:18:53 --> UTF-8 Support Enabled
INFO - 2016-10-12 06:18:53 --> Utf8 Class Initialized
INFO - 2016-10-12 06:18:53 --> URI Class Initialized
INFO - 2016-10-12 06:18:53 --> Router Class Initialized
INFO - 2016-10-12 06:18:53 --> Output Class Initialized
INFO - 2016-10-12 06:18:53 --> Security Class Initialized
DEBUG - 2016-10-12 06:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 06:18:53 --> Input Class Initialized
INFO - 2016-10-12 06:18:53 --> Language Class Initialized
INFO - 2016-10-12 06:18:53 --> Language Class Initialized
INFO - 2016-10-12 06:18:53 --> Config Class Initialized
INFO - 2016-10-12 06:18:53 --> Loader Class Initialized
INFO - 2016-10-12 06:18:53 --> Helper loaded: common_helper
INFO - 2016-10-12 06:18:53 --> Helper loaded: url_helper
INFO - 2016-10-12 06:18:53 --> Database Driver Class Initialized
INFO - 2016-10-12 06:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 06:18:53 --> Parser Class Initialized
INFO - 2016-10-12 06:18:53 --> Controller Class Initialized
DEBUG - 2016-10-12 06:18:53 --> Content MX_Controller Initialized
INFO - 2016-10-12 06:18:53 --> Model Class Initialized
DEBUG - 2016-10-12 06:18:53 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-12 06:18:53 --> Model Class Initialized
DEBUG - 2016-10-12 06:18:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 06:18:53 --> Model Class Initialized
DEBUG - 2016-10-12 06:18:53 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-12 06:18:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-12 06:18:53 --> Slider MX_Controller Initialized
DEBUG - 2016-10-12 06:18:53 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-12 06:18:53 --> Model Class Initialized
DEBUG - 2016-10-12 06:18:53 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-12 06:18:53 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-12 06:18:53 --> Servers MX_Controller Initialized
DEBUG - 2016-10-12 06:18:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 06:18:54 --> Model Class Initialized
DEBUG - 2016-10-12 06:18:54 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-12 06:18:54 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 06:18:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 06:18:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 06:18:54 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-12 06:18:54 --> Final output sent to browser
DEBUG - 2016-10-12 06:18:54 --> Total execution time: 0.1576
INFO - 2016-10-12 08:53:29 --> Config Class Initialized
INFO - 2016-10-12 08:53:29 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:53:29 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:53:29 --> Utf8 Class Initialized
INFO - 2016-10-12 08:53:29 --> URI Class Initialized
INFO - 2016-10-12 08:53:29 --> Router Class Initialized
INFO - 2016-10-12 08:53:29 --> Output Class Initialized
INFO - 2016-10-12 08:53:29 --> Security Class Initialized
DEBUG - 2016-10-12 08:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:53:29 --> Input Class Initialized
INFO - 2016-10-12 08:53:29 --> Language Class Initialized
INFO - 2016-10-12 08:53:29 --> Language Class Initialized
INFO - 2016-10-12 08:53:29 --> Config Class Initialized
INFO - 2016-10-12 08:53:29 --> Loader Class Initialized
INFO - 2016-10-12 08:53:29 --> Helper loaded: common_helper
INFO - 2016-10-12 08:53:29 --> Helper loaded: url_helper
INFO - 2016-10-12 08:53:29 --> Database Driver Class Initialized
INFO - 2016-10-12 08:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:53:29 --> Parser Class Initialized
INFO - 2016-10-12 08:53:29 --> Controller Class Initialized
DEBUG - 2016-10-12 08:53:29 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 08:53:29 --> Config Class Initialized
INFO - 2016-10-12 08:53:29 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:53:29 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:53:29 --> Utf8 Class Initialized
INFO - 2016-10-12 08:53:29 --> URI Class Initialized
INFO - 2016-10-12 08:53:29 --> Router Class Initialized
INFO - 2016-10-12 08:53:29 --> Output Class Initialized
INFO - 2016-10-12 08:53:29 --> Security Class Initialized
DEBUG - 2016-10-12 08:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:53:29 --> Input Class Initialized
INFO - 2016-10-12 08:53:29 --> Language Class Initialized
INFO - 2016-10-12 08:53:29 --> Language Class Initialized
INFO - 2016-10-12 08:53:29 --> Config Class Initialized
INFO - 2016-10-12 08:53:29 --> Loader Class Initialized
INFO - 2016-10-12 08:53:29 --> Helper loaded: common_helper
INFO - 2016-10-12 08:53:29 --> Helper loaded: url_helper
INFO - 2016-10-12 08:53:29 --> Database Driver Class Initialized
INFO - 2016-10-12 08:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:53:29 --> Parser Class Initialized
INFO - 2016-10-12 08:53:29 --> Controller Class Initialized
DEBUG - 2016-10-12 08:53:29 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 08:53:29 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:53:29 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:29 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-12 08:53:29 --> Final output sent to browser
DEBUG - 2016-10-12 08:53:29 --> Total execution time: 0.0388
INFO - 2016-10-12 08:53:36 --> Config Class Initialized
INFO - 2016-10-12 08:53:36 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:53:36 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:53:36 --> Utf8 Class Initialized
INFO - 2016-10-12 08:53:36 --> URI Class Initialized
INFO - 2016-10-12 08:53:36 --> Router Class Initialized
INFO - 2016-10-12 08:53:36 --> Output Class Initialized
INFO - 2016-10-12 08:53:36 --> Security Class Initialized
DEBUG - 2016-10-12 08:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:53:36 --> Input Class Initialized
INFO - 2016-10-12 08:53:36 --> Language Class Initialized
INFO - 2016-10-12 08:53:36 --> Language Class Initialized
INFO - 2016-10-12 08:53:36 --> Config Class Initialized
INFO - 2016-10-12 08:53:36 --> Loader Class Initialized
INFO - 2016-10-12 08:53:36 --> Helper loaded: common_helper
INFO - 2016-10-12 08:53:36 --> Helper loaded: url_helper
INFO - 2016-10-12 08:53:36 --> Database Driver Class Initialized
INFO - 2016-10-12 08:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:53:36 --> Parser Class Initialized
INFO - 2016-10-12 08:53:36 --> Controller Class Initialized
DEBUG - 2016-10-12 08:53:36 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 08:53:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:53:36 --> Model Class Initialized
INFO - 2016-10-12 08:53:36 --> Final output sent to browser
DEBUG - 2016-10-12 08:53:36 --> Total execution time: 0.0442
INFO - 2016-10-12 08:53:36 --> Config Class Initialized
INFO - 2016-10-12 08:53:36 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:53:36 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:53:36 --> Utf8 Class Initialized
INFO - 2016-10-12 08:53:36 --> URI Class Initialized
INFO - 2016-10-12 08:53:36 --> Router Class Initialized
INFO - 2016-10-12 08:53:36 --> Output Class Initialized
INFO - 2016-10-12 08:53:36 --> Security Class Initialized
DEBUG - 2016-10-12 08:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:53:36 --> Input Class Initialized
INFO - 2016-10-12 08:53:36 --> Language Class Initialized
INFO - 2016-10-12 08:53:36 --> Language Class Initialized
INFO - 2016-10-12 08:53:36 --> Config Class Initialized
INFO - 2016-10-12 08:53:36 --> Loader Class Initialized
INFO - 2016-10-12 08:53:36 --> Helper loaded: common_helper
INFO - 2016-10-12 08:53:36 --> Helper loaded: url_helper
INFO - 2016-10-12 08:53:36 --> Database Driver Class Initialized
INFO - 2016-10-12 08:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:53:36 --> Parser Class Initialized
INFO - 2016-10-12 08:53:36 --> Controller Class Initialized
DEBUG - 2016-10-12 08:53:36 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 08:53:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:53:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-12 08:53:36 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:53:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 08:53:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:53:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 08:53:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 08:53:36 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 08:53:36 --> Final output sent to browser
DEBUG - 2016-10-12 08:53:36 --> Total execution time: 0.0922
INFO - 2016-10-12 08:53:37 --> Config Class Initialized
INFO - 2016-10-12 08:53:37 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:53:37 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:53:37 --> Utf8 Class Initialized
INFO - 2016-10-12 08:53:37 --> URI Class Initialized
INFO - 2016-10-12 08:53:37 --> Router Class Initialized
INFO - 2016-10-12 08:53:37 --> Output Class Initialized
INFO - 2016-10-12 08:53:37 --> Security Class Initialized
DEBUG - 2016-10-12 08:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:53:37 --> Input Class Initialized
INFO - 2016-10-12 08:53:37 --> Language Class Initialized
ERROR - 2016-10-12 08:53:37 --> 404 Page Not Found: /index
INFO - 2016-10-12 08:53:49 --> Config Class Initialized
INFO - 2016-10-12 08:53:49 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:53:49 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:53:49 --> Utf8 Class Initialized
INFO - 2016-10-12 08:53:49 --> URI Class Initialized
INFO - 2016-10-12 08:53:49 --> Router Class Initialized
INFO - 2016-10-12 08:53:49 --> Output Class Initialized
INFO - 2016-10-12 08:53:49 --> Security Class Initialized
DEBUG - 2016-10-12 08:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:53:49 --> Input Class Initialized
INFO - 2016-10-12 08:53:49 --> Language Class Initialized
INFO - 2016-10-12 08:53:49 --> Language Class Initialized
INFO - 2016-10-12 08:53:49 --> Config Class Initialized
INFO - 2016-10-12 08:53:49 --> Loader Class Initialized
INFO - 2016-10-12 08:53:49 --> Helper loaded: common_helper
INFO - 2016-10-12 08:53:49 --> Helper loaded: url_helper
INFO - 2016-10-12 08:53:49 --> Database Driver Class Initialized
INFO - 2016-10-12 08:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:53:49 --> Parser Class Initialized
INFO - 2016-10-12 08:53:49 --> Controller Class Initialized
DEBUG - 2016-10-12 08:53:49 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:53:49 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:53:49 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:53:49 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 08:53:49 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 08:53:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 08:53:49 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:53:49 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-12 08:53:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 08:53:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 08:53:49 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 08:53:49 --> Final output sent to browser
DEBUG - 2016-10-12 08:53:49 --> Total execution time: 0.0531
INFO - 2016-10-12 08:53:50 --> Config Class Initialized
INFO - 2016-10-12 08:53:50 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:53:50 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:53:50 --> Utf8 Class Initialized
INFO - 2016-10-12 08:53:50 --> URI Class Initialized
INFO - 2016-10-12 08:53:50 --> Router Class Initialized
INFO - 2016-10-12 08:53:50 --> Output Class Initialized
INFO - 2016-10-12 08:53:50 --> Security Class Initialized
DEBUG - 2016-10-12 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:53:50 --> Input Class Initialized
INFO - 2016-10-12 08:53:50 --> Language Class Initialized
ERROR - 2016-10-12 08:53:50 --> 404 Page Not Found: /index
INFO - 2016-10-12 08:53:50 --> Config Class Initialized
INFO - 2016-10-12 08:53:50 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:53:50 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:53:50 --> Utf8 Class Initialized
INFO - 2016-10-12 08:53:50 --> URI Class Initialized
INFO - 2016-10-12 08:53:50 --> Router Class Initialized
INFO - 2016-10-12 08:53:50 --> Output Class Initialized
INFO - 2016-10-12 08:53:50 --> Security Class Initialized
DEBUG - 2016-10-12 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:53:50 --> Input Class Initialized
INFO - 2016-10-12 08:53:50 --> Language Class Initialized
INFO - 2016-10-12 08:53:50 --> Language Class Initialized
INFO - 2016-10-12 08:53:50 --> Config Class Initialized
INFO - 2016-10-12 08:53:50 --> Loader Class Initialized
INFO - 2016-10-12 08:53:50 --> Helper loaded: common_helper
INFO - 2016-10-12 08:53:50 --> Helper loaded: url_helper
INFO - 2016-10-12 08:53:50 --> Database Driver Class Initialized
INFO - 2016-10-12 08:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:53:50 --> Parser Class Initialized
INFO - 2016-10-12 08:53:50 --> Controller Class Initialized
DEBUG - 2016-10-12 08:53:50 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:53:50 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:53:50 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:53:50 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:50 --> Pagination Class Initialized
DEBUG - 2016-10-12 08:53:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 08:53:50 --> Final output sent to browser
DEBUG - 2016-10-12 08:53:50 --> Total execution time: 0.0517
INFO - 2016-10-12 08:53:52 --> Config Class Initialized
INFO - 2016-10-12 08:53:52 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:53:52 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:53:52 --> Utf8 Class Initialized
INFO - 2016-10-12 08:53:52 --> URI Class Initialized
INFO - 2016-10-12 08:53:52 --> Router Class Initialized
INFO - 2016-10-12 08:53:52 --> Output Class Initialized
INFO - 2016-10-12 08:53:52 --> Security Class Initialized
DEBUG - 2016-10-12 08:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:53:52 --> Input Class Initialized
INFO - 2016-10-12 08:53:52 --> Language Class Initialized
INFO - 2016-10-12 08:53:52 --> Language Class Initialized
INFO - 2016-10-12 08:53:52 --> Config Class Initialized
INFO - 2016-10-12 08:53:52 --> Loader Class Initialized
INFO - 2016-10-12 08:53:52 --> Helper loaded: common_helper
INFO - 2016-10-12 08:53:52 --> Helper loaded: url_helper
INFO - 2016-10-12 08:53:52 --> Database Driver Class Initialized
INFO - 2016-10-12 08:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:53:52 --> Parser Class Initialized
INFO - 2016-10-12 08:53:52 --> Controller Class Initialized
DEBUG - 2016-10-12 08:53:52 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:53:52 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:52 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:53:52 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:53:52 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:52 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 08:53:52 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 08:53:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 08:53:52 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:53:52 --> Model Class Initialized
DEBUG - 2016-10-12 08:53:52 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-12 08:53:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 08:53:52 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 08:53:52 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 08:53:52 --> Final output sent to browser
DEBUG - 2016-10-12 08:53:52 --> Total execution time: 0.0628
INFO - 2016-10-12 08:54:16 --> Config Class Initialized
INFO - 2016-10-12 08:54:16 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:54:16 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:54:16 --> Utf8 Class Initialized
INFO - 2016-10-12 08:54:16 --> URI Class Initialized
INFO - 2016-10-12 08:54:16 --> Router Class Initialized
INFO - 2016-10-12 08:54:16 --> Output Class Initialized
INFO - 2016-10-12 08:54:16 --> Security Class Initialized
DEBUG - 2016-10-12 08:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:54:16 --> Input Class Initialized
INFO - 2016-10-12 08:54:16 --> Language Class Initialized
INFO - 2016-10-12 08:54:16 --> Language Class Initialized
INFO - 2016-10-12 08:54:16 --> Config Class Initialized
INFO - 2016-10-12 08:54:16 --> Loader Class Initialized
INFO - 2016-10-12 08:54:16 --> Helper loaded: common_helper
INFO - 2016-10-12 08:54:16 --> Helper loaded: url_helper
INFO - 2016-10-12 08:54:16 --> Database Driver Class Initialized
INFO - 2016-10-12 08:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:54:16 --> Parser Class Initialized
INFO - 2016-10-12 08:54:16 --> Controller Class Initialized
DEBUG - 2016-10-12 08:54:16 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:54:16 --> Model Class Initialized
DEBUG - 2016-10-12 08:54:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:54:16 --> Model Class Initialized
DEBUG - 2016-10-12 08:54:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:54:16 --> Model Class Initialized
DEBUG - 2016-10-12 08:54:16 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 08:54:16 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 08:54:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 08:54:16 --> Model Class Initialized
DEBUG - 2016-10-12 08:54:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:54:16 --> Model Class Initialized
INFO - 2016-10-12 08:58:47 --> Config Class Initialized
INFO - 2016-10-12 08:58:47 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:58:47 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:58:47 --> Utf8 Class Initialized
INFO - 2016-10-12 08:58:47 --> URI Class Initialized
INFO - 2016-10-12 08:58:47 --> Router Class Initialized
INFO - 2016-10-12 08:58:47 --> Output Class Initialized
INFO - 2016-10-12 08:58:47 --> Security Class Initialized
DEBUG - 2016-10-12 08:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:58:47 --> Input Class Initialized
INFO - 2016-10-12 08:58:47 --> Language Class Initialized
INFO - 2016-10-12 08:58:47 --> Language Class Initialized
INFO - 2016-10-12 08:58:47 --> Config Class Initialized
INFO - 2016-10-12 08:58:47 --> Loader Class Initialized
INFO - 2016-10-12 08:58:47 --> Helper loaded: common_helper
INFO - 2016-10-12 08:58:47 --> Helper loaded: url_helper
INFO - 2016-10-12 08:58:47 --> Database Driver Class Initialized
INFO - 2016-10-12 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:58:47 --> Parser Class Initialized
INFO - 2016-10-12 08:58:47 --> Controller Class Initialized
DEBUG - 2016-10-12 08:58:47 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:58:47 --> Model Class Initialized
DEBUG - 2016-10-12 08:58:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:58:47 --> Model Class Initialized
DEBUG - 2016-10-12 08:58:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:58:47 --> Model Class Initialized
DEBUG - 2016-10-12 08:58:47 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 08:58:47 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 08:58:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 08:58:47 --> Model Class Initialized
DEBUG - 2016-10-12 08:58:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:58:47 --> Model Class Initialized
DEBUG - 2016-10-12 08:58:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-12 08:58:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 08:58:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 08:58:47 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 08:58:47 --> Final output sent to browser
DEBUG - 2016-10-12 08:58:47 --> Total execution time: 0.0500
INFO - 2016-10-12 08:59:19 --> Config Class Initialized
INFO - 2016-10-12 08:59:19 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:59:19 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:59:19 --> Utf8 Class Initialized
INFO - 2016-10-12 08:59:19 --> URI Class Initialized
INFO - 2016-10-12 08:59:19 --> Router Class Initialized
INFO - 2016-10-12 08:59:19 --> Output Class Initialized
INFO - 2016-10-12 08:59:19 --> Security Class Initialized
DEBUG - 2016-10-12 08:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:59:19 --> Input Class Initialized
INFO - 2016-10-12 08:59:19 --> Language Class Initialized
INFO - 2016-10-12 08:59:19 --> Language Class Initialized
INFO - 2016-10-12 08:59:19 --> Config Class Initialized
INFO - 2016-10-12 08:59:19 --> Loader Class Initialized
INFO - 2016-10-12 08:59:19 --> Helper loaded: common_helper
INFO - 2016-10-12 08:59:19 --> Helper loaded: url_helper
INFO - 2016-10-12 08:59:19 --> Database Driver Class Initialized
INFO - 2016-10-12 08:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:59:19 --> Parser Class Initialized
INFO - 2016-10-12 08:59:19 --> Controller Class Initialized
DEBUG - 2016-10-12 08:59:19 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:59:19 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:59:19 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:59:19 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:19 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 08:59:19 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 08:59:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 08:59:19 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:59:19 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-12 08:59:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 08:59:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 08:59:19 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 08:59:19 --> Final output sent to browser
DEBUG - 2016-10-12 08:59:19 --> Total execution time: 0.0531
INFO - 2016-10-12 08:59:36 --> Config Class Initialized
INFO - 2016-10-12 08:59:36 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:59:36 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:59:36 --> Utf8 Class Initialized
INFO - 2016-10-12 08:59:36 --> URI Class Initialized
INFO - 2016-10-12 08:59:36 --> Router Class Initialized
INFO - 2016-10-12 08:59:36 --> Output Class Initialized
INFO - 2016-10-12 08:59:36 --> Security Class Initialized
DEBUG - 2016-10-12 08:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:59:36 --> Input Class Initialized
INFO - 2016-10-12 08:59:36 --> Language Class Initialized
INFO - 2016-10-12 08:59:36 --> Language Class Initialized
INFO - 2016-10-12 08:59:36 --> Config Class Initialized
INFO - 2016-10-12 08:59:36 --> Loader Class Initialized
INFO - 2016-10-12 08:59:36 --> Helper loaded: common_helper
INFO - 2016-10-12 08:59:36 --> Helper loaded: url_helper
INFO - 2016-10-12 08:59:36 --> Database Driver Class Initialized
INFO - 2016-10-12 08:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:59:36 --> Parser Class Initialized
INFO - 2016-10-12 08:59:36 --> Controller Class Initialized
DEBUG - 2016-10-12 08:59:36 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 08:59:36 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/donate_config/controllers/Donate_config.php
DEBUG - 2016-10-12 08:59:36 --> Donate_config MX_Controller Initialized
ERROR - 2016-10-12 08:59:36 --> Module controller failed to run: donate_config/syncConfig
INFO - 2016-10-12 08:59:36 --> Config Class Initialized
INFO - 2016-10-12 08:59:36 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:59:36 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:59:36 --> Utf8 Class Initialized
INFO - 2016-10-12 08:59:36 --> URI Class Initialized
INFO - 2016-10-12 08:59:36 --> Router Class Initialized
INFO - 2016-10-12 08:59:36 --> Output Class Initialized
INFO - 2016-10-12 08:59:36 --> Security Class Initialized
DEBUG - 2016-10-12 08:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:59:36 --> Input Class Initialized
INFO - 2016-10-12 08:59:36 --> Language Class Initialized
INFO - 2016-10-12 08:59:36 --> Language Class Initialized
INFO - 2016-10-12 08:59:36 --> Config Class Initialized
INFO - 2016-10-12 08:59:36 --> Loader Class Initialized
INFO - 2016-10-12 08:59:36 --> Helper loaded: common_helper
INFO - 2016-10-12 08:59:36 --> Helper loaded: url_helper
INFO - 2016-10-12 08:59:36 --> Database Driver Class Initialized
INFO - 2016-10-12 08:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:59:36 --> Parser Class Initialized
INFO - 2016-10-12 08:59:36 --> Controller Class Initialized
DEBUG - 2016-10-12 08:59:36 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 08:59:36 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 08:59:36 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 08:59:36 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 08:59:36 --> Final output sent to browser
DEBUG - 2016-10-12 08:59:36 --> Total execution time: 0.0459
INFO - 2016-10-12 08:59:37 --> Config Class Initialized
INFO - 2016-10-12 08:59:37 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:59:37 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:59:37 --> Utf8 Class Initialized
INFO - 2016-10-12 08:59:37 --> URI Class Initialized
INFO - 2016-10-12 08:59:37 --> Router Class Initialized
INFO - 2016-10-12 08:59:37 --> Output Class Initialized
INFO - 2016-10-12 08:59:37 --> Security Class Initialized
DEBUG - 2016-10-12 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:59:37 --> Input Class Initialized
INFO - 2016-10-12 08:59:37 --> Language Class Initialized
ERROR - 2016-10-12 08:59:37 --> 404 Page Not Found: /index
INFO - 2016-10-12 08:59:37 --> Config Class Initialized
INFO - 2016-10-12 08:59:37 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:59:37 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:59:37 --> Utf8 Class Initialized
INFO - 2016-10-12 08:59:37 --> URI Class Initialized
INFO - 2016-10-12 08:59:37 --> Router Class Initialized
INFO - 2016-10-12 08:59:37 --> Output Class Initialized
INFO - 2016-10-12 08:59:37 --> Security Class Initialized
DEBUG - 2016-10-12 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:59:37 --> Input Class Initialized
INFO - 2016-10-12 08:59:37 --> Language Class Initialized
INFO - 2016-10-12 08:59:37 --> Language Class Initialized
INFO - 2016-10-12 08:59:37 --> Config Class Initialized
INFO - 2016-10-12 08:59:37 --> Loader Class Initialized
INFO - 2016-10-12 08:59:37 --> Helper loaded: common_helper
INFO - 2016-10-12 08:59:37 --> Helper loaded: url_helper
INFO - 2016-10-12 08:59:37 --> Database Driver Class Initialized
INFO - 2016-10-12 08:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:59:37 --> Parser Class Initialized
INFO - 2016-10-12 08:59:37 --> Controller Class Initialized
DEBUG - 2016-10-12 08:59:37 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:59:37 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:59:37 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:37 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:59:37 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:37 --> Pagination Class Initialized
DEBUG - 2016-10-12 08:59:37 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 08:59:37 --> Final output sent to browser
DEBUG - 2016-10-12 08:59:37 --> Total execution time: 0.0346
INFO - 2016-10-12 08:59:44 --> Config Class Initialized
INFO - 2016-10-12 08:59:44 --> Hooks Class Initialized
DEBUG - 2016-10-12 08:59:44 --> UTF-8 Support Enabled
INFO - 2016-10-12 08:59:44 --> Utf8 Class Initialized
INFO - 2016-10-12 08:59:44 --> URI Class Initialized
INFO - 2016-10-12 08:59:44 --> Router Class Initialized
INFO - 2016-10-12 08:59:44 --> Output Class Initialized
INFO - 2016-10-12 08:59:44 --> Security Class Initialized
DEBUG - 2016-10-12 08:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 08:59:44 --> Input Class Initialized
INFO - 2016-10-12 08:59:44 --> Language Class Initialized
INFO - 2016-10-12 08:59:44 --> Language Class Initialized
INFO - 2016-10-12 08:59:44 --> Config Class Initialized
INFO - 2016-10-12 08:59:44 --> Loader Class Initialized
INFO - 2016-10-12 08:59:44 --> Helper loaded: common_helper
INFO - 2016-10-12 08:59:44 --> Helper loaded: url_helper
INFO - 2016-10-12 08:59:44 --> Database Driver Class Initialized
INFO - 2016-10-12 08:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 08:59:44 --> Parser Class Initialized
INFO - 2016-10-12 08:59:44 --> Controller Class Initialized
DEBUG - 2016-10-12 08:59:44 --> Servers MX_Controller Initialized
INFO - 2016-10-12 08:59:44 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 08:59:44 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 08:59:44 --> Model Class Initialized
DEBUG - 2016-10-12 08:59:44 --> Pagination Class Initialized
DEBUG - 2016-10-12 08:59:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 08:59:44 --> Final output sent to browser
DEBUG - 2016-10-12 08:59:44 --> Total execution time: 0.0582
INFO - 2016-10-12 09:01:16 --> Config Class Initialized
INFO - 2016-10-12 09:01:16 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:16 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:16 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:16 --> URI Class Initialized
INFO - 2016-10-12 09:01:16 --> Router Class Initialized
INFO - 2016-10-12 09:01:16 --> Output Class Initialized
INFO - 2016-10-12 09:01:16 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:16 --> Input Class Initialized
INFO - 2016-10-12 09:01:16 --> Language Class Initialized
INFO - 2016-10-12 09:01:16 --> Language Class Initialized
INFO - 2016-10-12 09:01:16 --> Config Class Initialized
INFO - 2016-10-12 09:01:16 --> Loader Class Initialized
INFO - 2016-10-12 09:01:16 --> Helper loaded: common_helper
INFO - 2016-10-12 09:01:16 --> Helper loaded: url_helper
INFO - 2016-10-12 09:01:16 --> Database Driver Class Initialized
INFO - 2016-10-12 09:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:01:16 --> Parser Class Initialized
INFO - 2016-10-12 09:01:16 --> Controller Class Initialized
DEBUG - 2016-10-12 09:01:16 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 09:01:16 --> Config Class Initialized
INFO - 2016-10-12 09:01:16 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:16 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:16 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:16 --> URI Class Initialized
INFO - 2016-10-12 09:01:16 --> Router Class Initialized
INFO - 2016-10-12 09:01:16 --> Output Class Initialized
INFO - 2016-10-12 09:01:16 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:16 --> Input Class Initialized
INFO - 2016-10-12 09:01:16 --> Language Class Initialized
INFO - 2016-10-12 09:01:16 --> Language Class Initialized
INFO - 2016-10-12 09:01:16 --> Config Class Initialized
INFO - 2016-10-12 09:01:16 --> Loader Class Initialized
INFO - 2016-10-12 09:01:16 --> Helper loaded: common_helper
INFO - 2016-10-12 09:01:16 --> Helper loaded: url_helper
INFO - 2016-10-12 09:01:16 --> Database Driver Class Initialized
INFO - 2016-10-12 09:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:01:16 --> Parser Class Initialized
INFO - 2016-10-12 09:01:16 --> Controller Class Initialized
DEBUG - 2016-10-12 09:01:16 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 09:01:16 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:01:16 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:16 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-12 09:01:16 --> Final output sent to browser
DEBUG - 2016-10-12 09:01:16 --> Total execution time: 0.0397
INFO - 2016-10-12 09:01:18 --> Config Class Initialized
INFO - 2016-10-12 09:01:18 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:18 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:18 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:18 --> URI Class Initialized
INFO - 2016-10-12 09:01:18 --> Router Class Initialized
INFO - 2016-10-12 09:01:18 --> Output Class Initialized
INFO - 2016-10-12 09:01:18 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:18 --> Input Class Initialized
INFO - 2016-10-12 09:01:18 --> Language Class Initialized
INFO - 2016-10-12 09:01:18 --> Language Class Initialized
INFO - 2016-10-12 09:01:18 --> Config Class Initialized
INFO - 2016-10-12 09:01:18 --> Loader Class Initialized
INFO - 2016-10-12 09:01:18 --> Helper loaded: common_helper
INFO - 2016-10-12 09:01:18 --> Helper loaded: url_helper
INFO - 2016-10-12 09:01:18 --> Database Driver Class Initialized
INFO - 2016-10-12 09:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:01:18 --> Parser Class Initialized
INFO - 2016-10-12 09:01:18 --> Controller Class Initialized
DEBUG - 2016-10-12 09:01:18 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 09:01:18 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:01:18 --> Model Class Initialized
INFO - 2016-10-12 09:01:18 --> Final output sent to browser
DEBUG - 2016-10-12 09:01:18 --> Total execution time: 0.0433
INFO - 2016-10-12 09:01:18 --> Config Class Initialized
INFO - 2016-10-12 09:01:18 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:18 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:18 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:18 --> URI Class Initialized
INFO - 2016-10-12 09:01:18 --> Router Class Initialized
INFO - 2016-10-12 09:01:18 --> Output Class Initialized
INFO - 2016-10-12 09:01:18 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:18 --> Input Class Initialized
INFO - 2016-10-12 09:01:18 --> Language Class Initialized
INFO - 2016-10-12 09:01:18 --> Language Class Initialized
INFO - 2016-10-12 09:01:18 --> Config Class Initialized
INFO - 2016-10-12 09:01:18 --> Loader Class Initialized
INFO - 2016-10-12 09:01:18 --> Helper loaded: common_helper
INFO - 2016-10-12 09:01:18 --> Helper loaded: url_helper
INFO - 2016-10-12 09:01:18 --> Database Driver Class Initialized
INFO - 2016-10-12 09:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:01:18 --> Parser Class Initialized
INFO - 2016-10-12 09:01:18 --> Controller Class Initialized
DEBUG - 2016-10-12 09:01:18 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 09:01:18 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:01:18 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-12 09:01:18 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:01:18 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 09:01:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:01:18 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:01:18 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 09:01:18 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 09:01:18 --> Final output sent to browser
DEBUG - 2016-10-12 09:01:18 --> Total execution time: 0.0484
INFO - 2016-10-12 09:01:19 --> Config Class Initialized
INFO - 2016-10-12 09:01:19 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:19 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:19 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:19 --> URI Class Initialized
INFO - 2016-10-12 09:01:19 --> Router Class Initialized
INFO - 2016-10-12 09:01:19 --> Output Class Initialized
INFO - 2016-10-12 09:01:19 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:19 --> Input Class Initialized
INFO - 2016-10-12 09:01:19 --> Language Class Initialized
ERROR - 2016-10-12 09:01:19 --> 404 Page Not Found: /index
INFO - 2016-10-12 09:01:33 --> Config Class Initialized
INFO - 2016-10-12 09:01:33 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:33 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:33 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:33 --> URI Class Initialized
INFO - 2016-10-12 09:01:33 --> Router Class Initialized
INFO - 2016-10-12 09:01:33 --> Output Class Initialized
INFO - 2016-10-12 09:01:33 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:33 --> Input Class Initialized
INFO - 2016-10-12 09:01:33 --> Language Class Initialized
ERROR - 2016-10-12 09:01:33 --> 404 Page Not Found: /index
INFO - 2016-10-12 09:01:34 --> Config Class Initialized
INFO - 2016-10-12 09:01:34 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:34 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:34 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:34 --> URI Class Initialized
INFO - 2016-10-12 09:01:34 --> Router Class Initialized
INFO - 2016-10-12 09:01:34 --> Output Class Initialized
INFO - 2016-10-12 09:01:34 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:34 --> Input Class Initialized
INFO - 2016-10-12 09:01:34 --> Language Class Initialized
ERROR - 2016-10-12 09:01:34 --> 404 Page Not Found: /index
INFO - 2016-10-12 09:01:35 --> Config Class Initialized
INFO - 2016-10-12 09:01:35 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:35 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:35 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:35 --> URI Class Initialized
INFO - 2016-10-12 09:01:35 --> Router Class Initialized
INFO - 2016-10-12 09:01:35 --> Output Class Initialized
INFO - 2016-10-12 09:01:35 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:35 --> Input Class Initialized
INFO - 2016-10-12 09:01:35 --> Language Class Initialized
INFO - 2016-10-12 09:01:35 --> Language Class Initialized
INFO - 2016-10-12 09:01:35 --> Config Class Initialized
INFO - 2016-10-12 09:01:35 --> Loader Class Initialized
INFO - 2016-10-12 09:01:35 --> Helper loaded: common_helper
INFO - 2016-10-12 09:01:35 --> Helper loaded: url_helper
INFO - 2016-10-12 09:01:35 --> Database Driver Class Initialized
INFO - 2016-10-12 09:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:01:35 --> Parser Class Initialized
INFO - 2016-10-12 09:01:35 --> Controller Class Initialized
DEBUG - 2016-10-12 09:01:35 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 09:01:35 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:01:35 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-12 09:01:35 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:01:35 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 09:01:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:01:35 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:01:35 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 09:01:35 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 09:01:35 --> Final output sent to browser
DEBUG - 2016-10-12 09:01:35 --> Total execution time: 0.0559
INFO - 2016-10-12 09:01:47 --> Config Class Initialized
INFO - 2016-10-12 09:01:47 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:47 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:47 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:47 --> URI Class Initialized
INFO - 2016-10-12 09:01:47 --> Router Class Initialized
INFO - 2016-10-12 09:01:47 --> Output Class Initialized
INFO - 2016-10-12 09:01:47 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:47 --> Input Class Initialized
INFO - 2016-10-12 09:01:47 --> Language Class Initialized
INFO - 2016-10-12 09:01:47 --> Language Class Initialized
INFO - 2016-10-12 09:01:47 --> Config Class Initialized
INFO - 2016-10-12 09:01:47 --> Loader Class Initialized
INFO - 2016-10-12 09:01:47 --> Helper loaded: common_helper
INFO - 2016-10-12 09:01:47 --> Helper loaded: url_helper
INFO - 2016-10-12 09:01:47 --> Database Driver Class Initialized
INFO - 2016-10-12 09:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:01:47 --> Parser Class Initialized
INFO - 2016-10-12 09:01:47 --> Controller Class Initialized
DEBUG - 2016-10-12 09:01:47 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:01:47 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:01:47 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:01:47 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:47 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:01:47 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:01:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:01:47 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:01:47 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-12 09:01:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 09:01:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 09:01:47 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 09:01:47 --> Final output sent to browser
DEBUG - 2016-10-12 09:01:47 --> Total execution time: 0.0559
INFO - 2016-10-12 09:01:48 --> Config Class Initialized
INFO - 2016-10-12 09:01:48 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:48 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:48 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:48 --> URI Class Initialized
INFO - 2016-10-12 09:01:48 --> Router Class Initialized
INFO - 2016-10-12 09:01:48 --> Output Class Initialized
INFO - 2016-10-12 09:01:48 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:48 --> Input Class Initialized
INFO - 2016-10-12 09:01:48 --> Language Class Initialized
ERROR - 2016-10-12 09:01:48 --> 404 Page Not Found: /index
INFO - 2016-10-12 09:01:48 --> Config Class Initialized
INFO - 2016-10-12 09:01:48 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:48 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:48 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:48 --> URI Class Initialized
INFO - 2016-10-12 09:01:48 --> Router Class Initialized
INFO - 2016-10-12 09:01:48 --> Output Class Initialized
INFO - 2016-10-12 09:01:48 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:48 --> Input Class Initialized
INFO - 2016-10-12 09:01:48 --> Language Class Initialized
INFO - 2016-10-12 09:01:48 --> Language Class Initialized
INFO - 2016-10-12 09:01:48 --> Config Class Initialized
INFO - 2016-10-12 09:01:48 --> Loader Class Initialized
INFO - 2016-10-12 09:01:48 --> Helper loaded: common_helper
INFO - 2016-10-12 09:01:48 --> Helper loaded: url_helper
INFO - 2016-10-12 09:01:48 --> Database Driver Class Initialized
INFO - 2016-10-12 09:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:01:48 --> Parser Class Initialized
INFO - 2016-10-12 09:01:48 --> Controller Class Initialized
DEBUG - 2016-10-12 09:01:48 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:01:48 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:01:48 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:01:48 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:48 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:01:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:01:48 --> Final output sent to browser
DEBUG - 2016-10-12 09:01:48 --> Total execution time: 0.0437
INFO - 2016-10-12 09:01:49 --> Config Class Initialized
INFO - 2016-10-12 09:01:49 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:01:49 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:01:49 --> Utf8 Class Initialized
INFO - 2016-10-12 09:01:49 --> URI Class Initialized
INFO - 2016-10-12 09:01:49 --> Router Class Initialized
INFO - 2016-10-12 09:01:49 --> Output Class Initialized
INFO - 2016-10-12 09:01:49 --> Security Class Initialized
DEBUG - 2016-10-12 09:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:01:49 --> Input Class Initialized
INFO - 2016-10-12 09:01:49 --> Language Class Initialized
INFO - 2016-10-12 09:01:49 --> Language Class Initialized
INFO - 2016-10-12 09:01:49 --> Config Class Initialized
INFO - 2016-10-12 09:01:49 --> Loader Class Initialized
INFO - 2016-10-12 09:01:49 --> Helper loaded: common_helper
INFO - 2016-10-12 09:01:49 --> Helper loaded: url_helper
INFO - 2016-10-12 09:01:49 --> Database Driver Class Initialized
INFO - 2016-10-12 09:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:01:49 --> Parser Class Initialized
INFO - 2016-10-12 09:01:49 --> Controller Class Initialized
DEBUG - 2016-10-12 09:01:49 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:01:49 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:01:49 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:01:49 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:01:49 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:01:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:01:49 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:01:49 --> Model Class Initialized
DEBUG - 2016-10-12 09:01:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-12 09:01:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 09:01:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 09:01:49 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 09:01:49 --> Final output sent to browser
DEBUG - 2016-10-12 09:01:49 --> Total execution time: 0.0509
INFO - 2016-10-12 09:02:15 --> Config Class Initialized
INFO - 2016-10-12 09:02:15 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:02:15 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:02:15 --> Utf8 Class Initialized
INFO - 2016-10-12 09:02:15 --> URI Class Initialized
INFO - 2016-10-12 09:02:15 --> Router Class Initialized
INFO - 2016-10-12 09:02:15 --> Output Class Initialized
INFO - 2016-10-12 09:02:15 --> Security Class Initialized
DEBUG - 2016-10-12 09:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:02:15 --> Input Class Initialized
INFO - 2016-10-12 09:02:15 --> Language Class Initialized
INFO - 2016-10-12 09:02:16 --> Language Class Initialized
INFO - 2016-10-12 09:02:16 --> Config Class Initialized
INFO - 2016-10-12 09:02:16 --> Loader Class Initialized
INFO - 2016-10-12 09:02:16 --> Helper loaded: common_helper
INFO - 2016-10-12 09:02:16 --> Helper loaded: url_helper
INFO - 2016-10-12 09:02:16 --> Database Driver Class Initialized
INFO - 2016-10-12 09:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:02:16 --> Parser Class Initialized
INFO - 2016-10-12 09:02:16 --> Controller Class Initialized
DEBUG - 2016-10-12 09:02:16 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:02:16 --> Model Class Initialized
DEBUG - 2016-10-12 09:02:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:02:16 --> Model Class Initialized
DEBUG - 2016-10-12 09:02:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:02:16 --> Model Class Initialized
DEBUG - 2016-10-12 09:02:16 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:02:16 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:02:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:02:16 --> Model Class Initialized
DEBUG - 2016-10-12 09:02:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:02:16 --> Model Class Initialized
ERROR - 2016-10-12 09:02:16 --> Severity: Notice --> Undefined variable: fileName /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php 133
INFO - 2016-10-12 09:04:34 --> Config Class Initialized
INFO - 2016-10-12 09:04:34 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:34 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:34 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:34 --> URI Class Initialized
INFO - 2016-10-12 09:04:34 --> Router Class Initialized
INFO - 2016-10-12 09:04:34 --> Output Class Initialized
INFO - 2016-10-12 09:04:34 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:34 --> Input Class Initialized
INFO - 2016-10-12 09:04:34 --> Language Class Initialized
INFO - 2016-10-12 09:04:34 --> Language Class Initialized
INFO - 2016-10-12 09:04:34 --> Config Class Initialized
INFO - 2016-10-12 09:04:34 --> Loader Class Initialized
INFO - 2016-10-12 09:04:34 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:34 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:34 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:34 --> Parser Class Initialized
INFO - 2016-10-12 09:04:34 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:34 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:34 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:34 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:34 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:34 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:34 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:34 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-12 09:04:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 09:04:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 09:04:34 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 09:04:34 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:34 --> Total execution time: 0.0570
INFO - 2016-10-12 09:04:39 --> Config Class Initialized
INFO - 2016-10-12 09:04:39 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:39 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:39 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:39 --> URI Class Initialized
INFO - 2016-10-12 09:04:39 --> Router Class Initialized
INFO - 2016-10-12 09:04:39 --> Output Class Initialized
INFO - 2016-10-12 09:04:39 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:39 --> Input Class Initialized
INFO - 2016-10-12 09:04:39 --> Language Class Initialized
INFO - 2016-10-12 09:04:39 --> Language Class Initialized
INFO - 2016-10-12 09:04:39 --> Config Class Initialized
INFO - 2016-10-12 09:04:39 --> Loader Class Initialized
INFO - 2016-10-12 09:04:39 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:39 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:39 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:39 --> Parser Class Initialized
INFO - 2016-10-12 09:04:39 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:39 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:39 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:39 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:39 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:39 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:39 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:39 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 09:04:39 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:39 --> Total execution time: 0.0505
INFO - 2016-10-12 09:04:39 --> Config Class Initialized
INFO - 2016-10-12 09:04:39 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:39 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:39 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:39 --> URI Class Initialized
INFO - 2016-10-12 09:04:39 --> Router Class Initialized
INFO - 2016-10-12 09:04:39 --> Output Class Initialized
INFO - 2016-10-12 09:04:39 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:39 --> Input Class Initialized
INFO - 2016-10-12 09:04:39 --> Language Class Initialized
ERROR - 2016-10-12 09:04:39 --> 404 Page Not Found: /index
INFO - 2016-10-12 09:04:39 --> Config Class Initialized
INFO - 2016-10-12 09:04:39 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:39 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:39 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:39 --> URI Class Initialized
INFO - 2016-10-12 09:04:39 --> Router Class Initialized
INFO - 2016-10-12 09:04:39 --> Output Class Initialized
INFO - 2016-10-12 09:04:39 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:39 --> Input Class Initialized
INFO - 2016-10-12 09:04:39 --> Language Class Initialized
INFO - 2016-10-12 09:04:39 --> Language Class Initialized
INFO - 2016-10-12 09:04:39 --> Config Class Initialized
INFO - 2016-10-12 09:04:39 --> Loader Class Initialized
INFO - 2016-10-12 09:04:39 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:39 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:39 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:39 --> Parser Class Initialized
INFO - 2016-10-12 09:04:39 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:39 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:39 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:39 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:39 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:39 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:04:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:39 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:39 --> Total execution time: 0.0375
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:57 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:57 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:57 --> Parser Class Initialized
INFO - 2016-10-12 09:04:57 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:57 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:57 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:57 --> Total execution time: 0.2325
INFO - 2016-10-12 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:57 --> Parser Class Initialized
INFO - 2016-10-12 09:04:57 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:57 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:57 --> Total execution time: 0.2291
INFO - 2016-10-12 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:57 --> Parser Class Initialized
INFO - 2016-10-12 09:04:57 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:57 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:57 --> Total execution time: 0.2761
INFO - 2016-10-12 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:57 --> Parser Class Initialized
INFO - 2016-10-12 09:04:57 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:57 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
INFO - 2016-10-12 09:04:57 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:57 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:57 --> Total execution time: 0.2964
INFO - 2016-10-12 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:57 --> Parser Class Initialized
INFO - 2016-10-12 09:04:57 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:57 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
INFO - 2016-10-12 09:04:57 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:57 --> Total execution time: 0.3182
INFO - 2016-10-12 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:57 --> Parser Class Initialized
INFO - 2016-10-12 09:04:57 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:57 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:57 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:57 --> Total execution time: 0.1827
INFO - 2016-10-12 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:57 --> Parser Class Initialized
INFO - 2016-10-12 09:04:57 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:57 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Loader Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:57 --> Total execution time: 0.1975
INFO - 2016-10-12 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:57 --> Parser Class Initialized
INFO - 2016-10-12 09:04:57 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
INFO - 2016-10-12 09:04:57 --> Hooks Class Initialized
INFO - 2016-10-12 09:04:57 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:57 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:57 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:57 --> URI Class Initialized
INFO - 2016-10-12 09:04:57 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:57 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:57 --> Input Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Language Class Initialized
INFO - 2016-10-12 09:04:57 --> Config Class Initialized
DEBUG - 2016-10-12 09:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:57 --> Model Class Initialized
INFO - 2016-10-12 09:04:57 --> Router Class Initialized
INFO - 2016-10-12 09:04:57 --> Output Class Initialized
INFO - 2016-10-12 09:04:57 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:58 --> Input Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.2128
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Hooks Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:58 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:04:58 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:58 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:58 --> URI Class Initialized
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Router Class Initialized
INFO - 2016-10-12 09:04:58 --> Output Class Initialized
INFO - 2016-10-12 09:04:58 --> Security Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.2039
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:04:58 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:58 --> Input Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:58 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:58 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:58 --> URI Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:58 --> Router Class Initialized
INFO - 2016-10-12 09:04:58 --> Output Class Initialized
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.2201
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Hooks Class Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:58 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:58 --> Input Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:04:58 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:58 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:58 --> URI Class Initialized
INFO - 2016-10-12 09:04:58 --> Router Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.1997
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
INFO - 2016-10-12 09:04:58 --> Output Class Initialized
INFO - 2016-10-12 09:04:58 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:58 --> Input Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Hooks Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.1973
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
DEBUG - 2016-10-12 09:04:58 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:58 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:58 --> URI Class Initialized
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Hooks Class Initialized
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
INFO - 2016-10-12 09:04:58 --> Router Class Initialized
INFO - 2016-10-12 09:04:58 --> Output Class Initialized
INFO - 2016-10-12 09:04:58 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:58 --> Input Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:04:58 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:58 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:58 --> URI Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.1979
INFO - 2016-10-12 09:04:58 --> Router Class Initialized
INFO - 2016-10-12 09:04:58 --> Output Class Initialized
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
INFO - 2016-10-12 09:04:58 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:58 --> Input Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Hooks Class Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
DEBUG - 2016-10-12 09:04:58 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:58 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:58 --> URI Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.2002
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Router Class Initialized
INFO - 2016-10-12 09:04:58 --> Output Class Initialized
INFO - 2016-10-12 09:04:58 --> Security Class Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Hooks Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:58 --> Input Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:04:58 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:58 --> Utf8 Class Initialized
INFO - 2016-10-12 09:04:58 --> URI Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.1977
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:58 --> Router Class Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Output Class Initialized
INFO - 2016-10-12 09:04:58 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:58 --> Input Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:04:58 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:04:58 --> Utf8 Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
INFO - 2016-10-12 09:04:58 --> URI Class Initialized
INFO - 2016-10-12 09:04:58 --> Router Class Initialized
INFO - 2016-10-12 09:04:58 --> Output Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.2078
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
INFO - 2016-10-12 09:04:58 --> Security Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:04:58 --> Input Class Initialized
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.2006
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
INFO - 2016-10-12 09:04:58 --> Language Class Initialized
INFO - 2016-10-12 09:04:58 --> Config Class Initialized
INFO - 2016-10-12 09:04:58 --> Loader Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: common_helper
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
INFO - 2016-10-12 09:04:58 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.1776
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
INFO - 2016-10-12 09:04:58 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.1521
INFO - 2016-10-12 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:04:58 --> Parser Class Initialized
INFO - 2016-10-12 09:04:58 --> Controller Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:04:58 --> Model Class Initialized
DEBUG - 2016-10-12 09:04:58 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:04:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:04:58 --> Final output sent to browser
DEBUG - 2016-10-12 09:04:58 --> Total execution time: 0.1358
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:43 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.2416
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:43 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.2212
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:43 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.2594
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:43 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.3076
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:43 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.3105
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:43 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.1802
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:43 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.2012
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:43 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.2067
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:43 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.2090
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Pagination Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.1964
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Pagination Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.1994
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Pagination Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.2017
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.1993
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:43 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:43 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:43 --> URI Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Pagination Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.2045
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Router Class Initialized
INFO - 2016-10-12 09:05:43 --> Output Class Initialized
INFO - 2016-10-12 09:05:43 --> Security Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Pagination Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.2027
DEBUG - 2016-10-12 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:43 --> Input Class Initialized
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Language Class Initialized
INFO - 2016-10-12 09:05:43 --> Config Class Initialized
INFO - 2016-10-12 09:05:43 --> Loader Class Initialized
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:43 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:43 --> Helper loaded: url_helper
DEBUG - 2016-10-12 09:05:43 --> Pagination Class Initialized
INFO - 2016-10-12 09:05:43 --> Database Driver Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.1768
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.1554
INFO - 2016-10-12 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:43 --> Parser Class Initialized
INFO - 2016-10-12 09:05:43 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:43 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:43 --> Pagination Class Initialized
DEBUG - 2016-10-12 09:05:43 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 09:05:43 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:43 --> Total execution time: 0.1240
INFO - 2016-10-12 09:05:56 --> Config Class Initialized
INFO - 2016-10-12 09:05:56 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:56 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:56 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:56 --> URI Class Initialized
INFO - 2016-10-12 09:05:56 --> Router Class Initialized
INFO - 2016-10-12 09:05:56 --> Output Class Initialized
INFO - 2016-10-12 09:05:56 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:56 --> Input Class Initialized
INFO - 2016-10-12 09:05:56 --> Language Class Initialized
INFO - 2016-10-12 09:05:56 --> Language Class Initialized
INFO - 2016-10-12 09:05:56 --> Config Class Initialized
INFO - 2016-10-12 09:05:56 --> Loader Class Initialized
INFO - 2016-10-12 09:05:56 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:56 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:56 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:56 --> Parser Class Initialized
INFO - 2016-10-12 09:05:56 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:56 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:05:56 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:56 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:05:56 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:05:56 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:56 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 09:05:56 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 09:05:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 09:05:56 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:05:56 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:56 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_updateStatus.php
INFO - 2016-10-12 09:05:56 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:56 --> Total execution time: 0.0523
INFO - 2016-10-12 09:05:59 --> Config Class Initialized
INFO - 2016-10-12 09:05:59 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:05:59 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:05:59 --> Utf8 Class Initialized
INFO - 2016-10-12 09:05:59 --> URI Class Initialized
DEBUG - 2016-10-12 09:05:59 --> No URI present. Default controller set.
INFO - 2016-10-12 09:05:59 --> Router Class Initialized
INFO - 2016-10-12 09:05:59 --> Output Class Initialized
INFO - 2016-10-12 09:05:59 --> Security Class Initialized
DEBUG - 2016-10-12 09:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:05:59 --> Input Class Initialized
INFO - 2016-10-12 09:05:59 --> Language Class Initialized
INFO - 2016-10-12 09:05:59 --> Language Class Initialized
INFO - 2016-10-12 09:05:59 --> Config Class Initialized
INFO - 2016-10-12 09:05:59 --> Loader Class Initialized
INFO - 2016-10-12 09:05:59 --> Helper loaded: common_helper
INFO - 2016-10-12 09:05:59 --> Helper loaded: url_helper
INFO - 2016-10-12 09:05:59 --> Database Driver Class Initialized
INFO - 2016-10-12 09:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:05:59 --> Parser Class Initialized
INFO - 2016-10-12 09:05:59 --> Controller Class Initialized
DEBUG - 2016-10-12 09:05:59 --> Home MX_Controller Initialized
INFO - 2016-10-12 09:05:59 --> Model Class Initialized
DEBUG - 2016-10-12 09:05:59 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 09:05:59 --> Model Class Initialized
ERROR - 2016-10-12 09:05:59 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 09:05:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 09:05:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 09:05:59 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 09:05:59 --> Final output sent to browser
DEBUG - 2016-10-12 09:05:59 --> Total execution time: 0.0430
INFO - 2016-10-12 09:06:08 --> Config Class Initialized
INFO - 2016-10-12 09:06:08 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:06:08 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:06:08 --> Utf8 Class Initialized
INFO - 2016-10-12 09:06:08 --> URI Class Initialized
INFO - 2016-10-12 09:06:08 --> Router Class Initialized
INFO - 2016-10-12 09:06:08 --> Output Class Initialized
INFO - 2016-10-12 09:06:08 --> Security Class Initialized
DEBUG - 2016-10-12 09:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:06:08 --> Input Class Initialized
INFO - 2016-10-12 09:06:08 --> Language Class Initialized
INFO - 2016-10-12 09:06:08 --> Language Class Initialized
INFO - 2016-10-12 09:06:08 --> Config Class Initialized
INFO - 2016-10-12 09:06:08 --> Loader Class Initialized
INFO - 2016-10-12 09:06:08 --> Helper loaded: common_helper
INFO - 2016-10-12 09:06:08 --> Helper loaded: url_helper
INFO - 2016-10-12 09:06:08 --> Database Driver Class Initialized
INFO - 2016-10-12 09:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:06:08 --> Parser Class Initialized
INFO - 2016-10-12 09:06:08 --> Controller Class Initialized
DEBUG - 2016-10-12 09:06:08 --> Home MX_Controller Initialized
INFO - 2016-10-12 09:06:08 --> Model Class Initialized
DEBUG - 2016-10-12 09:06:08 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 09:06:08 --> Model Class Initialized
DEBUG - 2016-10-12 09:06:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-12 09:06:08 --> Content MX_Controller Initialized
DEBUG - 2016-10-12 09:06:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:06:08 --> Model Class Initialized
DEBUG - 2016-10-12 09:06:08 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:06:08 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:06:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-12 09:06:08 --> Slider MX_Controller Initialized
DEBUG - 2016-10-12 09:06:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-12 09:06:08 --> Model Class Initialized
DEBUG - 2016-10-12 09:06:08 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:06:08 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-12 09:06:08 --> Servers MX_Controller Initialized
DEBUG - 2016-10-12 09:06:09 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:06:09 --> Model Class Initialized
DEBUG - 2016-10-12 09:06:09 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-12 09:06:09 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 09:06:09 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 09:06:09 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 09:06:09 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-12 09:06:09 --> Final output sent to browser
DEBUG - 2016-10-12 09:06:09 --> Total execution time: 0.0720
INFO - 2016-10-12 09:06:14 --> Config Class Initialized
INFO - 2016-10-12 09:06:14 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:06:14 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:06:14 --> Utf8 Class Initialized
INFO - 2016-10-12 09:06:14 --> URI Class Initialized
INFO - 2016-10-12 09:06:14 --> Router Class Initialized
INFO - 2016-10-12 09:06:14 --> Output Class Initialized
INFO - 2016-10-12 09:06:14 --> Security Class Initialized
DEBUG - 2016-10-12 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:06:14 --> Input Class Initialized
INFO - 2016-10-12 09:06:14 --> Language Class Initialized
ERROR - 2016-10-12 09:06:14 --> 404 Page Not Found: /index
INFO - 2016-10-12 09:07:14 --> Config Class Initialized
INFO - 2016-10-12 09:07:14 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:07:14 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:07:14 --> Utf8 Class Initialized
INFO - 2016-10-12 09:07:14 --> URI Class Initialized
INFO - 2016-10-12 09:07:14 --> Router Class Initialized
INFO - 2016-10-12 09:07:14 --> Output Class Initialized
INFO - 2016-10-12 09:07:14 --> Security Class Initialized
DEBUG - 2016-10-12 09:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:07:14 --> Input Class Initialized
INFO - 2016-10-12 09:07:14 --> Language Class Initialized
INFO - 2016-10-12 09:07:14 --> Language Class Initialized
INFO - 2016-10-12 09:07:14 --> Config Class Initialized
INFO - 2016-10-12 09:07:14 --> Loader Class Initialized
INFO - 2016-10-12 09:07:14 --> Helper loaded: common_helper
INFO - 2016-10-12 09:07:14 --> Helper loaded: url_helper
INFO - 2016-10-12 09:07:14 --> Database Driver Class Initialized
INFO - 2016-10-12 09:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:07:14 --> Parser Class Initialized
INFO - 2016-10-12 09:07:14 --> Controller Class Initialized
DEBUG - 2016-10-12 09:07:14 --> User MX_Controller Initialized
INFO - 2016-10-12 09:07:14 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:14 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-12 09:07:14 --> Model Class Initialized
INFO - 2016-10-12 09:07:14 --> Helper loaded: cookie_helper
INFO - 2016-10-12 09:07:14 --> Helper loaded: form_helper
DEBUG - 2016-10-12 09:07:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 09:07:14 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:14 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:07:14 --> Model Class Initialized
INFO - 2016-10-12 09:07:14 --> Final output sent to browser
DEBUG - 2016-10-12 09:07:14 --> Total execution time: 0.0982
INFO - 2016-10-12 09:07:16 --> Config Class Initialized
INFO - 2016-10-12 09:07:16 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:07:16 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:07:16 --> Utf8 Class Initialized
INFO - 2016-10-12 09:07:16 --> URI Class Initialized
DEBUG - 2016-10-12 09:07:16 --> No URI present. Default controller set.
INFO - 2016-10-12 09:07:16 --> Router Class Initialized
INFO - 2016-10-12 09:07:16 --> Output Class Initialized
INFO - 2016-10-12 09:07:16 --> Security Class Initialized
DEBUG - 2016-10-12 09:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:07:16 --> Input Class Initialized
INFO - 2016-10-12 09:07:16 --> Language Class Initialized
INFO - 2016-10-12 09:07:16 --> Language Class Initialized
INFO - 2016-10-12 09:07:16 --> Config Class Initialized
INFO - 2016-10-12 09:07:16 --> Loader Class Initialized
INFO - 2016-10-12 09:07:16 --> Helper loaded: common_helper
INFO - 2016-10-12 09:07:16 --> Helper loaded: url_helper
INFO - 2016-10-12 09:07:16 --> Database Driver Class Initialized
INFO - 2016-10-12 09:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:07:16 --> Parser Class Initialized
INFO - 2016-10-12 09:07:16 --> Controller Class Initialized
DEBUG - 2016-10-12 09:07:16 --> Home MX_Controller Initialized
INFO - 2016-10-12 09:07:16 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:16 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 09:07:16 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-12 09:07:16 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 09:07:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 09:07:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 09:07:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 09:07:16 --> Final output sent to browser
DEBUG - 2016-10-12 09:07:16 --> Total execution time: 0.0489
INFO - 2016-10-12 09:07:24 --> Config Class Initialized
INFO - 2016-10-12 09:07:24 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:07:24 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:07:24 --> Utf8 Class Initialized
INFO - 2016-10-12 09:07:24 --> URI Class Initialized
INFO - 2016-10-12 09:07:24 --> Router Class Initialized
INFO - 2016-10-12 09:07:24 --> Output Class Initialized
INFO - 2016-10-12 09:07:24 --> Security Class Initialized
DEBUG - 2016-10-12 09:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:07:24 --> Input Class Initialized
INFO - 2016-10-12 09:07:24 --> Language Class Initialized
INFO - 2016-10-12 09:07:24 --> Language Class Initialized
INFO - 2016-10-12 09:07:24 --> Config Class Initialized
INFO - 2016-10-12 09:07:24 --> Loader Class Initialized
INFO - 2016-10-12 09:07:24 --> Helper loaded: common_helper
INFO - 2016-10-12 09:07:24 --> Helper loaded: url_helper
INFO - 2016-10-12 09:07:24 --> Database Driver Class Initialized
INFO - 2016-10-12 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:07:24 --> Parser Class Initialized
INFO - 2016-10-12 09:07:24 --> Controller Class Initialized
DEBUG - 2016-10-12 09:07:24 --> Home MX_Controller Initialized
INFO - 2016-10-12 09:07:24 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 09:07:24 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-12 09:07:24 --> Content MX_Controller Initialized
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:07:24 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-12 09:07:24 --> Slider MX_Controller Initialized
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-12 09:07:24 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-12 09:07:24 --> Servers MX_Controller Initialized
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:07:24 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-12 09:07:24 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 09:07:24 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-12 09:07:24 --> Final output sent to browser
DEBUG - 2016-10-12 09:07:24 --> Total execution time: 0.0599
INFO - 2016-10-12 09:07:26 --> Config Class Initialized
INFO - 2016-10-12 09:07:26 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:07:26 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:07:26 --> Utf8 Class Initialized
INFO - 2016-10-12 09:07:26 --> URI Class Initialized
INFO - 2016-10-12 09:07:26 --> Router Class Initialized
INFO - 2016-10-12 09:07:26 --> Output Class Initialized
INFO - 2016-10-12 09:07:26 --> Security Class Initialized
DEBUG - 2016-10-12 09:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:07:26 --> Input Class Initialized
INFO - 2016-10-12 09:07:26 --> Language Class Initialized
ERROR - 2016-10-12 09:07:26 --> 404 Page Not Found: /index
INFO - 2016-10-12 09:07:28 --> Config Class Initialized
INFO - 2016-10-12 09:07:28 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:07:28 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:07:28 --> Utf8 Class Initialized
INFO - 2016-10-12 09:07:28 --> URI Class Initialized
INFO - 2016-10-12 09:07:28 --> Router Class Initialized
INFO - 2016-10-12 09:07:28 --> Output Class Initialized
INFO - 2016-10-12 09:07:28 --> Security Class Initialized
DEBUG - 2016-10-12 09:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:07:28 --> Input Class Initialized
INFO - 2016-10-12 09:07:28 --> Language Class Initialized
INFO - 2016-10-12 09:07:28 --> Language Class Initialized
INFO - 2016-10-12 09:07:28 --> Config Class Initialized
INFO - 2016-10-12 09:07:28 --> Loader Class Initialized
INFO - 2016-10-12 09:07:28 --> Helper loaded: common_helper
INFO - 2016-10-12 09:07:28 --> Helper loaded: url_helper
INFO - 2016-10-12 09:07:28 --> Database Driver Class Initialized
INFO - 2016-10-12 09:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:07:28 --> Parser Class Initialized
INFO - 2016-10-12 09:07:28 --> Controller Class Initialized
DEBUG - 2016-10-12 09:07:28 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:07:28 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:28 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:07:28 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:07:28 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:28 --> File already loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:07:28 --> Model Class Initialized
INFO - 2016-10-12 09:07:28 --> Config Class Initialized
INFO - 2016-10-12 09:07:28 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:07:28 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:07:28 --> Utf8 Class Initialized
INFO - 2016-10-12 09:07:28 --> URI Class Initialized
INFO - 2016-10-12 09:07:28 --> Router Class Initialized
INFO - 2016-10-12 09:07:28 --> Output Class Initialized
INFO - 2016-10-12 09:07:28 --> Security Class Initialized
DEBUG - 2016-10-12 09:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:07:28 --> Input Class Initialized
INFO - 2016-10-12 09:07:28 --> Language Class Initialized
INFO - 2016-10-12 09:07:28 --> Language Class Initialized
INFO - 2016-10-12 09:07:29 --> Config Class Initialized
INFO - 2016-10-12 09:07:29 --> Loader Class Initialized
INFO - 2016-10-12 09:07:29 --> Helper loaded: common_helper
INFO - 2016-10-12 09:07:29 --> Helper loaded: url_helper
INFO - 2016-10-12 09:07:29 --> Database Driver Class Initialized
INFO - 2016-10-12 09:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:07:29 --> Parser Class Initialized
INFO - 2016-10-12 09:07:29 --> Controller Class Initialized
DEBUG - 2016-10-12 09:07:29 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:07:29 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:29 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:07:29 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:29 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:07:29 --> Model Class Initialized
INFO - 2016-10-12 09:07:48 --> Config Class Initialized
INFO - 2016-10-12 09:07:48 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:07:48 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:07:48 --> Utf8 Class Initialized
INFO - 2016-10-12 09:07:48 --> URI Class Initialized
INFO - 2016-10-12 09:07:48 --> Router Class Initialized
INFO - 2016-10-12 09:07:49 --> Output Class Initialized
INFO - 2016-10-12 09:07:49 --> Security Class Initialized
DEBUG - 2016-10-12 09:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:07:49 --> Input Class Initialized
INFO - 2016-10-12 09:07:49 --> Language Class Initialized
INFO - 2016-10-12 09:07:49 --> Language Class Initialized
INFO - 2016-10-12 09:07:49 --> Config Class Initialized
INFO - 2016-10-12 09:07:49 --> Loader Class Initialized
INFO - 2016-10-12 09:07:49 --> Helper loaded: common_helper
INFO - 2016-10-12 09:07:49 --> Helper loaded: url_helper
INFO - 2016-10-12 09:07:49 --> Database Driver Class Initialized
INFO - 2016-10-12 09:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:07:49 --> Parser Class Initialized
INFO - 2016-10-12 09:07:49 --> Controller Class Initialized
DEBUG - 2016-10-12 09:07:49 --> Servers MX_Controller Initialized
INFO - 2016-10-12 09:07:49 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:07:49 --> Model Class Initialized
DEBUG - 2016-10-12 09:07:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:07:49 --> Model Class Initialized
ERROR - 2016-10-12 09:08:49 --> Severity: Warning --> file_get_contents(http://103.27.60.212:8888/api_new_account.php?account=pullup_858e630f86eadcb72dbd610c95bfdf04&sid=1): failed to open stream: Connection timed out /home/dolongpk/public_html/application/modules/servers/controllers/Servers.php 397
ERROR - 2016-10-12 09:08:49 --> Query error: MySQL server has gone away - Invalid query: SELECT * from admin_nqt_settings WHERE slug = 'is_local'
INFO - 2016-10-12 09:08:49 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-12 09:08:49 --> Config Class Initialized
INFO - 2016-10-12 09:08:49 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:08:49 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:08:49 --> Utf8 Class Initialized
INFO - 2016-10-12 09:08:49 --> URI Class Initialized
INFO - 2016-10-12 09:08:49 --> Router Class Initialized
INFO - 2016-10-12 09:08:49 --> Output Class Initialized
INFO - 2016-10-12 09:08:49 --> Security Class Initialized
DEBUG - 2016-10-12 09:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:08:49 --> Input Class Initialized
INFO - 2016-10-12 09:08:49 --> Language Class Initialized
ERROR - 2016-10-12 09:08:49 --> 404 Page Not Found: /index
INFO - 2016-10-12 09:22:20 --> Config Class Initialized
INFO - 2016-10-12 09:22:20 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:22:20 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:22:20 --> Utf8 Class Initialized
INFO - 2016-10-12 09:22:20 --> URI Class Initialized
DEBUG - 2016-10-12 09:22:20 --> No URI present. Default controller set.
INFO - 2016-10-12 09:22:20 --> Router Class Initialized
INFO - 2016-10-12 09:22:20 --> Output Class Initialized
INFO - 2016-10-12 09:22:20 --> Security Class Initialized
DEBUG - 2016-10-12 09:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:22:20 --> Input Class Initialized
INFO - 2016-10-12 09:22:20 --> Language Class Initialized
INFO - 2016-10-12 09:22:20 --> Language Class Initialized
INFO - 2016-10-12 09:22:20 --> Config Class Initialized
INFO - 2016-10-12 09:22:20 --> Loader Class Initialized
INFO - 2016-10-12 09:22:20 --> Helper loaded: common_helper
INFO - 2016-10-12 09:22:20 --> Helper loaded: url_helper
INFO - 2016-10-12 09:22:20 --> Database Driver Class Initialized
INFO - 2016-10-12 09:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:22:20 --> Parser Class Initialized
INFO - 2016-10-12 09:22:20 --> Controller Class Initialized
DEBUG - 2016-10-12 09:22:20 --> Home MX_Controller Initialized
INFO - 2016-10-12 09:22:20 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:20 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 09:22:20 --> Model Class Initialized
ERROR - 2016-10-12 09:22:20 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 09:22:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 09:22:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 09:22:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 09:22:20 --> Final output sent to browser
DEBUG - 2016-10-12 09:22:20 --> Total execution time: 0.0424
INFO - 2016-10-12 09:22:36 --> Config Class Initialized
INFO - 2016-10-12 09:22:36 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:22:36 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:22:36 --> Utf8 Class Initialized
INFO - 2016-10-12 09:22:36 --> URI Class Initialized
INFO - 2016-10-12 09:22:36 --> Router Class Initialized
INFO - 2016-10-12 09:22:36 --> Output Class Initialized
INFO - 2016-10-12 09:22:36 --> Security Class Initialized
DEBUG - 2016-10-12 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:22:36 --> Input Class Initialized
INFO - 2016-10-12 09:22:36 --> Language Class Initialized
INFO - 2016-10-12 09:22:36 --> Language Class Initialized
INFO - 2016-10-12 09:22:36 --> Config Class Initialized
INFO - 2016-10-12 09:22:36 --> Loader Class Initialized
INFO - 2016-10-12 09:22:36 --> Helper loaded: common_helper
INFO - 2016-10-12 09:22:36 --> Helper loaded: url_helper
INFO - 2016-10-12 09:22:36 --> Database Driver Class Initialized
INFO - 2016-10-12 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:22:36 --> Parser Class Initialized
INFO - 2016-10-12 09:22:36 --> Controller Class Initialized
DEBUG - 2016-10-12 09:22:36 --> Home MX_Controller Initialized
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-12 09:22:36 --> Content MX_Controller Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-12 09:22:36 --> Slider MX_Controller Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-12 09:22:36 --> Servers MX_Controller Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-12 09:22:36 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-12 09:22:36 --> Final output sent to browser
DEBUG - 2016-10-12 09:22:36 --> Total execution time: 0.0779
INFO - 2016-10-12 09:22:36 --> Config Class Initialized
INFO - 2016-10-12 09:22:36 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:22:36 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:22:36 --> Utf8 Class Initialized
INFO - 2016-10-12 09:22:36 --> URI Class Initialized
INFO - 2016-10-12 09:22:36 --> Router Class Initialized
INFO - 2016-10-12 09:22:36 --> Output Class Initialized
INFO - 2016-10-12 09:22:36 --> Security Class Initialized
DEBUG - 2016-10-12 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:22:36 --> Input Class Initialized
INFO - 2016-10-12 09:22:36 --> Language Class Initialized
INFO - 2016-10-12 09:22:36 --> Language Class Initialized
INFO - 2016-10-12 09:22:36 --> Config Class Initialized
INFO - 2016-10-12 09:22:36 --> Loader Class Initialized
INFO - 2016-10-12 09:22:36 --> Helper loaded: common_helper
INFO - 2016-10-12 09:22:36 --> Helper loaded: url_helper
INFO - 2016-10-12 09:22:36 --> Database Driver Class Initialized
INFO - 2016-10-12 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 09:22:36 --> Parser Class Initialized
INFO - 2016-10-12 09:22:36 --> Controller Class Initialized
DEBUG - 2016-10-12 09:22:36 --> Home MX_Controller Initialized
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-12 09:22:36 --> Content MX_Controller Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-12 09:22:36 --> Slider MX_Controller Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-12 09:22:36 --> Servers MX_Controller Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 09:22:36 --> Model Class Initialized
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-12 09:22:36 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 09:22:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-12 09:22:36 --> Final output sent to browser
DEBUG - 2016-10-12 09:22:36 --> Total execution time: 0.0632
INFO - 2016-10-12 09:22:37 --> Config Class Initialized
INFO - 2016-10-12 09:22:37 --> Hooks Class Initialized
DEBUG - 2016-10-12 09:22:37 --> UTF-8 Support Enabled
INFO - 2016-10-12 09:22:37 --> Utf8 Class Initialized
INFO - 2016-10-12 09:22:37 --> URI Class Initialized
INFO - 2016-10-12 09:22:37 --> Router Class Initialized
INFO - 2016-10-12 09:22:37 --> Output Class Initialized
INFO - 2016-10-12 09:22:37 --> Security Class Initialized
DEBUG - 2016-10-12 09:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 09:22:37 --> Input Class Initialized
INFO - 2016-10-12 09:22:37 --> Language Class Initialized
ERROR - 2016-10-12 09:22:37 --> 404 Page Not Found: /index
INFO - 2016-10-12 10:03:19 --> Config Class Initialized
INFO - 2016-10-12 10:03:19 --> Hooks Class Initialized
DEBUG - 2016-10-12 10:03:19 --> UTF-8 Support Enabled
INFO - 2016-10-12 10:03:19 --> Utf8 Class Initialized
INFO - 2016-10-12 10:03:19 --> URI Class Initialized
INFO - 2016-10-12 10:03:19 --> Router Class Initialized
INFO - 2016-10-12 10:03:19 --> Output Class Initialized
INFO - 2016-10-12 10:03:19 --> Security Class Initialized
DEBUG - 2016-10-12 10:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 10:03:19 --> Input Class Initialized
INFO - 2016-10-12 10:03:19 --> Language Class Initialized
ERROR - 2016-10-12 10:03:19 --> 404 Page Not Found: /index
INFO - 2016-10-12 10:03:33 --> Config Class Initialized
INFO - 2016-10-12 10:03:33 --> Hooks Class Initialized
DEBUG - 2016-10-12 10:03:33 --> UTF-8 Support Enabled
INFO - 2016-10-12 10:03:33 --> Utf8 Class Initialized
INFO - 2016-10-12 10:03:33 --> URI Class Initialized
DEBUG - 2016-10-12 10:03:33 --> No URI present. Default controller set.
INFO - 2016-10-12 10:03:33 --> Router Class Initialized
INFO - 2016-10-12 10:03:33 --> Output Class Initialized
INFO - 2016-10-12 10:03:33 --> Security Class Initialized
DEBUG - 2016-10-12 10:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 10:03:33 --> Input Class Initialized
INFO - 2016-10-12 10:03:33 --> Language Class Initialized
INFO - 2016-10-12 10:03:33 --> Language Class Initialized
INFO - 2016-10-12 10:03:33 --> Config Class Initialized
INFO - 2016-10-12 10:03:33 --> Loader Class Initialized
INFO - 2016-10-12 10:03:33 --> Helper loaded: common_helper
INFO - 2016-10-12 10:03:33 --> Helper loaded: url_helper
INFO - 2016-10-12 10:03:33 --> Database Driver Class Initialized
INFO - 2016-10-12 10:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 10:03:33 --> Parser Class Initialized
INFO - 2016-10-12 10:03:33 --> Controller Class Initialized
DEBUG - 2016-10-12 10:03:33 --> Home MX_Controller Initialized
INFO - 2016-10-12 10:03:33 --> Model Class Initialized
DEBUG - 2016-10-12 10:03:33 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 10:03:33 --> Model Class Initialized
DEBUG - 2016-10-12 10:03:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-12 10:03:33 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 10:03:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 10:03:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 10:03:33 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 10:03:33 --> Final output sent to browser
DEBUG - 2016-10-12 10:03:33 --> Total execution time: 0.0462
INFO - 2016-10-12 10:15:48 --> Config Class Initialized
INFO - 2016-10-12 10:15:48 --> Hooks Class Initialized
DEBUG - 2016-10-12 10:15:48 --> UTF-8 Support Enabled
INFO - 2016-10-12 10:15:48 --> Utf8 Class Initialized
INFO - 2016-10-12 10:15:48 --> URI Class Initialized
INFO - 2016-10-12 10:15:48 --> Router Class Initialized
INFO - 2016-10-12 10:15:48 --> Output Class Initialized
INFO - 2016-10-12 10:15:48 --> Security Class Initialized
DEBUG - 2016-10-12 10:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 10:15:48 --> Input Class Initialized
INFO - 2016-10-12 10:15:48 --> Language Class Initialized
ERROR - 2016-10-12 10:15:48 --> 404 Page Not Found: /index
INFO - 2016-10-12 10:54:38 --> Config Class Initialized
INFO - 2016-10-12 10:54:38 --> Hooks Class Initialized
DEBUG - 2016-10-12 10:54:38 --> UTF-8 Support Enabled
INFO - 2016-10-12 10:54:38 --> Utf8 Class Initialized
INFO - 2016-10-12 10:54:38 --> URI Class Initialized
DEBUG - 2016-10-12 10:54:38 --> No URI present. Default controller set.
INFO - 2016-10-12 10:54:38 --> Router Class Initialized
INFO - 2016-10-12 10:54:38 --> Output Class Initialized
INFO - 2016-10-12 10:54:38 --> Security Class Initialized
DEBUG - 2016-10-12 10:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 10:54:38 --> Input Class Initialized
INFO - 2016-10-12 10:54:38 --> Language Class Initialized
INFO - 2016-10-12 10:54:38 --> Language Class Initialized
INFO - 2016-10-12 10:54:38 --> Config Class Initialized
INFO - 2016-10-12 10:54:38 --> Loader Class Initialized
INFO - 2016-10-12 10:54:38 --> Helper loaded: common_helper
INFO - 2016-10-12 10:54:38 --> Helper loaded: url_helper
INFO - 2016-10-12 10:54:38 --> Database Driver Class Initialized
INFO - 2016-10-12 10:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 10:54:38 --> Parser Class Initialized
INFO - 2016-10-12 10:54:38 --> Controller Class Initialized
DEBUG - 2016-10-12 10:54:38 --> Home MX_Controller Initialized
INFO - 2016-10-12 10:54:38 --> Model Class Initialized
DEBUG - 2016-10-12 10:54:38 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 10:54:38 --> Model Class Initialized
ERROR - 2016-10-12 10:54:38 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 10:54:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 10:54:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 10:54:38 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 10:54:38 --> Final output sent to browser
DEBUG - 2016-10-12 10:54:38 --> Total execution time: 0.0427
INFO - 2016-10-12 10:56:21 --> Config Class Initialized
INFO - 2016-10-12 10:56:21 --> Hooks Class Initialized
DEBUG - 2016-10-12 10:56:21 --> UTF-8 Support Enabled
INFO - 2016-10-12 10:56:21 --> Utf8 Class Initialized
INFO - 2016-10-12 10:56:21 --> URI Class Initialized
DEBUG - 2016-10-12 10:56:21 --> No URI present. Default controller set.
INFO - 2016-10-12 10:56:21 --> Router Class Initialized
INFO - 2016-10-12 10:56:21 --> Output Class Initialized
INFO - 2016-10-12 10:56:21 --> Security Class Initialized
DEBUG - 2016-10-12 10:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 10:56:21 --> Input Class Initialized
INFO - 2016-10-12 10:56:21 --> Language Class Initialized
INFO - 2016-10-12 10:56:21 --> Language Class Initialized
INFO - 2016-10-12 10:56:21 --> Config Class Initialized
INFO - 2016-10-12 10:56:21 --> Loader Class Initialized
INFO - 2016-10-12 10:56:21 --> Helper loaded: common_helper
INFO - 2016-10-12 10:56:21 --> Helper loaded: url_helper
INFO - 2016-10-12 10:56:21 --> Database Driver Class Initialized
INFO - 2016-10-12 10:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 10:56:21 --> Parser Class Initialized
INFO - 2016-10-12 10:56:21 --> Controller Class Initialized
DEBUG - 2016-10-12 10:56:21 --> Home MX_Controller Initialized
INFO - 2016-10-12 10:56:21 --> Model Class Initialized
DEBUG - 2016-10-12 10:56:21 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 10:56:21 --> Model Class Initialized
ERROR - 2016-10-12 10:56:21 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 10:56:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 10:56:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 10:56:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 10:56:21 --> Final output sent to browser
DEBUG - 2016-10-12 10:56:21 --> Total execution time: 0.0415
INFO - 2016-10-12 13:37:48 --> Config Class Initialized
INFO - 2016-10-12 13:37:48 --> Hooks Class Initialized
DEBUG - 2016-10-12 13:37:48 --> UTF-8 Support Enabled
INFO - 2016-10-12 13:37:48 --> Utf8 Class Initialized
INFO - 2016-10-12 13:37:48 --> URI Class Initialized
INFO - 2016-10-12 13:37:48 --> Router Class Initialized
INFO - 2016-10-12 13:37:48 --> Output Class Initialized
INFO - 2016-10-12 13:37:48 --> Security Class Initialized
DEBUG - 2016-10-12 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 13:37:48 --> Input Class Initialized
INFO - 2016-10-12 13:37:48 --> Language Class Initialized
ERROR - 2016-10-12 13:37:48 --> 404 Page Not Found: /index
INFO - 2016-10-12 13:37:48 --> Config Class Initialized
INFO - 2016-10-12 13:37:48 --> Hooks Class Initialized
DEBUG - 2016-10-12 13:37:48 --> UTF-8 Support Enabled
INFO - 2016-10-12 13:37:48 --> Utf8 Class Initialized
INFO - 2016-10-12 13:37:48 --> URI Class Initialized
INFO - 2016-10-12 13:37:48 --> Router Class Initialized
INFO - 2016-10-12 13:37:48 --> Output Class Initialized
INFO - 2016-10-12 13:37:48 --> Security Class Initialized
DEBUG - 2016-10-12 13:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 13:37:48 --> Input Class Initialized
INFO - 2016-10-12 13:37:48 --> Language Class Initialized
INFO - 2016-10-12 13:37:48 --> Language Class Initialized
INFO - 2016-10-12 13:37:48 --> Config Class Initialized
INFO - 2016-10-12 13:37:48 --> Loader Class Initialized
INFO - 2016-10-12 13:37:48 --> Helper loaded: common_helper
INFO - 2016-10-12 13:37:48 --> Helper loaded: url_helper
INFO - 2016-10-12 13:37:48 --> Database Driver Class Initialized
INFO - 2016-10-12 13:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 13:37:48 --> Parser Class Initialized
INFO - 2016-10-12 13:37:48 --> Controller Class Initialized
DEBUG - 2016-10-12 13:37:48 --> Content MX_Controller Initialized
INFO - 2016-10-12 13:37:48 --> Model Class Initialized
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-12 13:37:48 --> Model Class Initialized
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 13:37:48 --> Model Class Initialized
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-12 13:37:48 --> Slider MX_Controller Initialized
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-12 13:37:48 --> Model Class Initialized
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-12 13:37:48 --> Servers MX_Controller Initialized
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 13:37:48 --> Model Class Initialized
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-12 13:37:48 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 13:37:48 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-12 13:37:48 --> Final output sent to browser
DEBUG - 2016-10-12 13:37:48 --> Total execution time: 0.0587
INFO - 2016-10-12 16:32:30 --> Config Class Initialized
INFO - 2016-10-12 16:32:30 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:32:30 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:32:30 --> Utf8 Class Initialized
INFO - 2016-10-12 16:32:30 --> URI Class Initialized
DEBUG - 2016-10-12 16:32:30 --> No URI present. Default controller set.
INFO - 2016-10-12 16:32:30 --> Router Class Initialized
INFO - 2016-10-12 16:32:30 --> Output Class Initialized
INFO - 2016-10-12 16:32:30 --> Security Class Initialized
DEBUG - 2016-10-12 16:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:32:30 --> Input Class Initialized
INFO - 2016-10-12 16:32:30 --> Language Class Initialized
INFO - 2016-10-12 16:32:30 --> Language Class Initialized
INFO - 2016-10-12 16:32:30 --> Config Class Initialized
INFO - 2016-10-12 16:32:30 --> Loader Class Initialized
INFO - 2016-10-12 16:32:30 --> Helper loaded: common_helper
INFO - 2016-10-12 16:32:30 --> Helper loaded: url_helper
INFO - 2016-10-12 16:32:30 --> Database Driver Class Initialized
INFO - 2016-10-12 16:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:32:30 --> Parser Class Initialized
INFO - 2016-10-12 16:32:30 --> Controller Class Initialized
DEBUG - 2016-10-12 16:32:30 --> Home MX_Controller Initialized
INFO - 2016-10-12 16:32:30 --> Model Class Initialized
DEBUG - 2016-10-12 16:32:30 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 16:32:30 --> Model Class Initialized
ERROR - 2016-10-12 16:32:30 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 16:32:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 16:32:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 16:32:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 16:32:30 --> Final output sent to browser
DEBUG - 2016-10-12 16:32:30 --> Total execution time: 0.0425
INFO - 2016-10-12 16:37:26 --> Config Class Initialized
INFO - 2016-10-12 16:37:26 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:37:26 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:37:26 --> Utf8 Class Initialized
INFO - 2016-10-12 16:37:26 --> URI Class Initialized
INFO - 2016-10-12 16:37:26 --> Router Class Initialized
INFO - 2016-10-12 16:37:26 --> Output Class Initialized
INFO - 2016-10-12 16:37:26 --> Security Class Initialized
DEBUG - 2016-10-12 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:37:26 --> Input Class Initialized
INFO - 2016-10-12 16:37:26 --> Language Class Initialized
INFO - 2016-10-12 16:37:26 --> Language Class Initialized
INFO - 2016-10-12 16:37:26 --> Config Class Initialized
INFO - 2016-10-12 16:37:26 --> Loader Class Initialized
INFO - 2016-10-12 16:37:26 --> Helper loaded: common_helper
INFO - 2016-10-12 16:37:26 --> Helper loaded: url_helper
INFO - 2016-10-12 16:37:26 --> Database Driver Class Initialized
INFO - 2016-10-12 16:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:37:26 --> Parser Class Initialized
INFO - 2016-10-12 16:37:26 --> Controller Class Initialized
DEBUG - 2016-10-12 16:37:26 --> Donate_report MX_Controller Initialized
INFO - 2016-10-12 16:37:26 --> Model Class Initialized
DEBUG - 2016-10-12 16:37:26 --> File loaded: /home/dolongpk/public_html/application/modules/donate_report/models/Donate_report_model.php
DEBUG - 2016-10-12 16:37:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:37:26 --> Model Class Initialized
DEBUG - 2016-10-12 16:37:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:37:26 --> Model Class Initialized
INFO - 2016-10-12 16:37:27 --> Helper loaded: form_helper
INFO - 2016-10-12 16:37:27 --> Form Validation Class Initialized
INFO - 2016-10-12 16:37:27 --> Config Class Initialized
INFO - 2016-10-12 16:37:27 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:37:27 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:37:27 --> Utf8 Class Initialized
INFO - 2016-10-12 16:37:27 --> URI Class Initialized
INFO - 2016-10-12 16:37:27 --> Router Class Initialized
INFO - 2016-10-12 16:37:27 --> Output Class Initialized
INFO - 2016-10-12 16:37:27 --> Security Class Initialized
DEBUG - 2016-10-12 16:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:37:27 --> Input Class Initialized
INFO - 2016-10-12 16:37:27 --> Language Class Initialized
INFO - 2016-10-12 16:37:27 --> Language Class Initialized
INFO - 2016-10-12 16:37:27 --> Config Class Initialized
INFO - 2016-10-12 16:37:27 --> Loader Class Initialized
INFO - 2016-10-12 16:37:27 --> Helper loaded: common_helper
INFO - 2016-10-12 16:37:27 --> Helper loaded: url_helper
INFO - 2016-10-12 16:37:27 --> Database Driver Class Initialized
INFO - 2016-10-12 16:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:37:27 --> Parser Class Initialized
INFO - 2016-10-12 16:37:27 --> Controller Class Initialized
DEBUG - 2016-10-12 16:37:27 --> Home MX_Controller Initialized
INFO - 2016-10-12 16:37:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 16:37:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-12 16:37:27 --> Content MX_Controller Initialized
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:37:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-12 16:37:27 --> Slider MX_Controller Initialized
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-12 16:37:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-12 16:37:27 --> Servers MX_Controller Initialized
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 16:37:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-12 16:37:27 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 16:37:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-12 16:37:27 --> Final output sent to browser
DEBUG - 2016-10-12 16:37:27 --> Total execution time: 0.0478
INFO - 2016-10-12 16:37:27 --> Config Class Initialized
INFO - 2016-10-12 16:37:27 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:37:27 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:37:27 --> Utf8 Class Initialized
INFO - 2016-10-12 16:37:27 --> URI Class Initialized
INFO - 2016-10-12 16:37:27 --> Router Class Initialized
INFO - 2016-10-12 16:37:27 --> Output Class Initialized
INFO - 2016-10-12 16:37:27 --> Security Class Initialized
DEBUG - 2016-10-12 16:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:37:27 --> Input Class Initialized
INFO - 2016-10-12 16:37:27 --> Language Class Initialized
ERROR - 2016-10-12 16:37:27 --> 404 Page Not Found: /index
INFO - 2016-10-12 16:47:33 --> Config Class Initialized
INFO - 2016-10-12 16:47:33 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:47:33 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:47:33 --> Utf8 Class Initialized
INFO - 2016-10-12 16:47:33 --> URI Class Initialized
INFO - 2016-10-12 16:47:33 --> Router Class Initialized
INFO - 2016-10-12 16:47:33 --> Output Class Initialized
INFO - 2016-10-12 16:47:33 --> Security Class Initialized
DEBUG - 2016-10-12 16:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:47:33 --> Input Class Initialized
INFO - 2016-10-12 16:47:33 --> Language Class Initialized
INFO - 2016-10-12 16:47:33 --> Language Class Initialized
INFO - 2016-10-12 16:47:33 --> Config Class Initialized
INFO - 2016-10-12 16:47:33 --> Loader Class Initialized
INFO - 2016-10-12 16:47:33 --> Helper loaded: common_helper
INFO - 2016-10-12 16:47:33 --> Helper loaded: url_helper
INFO - 2016-10-12 16:47:33 --> Database Driver Class Initialized
INFO - 2016-10-12 16:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:47:33 --> Parser Class Initialized
INFO - 2016-10-12 16:47:33 --> Controller Class Initialized
DEBUG - 2016-10-12 16:47:33 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 16:47:33 --> Config Class Initialized
INFO - 2016-10-12 16:47:33 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:47:33 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:47:33 --> Utf8 Class Initialized
INFO - 2016-10-12 16:47:33 --> URI Class Initialized
INFO - 2016-10-12 16:47:33 --> Router Class Initialized
INFO - 2016-10-12 16:47:33 --> Output Class Initialized
INFO - 2016-10-12 16:47:33 --> Security Class Initialized
DEBUG - 2016-10-12 16:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:47:33 --> Input Class Initialized
INFO - 2016-10-12 16:47:33 --> Language Class Initialized
INFO - 2016-10-12 16:47:33 --> Language Class Initialized
INFO - 2016-10-12 16:47:33 --> Config Class Initialized
INFO - 2016-10-12 16:47:33 --> Loader Class Initialized
INFO - 2016-10-12 16:47:33 --> Helper loaded: common_helper
INFO - 2016-10-12 16:47:33 --> Helper loaded: url_helper
INFO - 2016-10-12 16:47:33 --> Database Driver Class Initialized
INFO - 2016-10-12 16:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:47:33 --> Parser Class Initialized
INFO - 2016-10-12 16:47:33 --> Controller Class Initialized
DEBUG - 2016-10-12 16:47:33 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 16:47:33 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:47:33 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:33 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-12 16:47:33 --> Final output sent to browser
DEBUG - 2016-10-12 16:47:33 --> Total execution time: 0.0366
INFO - 2016-10-12 16:47:38 --> Config Class Initialized
INFO - 2016-10-12 16:47:38 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:47:38 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:47:38 --> Utf8 Class Initialized
INFO - 2016-10-12 16:47:38 --> URI Class Initialized
INFO - 2016-10-12 16:47:38 --> Router Class Initialized
INFO - 2016-10-12 16:47:38 --> Output Class Initialized
INFO - 2016-10-12 16:47:38 --> Security Class Initialized
DEBUG - 2016-10-12 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:47:38 --> Input Class Initialized
INFO - 2016-10-12 16:47:38 --> Language Class Initialized
INFO - 2016-10-12 16:47:38 --> Language Class Initialized
INFO - 2016-10-12 16:47:38 --> Config Class Initialized
INFO - 2016-10-12 16:47:38 --> Loader Class Initialized
INFO - 2016-10-12 16:47:38 --> Helper loaded: common_helper
INFO - 2016-10-12 16:47:38 --> Helper loaded: url_helper
INFO - 2016-10-12 16:47:38 --> Database Driver Class Initialized
INFO - 2016-10-12 16:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:47:38 --> Parser Class Initialized
INFO - 2016-10-12 16:47:38 --> Controller Class Initialized
DEBUG - 2016-10-12 16:47:38 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 16:47:38 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:47:38 --> Model Class Initialized
INFO - 2016-10-12 16:47:38 --> Final output sent to browser
DEBUG - 2016-10-12 16:47:38 --> Total execution time: 0.0431
INFO - 2016-10-12 16:47:38 --> Config Class Initialized
INFO - 2016-10-12 16:47:38 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:47:38 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:47:38 --> Utf8 Class Initialized
INFO - 2016-10-12 16:47:38 --> URI Class Initialized
INFO - 2016-10-12 16:47:38 --> Router Class Initialized
INFO - 2016-10-12 16:47:38 --> Output Class Initialized
INFO - 2016-10-12 16:47:38 --> Security Class Initialized
DEBUG - 2016-10-12 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:47:38 --> Input Class Initialized
INFO - 2016-10-12 16:47:38 --> Language Class Initialized
INFO - 2016-10-12 16:47:38 --> Language Class Initialized
INFO - 2016-10-12 16:47:38 --> Config Class Initialized
INFO - 2016-10-12 16:47:38 --> Loader Class Initialized
INFO - 2016-10-12 16:47:38 --> Helper loaded: common_helper
INFO - 2016-10-12 16:47:38 --> Helper loaded: url_helper
INFO - 2016-10-12 16:47:38 --> Database Driver Class Initialized
INFO - 2016-10-12 16:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:47:38 --> Parser Class Initialized
INFO - 2016-10-12 16:47:38 --> Controller Class Initialized
DEBUG - 2016-10-12 16:47:38 --> Admincp MX_Controller Initialized
INFO - 2016-10-12 16:47:38 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:47:38 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-12 16:47:38 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:47:38 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 16:47:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:47:38 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 16:47:38 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 16:47:38 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 16:47:38 --> Final output sent to browser
DEBUG - 2016-10-12 16:47:38 --> Total execution time: 0.0472
INFO - 2016-10-12 16:47:40 --> Config Class Initialized
INFO - 2016-10-12 16:47:40 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:47:40 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:47:40 --> Utf8 Class Initialized
INFO - 2016-10-12 16:47:40 --> URI Class Initialized
INFO - 2016-10-12 16:47:40 --> Router Class Initialized
INFO - 2016-10-12 16:47:40 --> Output Class Initialized
INFO - 2016-10-12 16:47:40 --> Security Class Initialized
DEBUG - 2016-10-12 16:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:47:40 --> Input Class Initialized
INFO - 2016-10-12 16:47:40 --> Language Class Initialized
ERROR - 2016-10-12 16:47:40 --> 404 Page Not Found: /index
INFO - 2016-10-12 16:47:56 --> Config Class Initialized
INFO - 2016-10-12 16:47:56 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:47:56 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:47:56 --> Utf8 Class Initialized
INFO - 2016-10-12 16:47:56 --> URI Class Initialized
INFO - 2016-10-12 16:47:56 --> Router Class Initialized
INFO - 2016-10-12 16:47:56 --> Output Class Initialized
INFO - 2016-10-12 16:47:56 --> Security Class Initialized
DEBUG - 2016-10-12 16:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:47:56 --> Input Class Initialized
INFO - 2016-10-12 16:47:56 --> Language Class Initialized
INFO - 2016-10-12 16:47:56 --> Language Class Initialized
INFO - 2016-10-12 16:47:56 --> Config Class Initialized
INFO - 2016-10-12 16:47:56 --> Loader Class Initialized
INFO - 2016-10-12 16:47:56 --> Helper loaded: common_helper
INFO - 2016-10-12 16:47:56 --> Helper loaded: url_helper
INFO - 2016-10-12 16:47:56 --> Database Driver Class Initialized
INFO - 2016-10-12 16:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:47:56 --> Parser Class Initialized
INFO - 2016-10-12 16:47:56 --> Controller Class Initialized
DEBUG - 2016-10-12 16:47:56 --> User MX_Controller Initialized
INFO - 2016-10-12 16:47:56 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-12 16:47:56 --> Model Class Initialized
INFO - 2016-10-12 16:47:56 --> Helper loaded: cookie_helper
INFO - 2016-10-12 16:47:56 --> Helper loaded: form_helper
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:47:56 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:47:56 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 16:47:56 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 16:47:56 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/BACKEND/index.php
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 16:47:56 --> Final output sent to browser
DEBUG - 2016-10-12 16:47:56 --> Total execution time: 0.0733
INFO - 2016-10-12 16:47:56 --> Config Class Initialized
INFO - 2016-10-12 16:47:56 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:47:56 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:47:56 --> Utf8 Class Initialized
INFO - 2016-10-12 16:47:56 --> URI Class Initialized
INFO - 2016-10-12 16:47:56 --> Router Class Initialized
INFO - 2016-10-12 16:47:56 --> Output Class Initialized
INFO - 2016-10-12 16:47:56 --> Security Class Initialized
DEBUG - 2016-10-12 16:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:47:56 --> Input Class Initialized
INFO - 2016-10-12 16:47:56 --> Language Class Initialized
ERROR - 2016-10-12 16:47:56 --> 404 Page Not Found: /index
INFO - 2016-10-12 16:47:56 --> Config Class Initialized
INFO - 2016-10-12 16:47:56 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:47:56 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:47:56 --> Utf8 Class Initialized
INFO - 2016-10-12 16:47:56 --> URI Class Initialized
INFO - 2016-10-12 16:47:56 --> Router Class Initialized
INFO - 2016-10-12 16:47:56 --> Output Class Initialized
INFO - 2016-10-12 16:47:56 --> Security Class Initialized
DEBUG - 2016-10-12 16:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:47:56 --> Input Class Initialized
INFO - 2016-10-12 16:47:56 --> Language Class Initialized
INFO - 2016-10-12 16:47:56 --> Language Class Initialized
INFO - 2016-10-12 16:47:56 --> Config Class Initialized
INFO - 2016-10-12 16:47:56 --> Loader Class Initialized
INFO - 2016-10-12 16:47:56 --> Helper loaded: common_helper
INFO - 2016-10-12 16:47:56 --> Helper loaded: url_helper
INFO - 2016-10-12 16:47:56 --> Database Driver Class Initialized
INFO - 2016-10-12 16:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:47:56 --> Parser Class Initialized
INFO - 2016-10-12 16:47:56 --> Controller Class Initialized
DEBUG - 2016-10-12 16:47:56 --> User MX_Controller Initialized
INFO - 2016-10-12 16:47:56 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-12 16:47:56 --> Model Class Initialized
INFO - 2016-10-12 16:47:56 --> Helper loaded: cookie_helper
INFO - 2016-10-12 16:47:56 --> Helper loaded: form_helper
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:47:56 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:47:56 --> Model Class Initialized
DEBUG - 2016-10-12 16:47:56 --> Pagination Class Initialized
ERROR - 2016-10-12 16:47:56 --> Severity: Notice --> Undefined property: stdClass::$token /home/dolongpk/public_html/application/modules/user/views/BACKEND/ajax_loadContent.php 29
ERROR - 2016-10-12 16:47:56 --> Severity: Notice --> Undefined property: stdClass::$token /home/dolongpk/public_html/application/modules/user/views/BACKEND/ajax_loadContent.php 29
ERROR - 2016-10-12 16:47:56 --> Severity: Notice --> Undefined property: stdClass::$token /home/dolongpk/public_html/application/modules/user/views/BACKEND/ajax_loadContent.php 29
DEBUG - 2016-10-12 16:47:56 --> File loaded: /home/dolongpk/public_html/application/modules/user/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 16:47:56 --> Final output sent to browser
DEBUG - 2016-10-12 16:47:56 --> Total execution time: 0.0594
INFO - 2016-10-12 16:48:27 --> Config Class Initialized
INFO - 2016-10-12 16:48:27 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:48:27 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:48:27 --> Utf8 Class Initialized
INFO - 2016-10-12 16:48:27 --> URI Class Initialized
INFO - 2016-10-12 16:48:27 --> Router Class Initialized
INFO - 2016-10-12 16:48:27 --> Output Class Initialized
INFO - 2016-10-12 16:48:27 --> Security Class Initialized
DEBUG - 2016-10-12 16:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:48:27 --> Input Class Initialized
INFO - 2016-10-12 16:48:27 --> Language Class Initialized
INFO - 2016-10-12 16:48:27 --> Language Class Initialized
INFO - 2016-10-12 16:48:27 --> Config Class Initialized
INFO - 2016-10-12 16:48:27 --> Loader Class Initialized
INFO - 2016-10-12 16:48:27 --> Helper loaded: common_helper
INFO - 2016-10-12 16:48:27 --> Helper loaded: url_helper
INFO - 2016-10-12 16:48:27 --> Database Driver Class Initialized
INFO - 2016-10-12 16:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:48:27 --> Parser Class Initialized
INFO - 2016-10-12 16:48:27 --> Controller Class Initialized
DEBUG - 2016-10-12 16:48:27 --> Servers MX_Controller Initialized
INFO - 2016-10-12 16:48:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 16:48:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:48:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 16:48:27 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 16:48:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:48:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 16:48:27 --> Final output sent to browser
DEBUG - 2016-10-12 16:48:27 --> Total execution time: 0.0508
INFO - 2016-10-12 16:48:27 --> Config Class Initialized
INFO - 2016-10-12 16:48:27 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:48:27 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:48:27 --> Utf8 Class Initialized
INFO - 2016-10-12 16:48:27 --> URI Class Initialized
INFO - 2016-10-12 16:48:27 --> Router Class Initialized
INFO - 2016-10-12 16:48:27 --> Output Class Initialized
INFO - 2016-10-12 16:48:27 --> Security Class Initialized
DEBUG - 2016-10-12 16:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:48:27 --> Input Class Initialized
INFO - 2016-10-12 16:48:27 --> Language Class Initialized
ERROR - 2016-10-12 16:48:27 --> 404 Page Not Found: /index
INFO - 2016-10-12 16:48:27 --> Config Class Initialized
INFO - 2016-10-12 16:48:27 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:48:27 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:48:27 --> Utf8 Class Initialized
INFO - 2016-10-12 16:48:27 --> URI Class Initialized
INFO - 2016-10-12 16:48:27 --> Router Class Initialized
INFO - 2016-10-12 16:48:27 --> Output Class Initialized
INFO - 2016-10-12 16:48:27 --> Security Class Initialized
DEBUG - 2016-10-12 16:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:48:27 --> Input Class Initialized
INFO - 2016-10-12 16:48:27 --> Language Class Initialized
INFO - 2016-10-12 16:48:27 --> Language Class Initialized
INFO - 2016-10-12 16:48:27 --> Config Class Initialized
INFO - 2016-10-12 16:48:27 --> Loader Class Initialized
INFO - 2016-10-12 16:48:27 --> Helper loaded: common_helper
INFO - 2016-10-12 16:48:27 --> Helper loaded: url_helper
INFO - 2016-10-12 16:48:27 --> Database Driver Class Initialized
INFO - 2016-10-12 16:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:48:27 --> Parser Class Initialized
INFO - 2016-10-12 16:48:27 --> Controller Class Initialized
DEBUG - 2016-10-12 16:48:27 --> Servers MX_Controller Initialized
INFO - 2016-10-12 16:48:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 16:48:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:48:27 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:27 --> Pagination Class Initialized
DEBUG - 2016-10-12 16:48:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 16:48:27 --> Final output sent to browser
DEBUG - 2016-10-12 16:48:27 --> Total execution time: 0.0466
INFO - 2016-10-12 16:48:41 --> Config Class Initialized
INFO - 2016-10-12 16:48:41 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:48:41 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:48:41 --> Utf8 Class Initialized
INFO - 2016-10-12 16:48:41 --> URI Class Initialized
INFO - 2016-10-12 16:48:41 --> Router Class Initialized
INFO - 2016-10-12 16:48:41 --> Output Class Initialized
INFO - 2016-10-12 16:48:41 --> Security Class Initialized
DEBUG - 2016-10-12 16:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:48:41 --> Input Class Initialized
INFO - 2016-10-12 16:48:41 --> Language Class Initialized
INFO - 2016-10-12 16:48:41 --> Language Class Initialized
INFO - 2016-10-12 16:48:41 --> Config Class Initialized
INFO - 2016-10-12 16:48:41 --> Loader Class Initialized
INFO - 2016-10-12 16:48:41 --> Helper loaded: common_helper
INFO - 2016-10-12 16:48:41 --> Helper loaded: url_helper
INFO - 2016-10-12 16:48:41 --> Database Driver Class Initialized
INFO - 2016-10-12 16:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:48:41 --> Parser Class Initialized
INFO - 2016-10-12 16:48:41 --> Controller Class Initialized
DEBUG - 2016-10-12 16:48:41 --> Servers MX_Controller Initialized
INFO - 2016-10-12 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:41 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 16:48:41 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:48:41 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-12 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 16:48:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 16:48:41 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 16:48:41 --> Final output sent to browser
DEBUG - 2016-10-12 16:48:41 --> Total execution time: 0.0530
INFO - 2016-10-12 16:48:44 --> Config Class Initialized
INFO - 2016-10-12 16:48:44 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:48:44 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:48:44 --> Utf8 Class Initialized
INFO - 2016-10-12 16:48:44 --> URI Class Initialized
INFO - 2016-10-12 16:48:44 --> Router Class Initialized
INFO - 2016-10-12 16:48:44 --> Output Class Initialized
INFO - 2016-10-12 16:48:44 --> Security Class Initialized
DEBUG - 2016-10-12 16:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:48:44 --> Input Class Initialized
INFO - 2016-10-12 16:48:44 --> Language Class Initialized
INFO - 2016-10-12 16:48:44 --> Language Class Initialized
INFO - 2016-10-12 16:48:44 --> Config Class Initialized
INFO - 2016-10-12 16:48:44 --> Loader Class Initialized
INFO - 2016-10-12 16:48:44 --> Helper loaded: common_helper
INFO - 2016-10-12 16:48:44 --> Helper loaded: url_helper
INFO - 2016-10-12 16:48:44 --> Database Driver Class Initialized
INFO - 2016-10-12 16:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:48:44 --> Parser Class Initialized
INFO - 2016-10-12 16:48:44 --> Controller Class Initialized
DEBUG - 2016-10-12 16:48:44 --> Servers MX_Controller Initialized
INFO - 2016-10-12 16:48:44 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 16:48:44 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:48:44 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 16:48:44 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 16:48:44 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:48:44 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/index.php
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 16:48:44 --> Final output sent to browser
DEBUG - 2016-10-12 16:48:44 --> Total execution time: 0.0495
INFO - 2016-10-12 16:48:44 --> Config Class Initialized
INFO - 2016-10-12 16:48:44 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:48:44 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:48:44 --> Utf8 Class Initialized
INFO - 2016-10-12 16:48:44 --> URI Class Initialized
INFO - 2016-10-12 16:48:44 --> Router Class Initialized
INFO - 2016-10-12 16:48:44 --> Output Class Initialized
INFO - 2016-10-12 16:48:44 --> Security Class Initialized
DEBUG - 2016-10-12 16:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:48:44 --> Input Class Initialized
INFO - 2016-10-12 16:48:44 --> Language Class Initialized
INFO - 2016-10-12 16:48:44 --> Language Class Initialized
INFO - 2016-10-12 16:48:44 --> Config Class Initialized
INFO - 2016-10-12 16:48:44 --> Loader Class Initialized
INFO - 2016-10-12 16:48:44 --> Helper loaded: common_helper
INFO - 2016-10-12 16:48:44 --> Helper loaded: url_helper
INFO - 2016-10-12 16:48:44 --> Database Driver Class Initialized
INFO - 2016-10-12 16:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:48:44 --> Parser Class Initialized
INFO - 2016-10-12 16:48:44 --> Controller Class Initialized
DEBUG - 2016-10-12 16:48:44 --> Servers MX_Controller Initialized
INFO - 2016-10-12 16:48:44 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 16:48:44 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:48:44 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:44 --> Pagination Class Initialized
DEBUG - 2016-10-12 16:48:44 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_loadContent.php
INFO - 2016-10-12 16:48:44 --> Final output sent to browser
DEBUG - 2016-10-12 16:48:44 --> Total execution time: 0.0380
INFO - 2016-10-12 16:48:45 --> Config Class Initialized
INFO - 2016-10-12 16:48:45 --> Hooks Class Initialized
DEBUG - 2016-10-12 16:48:45 --> UTF-8 Support Enabled
INFO - 2016-10-12 16:48:45 --> Utf8 Class Initialized
INFO - 2016-10-12 16:48:45 --> URI Class Initialized
INFO - 2016-10-12 16:48:45 --> Router Class Initialized
INFO - 2016-10-12 16:48:45 --> Output Class Initialized
INFO - 2016-10-12 16:48:45 --> Security Class Initialized
DEBUG - 2016-10-12 16:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 16:48:45 --> Input Class Initialized
INFO - 2016-10-12 16:48:45 --> Language Class Initialized
INFO - 2016-10-12 16:48:45 --> Language Class Initialized
INFO - 2016-10-12 16:48:45 --> Config Class Initialized
INFO - 2016-10-12 16:48:45 --> Loader Class Initialized
INFO - 2016-10-12 16:48:45 --> Helper loaded: common_helper
INFO - 2016-10-12 16:48:45 --> Helper loaded: url_helper
INFO - 2016-10-12 16:48:45 --> Database Driver Class Initialized
INFO - 2016-10-12 16:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 16:48:46 --> Parser Class Initialized
INFO - 2016-10-12 16:48:46 --> Controller Class Initialized
DEBUG - 2016-10-12 16:48:46 --> Servers MX_Controller Initialized
INFO - 2016-10-12 16:48:46 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 16:48:46 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 16:48:46 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:46 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 16:48:46 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 16:48:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 16:48:46 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 16:48:46 --> Model Class Initialized
DEBUG - 2016-10-12 16:48:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-12 16:48:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 16:48:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 16:48:46 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 16:48:46 --> Final output sent to browser
DEBUG - 2016-10-12 16:48:46 --> Total execution time: 0.0429
INFO - 2016-10-12 17:00:32 --> Config Class Initialized
INFO - 2016-10-12 17:00:32 --> Hooks Class Initialized
DEBUG - 2016-10-12 17:00:32 --> UTF-8 Support Enabled
INFO - 2016-10-12 17:00:32 --> Utf8 Class Initialized
INFO - 2016-10-12 17:00:32 --> URI Class Initialized
INFO - 2016-10-12 17:00:32 --> Router Class Initialized
INFO - 2016-10-12 17:00:32 --> Output Class Initialized
INFO - 2016-10-12 17:00:32 --> Security Class Initialized
DEBUG - 2016-10-12 17:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 17:00:32 --> Input Class Initialized
INFO - 2016-10-12 17:00:32 --> Language Class Initialized
INFO - 2016-10-12 17:00:32 --> Language Class Initialized
INFO - 2016-10-12 17:00:32 --> Config Class Initialized
INFO - 2016-10-12 17:00:32 --> Loader Class Initialized
INFO - 2016-10-12 17:00:32 --> Helper loaded: common_helper
INFO - 2016-10-12 17:00:32 --> Helper loaded: url_helper
INFO - 2016-10-12 17:00:32 --> Database Driver Class Initialized
INFO - 2016-10-12 17:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 17:00:32 --> Parser Class Initialized
INFO - 2016-10-12 17:00:32 --> Controller Class Initialized
DEBUG - 2016-10-12 17:00:32 --> Servers MX_Controller Initialized
INFO - 2016-10-12 17:00:32 --> Model Class Initialized
DEBUG - 2016-10-12 17:00:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 17:00:32 --> Model Class Initialized
DEBUG - 2016-10-12 17:00:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 17:00:32 --> Model Class Initialized
DEBUG - 2016-10-12 17:00:32 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/admincp/controllers/Admincp.php
DEBUG - 2016-10-12 17:00:32 --> Admincp MX_Controller Initialized
DEBUG - 2016-10-12 17:00:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-12 17:00:32 --> Model Class Initialized
DEBUG - 2016-10-12 17:00:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-12 17:00:32 --> Model Class Initialized
DEBUG - 2016-10-12 17:00:32 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/BACKEND/ajax_editContent.php
DEBUG - 2016-10-12 17:00:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-12 17:00:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-12 17:00:32 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-12 17:00:32 --> Final output sent to browser
DEBUG - 2016-10-12 17:00:32 --> Total execution time: 0.0511
INFO - 2016-10-12 20:44:34 --> Config Class Initialized
INFO - 2016-10-12 20:44:34 --> Hooks Class Initialized
DEBUG - 2016-10-12 20:44:34 --> UTF-8 Support Enabled
INFO - 2016-10-12 20:44:34 --> Utf8 Class Initialized
INFO - 2016-10-12 20:44:34 --> URI Class Initialized
DEBUG - 2016-10-12 20:44:34 --> No URI present. Default controller set.
INFO - 2016-10-12 20:44:34 --> Router Class Initialized
INFO - 2016-10-12 20:44:34 --> Output Class Initialized
INFO - 2016-10-12 20:44:34 --> Security Class Initialized
DEBUG - 2016-10-12 20:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 20:44:34 --> Input Class Initialized
INFO - 2016-10-12 20:44:34 --> Language Class Initialized
INFO - 2016-10-12 20:44:34 --> Language Class Initialized
INFO - 2016-10-12 20:44:34 --> Config Class Initialized
INFO - 2016-10-12 20:44:34 --> Loader Class Initialized
INFO - 2016-10-12 20:44:34 --> Helper loaded: common_helper
INFO - 2016-10-12 20:44:34 --> Helper loaded: url_helper
INFO - 2016-10-12 20:44:34 --> Database Driver Class Initialized
INFO - 2016-10-12 20:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 20:44:34 --> Parser Class Initialized
INFO - 2016-10-12 20:44:34 --> Controller Class Initialized
DEBUG - 2016-10-12 20:44:34 --> Home MX_Controller Initialized
INFO - 2016-10-12 20:44:34 --> Model Class Initialized
DEBUG - 2016-10-12 20:44:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 20:44:34 --> Model Class Initialized
ERROR - 2016-10-12 20:44:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 20:44:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 20:44:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 20:44:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-12 20:44:34 --> Final output sent to browser
DEBUG - 2016-10-12 20:44:34 --> Total execution time: 0.0444
INFO - 2016-10-12 20:44:39 --> Config Class Initialized
INFO - 2016-10-12 20:44:39 --> Hooks Class Initialized
DEBUG - 2016-10-12 20:44:39 --> UTF-8 Support Enabled
INFO - 2016-10-12 20:44:39 --> Utf8 Class Initialized
INFO - 2016-10-12 20:44:39 --> URI Class Initialized
INFO - 2016-10-12 20:44:39 --> Router Class Initialized
INFO - 2016-10-12 20:44:39 --> Output Class Initialized
INFO - 2016-10-12 20:44:39 --> Security Class Initialized
DEBUG - 2016-10-12 20:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 20:44:39 --> Input Class Initialized
INFO - 2016-10-12 20:44:40 --> Language Class Initialized
INFO - 2016-10-12 20:44:40 --> Language Class Initialized
INFO - 2016-10-12 20:44:40 --> Config Class Initialized
INFO - 2016-10-12 20:44:40 --> Loader Class Initialized
INFO - 2016-10-12 20:44:40 --> Helper loaded: common_helper
INFO - 2016-10-12 20:44:40 --> Helper loaded: url_helper
INFO - 2016-10-12 20:44:40 --> Database Driver Class Initialized
INFO - 2016-10-12 20:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-12 20:44:40 --> Parser Class Initialized
INFO - 2016-10-12 20:44:40 --> Controller Class Initialized
DEBUG - 2016-10-12 20:44:40 --> Home MX_Controller Initialized
INFO - 2016-10-12 20:44:40 --> Model Class Initialized
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-12 20:44:40 --> Model Class Initialized
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-12 20:44:40 --> Content MX_Controller Initialized
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-12 20:44:40 --> Model Class Initialized
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-12 20:44:40 --> Slider MX_Controller Initialized
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-12 20:44:40 --> Model Class Initialized
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-12 20:44:40 --> Servers MX_Controller Initialized
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-12 20:44:40 --> Model Class Initialized
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-12 20:44:40 --> Module controller failed to run: banner/index
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-12 20:44:40 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-12 20:44:40 --> Final output sent to browser
DEBUG - 2016-10-12 20:44:40 --> Total execution time: 0.0622
INFO - 2016-10-12 20:44:41 --> Config Class Initialized
INFO - 2016-10-12 20:44:41 --> Hooks Class Initialized
DEBUG - 2016-10-12 20:44:41 --> UTF-8 Support Enabled
INFO - 2016-10-12 20:44:41 --> Utf8 Class Initialized
INFO - 2016-10-12 20:44:41 --> URI Class Initialized
INFO - 2016-10-12 20:44:41 --> Router Class Initialized
INFO - 2016-10-12 20:44:41 --> Output Class Initialized
INFO - 2016-10-12 20:44:41 --> Security Class Initialized
DEBUG - 2016-10-12 20:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-12 20:44:41 --> Input Class Initialized
INFO - 2016-10-12 20:44:41 --> Language Class Initialized
ERROR - 2016-10-12 20:44:41 --> 404 Page Not Found: /index
