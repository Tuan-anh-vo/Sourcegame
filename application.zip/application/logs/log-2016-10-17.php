<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-17 06:52:46 --> Config Class Initialized
INFO - 2016-10-17 06:52:46 --> Hooks Class Initialized
DEBUG - 2016-10-17 06:52:46 --> UTF-8 Support Enabled
INFO - 2016-10-17 06:52:46 --> Utf8 Class Initialized
INFO - 2016-10-17 06:52:46 --> URI Class Initialized
INFO - 2016-10-17 06:52:46 --> Router Class Initialized
INFO - 2016-10-17 06:52:46 --> Output Class Initialized
INFO - 2016-10-17 06:52:46 --> Security Class Initialized
DEBUG - 2016-10-17 06:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 06:52:46 --> Input Class Initialized
INFO - 2016-10-17 06:52:46 --> Language Class Initialized
INFO - 2016-10-17 06:52:46 --> Language Class Initialized
INFO - 2016-10-17 06:52:46 --> Config Class Initialized
INFO - 2016-10-17 06:52:46 --> Loader Class Initialized
INFO - 2016-10-17 06:52:46 --> Helper loaded: common_helper
INFO - 2016-10-17 06:52:46 --> Helper loaded: url_helper
INFO - 2016-10-17 06:52:46 --> Database Driver Class Initialized
INFO - 2016-10-17 06:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 06:52:46 --> Parser Class Initialized
INFO - 2016-10-17 06:52:46 --> Controller Class Initialized
DEBUG - 2016-10-17 06:52:46 --> Content MX_Controller Initialized
INFO - 2016-10-17 06:52:46 --> Model Class Initialized
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-17 06:52:46 --> Model Class Initialized
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 06:52:46 --> Model Class Initialized
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-17 06:52:46 --> Slider MX_Controller Initialized
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-17 06:52:46 --> Model Class Initialized
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-17 06:52:46 --> Servers MX_Controller Initialized
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-17 06:52:46 --> Model Class Initialized
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-17 06:52:46 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 06:52:46 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-17 06:52:46 --> Final output sent to browser
DEBUG - 2016-10-17 06:52:46 --> Total execution time: 0.0623
INFO - 2016-10-17 07:14:16 --> Config Class Initialized
INFO - 2016-10-17 07:14:16 --> Hooks Class Initialized
DEBUG - 2016-10-17 07:14:16 --> UTF-8 Support Enabled
INFO - 2016-10-17 07:14:16 --> Utf8 Class Initialized
INFO - 2016-10-17 07:14:16 --> URI Class Initialized
INFO - 2016-10-17 07:14:16 --> Router Class Initialized
INFO - 2016-10-17 07:14:16 --> Output Class Initialized
INFO - 2016-10-17 07:14:16 --> Security Class Initialized
DEBUG - 2016-10-17 07:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 07:14:16 --> Input Class Initialized
INFO - 2016-10-17 07:14:16 --> Language Class Initialized
INFO - 2016-10-17 07:14:16 --> Language Class Initialized
INFO - 2016-10-17 07:14:16 --> Config Class Initialized
INFO - 2016-10-17 07:14:16 --> Loader Class Initialized
INFO - 2016-10-17 07:14:16 --> Helper loaded: common_helper
INFO - 2016-10-17 07:14:16 --> Helper loaded: url_helper
INFO - 2016-10-17 07:14:16 --> Database Driver Class Initialized
INFO - 2016-10-17 07:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 07:14:16 --> Parser Class Initialized
INFO - 2016-10-17 07:14:16 --> Controller Class Initialized
DEBUG - 2016-10-17 07:14:16 --> Content MX_Controller Initialized
INFO - 2016-10-17 07:14:16 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-17 07:14:16 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 07:14:16 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-17 07:14:16 --> Slider MX_Controller Initialized
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-17 07:14:16 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-17 07:14:16 --> Servers MX_Controller Initialized
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-17 07:14:16 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-17 07:14:16 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 07:14:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-17 07:14:16 --> Final output sent to browser
DEBUG - 2016-10-17 07:14:16 --> Total execution time: 0.0561
INFO - 2016-10-17 07:14:20 --> Config Class Initialized
INFO - 2016-10-17 07:14:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 07:14:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 07:14:20 --> Utf8 Class Initialized
INFO - 2016-10-17 07:14:20 --> URI Class Initialized
INFO - 2016-10-17 07:14:20 --> Router Class Initialized
INFO - 2016-10-17 07:14:20 --> Output Class Initialized
INFO - 2016-10-17 07:14:20 --> Security Class Initialized
DEBUG - 2016-10-17 07:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 07:14:20 --> Input Class Initialized
INFO - 2016-10-17 07:14:20 --> Language Class Initialized
INFO - 2016-10-17 07:14:20 --> Language Class Initialized
INFO - 2016-10-17 07:14:20 --> Config Class Initialized
INFO - 2016-10-17 07:14:20 --> Loader Class Initialized
INFO - 2016-10-17 07:14:20 --> Helper loaded: common_helper
INFO - 2016-10-17 07:14:20 --> Helper loaded: url_helper
INFO - 2016-10-17 07:14:20 --> Database Driver Class Initialized
INFO - 2016-10-17 07:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 07:14:20 --> Parser Class Initialized
INFO - 2016-10-17 07:14:20 --> Controller Class Initialized
DEBUG - 2016-10-17 07:14:20 --> Content MX_Controller Initialized
INFO - 2016-10-17 07:14:20 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-17 07:14:20 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 07:14:20 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-17 07:14:20 --> Slider MX_Controller Initialized
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-17 07:14:20 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-17 07:14:20 --> Servers MX_Controller Initialized
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-17 07:14:20 --> Model Class Initialized
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-17 07:14:20 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 07:14:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-17 07:14:20 --> Final output sent to browser
DEBUG - 2016-10-17 07:14:20 --> Total execution time: 0.0475
INFO - 2016-10-17 07:15:50 --> Config Class Initialized
INFO - 2016-10-17 07:15:50 --> Hooks Class Initialized
DEBUG - 2016-10-17 07:15:50 --> UTF-8 Support Enabled
INFO - 2016-10-17 07:15:50 --> Utf8 Class Initialized
INFO - 2016-10-17 07:15:50 --> URI Class Initialized
INFO - 2016-10-17 07:15:50 --> Router Class Initialized
INFO - 2016-10-17 07:15:50 --> Output Class Initialized
INFO - 2016-10-17 07:15:50 --> Security Class Initialized
DEBUG - 2016-10-17 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 07:15:50 --> Input Class Initialized
INFO - 2016-10-17 07:15:50 --> Language Class Initialized
INFO - 2016-10-17 07:15:50 --> Language Class Initialized
INFO - 2016-10-17 07:15:50 --> Config Class Initialized
INFO - 2016-10-17 07:15:50 --> Loader Class Initialized
INFO - 2016-10-17 07:15:50 --> Helper loaded: common_helper
INFO - 2016-10-17 07:15:50 --> Helper loaded: url_helper
INFO - 2016-10-17 07:15:51 --> Database Driver Class Initialized
INFO - 2016-10-17 07:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 07:15:51 --> Parser Class Initialized
INFO - 2016-10-17 07:15:51 --> Controller Class Initialized
DEBUG - 2016-10-17 07:15:51 --> Content MX_Controller Initialized
INFO - 2016-10-17 07:15:51 --> Model Class Initialized
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-17 07:15:51 --> Model Class Initialized
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 07:15:51 --> Model Class Initialized
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-17 07:15:51 --> Slider MX_Controller Initialized
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-17 07:15:51 --> Model Class Initialized
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-17 07:15:51 --> Servers MX_Controller Initialized
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-17 07:15:51 --> Model Class Initialized
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-17 07:15:51 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 07:15:51 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-17 07:15:51 --> Final output sent to browser
DEBUG - 2016-10-17 07:15:51 --> Total execution time: 0.0573
INFO - 2016-10-17 07:17:45 --> Config Class Initialized
INFO - 2016-10-17 07:17:45 --> Hooks Class Initialized
DEBUG - 2016-10-17 07:17:45 --> UTF-8 Support Enabled
INFO - 2016-10-17 07:17:45 --> Utf8 Class Initialized
INFO - 2016-10-17 07:17:45 --> URI Class Initialized
INFO - 2016-10-17 07:17:45 --> Router Class Initialized
INFO - 2016-10-17 07:17:45 --> Output Class Initialized
INFO - 2016-10-17 07:17:45 --> Security Class Initialized
DEBUG - 2016-10-17 07:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 07:17:45 --> Input Class Initialized
INFO - 2016-10-17 07:17:45 --> Language Class Initialized
INFO - 2016-10-17 07:17:45 --> Language Class Initialized
INFO - 2016-10-17 07:17:45 --> Config Class Initialized
INFO - 2016-10-17 07:17:45 --> Loader Class Initialized
INFO - 2016-10-17 07:17:45 --> Helper loaded: common_helper
INFO - 2016-10-17 07:17:45 --> Helper loaded: url_helper
INFO - 2016-10-17 07:17:45 --> Database Driver Class Initialized
INFO - 2016-10-17 07:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 07:17:45 --> Parser Class Initialized
INFO - 2016-10-17 07:17:45 --> Controller Class Initialized
DEBUG - 2016-10-17 07:17:45 --> Content MX_Controller Initialized
INFO - 2016-10-17 07:17:45 --> Model Class Initialized
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-17 07:17:45 --> Model Class Initialized
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 07:17:45 --> Model Class Initialized
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-17 07:17:45 --> Slider MX_Controller Initialized
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-17 07:17:45 --> Model Class Initialized
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-17 07:17:45 --> Servers MX_Controller Initialized
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-17 07:17:45 --> Model Class Initialized
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-17 07:17:45 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 07:17:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-17 07:17:45 --> Final output sent to browser
DEBUG - 2016-10-17 07:17:45 --> Total execution time: 0.0557
INFO - 2016-10-17 07:18:26 --> Config Class Initialized
INFO - 2016-10-17 07:18:26 --> Hooks Class Initialized
DEBUG - 2016-10-17 07:18:26 --> UTF-8 Support Enabled
INFO - 2016-10-17 07:18:26 --> Utf8 Class Initialized
INFO - 2016-10-17 07:18:26 --> URI Class Initialized
INFO - 2016-10-17 07:18:26 --> Router Class Initialized
INFO - 2016-10-17 07:18:26 --> Output Class Initialized
INFO - 2016-10-17 07:18:26 --> Security Class Initialized
DEBUG - 2016-10-17 07:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 07:18:26 --> Input Class Initialized
INFO - 2016-10-17 07:18:26 --> Language Class Initialized
INFO - 2016-10-17 07:18:26 --> Language Class Initialized
INFO - 2016-10-17 07:18:26 --> Config Class Initialized
INFO - 2016-10-17 07:18:26 --> Loader Class Initialized
INFO - 2016-10-17 07:18:26 --> Helper loaded: common_helper
INFO - 2016-10-17 07:18:26 --> Helper loaded: url_helper
INFO - 2016-10-17 07:18:26 --> Database Driver Class Initialized
INFO - 2016-10-17 07:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 07:18:26 --> Parser Class Initialized
INFO - 2016-10-17 07:18:26 --> Controller Class Initialized
DEBUG - 2016-10-17 07:18:26 --> Content MX_Controller Initialized
INFO - 2016-10-17 07:18:26 --> Model Class Initialized
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-17 07:18:26 --> Model Class Initialized
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 07:18:26 --> Model Class Initialized
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-17 07:18:26 --> Slider MX_Controller Initialized
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-17 07:18:26 --> Model Class Initialized
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-17 07:18:26 --> Servers MX_Controller Initialized
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-17 07:18:26 --> Model Class Initialized
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-17 07:18:26 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 07:18:26 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-17 07:18:26 --> Final output sent to browser
DEBUG - 2016-10-17 07:18:26 --> Total execution time: 0.0603
INFO - 2016-10-17 07:19:03 --> Config Class Initialized
INFO - 2016-10-17 07:19:03 --> Hooks Class Initialized
DEBUG - 2016-10-17 07:19:03 --> UTF-8 Support Enabled
INFO - 2016-10-17 07:19:03 --> Utf8 Class Initialized
INFO - 2016-10-17 07:19:03 --> URI Class Initialized
INFO - 2016-10-17 07:19:03 --> Router Class Initialized
INFO - 2016-10-17 07:19:03 --> Output Class Initialized
INFO - 2016-10-17 07:19:03 --> Security Class Initialized
DEBUG - 2016-10-17 07:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 07:19:03 --> Input Class Initialized
INFO - 2016-10-17 07:19:03 --> Language Class Initialized
INFO - 2016-10-17 07:19:03 --> Language Class Initialized
INFO - 2016-10-17 07:19:03 --> Config Class Initialized
INFO - 2016-10-17 07:19:03 --> Loader Class Initialized
INFO - 2016-10-17 07:19:03 --> Helper loaded: common_helper
INFO - 2016-10-17 07:19:03 --> Helper loaded: url_helper
INFO - 2016-10-17 07:19:03 --> Database Driver Class Initialized
INFO - 2016-10-17 07:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 07:19:03 --> Parser Class Initialized
INFO - 2016-10-17 07:19:03 --> Controller Class Initialized
DEBUG - 2016-10-17 07:19:03 --> Content MX_Controller Initialized
INFO - 2016-10-17 07:19:03 --> Model Class Initialized
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-17 07:19:03 --> Model Class Initialized
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 07:19:03 --> Model Class Initialized
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-17 07:19:03 --> Slider MX_Controller Initialized
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-17 07:19:03 --> Model Class Initialized
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-17 07:19:03 --> Servers MX_Controller Initialized
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-17 07:19:03 --> Model Class Initialized
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-17 07:19:03 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 07:19:03 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-17 07:19:03 --> Final output sent to browser
DEBUG - 2016-10-17 07:19:03 --> Total execution time: 0.0558
INFO - 2016-10-17 09:10:19 --> Config Class Initialized
INFO - 2016-10-17 09:10:19 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:10:19 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:10:19 --> Utf8 Class Initialized
INFO - 2016-10-17 09:10:19 --> URI Class Initialized
DEBUG - 2016-10-17 09:10:19 --> No URI present. Default controller set.
INFO - 2016-10-17 09:10:19 --> Router Class Initialized
INFO - 2016-10-17 09:10:19 --> Output Class Initialized
INFO - 2016-10-17 09:10:19 --> Security Class Initialized
DEBUG - 2016-10-17 09:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:10:19 --> Input Class Initialized
INFO - 2016-10-17 09:10:19 --> Language Class Initialized
INFO - 2016-10-17 09:10:19 --> Language Class Initialized
INFO - 2016-10-17 09:10:19 --> Config Class Initialized
INFO - 2016-10-17 09:10:19 --> Loader Class Initialized
INFO - 2016-10-17 09:10:19 --> Helper loaded: common_helper
INFO - 2016-10-17 09:10:19 --> Helper loaded: url_helper
INFO - 2016-10-17 09:10:19 --> Database Driver Class Initialized
INFO - 2016-10-17 09:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 09:10:19 --> Parser Class Initialized
INFO - 2016-10-17 09:10:19 --> Controller Class Initialized
DEBUG - 2016-10-17 09:10:19 --> Home MX_Controller Initialized
INFO - 2016-10-17 09:10:19 --> Model Class Initialized
DEBUG - 2016-10-17 09:10:19 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 09:10:19 --> Model Class Initialized
ERROR - 2016-10-17 09:10:19 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 09:10:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 09:10:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 09:10:19 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-17 09:10:19 --> Final output sent to browser
DEBUG - 2016-10-17 09:10:19 --> Total execution time: 0.0575
INFO - 2016-10-17 09:44:27 --> Config Class Initialized
INFO - 2016-10-17 09:44:27 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:44:27 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:44:27 --> Utf8 Class Initialized
INFO - 2016-10-17 09:44:27 --> URI Class Initialized
INFO - 2016-10-17 09:44:27 --> Router Class Initialized
INFO - 2016-10-17 09:44:27 --> Output Class Initialized
INFO - 2016-10-17 09:44:27 --> Security Class Initialized
DEBUG - 2016-10-17 09:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:44:27 --> Input Class Initialized
INFO - 2016-10-17 09:44:27 --> Language Class Initialized
INFO - 2016-10-17 09:44:27 --> Language Class Initialized
INFO - 2016-10-17 09:44:27 --> Config Class Initialized
INFO - 2016-10-17 09:44:27 --> Loader Class Initialized
INFO - 2016-10-17 09:44:27 --> Helper loaded: common_helper
INFO - 2016-10-17 09:44:27 --> Helper loaded: url_helper
INFO - 2016-10-17 09:44:27 --> Database Driver Class Initialized
INFO - 2016-10-17 09:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 09:44:27 --> Parser Class Initialized
INFO - 2016-10-17 09:44:27 --> Controller Class Initialized
DEBUG - 2016-10-17 09:44:27 --> Home MX_Controller Initialized
INFO - 2016-10-17 09:44:27 --> Model Class Initialized
DEBUG - 2016-10-17 09:44:27 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 09:44:27 --> Model Class Initialized
INFO - 2016-10-17 09:44:32 --> Final output sent to browser
DEBUG - 2016-10-17 09:44:32 --> Total execution time: 5.0484
INFO - 2016-10-17 09:44:32 --> Config Class Initialized
INFO - 2016-10-17 09:44:32 --> Hooks Class Initialized
DEBUG - 2016-10-17 09:44:32 --> UTF-8 Support Enabled
INFO - 2016-10-17 09:44:32 --> Utf8 Class Initialized
INFO - 2016-10-17 09:44:32 --> URI Class Initialized
INFO - 2016-10-17 09:44:32 --> Router Class Initialized
INFO - 2016-10-17 09:44:32 --> Output Class Initialized
INFO - 2016-10-17 09:44:32 --> Security Class Initialized
DEBUG - 2016-10-17 09:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 09:44:32 --> Input Class Initialized
INFO - 2016-10-17 09:44:32 --> Language Class Initialized
ERROR - 2016-10-17 09:44:32 --> 404 Page Not Found: /index
INFO - 2016-10-17 11:13:07 --> Config Class Initialized
INFO - 2016-10-17 11:13:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:07 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:07 --> URI Class Initialized
INFO - 2016-10-17 11:13:07 --> Router Class Initialized
INFO - 2016-10-17 11:13:07 --> Output Class Initialized
INFO - 2016-10-17 11:13:07 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:07 --> Input Class Initialized
INFO - 2016-10-17 11:13:07 --> Language Class Initialized
INFO - 2016-10-17 11:13:07 --> Language Class Initialized
INFO - 2016-10-17 11:13:07 --> Config Class Initialized
INFO - 2016-10-17 11:13:07 --> Loader Class Initialized
INFO - 2016-10-17 11:13:07 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:07 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:07 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:07 --> Parser Class Initialized
INFO - 2016-10-17 11:13:07 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:07 --> Admincp MX_Controller Initialized
INFO - 2016-10-17 11:13:07 --> Config Class Initialized
INFO - 2016-10-17 11:13:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:07 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:07 --> URI Class Initialized
INFO - 2016-10-17 11:13:07 --> Router Class Initialized
INFO - 2016-10-17 11:13:07 --> Output Class Initialized
INFO - 2016-10-17 11:13:07 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:07 --> Input Class Initialized
INFO - 2016-10-17 11:13:07 --> Language Class Initialized
INFO - 2016-10-17 11:13:07 --> Language Class Initialized
INFO - 2016-10-17 11:13:07 --> Config Class Initialized
INFO - 2016-10-17 11:13:07 --> Loader Class Initialized
INFO - 2016-10-17 11:13:07 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:07 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:07 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:07 --> Parser Class Initialized
INFO - 2016-10-17 11:13:07 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:07 --> Admincp MX_Controller Initialized
INFO - 2016-10-17 11:13:07 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:07 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:13:07 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:07 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-17 11:13:07 --> Final output sent to browser
DEBUG - 2016-10-17 11:13:07 --> Total execution time: 0.0593
INFO - 2016-10-17 11:13:09 --> Config Class Initialized
INFO - 2016-10-17 11:13:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:09 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:09 --> URI Class Initialized
INFO - 2016-10-17 11:13:09 --> Router Class Initialized
INFO - 2016-10-17 11:13:09 --> Output Class Initialized
INFO - 2016-10-17 11:13:09 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:09 --> Input Class Initialized
INFO - 2016-10-17 11:13:09 --> Language Class Initialized
INFO - 2016-10-17 11:13:09 --> Language Class Initialized
INFO - 2016-10-17 11:13:09 --> Config Class Initialized
INFO - 2016-10-17 11:13:09 --> Loader Class Initialized
INFO - 2016-10-17 11:13:09 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:09 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:09 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:09 --> Parser Class Initialized
INFO - 2016-10-17 11:13:09 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:09 --> Admincp MX_Controller Initialized
INFO - 2016-10-17 11:13:09 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:13:09 --> Model Class Initialized
INFO - 2016-10-17 11:13:09 --> Final output sent to browser
DEBUG - 2016-10-17 11:13:09 --> Total execution time: 0.0537
INFO - 2016-10-17 11:13:09 --> Config Class Initialized
INFO - 2016-10-17 11:13:09 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:09 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:09 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:09 --> URI Class Initialized
INFO - 2016-10-17 11:13:09 --> Router Class Initialized
INFO - 2016-10-17 11:13:09 --> Output Class Initialized
INFO - 2016-10-17 11:13:09 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:09 --> Input Class Initialized
INFO - 2016-10-17 11:13:09 --> Language Class Initialized
INFO - 2016-10-17 11:13:09 --> Language Class Initialized
INFO - 2016-10-17 11:13:09 --> Config Class Initialized
INFO - 2016-10-17 11:13:09 --> Loader Class Initialized
INFO - 2016-10-17 11:13:09 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:09 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:09 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:09 --> Parser Class Initialized
INFO - 2016-10-17 11:13:09 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:09 --> Admincp MX_Controller Initialized
INFO - 2016-10-17 11:13:09 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:13:09 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-17 11:13:09 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:13:09 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-17 11:13:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 11:13:09 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-17 11:13:09 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:09 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-17 11:13:09 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-17 11:13:09 --> Final output sent to browser
DEBUG - 2016-10-17 11:13:09 --> Total execution time: 0.1069
INFO - 2016-10-17 11:13:10 --> Config Class Initialized
INFO - 2016-10-17 11:13:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:10 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:10 --> URI Class Initialized
INFO - 2016-10-17 11:13:10 --> Router Class Initialized
INFO - 2016-10-17 11:13:10 --> Output Class Initialized
INFO - 2016-10-17 11:13:10 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:10 --> Input Class Initialized
INFO - 2016-10-17 11:13:10 --> Language Class Initialized
ERROR - 2016-10-17 11:13:10 --> 404 Page Not Found: /index
INFO - 2016-10-17 11:13:10 --> Config Class Initialized
INFO - 2016-10-17 11:13:10 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:10 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:10 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:10 --> URI Class Initialized
INFO - 2016-10-17 11:13:10 --> Router Class Initialized
INFO - 2016-10-17 11:13:10 --> Output Class Initialized
INFO - 2016-10-17 11:13:10 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:10 --> Input Class Initialized
INFO - 2016-10-17 11:13:10 --> Language Class Initialized
INFO - 2016-10-17 11:13:10 --> Language Class Initialized
INFO - 2016-10-17 11:13:10 --> Config Class Initialized
INFO - 2016-10-17 11:13:10 --> Loader Class Initialized
INFO - 2016-10-17 11:13:10 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:10 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:10 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:11 --> Parser Class Initialized
INFO - 2016-10-17 11:13:11 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:11 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:13:11 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:11 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:13:11 --> Model Class Initialized
INFO - 2016-10-17 11:13:11 --> Config Class Initialized
INFO - 2016-10-17 11:13:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:11 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:11 --> URI Class Initialized
INFO - 2016-10-17 11:13:11 --> Router Class Initialized
INFO - 2016-10-17 11:13:11 --> Output Class Initialized
INFO - 2016-10-17 11:13:11 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:11 --> Input Class Initialized
INFO - 2016-10-17 11:13:11 --> Language Class Initialized
INFO - 2016-10-17 11:13:11 --> Language Class Initialized
INFO - 2016-10-17 11:13:11 --> Config Class Initialized
INFO - 2016-10-17 11:13:11 --> Loader Class Initialized
INFO - 2016-10-17 11:13:11 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:11 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:11 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:11 --> Parser Class Initialized
INFO - 2016-10-17 11:13:11 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:11 --> Admincp MX_Controller Initialized
INFO - 2016-10-17 11:13:11 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:13:11 --> Model Class Initialized
INFO - 2016-10-17 11:13:11 --> Config Class Initialized
INFO - 2016-10-17 11:13:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:11 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:11 --> URI Class Initialized
DEBUG - 2016-10-17 11:13:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/security_gt.php
INFO - 2016-10-17 11:13:11 --> Final output sent to browser
DEBUG - 2016-10-17 11:13:11 --> Total execution time: 0.0939
INFO - 2016-10-17 11:13:11 --> Router Class Initialized
INFO - 2016-10-17 11:13:11 --> Output Class Initialized
INFO - 2016-10-17 11:13:11 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:11 --> Input Class Initialized
INFO - 2016-10-17 11:13:11 --> Language Class Initialized
ERROR - 2016-10-17 11:13:11 --> 404 Page Not Found: /index
INFO - 2016-10-17 11:13:11 --> Config Class Initialized
INFO - 2016-10-17 11:13:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:11 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:11 --> URI Class Initialized
INFO - 2016-10-17 11:13:11 --> Router Class Initialized
INFO - 2016-10-17 11:13:11 --> Output Class Initialized
INFO - 2016-10-17 11:13:11 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:11 --> Input Class Initialized
INFO - 2016-10-17 11:13:11 --> Language Class Initialized
ERROR - 2016-10-17 11:13:11 --> 404 Page Not Found: /index
INFO - 2016-10-17 11:13:28 --> Config Class Initialized
INFO - 2016-10-17 11:13:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:28 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:28 --> URI Class Initialized
INFO - 2016-10-17 11:13:28 --> Router Class Initialized
INFO - 2016-10-17 11:13:28 --> Output Class Initialized
INFO - 2016-10-17 11:13:28 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:28 --> Input Class Initialized
INFO - 2016-10-17 11:13:28 --> Language Class Initialized
INFO - 2016-10-17 11:13:28 --> Language Class Initialized
INFO - 2016-10-17 11:13:28 --> Config Class Initialized
INFO - 2016-10-17 11:13:28 --> Loader Class Initialized
INFO - 2016-10-17 11:13:28 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:28 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:28 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:28 --> Parser Class Initialized
INFO - 2016-10-17 11:13:28 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:28 --> Admincp MX_Controller Initialized
INFO - 2016-10-17 11:13:28 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:13:28 --> Model Class Initialized
INFO - 2016-10-17 11:13:28 --> Config Class Initialized
INFO - 2016-10-17 11:13:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:28 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:28 --> URI Class Initialized
INFO - 2016-10-17 11:13:28 --> Router Class Initialized
INFO - 2016-10-17 11:13:28 --> Output Class Initialized
INFO - 2016-10-17 11:13:28 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:28 --> Input Class Initialized
INFO - 2016-10-17 11:13:28 --> Language Class Initialized
INFO - 2016-10-17 11:13:28 --> Language Class Initialized
INFO - 2016-10-17 11:13:28 --> Config Class Initialized
INFO - 2016-10-17 11:13:28 --> Loader Class Initialized
INFO - 2016-10-17 11:13:28 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:28 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:28 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:28 --> Parser Class Initialized
INFO - 2016-10-17 11:13:28 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:28 --> Admincp MX_Controller Initialized
INFO - 2016-10-17 11:13:28 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:13:28 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/setting.php
ERROR - 2016-10-17 11:13:28 --> Severity: Notice --> Undefined variable: module /home/dolongpk/public_html/application/views/BACKEND/template.php 11
DEBUG - 2016-10-17 11:13:28 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:13:28 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-17 11:13:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 11:13:28 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-17 11:13:28 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-17 11:13:28 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-17 11:13:28 --> Final output sent to browser
DEBUG - 2016-10-17 11:13:28 --> Total execution time: 0.0673
INFO - 2016-10-17 11:13:31 --> Config Class Initialized
INFO - 2016-10-17 11:13:31 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:31 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:31 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:31 --> URI Class Initialized
INFO - 2016-10-17 11:13:31 --> Router Class Initialized
INFO - 2016-10-17 11:13:31 --> Output Class Initialized
INFO - 2016-10-17 11:13:31 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:31 --> Input Class Initialized
INFO - 2016-10-17 11:13:31 --> Language Class Initialized
INFO - 2016-10-17 11:13:31 --> Language Class Initialized
INFO - 2016-10-17 11:13:31 --> Config Class Initialized
INFO - 2016-10-17 11:13:31 --> Loader Class Initialized
INFO - 2016-10-17 11:13:31 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:31 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:31 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:31 --> Parser Class Initialized
INFO - 2016-10-17 11:13:31 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:31 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:13:31 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:31 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:13:31 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:31 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-17 11:13:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-17 11:13:31 --> Final output sent to browser
DEBUG - 2016-10-17 11:13:31 --> Total execution time: 0.0693
INFO - 2016-10-17 11:13:32 --> Config Class Initialized
INFO - 2016-10-17 11:13:32 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:32 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:32 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:32 --> URI Class Initialized
INFO - 2016-10-17 11:13:32 --> Router Class Initialized
INFO - 2016-10-17 11:13:32 --> Output Class Initialized
INFO - 2016-10-17 11:13:32 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:32 --> Input Class Initialized
INFO - 2016-10-17 11:13:32 --> Language Class Initialized
INFO - 2016-10-17 11:13:32 --> Language Class Initialized
INFO - 2016-10-17 11:13:32 --> Config Class Initialized
INFO - 2016-10-17 11:13:32 --> Loader Class Initialized
INFO - 2016-10-17 11:13:32 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:32 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:32 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:32 --> Parser Class Initialized
INFO - 2016-10-17 11:13:32 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:32 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:13:32 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:32 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:13:32 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:32 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-17 11:13:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-17 11:13:32 --> Final output sent to browser
DEBUG - 2016-10-17 11:13:32 --> Total execution time: 0.0417
INFO - 2016-10-17 11:13:37 --> Config Class Initialized
INFO - 2016-10-17 11:13:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:37 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:37 --> URI Class Initialized
INFO - 2016-10-17 11:13:37 --> Router Class Initialized
INFO - 2016-10-17 11:13:37 --> Output Class Initialized
INFO - 2016-10-17 11:13:37 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:37 --> Input Class Initialized
INFO - 2016-10-17 11:13:37 --> Language Class Initialized
INFO - 2016-10-17 11:13:37 --> Language Class Initialized
INFO - 2016-10-17 11:13:37 --> Config Class Initialized
INFO - 2016-10-17 11:13:37 --> Loader Class Initialized
INFO - 2016-10-17 11:13:37 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:37 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:37 --> Database Driver Class Initialized
INFO - 2016-10-17 11:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:13:37 --> Parser Class Initialized
INFO - 2016-10-17 11:13:37 --> Controller Class Initialized
DEBUG - 2016-10-17 11:13:37 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:13:37 --> Model Class Initialized
DEBUG - 2016-10-17 11:13:37 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:13:37 --> Model Class Initialized
INFO - 2016-10-17 11:13:39 --> Config Class Initialized
INFO - 2016-10-17 11:13:39 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:13:39 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:13:39 --> Utf8 Class Initialized
INFO - 2016-10-17 11:13:39 --> URI Class Initialized
INFO - 2016-10-17 11:13:39 --> Router Class Initialized
INFO - 2016-10-17 11:13:39 --> Output Class Initialized
INFO - 2016-10-17 11:13:39 --> Security Class Initialized
DEBUG - 2016-10-17 11:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:13:39 --> Input Class Initialized
INFO - 2016-10-17 11:13:39 --> Language Class Initialized
INFO - 2016-10-17 11:13:39 --> Language Class Initialized
INFO - 2016-10-17 11:13:39 --> Config Class Initialized
INFO - 2016-10-17 11:13:39 --> Loader Class Initialized
INFO - 2016-10-17 11:13:39 --> Helper loaded: common_helper
INFO - 2016-10-17 11:13:39 --> Helper loaded: url_helper
INFO - 2016-10-17 11:13:39 --> Database Driver Class Initialized
ERROR - 2016-10-17 11:14:38 --> Severity: Warning --> file_get_contents(http://103.27.60.212:8888/api_tan.php): failed to open stream: Connection timed out /home/dolongpk/public_html/application/modules/gametool/controllers/Gametool.php 65
INFO - 2016-10-17 11:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:14:38 --> Parser Class Initialized
INFO - 2016-10-17 11:14:38 --> Controller Class Initialized
DEBUG - 2016-10-17 11:14:38 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:14:38 --> Model Class Initialized
DEBUG - 2016-10-17 11:14:38 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:14:38 --> Model Class Initialized
ERROR - 2016-10-17 11:14:38 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `cli_servers`
WHERE `id` = 1
INFO - 2016-10-17 11:14:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 11:15:45 --> Config Class Initialized
INFO - 2016-10-17 11:15:45 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:15:45 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:15:45 --> Utf8 Class Initialized
INFO - 2016-10-17 11:15:45 --> URI Class Initialized
INFO - 2016-10-17 11:15:45 --> Router Class Initialized
INFO - 2016-10-17 11:15:45 --> Output Class Initialized
INFO - 2016-10-17 11:15:45 --> Security Class Initialized
DEBUG - 2016-10-17 11:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:15:45 --> Input Class Initialized
INFO - 2016-10-17 11:15:45 --> Language Class Initialized
INFO - 2016-10-17 11:15:45 --> Language Class Initialized
INFO - 2016-10-17 11:15:45 --> Config Class Initialized
INFO - 2016-10-17 11:15:45 --> Loader Class Initialized
INFO - 2016-10-17 11:15:45 --> Helper loaded: common_helper
INFO - 2016-10-17 11:15:45 --> Helper loaded: url_helper
INFO - 2016-10-17 11:15:45 --> Database Driver Class Initialized
INFO - 2016-10-17 11:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:15:45 --> Parser Class Initialized
INFO - 2016-10-17 11:15:45 --> Controller Class Initialized
DEBUG - 2016-10-17 11:15:45 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:15:45 --> Model Class Initialized
DEBUG - 2016-10-17 11:15:45 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:15:45 --> Model Class Initialized
DEBUG - 2016-10-17 11:15:45 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-17 11:15:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-17 11:15:45 --> Final output sent to browser
DEBUG - 2016-10-17 11:15:45 --> Total execution time: 0.0420
INFO - 2016-10-17 11:15:57 --> Config Class Initialized
INFO - 2016-10-17 11:15:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:15:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:15:57 --> Utf8 Class Initialized
INFO - 2016-10-17 11:15:57 --> URI Class Initialized
INFO - 2016-10-17 11:15:57 --> Router Class Initialized
INFO - 2016-10-17 11:15:57 --> Output Class Initialized
INFO - 2016-10-17 11:15:57 --> Security Class Initialized
DEBUG - 2016-10-17 11:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:15:57 --> Input Class Initialized
INFO - 2016-10-17 11:15:57 --> Language Class Initialized
INFO - 2016-10-17 11:15:57 --> Language Class Initialized
INFO - 2016-10-17 11:15:57 --> Config Class Initialized
INFO - 2016-10-17 11:15:57 --> Loader Class Initialized
INFO - 2016-10-17 11:15:57 --> Helper loaded: common_helper
INFO - 2016-10-17 11:15:57 --> Helper loaded: url_helper
INFO - 2016-10-17 11:15:57 --> Database Driver Class Initialized
INFO - 2016-10-17 11:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:15:57 --> Parser Class Initialized
INFO - 2016-10-17 11:15:57 --> Controller Class Initialized
DEBUG - 2016-10-17 11:15:57 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:15:57 --> Model Class Initialized
DEBUG - 2016-10-17 11:15:58 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:15:58 --> Model Class Initialized
INFO - 2016-10-17 11:15:59 --> Config Class Initialized
INFO - 2016-10-17 11:15:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:15:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:15:59 --> Utf8 Class Initialized
INFO - 2016-10-17 11:15:59 --> URI Class Initialized
INFO - 2016-10-17 11:15:59 --> Router Class Initialized
INFO - 2016-10-17 11:15:59 --> Output Class Initialized
INFO - 2016-10-17 11:15:59 --> Security Class Initialized
DEBUG - 2016-10-17 11:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:15:59 --> Input Class Initialized
INFO - 2016-10-17 11:15:59 --> Language Class Initialized
INFO - 2016-10-17 11:15:59 --> Language Class Initialized
INFO - 2016-10-17 11:15:59 --> Config Class Initialized
INFO - 2016-10-17 11:15:59 --> Loader Class Initialized
INFO - 2016-10-17 11:15:59 --> Helper loaded: common_helper
INFO - 2016-10-17 11:15:59 --> Helper loaded: url_helper
INFO - 2016-10-17 11:15:59 --> Database Driver Class Initialized
ERROR - 2016-10-17 11:16:58 --> Severity: Warning --> file_get_contents(http://103.27.60.212:8888/api_tan.php): failed to open stream: Connection timed out /home/dolongpk/public_html/application/modules/gametool/controllers/Gametool.php 65
INFO - 2016-10-17 11:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:16:58 --> Parser Class Initialized
INFO - 2016-10-17 11:16:58 --> Controller Class Initialized
DEBUG - 2016-10-17 11:16:58 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:16:58 --> Model Class Initialized
DEBUG - 2016-10-17 11:16:58 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:16:58 --> Model Class Initialized
ERROR - 2016-10-17 11:16:58 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `cli_servers`
WHERE `id` = 1
INFO - 2016-10-17 11:16:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 11:46:18 --> Config Class Initialized
INFO - 2016-10-17 11:46:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:46:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:46:18 --> Utf8 Class Initialized
INFO - 2016-10-17 11:46:18 --> URI Class Initialized
INFO - 2016-10-17 11:46:18 --> Router Class Initialized
INFO - 2016-10-17 11:46:18 --> Output Class Initialized
INFO - 2016-10-17 11:46:18 --> Security Class Initialized
DEBUG - 2016-10-17 11:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:46:18 --> Input Class Initialized
INFO - 2016-10-17 11:46:18 --> Language Class Initialized
INFO - 2016-10-17 11:46:18 --> Language Class Initialized
INFO - 2016-10-17 11:46:18 --> Config Class Initialized
INFO - 2016-10-17 11:46:18 --> Loader Class Initialized
INFO - 2016-10-17 11:46:18 --> Helper loaded: common_helper
INFO - 2016-10-17 11:46:18 --> Helper loaded: url_helper
INFO - 2016-10-17 11:46:18 --> Database Driver Class Initialized
INFO - 2016-10-17 11:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:46:18 --> Parser Class Initialized
INFO - 2016-10-17 11:46:18 --> Controller Class Initialized
DEBUG - 2016-10-17 11:46:18 --> Admincp MX_Controller Initialized
INFO - 2016-10-17 11:46:18 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:46:18 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-17 11:46:18 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-17 11:46:18 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-17 11:46:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 11:46:18 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-17 11:46:18 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-17 11:46:18 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-17 11:46:18 --> Final output sent to browser
DEBUG - 2016-10-17 11:46:18 --> Total execution time: 0.0513
INFO - 2016-10-17 11:46:19 --> Config Class Initialized
INFO - 2016-10-17 11:46:19 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:46:19 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:46:19 --> Utf8 Class Initialized
INFO - 2016-10-17 11:46:19 --> URI Class Initialized
INFO - 2016-10-17 11:46:19 --> Router Class Initialized
INFO - 2016-10-17 11:46:19 --> Output Class Initialized
INFO - 2016-10-17 11:46:19 --> Security Class Initialized
DEBUG - 2016-10-17 11:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:46:19 --> Input Class Initialized
INFO - 2016-10-17 11:46:19 --> Language Class Initialized
ERROR - 2016-10-17 11:46:19 --> 404 Page Not Found: /index
INFO - 2016-10-17 11:46:20 --> Config Class Initialized
INFO - 2016-10-17 11:46:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:46:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:46:20 --> Utf8 Class Initialized
INFO - 2016-10-17 11:46:20 --> URI Class Initialized
INFO - 2016-10-17 11:46:20 --> Router Class Initialized
INFO - 2016-10-17 11:46:20 --> Output Class Initialized
INFO - 2016-10-17 11:46:20 --> Security Class Initialized
DEBUG - 2016-10-17 11:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:46:20 --> Input Class Initialized
INFO - 2016-10-17 11:46:20 --> Language Class Initialized
INFO - 2016-10-17 11:46:20 --> Language Class Initialized
INFO - 2016-10-17 11:46:20 --> Config Class Initialized
INFO - 2016-10-17 11:46:20 --> Loader Class Initialized
INFO - 2016-10-17 11:46:20 --> Helper loaded: common_helper
INFO - 2016-10-17 11:46:20 --> Helper loaded: url_helper
INFO - 2016-10-17 11:46:20 --> Database Driver Class Initialized
INFO - 2016-10-17 11:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:46:20 --> Parser Class Initialized
INFO - 2016-10-17 11:46:20 --> Controller Class Initialized
DEBUG - 2016-10-17 11:46:20 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:46:20 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:20 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:46:20 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:20 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-17 11:46:20 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-17 11:46:20 --> Final output sent to browser
DEBUG - 2016-10-17 11:46:20 --> Total execution time: 0.0432
INFO - 2016-10-17 11:46:22 --> Config Class Initialized
INFO - 2016-10-17 11:46:22 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:46:22 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:46:22 --> Utf8 Class Initialized
INFO - 2016-10-17 11:46:22 --> URI Class Initialized
INFO - 2016-10-17 11:46:22 --> Router Class Initialized
INFO - 2016-10-17 11:46:22 --> Output Class Initialized
INFO - 2016-10-17 11:46:22 --> Security Class Initialized
DEBUG - 2016-10-17 11:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:46:22 --> Input Class Initialized
INFO - 2016-10-17 11:46:22 --> Language Class Initialized
INFO - 2016-10-17 11:46:22 --> Language Class Initialized
INFO - 2016-10-17 11:46:22 --> Config Class Initialized
INFO - 2016-10-17 11:46:22 --> Loader Class Initialized
INFO - 2016-10-17 11:46:22 --> Helper loaded: common_helper
INFO - 2016-10-17 11:46:22 --> Helper loaded: url_helper
INFO - 2016-10-17 11:46:22 --> Database Driver Class Initialized
INFO - 2016-10-17 11:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:46:22 --> Parser Class Initialized
INFO - 2016-10-17 11:46:22 --> Controller Class Initialized
DEBUG - 2016-10-17 11:46:22 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:46:22 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:22 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:46:22 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:22 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-17 11:46:22 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-17 11:46:22 --> Final output sent to browser
DEBUG - 2016-10-17 11:46:22 --> Total execution time: 0.0427
INFO - 2016-10-17 11:46:27 --> Config Class Initialized
INFO - 2016-10-17 11:46:27 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:46:27 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:46:27 --> Utf8 Class Initialized
INFO - 2016-10-17 11:46:27 --> URI Class Initialized
INFO - 2016-10-17 11:46:28 --> Router Class Initialized
INFO - 2016-10-17 11:46:28 --> Output Class Initialized
INFO - 2016-10-17 11:46:28 --> Security Class Initialized
DEBUG - 2016-10-17 11:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:46:28 --> Input Class Initialized
INFO - 2016-10-17 11:46:28 --> Language Class Initialized
INFO - 2016-10-17 11:46:28 --> Language Class Initialized
INFO - 2016-10-17 11:46:28 --> Config Class Initialized
INFO - 2016-10-17 11:46:28 --> Loader Class Initialized
INFO - 2016-10-17 11:46:28 --> Helper loaded: common_helper
INFO - 2016-10-17 11:46:28 --> Helper loaded: url_helper
INFO - 2016-10-17 11:46:28 --> Database Driver Class Initialized
INFO - 2016-10-17 11:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:46:28 --> Parser Class Initialized
INFO - 2016-10-17 11:46:28 --> Controller Class Initialized
DEBUG - 2016-10-17 11:46:28 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:46:28 --> Model Class Initialized
DEBUG - 2016-10-17 11:46:28 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:46:28 --> Model Class Initialized
INFO - 2016-10-17 11:46:29 --> Config Class Initialized
INFO - 2016-10-17 11:46:29 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:46:29 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:46:29 --> Utf8 Class Initialized
INFO - 2016-10-17 11:46:29 --> URI Class Initialized
INFO - 2016-10-17 11:46:29 --> Router Class Initialized
INFO - 2016-10-17 11:46:29 --> Output Class Initialized
INFO - 2016-10-17 11:46:29 --> Security Class Initialized
DEBUG - 2016-10-17 11:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:46:29 --> Input Class Initialized
INFO - 2016-10-17 11:46:29 --> Language Class Initialized
INFO - 2016-10-17 11:46:29 --> Language Class Initialized
INFO - 2016-10-17 11:46:29 --> Config Class Initialized
INFO - 2016-10-17 11:46:29 --> Loader Class Initialized
INFO - 2016-10-17 11:46:29 --> Helper loaded: common_helper
INFO - 2016-10-17 11:46:29 --> Helper loaded: url_helper
INFO - 2016-10-17 11:46:29 --> Database Driver Class Initialized
INFO - 2016-10-17 11:46:41 --> Config Class Initialized
INFO - 2016-10-17 11:46:41 --> Hooks Class Initialized
DEBUG - 2016-10-17 11:46:41 --> UTF-8 Support Enabled
INFO - 2016-10-17 11:46:41 --> Utf8 Class Initialized
INFO - 2016-10-17 11:46:41 --> URI Class Initialized
INFO - 2016-10-17 11:46:41 --> Router Class Initialized
INFO - 2016-10-17 11:46:41 --> Output Class Initialized
INFO - 2016-10-17 11:46:41 --> Security Class Initialized
DEBUG - 2016-10-17 11:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 11:46:41 --> Input Class Initialized
INFO - 2016-10-17 11:46:41 --> Language Class Initialized
INFO - 2016-10-17 11:46:41 --> Language Class Initialized
INFO - 2016-10-17 11:46:41 --> Config Class Initialized
INFO - 2016-10-17 11:46:41 --> Loader Class Initialized
INFO - 2016-10-17 11:46:41 --> Helper loaded: common_helper
INFO - 2016-10-17 11:46:41 --> Helper loaded: url_helper
INFO - 2016-10-17 11:46:41 --> Database Driver Class Initialized
INFO - 2016-10-17 11:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:47:31 --> Parser Class Initialized
INFO - 2016-10-17 11:47:31 --> Controller Class Initialized
DEBUG - 2016-10-17 11:47:31 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:47:31 --> Model Class Initialized
DEBUG - 2016-10-17 11:47:31 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:47:31 --> Model Class Initialized
ERROR - 2016-10-17 11:47:31 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `cli_servers`
WHERE `id` = 1
INFO - 2016-10-17 11:47:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 11:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 11:47:31 --> Parser Class Initialized
INFO - 2016-10-17 11:47:31 --> Controller Class Initialized
DEBUG - 2016-10-17 11:47:31 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 11:47:31 --> Model Class Initialized
DEBUG - 2016-10-17 11:47:31 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 11:47:31 --> Model Class Initialized
ERROR - 2016-10-17 11:47:31 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `cli_servers`
WHERE `id` = 1
INFO - 2016-10-17 11:47:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 12:23:52 --> Config Class Initialized
INFO - 2016-10-17 12:23:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:23:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:23:52 --> Utf8 Class Initialized
INFO - 2016-10-17 12:23:52 --> URI Class Initialized
INFO - 2016-10-17 12:23:52 --> Router Class Initialized
INFO - 2016-10-17 12:23:52 --> Output Class Initialized
INFO - 2016-10-17 12:23:52 --> Security Class Initialized
DEBUG - 2016-10-17 12:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:23:52 --> Input Class Initialized
INFO - 2016-10-17 12:23:52 --> Language Class Initialized
INFO - 2016-10-17 12:23:52 --> Language Class Initialized
INFO - 2016-10-17 12:23:52 --> Config Class Initialized
INFO - 2016-10-17 12:23:52 --> Loader Class Initialized
INFO - 2016-10-17 12:23:52 --> Helper loaded: common_helper
INFO - 2016-10-17 12:23:52 --> Helper loaded: url_helper
INFO - 2016-10-17 12:23:52 --> Database Driver Class Initialized
INFO - 2016-10-17 12:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:23:52 --> Parser Class Initialized
INFO - 2016-10-17 12:23:52 --> Controller Class Initialized
DEBUG - 2016-10-17 12:23:52 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 12:23:52 --> Model Class Initialized
DEBUG - 2016-10-17 12:23:52 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 12:23:52 --> Model Class Initialized
DEBUG - 2016-10-17 12:23:52 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-17 12:23:52 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-17 12:23:52 --> Final output sent to browser
DEBUG - 2016-10-17 12:23:52 --> Total execution time: 0.0454
INFO - 2016-10-17 12:31:17 --> Config Class Initialized
INFO - 2016-10-17 12:31:17 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:31:17 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:31:17 --> Utf8 Class Initialized
INFO - 2016-10-17 12:31:17 --> URI Class Initialized
INFO - 2016-10-17 12:31:17 --> Router Class Initialized
INFO - 2016-10-17 12:31:17 --> Output Class Initialized
INFO - 2016-10-17 12:31:17 --> Security Class Initialized
DEBUG - 2016-10-17 12:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:31:17 --> Input Class Initialized
INFO - 2016-10-17 12:31:17 --> Language Class Initialized
INFO - 2016-10-17 12:31:17 --> Language Class Initialized
INFO - 2016-10-17 12:31:17 --> Config Class Initialized
INFO - 2016-10-17 12:31:17 --> Loader Class Initialized
INFO - 2016-10-17 12:31:17 --> Helper loaded: common_helper
INFO - 2016-10-17 12:31:17 --> Helper loaded: url_helper
INFO - 2016-10-17 12:31:17 --> Database Driver Class Initialized
INFO - 2016-10-17 12:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:31:17 --> Parser Class Initialized
INFO - 2016-10-17 12:31:17 --> Controller Class Initialized
DEBUG - 2016-10-17 12:31:17 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 12:31:17 --> Model Class Initialized
DEBUG - 2016-10-17 12:31:17 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 12:31:17 --> Model Class Initialized
DEBUG - 2016-10-17 12:31:17 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-17 12:31:17 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-17 12:31:17 --> Final output sent to browser
DEBUG - 2016-10-17 12:31:17 --> Total execution time: 0.0567
INFO - 2016-10-17 12:31:24 --> Config Class Initialized
INFO - 2016-10-17 12:31:24 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:31:24 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:31:24 --> Utf8 Class Initialized
INFO - 2016-10-17 12:31:24 --> URI Class Initialized
INFO - 2016-10-17 12:31:24 --> Router Class Initialized
INFO - 2016-10-17 12:31:24 --> Output Class Initialized
INFO - 2016-10-17 12:31:24 --> Security Class Initialized
DEBUG - 2016-10-17 12:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:31:24 --> Input Class Initialized
INFO - 2016-10-17 12:31:24 --> Language Class Initialized
INFO - 2016-10-17 12:31:24 --> Language Class Initialized
INFO - 2016-10-17 12:31:24 --> Config Class Initialized
INFO - 2016-10-17 12:31:24 --> Loader Class Initialized
INFO - 2016-10-17 12:31:24 --> Helper loaded: common_helper
INFO - 2016-10-17 12:31:24 --> Helper loaded: url_helper
INFO - 2016-10-17 12:31:24 --> Database Driver Class Initialized
INFO - 2016-10-17 12:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:31:24 --> Parser Class Initialized
INFO - 2016-10-17 12:31:24 --> Controller Class Initialized
DEBUG - 2016-10-17 12:31:24 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 12:31:24 --> Model Class Initialized
DEBUG - 2016-10-17 12:31:24 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 12:31:24 --> Model Class Initialized
INFO - 2016-10-17 12:31:25 --> Config Class Initialized
INFO - 2016-10-17 12:31:25 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:31:25 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:31:25 --> Utf8 Class Initialized
INFO - 2016-10-17 12:31:25 --> URI Class Initialized
INFO - 2016-10-17 12:31:25 --> Router Class Initialized
INFO - 2016-10-17 12:31:25 --> Output Class Initialized
INFO - 2016-10-17 12:31:25 --> Security Class Initialized
DEBUG - 2016-10-17 12:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:31:25 --> Input Class Initialized
INFO - 2016-10-17 12:31:25 --> Language Class Initialized
INFO - 2016-10-17 12:31:25 --> Language Class Initialized
INFO - 2016-10-17 12:31:25 --> Config Class Initialized
INFO - 2016-10-17 12:31:25 --> Loader Class Initialized
INFO - 2016-10-17 12:31:26 --> Helper loaded: common_helper
INFO - 2016-10-17 12:31:26 --> Helper loaded: url_helper
INFO - 2016-10-17 12:31:26 --> Database Driver Class Initialized
INFO - 2016-10-17 12:31:34 --> Config Class Initialized
INFO - 2016-10-17 12:31:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:31:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:31:34 --> Utf8 Class Initialized
INFO - 2016-10-17 12:31:34 --> URI Class Initialized
INFO - 2016-10-17 12:31:34 --> Router Class Initialized
INFO - 2016-10-17 12:31:34 --> Output Class Initialized
INFO - 2016-10-17 12:31:34 --> Security Class Initialized
DEBUG - 2016-10-17 12:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:31:34 --> Input Class Initialized
INFO - 2016-10-17 12:31:34 --> Language Class Initialized
INFO - 2016-10-17 12:31:34 --> Language Class Initialized
INFO - 2016-10-17 12:31:34 --> Config Class Initialized
INFO - 2016-10-17 12:31:34 --> Loader Class Initialized
INFO - 2016-10-17 12:31:34 --> Helper loaded: common_helper
INFO - 2016-10-17 12:31:34 --> Helper loaded: url_helper
INFO - 2016-10-17 12:31:34 --> Database Driver Class Initialized
INFO - 2016-10-17 12:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:32:27 --> Parser Class Initialized
INFO - 2016-10-17 12:32:27 --> Controller Class Initialized
DEBUG - 2016-10-17 12:32:27 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 12:32:27 --> Model Class Initialized
DEBUG - 2016-10-17 12:32:27 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 12:32:27 --> Model Class Initialized
ERROR - 2016-10-17 12:32:27 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `cli_servers`
WHERE `id` = 1
INFO - 2016-10-17 12:32:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 12:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:32:27 --> Parser Class Initialized
INFO - 2016-10-17 12:32:27 --> Controller Class Initialized
DEBUG - 2016-10-17 12:32:27 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 12:32:27 --> Model Class Initialized
DEBUG - 2016-10-17 12:32:27 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 12:32:27 --> Model Class Initialized
ERROR - 2016-10-17 12:32:27 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `cli_servers`
WHERE `id` = 1
INFO - 2016-10-17 12:32:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-17 12:33:50 --> Config Class Initialized
INFO - 2016-10-17 12:33:50 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:33:50 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:33:50 --> Utf8 Class Initialized
INFO - 2016-10-17 12:33:50 --> URI Class Initialized
INFO - 2016-10-17 12:33:50 --> Router Class Initialized
INFO - 2016-10-17 12:33:50 --> Output Class Initialized
INFO - 2016-10-17 12:33:50 --> Security Class Initialized
DEBUG - 2016-10-17 12:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:33:50 --> Input Class Initialized
INFO - 2016-10-17 12:33:50 --> Language Class Initialized
INFO - 2016-10-17 12:33:50 --> Language Class Initialized
INFO - 2016-10-17 12:33:50 --> Config Class Initialized
INFO - 2016-10-17 12:33:50 --> Loader Class Initialized
INFO - 2016-10-17 12:33:50 --> Helper loaded: common_helper
INFO - 2016-10-17 12:33:50 --> Helper loaded: url_helper
INFO - 2016-10-17 12:33:50 --> Database Driver Class Initialized
INFO - 2016-10-17 12:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:33:50 --> Parser Class Initialized
INFO - 2016-10-17 12:33:50 --> Controller Class Initialized
DEBUG - 2016-10-17 12:33:50 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 12:33:50 --> Model Class Initialized
DEBUG - 2016-10-17 12:33:50 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 12:33:50 --> Model Class Initialized
DEBUG - 2016-10-17 12:33:50 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-17 12:33:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-17 12:33:50 --> Final output sent to browser
DEBUG - 2016-10-17 12:33:50 --> Total execution time: 0.0447
INFO - 2016-10-17 12:33:57 --> Config Class Initialized
INFO - 2016-10-17 12:33:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 12:33:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 12:33:57 --> Utf8 Class Initialized
INFO - 2016-10-17 12:33:57 --> URI Class Initialized
INFO - 2016-10-17 12:33:57 --> Router Class Initialized
INFO - 2016-10-17 12:33:57 --> Output Class Initialized
INFO - 2016-10-17 12:33:57 --> Security Class Initialized
DEBUG - 2016-10-17 12:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 12:33:57 --> Input Class Initialized
INFO - 2016-10-17 12:33:57 --> Language Class Initialized
INFO - 2016-10-17 12:33:57 --> Language Class Initialized
INFO - 2016-10-17 12:33:57 --> Config Class Initialized
INFO - 2016-10-17 12:33:57 --> Loader Class Initialized
INFO - 2016-10-17 12:33:57 --> Helper loaded: common_helper
INFO - 2016-10-17 12:33:57 --> Helper loaded: url_helper
INFO - 2016-10-17 12:33:57 --> Database Driver Class Initialized
INFO - 2016-10-17 12:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 12:33:57 --> Parser Class Initialized
INFO - 2016-10-17 12:33:57 --> Controller Class Initialized
DEBUG - 2016-10-17 12:33:57 --> Gametool MX_Controller Initialized
INFO - 2016-10-17 12:33:57 --> Model Class Initialized
DEBUG - 2016-10-17 12:33:57 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-17 12:33:57 --> Model Class Initialized
INFO - 2016-10-17 14:11:11 --> Config Class Initialized
INFO - 2016-10-17 14:11:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:11:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:11:11 --> Utf8 Class Initialized
INFO - 2016-10-17 14:11:11 --> URI Class Initialized
INFO - 2016-10-17 14:11:11 --> Router Class Initialized
INFO - 2016-10-17 14:11:11 --> Output Class Initialized
INFO - 2016-10-17 14:11:11 --> Security Class Initialized
DEBUG - 2016-10-17 14:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:11:11 --> Input Class Initialized
INFO - 2016-10-17 14:11:11 --> Language Class Initialized
INFO - 2016-10-17 14:11:11 --> Language Class Initialized
INFO - 2016-10-17 14:11:11 --> Config Class Initialized
INFO - 2016-10-17 14:11:11 --> Loader Class Initialized
INFO - 2016-10-17 14:11:11 --> Helper loaded: common_helper
INFO - 2016-10-17 14:11:11 --> Helper loaded: url_helper
INFO - 2016-10-17 14:11:11 --> Database Driver Class Initialized
INFO - 2016-10-17 14:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:11:11 --> Parser Class Initialized
INFO - 2016-10-17 14:11:11 --> Controller Class Initialized
DEBUG - 2016-10-17 14:11:11 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:11:11 --> Model Class Initialized
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:11:11 --> Model Class Initialized
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-17 14:11:11 --> Content MX_Controller Initialized
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-17 14:11:11 --> Model Class Initialized
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-17 14:11:11 --> Slider MX_Controller Initialized
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-17 14:11:11 --> Model Class Initialized
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-17 14:11:11 --> Servers MX_Controller Initialized
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-17 14:11:11 --> Model Class Initialized
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-17 14:11:11 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 14:11:11 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-17 14:11:11 --> Final output sent to browser
DEBUG - 2016-10-17 14:11:11 --> Total execution time: 0.0776
INFO - 2016-10-17 14:11:12 --> Config Class Initialized
INFO - 2016-10-17 14:11:12 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:11:12 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:11:12 --> Utf8 Class Initialized
INFO - 2016-10-17 14:11:12 --> URI Class Initialized
INFO - 2016-10-17 14:11:12 --> Router Class Initialized
INFO - 2016-10-17 14:11:12 --> Output Class Initialized
INFO - 2016-10-17 14:11:12 --> Security Class Initialized
DEBUG - 2016-10-17 14:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:11:12 --> Input Class Initialized
INFO - 2016-10-17 14:11:12 --> Language Class Initialized
ERROR - 2016-10-17 14:11:12 --> 404 Page Not Found: /index
INFO - 2016-10-17 14:11:13 --> Config Class Initialized
INFO - 2016-10-17 14:11:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:11:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:11:13 --> Utf8 Class Initialized
INFO - 2016-10-17 14:11:13 --> URI Class Initialized
INFO - 2016-10-17 14:11:13 --> Router Class Initialized
INFO - 2016-10-17 14:11:13 --> Output Class Initialized
INFO - 2016-10-17 14:11:13 --> Security Class Initialized
DEBUG - 2016-10-17 14:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:11:13 --> Input Class Initialized
INFO - 2016-10-17 14:11:13 --> Language Class Initialized
INFO - 2016-10-17 14:11:13 --> Language Class Initialized
INFO - 2016-10-17 14:11:13 --> Config Class Initialized
INFO - 2016-10-17 14:11:13 --> Loader Class Initialized
INFO - 2016-10-17 14:11:13 --> Helper loaded: common_helper
INFO - 2016-10-17 14:11:13 --> Helper loaded: url_helper
INFO - 2016-10-17 14:11:13 --> Database Driver Class Initialized
INFO - 2016-10-17 14:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:11:13 --> Parser Class Initialized
INFO - 2016-10-17 14:11:13 --> Controller Class Initialized
DEBUG - 2016-10-17 14:11:13 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:11:13 --> Model Class Initialized
DEBUG - 2016-10-17 14:11:13 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:11:13 --> Model Class Initialized
INFO - 2016-10-17 14:11:13 --> Final output sent to browser
DEBUG - 2016-10-17 14:11:13 --> Total execution time: 0.4783
INFO - 2016-10-17 14:13:13 --> Config Class Initialized
INFO - 2016-10-17 14:13:13 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:13:13 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:13:13 --> Utf8 Class Initialized
INFO - 2016-10-17 14:13:13 --> URI Class Initialized
INFO - 2016-10-17 14:13:13 --> Router Class Initialized
INFO - 2016-10-17 14:13:13 --> Output Class Initialized
INFO - 2016-10-17 14:13:13 --> Security Class Initialized
DEBUG - 2016-10-17 14:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:13:13 --> Input Class Initialized
INFO - 2016-10-17 14:13:13 --> Language Class Initialized
INFO - 2016-10-17 14:13:13 --> Language Class Initialized
INFO - 2016-10-17 14:13:13 --> Config Class Initialized
INFO - 2016-10-17 14:13:13 --> Loader Class Initialized
INFO - 2016-10-17 14:13:13 --> Helper loaded: common_helper
INFO - 2016-10-17 14:13:13 --> Helper loaded: url_helper
INFO - 2016-10-17 14:13:13 --> Database Driver Class Initialized
INFO - 2016-10-17 14:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:13:13 --> Parser Class Initialized
INFO - 2016-10-17 14:13:13 --> Controller Class Initialized
DEBUG - 2016-10-17 14:13:13 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:13:13 --> Model Class Initialized
DEBUG - 2016-10-17 14:13:13 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:13:13 --> Model Class Initialized
INFO - 2016-10-17 14:13:13 --> Final output sent to browser
DEBUG - 2016-10-17 14:13:13 --> Total execution time: 0.0434
INFO - 2016-10-17 14:13:15 --> Config Class Initialized
INFO - 2016-10-17 14:13:15 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:13:15 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:13:15 --> Utf8 Class Initialized
INFO - 2016-10-17 14:13:15 --> URI Class Initialized
INFO - 2016-10-17 14:13:15 --> Router Class Initialized
INFO - 2016-10-17 14:13:15 --> Output Class Initialized
INFO - 2016-10-17 14:13:15 --> Security Class Initialized
DEBUG - 2016-10-17 14:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:13:15 --> Input Class Initialized
INFO - 2016-10-17 14:13:15 --> Language Class Initialized
INFO - 2016-10-17 14:13:15 --> Language Class Initialized
INFO - 2016-10-17 14:13:15 --> Config Class Initialized
INFO - 2016-10-17 14:13:15 --> Loader Class Initialized
INFO - 2016-10-17 14:13:15 --> Helper loaded: common_helper
INFO - 2016-10-17 14:13:15 --> Helper loaded: url_helper
INFO - 2016-10-17 14:13:15 --> Database Driver Class Initialized
INFO - 2016-10-17 14:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:13:15 --> Parser Class Initialized
INFO - 2016-10-17 14:13:15 --> Controller Class Initialized
DEBUG - 2016-10-17 14:13:15 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:13:15 --> Model Class Initialized
DEBUG - 2016-10-17 14:13:15 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:13:15 --> Model Class Initialized
INFO - 2016-10-17 14:13:15 --> Final output sent to browser
DEBUG - 2016-10-17 14:13:15 --> Total execution time: 0.0586
INFO - 2016-10-17 14:14:00 --> Config Class Initialized
INFO - 2016-10-17 14:14:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:14:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:14:00 --> Utf8 Class Initialized
INFO - 2016-10-17 14:14:00 --> URI Class Initialized
INFO - 2016-10-17 14:14:00 --> Router Class Initialized
INFO - 2016-10-17 14:14:00 --> Output Class Initialized
INFO - 2016-10-17 14:14:00 --> Security Class Initialized
DEBUG - 2016-10-17 14:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:14:00 --> Input Class Initialized
INFO - 2016-10-17 14:14:00 --> Language Class Initialized
INFO - 2016-10-17 14:14:00 --> Language Class Initialized
INFO - 2016-10-17 14:14:00 --> Config Class Initialized
INFO - 2016-10-17 14:14:00 --> Loader Class Initialized
INFO - 2016-10-17 14:14:00 --> Helper loaded: common_helper
INFO - 2016-10-17 14:14:00 --> Helper loaded: url_helper
INFO - 2016-10-17 14:14:00 --> Database Driver Class Initialized
INFO - 2016-10-17 14:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:14:00 --> Parser Class Initialized
INFO - 2016-10-17 14:14:00 --> Controller Class Initialized
DEBUG - 2016-10-17 14:14:00 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:14:00 --> Model Class Initialized
DEBUG - 2016-10-17 14:14:00 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:14:00 --> Model Class Initialized
INFO - 2016-10-17 14:14:00 --> Final output sent to browser
DEBUG - 2016-10-17 14:14:00 --> Total execution time: 0.0444
INFO - 2016-10-17 14:15:20 --> Config Class Initialized
INFO - 2016-10-17 14:15:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:15:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:15:20 --> Utf8 Class Initialized
INFO - 2016-10-17 14:15:20 --> URI Class Initialized
INFO - 2016-10-17 14:15:20 --> Router Class Initialized
INFO - 2016-10-17 14:15:20 --> Output Class Initialized
INFO - 2016-10-17 14:15:20 --> Security Class Initialized
DEBUG - 2016-10-17 14:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:15:20 --> Input Class Initialized
INFO - 2016-10-17 14:15:20 --> Language Class Initialized
INFO - 2016-10-17 14:15:20 --> Language Class Initialized
INFO - 2016-10-17 14:15:20 --> Config Class Initialized
INFO - 2016-10-17 14:15:20 --> Loader Class Initialized
INFO - 2016-10-17 14:15:20 --> Helper loaded: common_helper
INFO - 2016-10-17 14:15:20 --> Helper loaded: url_helper
INFO - 2016-10-17 14:15:20 --> Database Driver Class Initialized
INFO - 2016-10-17 14:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:15:20 --> Parser Class Initialized
INFO - 2016-10-17 14:15:20 --> Controller Class Initialized
DEBUG - 2016-10-17 14:15:20 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:15:20 --> Model Class Initialized
DEBUG - 2016-10-17 14:15:20 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:15:20 --> Model Class Initialized
INFO - 2016-10-17 14:15:25 --> Final output sent to browser
DEBUG - 2016-10-17 14:15:25 --> Total execution time: 5.0614
INFO - 2016-10-17 14:17:43 --> Config Class Initialized
INFO - 2016-10-17 14:17:43 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:17:43 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:17:43 --> Utf8 Class Initialized
INFO - 2016-10-17 14:17:43 --> URI Class Initialized
INFO - 2016-10-17 14:17:43 --> Router Class Initialized
INFO - 2016-10-17 14:17:43 --> Output Class Initialized
INFO - 2016-10-17 14:17:43 --> Security Class Initialized
DEBUG - 2016-10-17 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:17:43 --> Input Class Initialized
INFO - 2016-10-17 14:17:43 --> Language Class Initialized
INFO - 2016-10-17 14:17:43 --> Language Class Initialized
INFO - 2016-10-17 14:17:43 --> Config Class Initialized
INFO - 2016-10-17 14:17:43 --> Loader Class Initialized
INFO - 2016-10-17 14:17:43 --> Helper loaded: common_helper
INFO - 2016-10-17 14:17:43 --> Helper loaded: url_helper
INFO - 2016-10-17 14:17:43 --> Database Driver Class Initialized
INFO - 2016-10-17 14:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:17:43 --> Parser Class Initialized
INFO - 2016-10-17 14:17:43 --> Controller Class Initialized
DEBUG - 2016-10-17 14:17:43 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:17:43 --> Model Class Initialized
DEBUG - 2016-10-17 14:17:43 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:17:43 --> Model Class Initialized
INFO - 2016-10-17 14:17:48 --> Final output sent to browser
DEBUG - 2016-10-17 14:17:48 --> Total execution time: 5.0468
INFO - 2016-10-17 14:19:01 --> Config Class Initialized
INFO - 2016-10-17 14:19:01 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:19:01 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:19:01 --> Utf8 Class Initialized
INFO - 2016-10-17 14:19:01 --> URI Class Initialized
INFO - 2016-10-17 14:19:01 --> Router Class Initialized
INFO - 2016-10-17 14:19:01 --> Output Class Initialized
INFO - 2016-10-17 14:19:01 --> Security Class Initialized
DEBUG - 2016-10-17 14:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:19:01 --> Input Class Initialized
INFO - 2016-10-17 14:19:01 --> Language Class Initialized
INFO - 2016-10-17 14:19:01 --> Language Class Initialized
INFO - 2016-10-17 14:19:01 --> Config Class Initialized
INFO - 2016-10-17 14:19:01 --> Loader Class Initialized
INFO - 2016-10-17 14:19:01 --> Helper loaded: common_helper
INFO - 2016-10-17 14:19:01 --> Helper loaded: url_helper
INFO - 2016-10-17 14:19:01 --> Database Driver Class Initialized
INFO - 2016-10-17 14:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:19:01 --> Parser Class Initialized
INFO - 2016-10-17 14:19:01 --> Controller Class Initialized
DEBUG - 2016-10-17 14:19:01 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:19:01 --> Model Class Initialized
DEBUG - 2016-10-17 14:19:01 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:19:01 --> Model Class Initialized
INFO - 2016-10-17 14:19:06 --> Final output sent to browser
DEBUG - 2016-10-17 14:19:06 --> Total execution time: 5.0462
INFO - 2016-10-17 14:19:55 --> Config Class Initialized
INFO - 2016-10-17 14:19:55 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:19:55 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:19:55 --> Utf8 Class Initialized
INFO - 2016-10-17 14:19:55 --> URI Class Initialized
INFO - 2016-10-17 14:19:55 --> Router Class Initialized
INFO - 2016-10-17 14:19:55 --> Output Class Initialized
INFO - 2016-10-17 14:19:55 --> Security Class Initialized
DEBUG - 2016-10-17 14:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:19:55 --> Input Class Initialized
INFO - 2016-10-17 14:19:55 --> Language Class Initialized
INFO - 2016-10-17 14:19:55 --> Language Class Initialized
INFO - 2016-10-17 14:19:55 --> Config Class Initialized
INFO - 2016-10-17 14:19:55 --> Loader Class Initialized
INFO - 2016-10-17 14:19:55 --> Helper loaded: common_helper
INFO - 2016-10-17 14:19:55 --> Helper loaded: url_helper
INFO - 2016-10-17 14:19:55 --> Database Driver Class Initialized
INFO - 2016-10-17 14:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:19:56 --> Parser Class Initialized
INFO - 2016-10-17 14:19:56 --> Controller Class Initialized
DEBUG - 2016-10-17 14:19:56 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:19:56 --> Model Class Initialized
DEBUG - 2016-10-17 14:19:56 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:19:56 --> Model Class Initialized
INFO - 2016-10-17 14:19:56 --> Config Class Initialized
INFO - 2016-10-17 14:19:56 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:19:56 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:19:56 --> Utf8 Class Initialized
INFO - 2016-10-17 14:19:56 --> URI Class Initialized
INFO - 2016-10-17 14:19:56 --> Router Class Initialized
INFO - 2016-10-17 14:19:56 --> Output Class Initialized
INFO - 2016-10-17 14:19:56 --> Security Class Initialized
DEBUG - 2016-10-17 14:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:19:56 --> Input Class Initialized
INFO - 2016-10-17 14:19:56 --> Language Class Initialized
INFO - 2016-10-17 14:19:56 --> Language Class Initialized
INFO - 2016-10-17 14:19:56 --> Config Class Initialized
INFO - 2016-10-17 14:19:56 --> Loader Class Initialized
INFO - 2016-10-17 14:19:56 --> Helper loaded: common_helper
INFO - 2016-10-17 14:19:56 --> Helper loaded: url_helper
INFO - 2016-10-17 14:19:56 --> Database Driver Class Initialized
INFO - 2016-10-17 14:19:57 --> Config Class Initialized
INFO - 2016-10-17 14:19:57 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:19:57 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:19:57 --> Utf8 Class Initialized
INFO - 2016-10-17 14:19:57 --> URI Class Initialized
INFO - 2016-10-17 14:19:57 --> Router Class Initialized
INFO - 2016-10-17 14:19:57 --> Output Class Initialized
INFO - 2016-10-17 14:19:57 --> Security Class Initialized
DEBUG - 2016-10-17 14:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:19:57 --> Input Class Initialized
INFO - 2016-10-17 14:19:57 --> Language Class Initialized
INFO - 2016-10-17 14:19:57 --> Language Class Initialized
INFO - 2016-10-17 14:19:57 --> Config Class Initialized
INFO - 2016-10-17 14:19:57 --> Loader Class Initialized
INFO - 2016-10-17 14:19:57 --> Helper loaded: common_helper
INFO - 2016-10-17 14:19:57 --> Helper loaded: url_helper
INFO - 2016-10-17 14:19:57 --> Database Driver Class Initialized
INFO - 2016-10-17 14:19:59 --> Config Class Initialized
INFO - 2016-10-17 14:19:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:19:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:19:59 --> Utf8 Class Initialized
INFO - 2016-10-17 14:19:59 --> URI Class Initialized
INFO - 2016-10-17 14:19:59 --> Router Class Initialized
INFO - 2016-10-17 14:19:59 --> Output Class Initialized
INFO - 2016-10-17 14:19:59 --> Security Class Initialized
DEBUG - 2016-10-17 14:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:19:59 --> Input Class Initialized
INFO - 2016-10-17 14:19:59 --> Language Class Initialized
INFO - 2016-10-17 14:19:59 --> Language Class Initialized
INFO - 2016-10-17 14:19:59 --> Config Class Initialized
INFO - 2016-10-17 14:19:59 --> Loader Class Initialized
INFO - 2016-10-17 14:19:59 --> Helper loaded: common_helper
INFO - 2016-10-17 14:19:59 --> Helper loaded: url_helper
INFO - 2016-10-17 14:19:59 --> Database Driver Class Initialized
INFO - 2016-10-17 14:20:01 --> Final output sent to browser
DEBUG - 2016-10-17 14:20:01 --> Total execution time: 5.0477
INFO - 2016-10-17 14:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:20:01 --> Parser Class Initialized
INFO - 2016-10-17 14:20:01 --> Controller Class Initialized
DEBUG - 2016-10-17 14:20:01 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:20:01 --> Model Class Initialized
DEBUG - 2016-10-17 14:20:01 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:20:01 --> Model Class Initialized
INFO - 2016-10-17 14:20:06 --> Final output sent to browser
DEBUG - 2016-10-17 14:20:06 --> Total execution time: 8.2720
INFO - 2016-10-17 14:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:20:06 --> Parser Class Initialized
INFO - 2016-10-17 14:20:06 --> Controller Class Initialized
DEBUG - 2016-10-17 14:20:06 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:20:06 --> Model Class Initialized
DEBUG - 2016-10-17 14:20:06 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:20:06 --> Model Class Initialized
INFO - 2016-10-17 14:20:11 --> Final output sent to browser
DEBUG - 2016-10-17 14:20:11 --> Total execution time: 11.8453
INFO - 2016-10-17 14:28:00 --> Config Class Initialized
INFO - 2016-10-17 14:28:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:28:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:28:00 --> Utf8 Class Initialized
INFO - 2016-10-17 14:28:00 --> URI Class Initialized
INFO - 2016-10-17 14:28:00 --> Router Class Initialized
INFO - 2016-10-17 14:28:00 --> Output Class Initialized
INFO - 2016-10-17 14:28:00 --> Security Class Initialized
DEBUG - 2016-10-17 14:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:28:00 --> Input Class Initialized
INFO - 2016-10-17 14:28:00 --> Language Class Initialized
INFO - 2016-10-17 14:28:00 --> Language Class Initialized
INFO - 2016-10-17 14:28:00 --> Config Class Initialized
INFO - 2016-10-17 14:28:00 --> Loader Class Initialized
INFO - 2016-10-17 14:28:00 --> Helper loaded: common_helper
INFO - 2016-10-17 14:28:00 --> Helper loaded: url_helper
INFO - 2016-10-17 14:28:00 --> Database Driver Class Initialized
INFO - 2016-10-17 14:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:28:01 --> Parser Class Initialized
INFO - 2016-10-17 14:28:01 --> Controller Class Initialized
DEBUG - 2016-10-17 14:28:01 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:28:01 --> Model Class Initialized
DEBUG - 2016-10-17 14:28:01 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:28:01 --> Model Class Initialized
INFO - 2016-10-17 14:28:01 --> Final output sent to browser
DEBUG - 2016-10-17 14:28:01 --> Total execution time: 0.0429
INFO - 2016-10-17 14:35:38 --> Config Class Initialized
INFO - 2016-10-17 14:35:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:35:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:35:38 --> Utf8 Class Initialized
INFO - 2016-10-17 14:35:38 --> URI Class Initialized
INFO - 2016-10-17 14:35:38 --> Router Class Initialized
INFO - 2016-10-17 14:35:38 --> Output Class Initialized
INFO - 2016-10-17 14:35:38 --> Security Class Initialized
DEBUG - 2016-10-17 14:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:35:38 --> Input Class Initialized
INFO - 2016-10-17 14:35:38 --> Language Class Initialized
INFO - 2016-10-17 14:35:38 --> Language Class Initialized
INFO - 2016-10-17 14:35:38 --> Config Class Initialized
INFO - 2016-10-17 14:35:38 --> Loader Class Initialized
INFO - 2016-10-17 14:35:38 --> Helper loaded: common_helper
INFO - 2016-10-17 14:35:38 --> Helper loaded: url_helper
INFO - 2016-10-17 14:35:38 --> Database Driver Class Initialized
INFO - 2016-10-17 14:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:35:38 --> Parser Class Initialized
INFO - 2016-10-17 14:35:38 --> Controller Class Initialized
DEBUG - 2016-10-17 14:35:38 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:35:38 --> Model Class Initialized
DEBUG - 2016-10-17 14:35:38 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:35:38 --> Model Class Initialized
INFO - 2016-10-17 14:35:38 --> Final output sent to browser
DEBUG - 2016-10-17 14:35:38 --> Total execution time: 0.0469
INFO - 2016-10-17 14:38:43 --> Config Class Initialized
INFO - 2016-10-17 14:38:43 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:38:43 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:38:43 --> Utf8 Class Initialized
INFO - 2016-10-17 14:38:43 --> URI Class Initialized
INFO - 2016-10-17 14:38:43 --> Router Class Initialized
INFO - 2016-10-17 14:38:43 --> Output Class Initialized
INFO - 2016-10-17 14:38:43 --> Security Class Initialized
DEBUG - 2016-10-17 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:38:43 --> Input Class Initialized
INFO - 2016-10-17 14:38:44 --> Language Class Initialized
INFO - 2016-10-17 14:38:44 --> Language Class Initialized
INFO - 2016-10-17 14:38:44 --> Config Class Initialized
INFO - 2016-10-17 14:38:44 --> Loader Class Initialized
INFO - 2016-10-17 14:38:44 --> Helper loaded: common_helper
INFO - 2016-10-17 14:38:44 --> Helper loaded: url_helper
INFO - 2016-10-17 14:38:44 --> Database Driver Class Initialized
INFO - 2016-10-17 14:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:38:44 --> Parser Class Initialized
INFO - 2016-10-17 14:38:44 --> Controller Class Initialized
DEBUG - 2016-10-17 14:38:44 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:38:44 --> Model Class Initialized
DEBUG - 2016-10-17 14:38:44 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:38:44 --> Model Class Initialized
INFO - 2016-10-17 14:38:49 --> Final output sent to browser
DEBUG - 2016-10-17 14:38:49 --> Total execution time: 5.0629
INFO - 2016-10-17 14:39:34 --> Config Class Initialized
INFO - 2016-10-17 14:39:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:39:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:39:34 --> Utf8 Class Initialized
INFO - 2016-10-17 14:39:34 --> URI Class Initialized
INFO - 2016-10-17 14:39:34 --> Router Class Initialized
INFO - 2016-10-17 14:39:34 --> Output Class Initialized
INFO - 2016-10-17 14:39:34 --> Security Class Initialized
DEBUG - 2016-10-17 14:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:39:34 --> Input Class Initialized
INFO - 2016-10-17 14:39:34 --> Language Class Initialized
INFO - 2016-10-17 14:39:34 --> Language Class Initialized
INFO - 2016-10-17 14:39:34 --> Config Class Initialized
INFO - 2016-10-17 14:39:34 --> Loader Class Initialized
INFO - 2016-10-17 14:39:34 --> Helper loaded: common_helper
INFO - 2016-10-17 14:39:34 --> Helper loaded: url_helper
INFO - 2016-10-17 14:39:34 --> Database Driver Class Initialized
INFO - 2016-10-17 14:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:39:34 --> Parser Class Initialized
INFO - 2016-10-17 14:39:34 --> Controller Class Initialized
DEBUG - 2016-10-17 14:39:34 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:39:34 --> Model Class Initialized
DEBUG - 2016-10-17 14:39:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:39:34 --> Model Class Initialized
INFO - 2016-10-17 14:39:39 --> Final output sent to browser
DEBUG - 2016-10-17 14:39:39 --> Total execution time: 5.0459
INFO - 2016-10-17 14:40:11 --> Config Class Initialized
INFO - 2016-10-17 14:40:11 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:40:11 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:40:11 --> Utf8 Class Initialized
INFO - 2016-10-17 14:40:11 --> URI Class Initialized
INFO - 2016-10-17 14:40:11 --> Router Class Initialized
INFO - 2016-10-17 14:40:11 --> Output Class Initialized
INFO - 2016-10-17 14:40:11 --> Security Class Initialized
DEBUG - 2016-10-17 14:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:40:11 --> Input Class Initialized
INFO - 2016-10-17 14:40:11 --> Language Class Initialized
INFO - 2016-10-17 14:40:11 --> Language Class Initialized
INFO - 2016-10-17 14:40:11 --> Config Class Initialized
INFO - 2016-10-17 14:40:11 --> Loader Class Initialized
INFO - 2016-10-17 14:40:11 --> Helper loaded: common_helper
INFO - 2016-10-17 14:40:11 --> Helper loaded: url_helper
INFO - 2016-10-17 14:40:11 --> Database Driver Class Initialized
INFO - 2016-10-17 14:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:40:11 --> Parser Class Initialized
INFO - 2016-10-17 14:40:11 --> Controller Class Initialized
DEBUG - 2016-10-17 14:40:11 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:40:11 --> Model Class Initialized
DEBUG - 2016-10-17 14:40:11 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:40:11 --> Model Class Initialized
INFO - 2016-10-17 14:40:16 --> Final output sent to browser
DEBUG - 2016-10-17 14:40:16 --> Total execution time: 5.0444
INFO - 2016-10-17 14:40:21 --> Config Class Initialized
INFO - 2016-10-17 14:40:21 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:40:21 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:40:21 --> Utf8 Class Initialized
INFO - 2016-10-17 14:40:21 --> URI Class Initialized
INFO - 2016-10-17 14:40:21 --> Router Class Initialized
INFO - 2016-10-17 14:40:21 --> Output Class Initialized
INFO - 2016-10-17 14:40:21 --> Security Class Initialized
DEBUG - 2016-10-17 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:40:21 --> Input Class Initialized
INFO - 2016-10-17 14:40:21 --> Language Class Initialized
INFO - 2016-10-17 14:40:21 --> Language Class Initialized
INFO - 2016-10-17 14:40:21 --> Config Class Initialized
INFO - 2016-10-17 14:40:21 --> Loader Class Initialized
INFO - 2016-10-17 14:40:21 --> Helper loaded: common_helper
INFO - 2016-10-17 14:40:21 --> Helper loaded: url_helper
INFO - 2016-10-17 14:40:21 --> Database Driver Class Initialized
INFO - 2016-10-17 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:40:21 --> Parser Class Initialized
INFO - 2016-10-17 14:40:21 --> Controller Class Initialized
DEBUG - 2016-10-17 14:40:21 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:40:21 --> Model Class Initialized
DEBUG - 2016-10-17 14:40:21 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:40:21 --> Model Class Initialized
INFO - 2016-10-17 14:40:26 --> Final output sent to browser
DEBUG - 2016-10-17 14:40:26 --> Total execution time: 5.0415
INFO - 2016-10-17 14:41:07 --> Config Class Initialized
INFO - 2016-10-17 14:41:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:41:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:41:07 --> Utf8 Class Initialized
INFO - 2016-10-17 14:41:07 --> URI Class Initialized
INFO - 2016-10-17 14:41:07 --> Router Class Initialized
INFO - 2016-10-17 14:41:07 --> Output Class Initialized
INFO - 2016-10-17 14:41:07 --> Security Class Initialized
DEBUG - 2016-10-17 14:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:41:07 --> Input Class Initialized
INFO - 2016-10-17 14:41:07 --> Language Class Initialized
INFO - 2016-10-17 14:41:07 --> Language Class Initialized
INFO - 2016-10-17 14:41:07 --> Config Class Initialized
INFO - 2016-10-17 14:41:07 --> Loader Class Initialized
INFO - 2016-10-17 14:41:07 --> Helper loaded: common_helper
INFO - 2016-10-17 14:41:07 --> Helper loaded: url_helper
INFO - 2016-10-17 14:41:07 --> Database Driver Class Initialized
INFO - 2016-10-17 14:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:41:07 --> Parser Class Initialized
INFO - 2016-10-17 14:41:07 --> Controller Class Initialized
DEBUG - 2016-10-17 14:41:07 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:41:07 --> Model Class Initialized
DEBUG - 2016-10-17 14:41:07 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:41:07 --> Model Class Initialized
INFO - 2016-10-17 14:41:12 --> Final output sent to browser
DEBUG - 2016-10-17 14:41:12 --> Total execution time: 5.0462
INFO - 2016-10-17 14:42:28 --> Config Class Initialized
INFO - 2016-10-17 14:42:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:28 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:28 --> URI Class Initialized
INFO - 2016-10-17 14:42:28 --> Router Class Initialized
INFO - 2016-10-17 14:42:28 --> Output Class Initialized
INFO - 2016-10-17 14:42:28 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:28 --> Input Class Initialized
INFO - 2016-10-17 14:42:28 --> Language Class Initialized
INFO - 2016-10-17 14:42:28 --> Language Class Initialized
INFO - 2016-10-17 14:42:28 --> Config Class Initialized
INFO - 2016-10-17 14:42:28 --> Loader Class Initialized
INFO - 2016-10-17 14:42:28 --> Helper loaded: common_helper
INFO - 2016-10-17 14:42:28 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:28 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:28 --> Parser Class Initialized
INFO - 2016-10-17 14:42:28 --> Controller Class Initialized
DEBUG - 2016-10-17 14:42:28 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:42:28 --> Model Class Initialized
DEBUG - 2016-10-17 14:42:28 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:42:28 --> Model Class Initialized
INFO - 2016-10-17 14:42:28 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:28 --> Total execution time: 0.0467
INFO - 2016-10-17 14:42:36 --> Config Class Initialized
INFO - 2016-10-17 14:42:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:36 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:36 --> URI Class Initialized
INFO - 2016-10-17 14:42:36 --> Router Class Initialized
INFO - 2016-10-17 14:42:36 --> Output Class Initialized
INFO - 2016-10-17 14:42:36 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:36 --> Input Class Initialized
INFO - 2016-10-17 14:42:36 --> Language Class Initialized
INFO - 2016-10-17 14:42:36 --> Language Class Initialized
INFO - 2016-10-17 14:42:36 --> Config Class Initialized
INFO - 2016-10-17 14:42:36 --> Loader Class Initialized
INFO - 2016-10-17 14:42:36 --> Helper loaded: common_helper
INFO - 2016-10-17 14:42:36 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:36 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:36 --> Parser Class Initialized
INFO - 2016-10-17 14:42:36 --> Controller Class Initialized
DEBUG - 2016-10-17 14:42:36 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:42:36 --> Model Class Initialized
DEBUG - 2016-10-17 14:42:36 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:42:36 --> Model Class Initialized
INFO - 2016-10-17 14:42:36 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:36 --> Total execution time: 0.0931
INFO - 2016-10-17 14:42:38 --> Config Class Initialized
INFO - 2016-10-17 14:42:38 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:42:38 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:42:38 --> Utf8 Class Initialized
INFO - 2016-10-17 14:42:38 --> URI Class Initialized
INFO - 2016-10-17 14:42:38 --> Router Class Initialized
INFO - 2016-10-17 14:42:38 --> Output Class Initialized
INFO - 2016-10-17 14:42:38 --> Security Class Initialized
DEBUG - 2016-10-17 14:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:42:38 --> Input Class Initialized
INFO - 2016-10-17 14:42:38 --> Language Class Initialized
INFO - 2016-10-17 14:42:38 --> Language Class Initialized
INFO - 2016-10-17 14:42:38 --> Config Class Initialized
INFO - 2016-10-17 14:42:38 --> Loader Class Initialized
INFO - 2016-10-17 14:42:38 --> Helper loaded: common_helper
INFO - 2016-10-17 14:42:38 --> Helper loaded: url_helper
INFO - 2016-10-17 14:42:38 --> Database Driver Class Initialized
INFO - 2016-10-17 14:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:42:38 --> Parser Class Initialized
INFO - 2016-10-17 14:42:38 --> Controller Class Initialized
DEBUG - 2016-10-17 14:42:38 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:42:38 --> Model Class Initialized
DEBUG - 2016-10-17 14:42:38 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:42:38 --> Model Class Initialized
INFO - 2016-10-17 14:42:38 --> Final output sent to browser
DEBUG - 2016-10-17 14:42:38 --> Total execution time: 0.0640
INFO - 2016-10-17 14:43:28 --> Config Class Initialized
INFO - 2016-10-17 14:43:28 --> Hooks Class Initialized
DEBUG - 2016-10-17 14:43:28 --> UTF-8 Support Enabled
INFO - 2016-10-17 14:43:28 --> Utf8 Class Initialized
INFO - 2016-10-17 14:43:28 --> URI Class Initialized
INFO - 2016-10-17 14:43:28 --> Router Class Initialized
INFO - 2016-10-17 14:43:28 --> Output Class Initialized
INFO - 2016-10-17 14:43:28 --> Security Class Initialized
DEBUG - 2016-10-17 14:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 14:43:28 --> Input Class Initialized
INFO - 2016-10-17 14:43:28 --> Language Class Initialized
INFO - 2016-10-17 14:43:28 --> Language Class Initialized
INFO - 2016-10-17 14:43:28 --> Config Class Initialized
INFO - 2016-10-17 14:43:28 --> Loader Class Initialized
INFO - 2016-10-17 14:43:28 --> Helper loaded: common_helper
INFO - 2016-10-17 14:43:28 --> Helper loaded: url_helper
INFO - 2016-10-17 14:43:28 --> Database Driver Class Initialized
INFO - 2016-10-17 14:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 14:43:28 --> Parser Class Initialized
INFO - 2016-10-17 14:43:28 --> Controller Class Initialized
DEBUG - 2016-10-17 14:43:28 --> Home MX_Controller Initialized
INFO - 2016-10-17 14:43:28 --> Model Class Initialized
DEBUG - 2016-10-17 14:43:28 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 14:43:28 --> Model Class Initialized
INFO - 2016-10-17 14:43:28 --> Final output sent to browser
DEBUG - 2016-10-17 14:43:28 --> Total execution time: 0.0529
INFO - 2016-10-17 15:11:00 --> Config Class Initialized
INFO - 2016-10-17 15:11:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:11:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:11:00 --> Utf8 Class Initialized
INFO - 2016-10-17 15:11:00 --> URI Class Initialized
INFO - 2016-10-17 15:11:00 --> Router Class Initialized
INFO - 2016-10-17 15:11:00 --> Output Class Initialized
INFO - 2016-10-17 15:11:00 --> Security Class Initialized
DEBUG - 2016-10-17 15:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:11:00 --> Input Class Initialized
INFO - 2016-10-17 15:11:00 --> Language Class Initialized
INFO - 2016-10-17 15:11:00 --> Language Class Initialized
INFO - 2016-10-17 15:11:00 --> Config Class Initialized
INFO - 2016-10-17 15:11:00 --> Loader Class Initialized
INFO - 2016-10-17 15:11:00 --> Helper loaded: common_helper
INFO - 2016-10-17 15:11:00 --> Helper loaded: url_helper
INFO - 2016-10-17 15:11:00 --> Database Driver Class Initialized
INFO - 2016-10-17 15:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:11:00 --> Parser Class Initialized
INFO - 2016-10-17 15:11:00 --> Controller Class Initialized
DEBUG - 2016-10-17 15:11:00 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:11:00 --> Model Class Initialized
DEBUG - 2016-10-17 15:11:00 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:11:00 --> Model Class Initialized
INFO - 2016-10-17 15:11:00 --> Final output sent to browser
DEBUG - 2016-10-17 15:11:00 --> Total execution time: 0.0582
INFO - 2016-10-17 15:26:52 --> Config Class Initialized
INFO - 2016-10-17 15:26:52 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:26:52 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:26:52 --> Utf8 Class Initialized
INFO - 2016-10-17 15:26:52 --> URI Class Initialized
INFO - 2016-10-17 15:26:52 --> Router Class Initialized
INFO - 2016-10-17 15:26:52 --> Output Class Initialized
INFO - 2016-10-17 15:26:52 --> Security Class Initialized
DEBUG - 2016-10-17 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:26:52 --> Input Class Initialized
INFO - 2016-10-17 15:26:52 --> Language Class Initialized
ERROR - 2016-10-17 15:26:52 --> Severity: Parsing Error --> syntax error, unexpected ',', expecting ')' /home/dolongpk/public_html/application/modules/home/controllers/Home.php 110
INFO - 2016-10-17 15:27:07 --> Config Class Initialized
INFO - 2016-10-17 15:27:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:27:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:27:07 --> Utf8 Class Initialized
INFO - 2016-10-17 15:27:07 --> URI Class Initialized
INFO - 2016-10-17 15:27:07 --> Router Class Initialized
INFO - 2016-10-17 15:27:07 --> Output Class Initialized
INFO - 2016-10-17 15:27:07 --> Security Class Initialized
DEBUG - 2016-10-17 15:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:27:07 --> Input Class Initialized
INFO - 2016-10-17 15:27:07 --> Language Class Initialized
INFO - 2016-10-17 15:27:07 --> Language Class Initialized
INFO - 2016-10-17 15:27:07 --> Config Class Initialized
INFO - 2016-10-17 15:27:07 --> Loader Class Initialized
INFO - 2016-10-17 15:27:07 --> Helper loaded: common_helper
INFO - 2016-10-17 15:27:07 --> Helper loaded: url_helper
INFO - 2016-10-17 15:27:07 --> Database Driver Class Initialized
INFO - 2016-10-17 15:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:27:07 --> Parser Class Initialized
INFO - 2016-10-17 15:27:07 --> Controller Class Initialized
DEBUG - 2016-10-17 15:27:07 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:27:07 --> Model Class Initialized
DEBUG - 2016-10-17 15:27:07 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:27:07 --> Model Class Initialized
DEBUG - 2016-10-17 15:27:07 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:27:07 --> Final output sent to browser
DEBUG - 2016-10-17 15:27:07 --> Total execution time: 0.0395
INFO - 2016-10-17 15:27:31 --> Config Class Initialized
INFO - 2016-10-17 15:27:31 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:27:31 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:27:31 --> Utf8 Class Initialized
INFO - 2016-10-17 15:27:31 --> URI Class Initialized
INFO - 2016-10-17 15:27:31 --> Router Class Initialized
INFO - 2016-10-17 15:27:31 --> Output Class Initialized
INFO - 2016-10-17 15:27:31 --> Security Class Initialized
DEBUG - 2016-10-17 15:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:27:31 --> Input Class Initialized
INFO - 2016-10-17 15:27:31 --> Language Class Initialized
INFO - 2016-10-17 15:27:31 --> Language Class Initialized
INFO - 2016-10-17 15:27:31 --> Config Class Initialized
INFO - 2016-10-17 15:27:31 --> Loader Class Initialized
INFO - 2016-10-17 15:27:31 --> Helper loaded: common_helper
INFO - 2016-10-17 15:27:31 --> Helper loaded: url_helper
INFO - 2016-10-17 15:27:31 --> Database Driver Class Initialized
INFO - 2016-10-17 15:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:27:31 --> Parser Class Initialized
INFO - 2016-10-17 15:27:31 --> Controller Class Initialized
DEBUG - 2016-10-17 15:27:31 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:27:31 --> Model Class Initialized
DEBUG - 2016-10-17 15:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:27:31 --> Model Class Initialized
DEBUG - 2016-10-17 15:27:31 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:27:31 --> Final output sent to browser
DEBUG - 2016-10-17 15:27:31 --> Total execution time: 0.0400
INFO - 2016-10-17 15:27:56 --> Config Class Initialized
INFO - 2016-10-17 15:27:56 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:27:56 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:27:56 --> Utf8 Class Initialized
INFO - 2016-10-17 15:27:56 --> URI Class Initialized
INFO - 2016-10-17 15:27:56 --> Router Class Initialized
INFO - 2016-10-17 15:27:56 --> Output Class Initialized
INFO - 2016-10-17 15:27:56 --> Security Class Initialized
DEBUG - 2016-10-17 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:27:56 --> Input Class Initialized
INFO - 2016-10-17 15:27:56 --> Language Class Initialized
INFO - 2016-10-17 15:27:56 --> Language Class Initialized
INFO - 2016-10-17 15:27:56 --> Config Class Initialized
INFO - 2016-10-17 15:27:56 --> Loader Class Initialized
INFO - 2016-10-17 15:27:56 --> Helper loaded: common_helper
INFO - 2016-10-17 15:27:56 --> Helper loaded: url_helper
INFO - 2016-10-17 15:27:56 --> Database Driver Class Initialized
INFO - 2016-10-17 15:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:27:56 --> Parser Class Initialized
INFO - 2016-10-17 15:27:56 --> Controller Class Initialized
DEBUG - 2016-10-17 15:27:56 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:27:56 --> Model Class Initialized
DEBUG - 2016-10-17 15:27:56 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:27:56 --> Model Class Initialized
DEBUG - 2016-10-17 15:27:56 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:27:56 --> Final output sent to browser
DEBUG - 2016-10-17 15:27:56 --> Total execution time: 0.0419
INFO - 2016-10-17 15:29:04 --> Config Class Initialized
INFO - 2016-10-17 15:29:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:29:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:29:04 --> Utf8 Class Initialized
INFO - 2016-10-17 15:29:04 --> URI Class Initialized
INFO - 2016-10-17 15:29:04 --> Router Class Initialized
INFO - 2016-10-17 15:29:04 --> Output Class Initialized
INFO - 2016-10-17 15:29:04 --> Security Class Initialized
DEBUG - 2016-10-17 15:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:29:04 --> Input Class Initialized
INFO - 2016-10-17 15:29:04 --> Language Class Initialized
INFO - 2016-10-17 15:29:04 --> Language Class Initialized
INFO - 2016-10-17 15:29:04 --> Config Class Initialized
INFO - 2016-10-17 15:29:04 --> Loader Class Initialized
INFO - 2016-10-17 15:29:04 --> Helper loaded: common_helper
INFO - 2016-10-17 15:29:04 --> Helper loaded: url_helper
INFO - 2016-10-17 15:29:04 --> Database Driver Class Initialized
INFO - 2016-10-17 15:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:29:04 --> Parser Class Initialized
INFO - 2016-10-17 15:29:04 --> Controller Class Initialized
DEBUG - 2016-10-17 15:29:04 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:29:04 --> Model Class Initialized
DEBUG - 2016-10-17 15:29:04 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:29:04 --> Model Class Initialized
DEBUG - 2016-10-17 15:29:04 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:29:04 --> Final output sent to browser
DEBUG - 2016-10-17 15:29:04 --> Total execution time: 0.0469
INFO - 2016-10-17 15:29:30 --> Config Class Initialized
INFO - 2016-10-17 15:29:30 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:29:30 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:29:30 --> Utf8 Class Initialized
INFO - 2016-10-17 15:29:30 --> URI Class Initialized
INFO - 2016-10-17 15:29:30 --> Router Class Initialized
INFO - 2016-10-17 15:29:30 --> Output Class Initialized
INFO - 2016-10-17 15:29:30 --> Security Class Initialized
DEBUG - 2016-10-17 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:29:30 --> Input Class Initialized
INFO - 2016-10-17 15:29:30 --> Language Class Initialized
INFO - 2016-10-17 15:29:30 --> Language Class Initialized
INFO - 2016-10-17 15:29:30 --> Config Class Initialized
INFO - 2016-10-17 15:29:30 --> Loader Class Initialized
INFO - 2016-10-17 15:29:30 --> Helper loaded: common_helper
INFO - 2016-10-17 15:29:30 --> Helper loaded: url_helper
INFO - 2016-10-17 15:29:30 --> Database Driver Class Initialized
INFO - 2016-10-17 15:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:29:30 --> Parser Class Initialized
INFO - 2016-10-17 15:29:30 --> Controller Class Initialized
DEBUG - 2016-10-17 15:29:30 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:29:30 --> Model Class Initialized
DEBUG - 2016-10-17 15:29:30 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:29:30 --> Model Class Initialized
DEBUG - 2016-10-17 15:29:30 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:31:04 --> Config Class Initialized
INFO - 2016-10-17 15:31:04 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:31:04 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:31:04 --> Utf8 Class Initialized
INFO - 2016-10-17 15:31:04 --> URI Class Initialized
INFO - 2016-10-17 15:31:04 --> Router Class Initialized
INFO - 2016-10-17 15:31:04 --> Output Class Initialized
INFO - 2016-10-17 15:31:04 --> Security Class Initialized
DEBUG - 2016-10-17 15:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:31:04 --> Input Class Initialized
INFO - 2016-10-17 15:31:04 --> Language Class Initialized
INFO - 2016-10-17 15:31:04 --> Language Class Initialized
INFO - 2016-10-17 15:31:04 --> Config Class Initialized
INFO - 2016-10-17 15:31:04 --> Loader Class Initialized
INFO - 2016-10-17 15:31:04 --> Helper loaded: common_helper
INFO - 2016-10-17 15:31:04 --> Helper loaded: url_helper
INFO - 2016-10-17 15:31:04 --> Database Driver Class Initialized
INFO - 2016-10-17 15:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:31:04 --> Parser Class Initialized
INFO - 2016-10-17 15:31:04 --> Controller Class Initialized
DEBUG - 2016-10-17 15:31:04 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:31:04 --> Model Class Initialized
DEBUG - 2016-10-17 15:31:04 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:31:04 --> Model Class Initialized
ERROR - 2016-10-17 15:32:04 --> Severity: Warning --> file_get_contents(http://103.27.60.212:8888/api_tan.php): failed to open stream: Connection timed out /home/dolongpk/public_html/application/modules/home/views/api_view.php 2
DEBUG - 2016-10-17 15:32:04 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:34:16 --> Config Class Initialized
INFO - 2016-10-17 15:34:16 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:34:16 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:34:16 --> Utf8 Class Initialized
INFO - 2016-10-17 15:34:16 --> URI Class Initialized
INFO - 2016-10-17 15:34:16 --> Router Class Initialized
INFO - 2016-10-17 15:34:16 --> Output Class Initialized
INFO - 2016-10-17 15:34:16 --> Security Class Initialized
DEBUG - 2016-10-17 15:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:34:16 --> Input Class Initialized
INFO - 2016-10-17 15:34:16 --> Language Class Initialized
INFO - 2016-10-17 15:34:16 --> Language Class Initialized
INFO - 2016-10-17 15:34:16 --> Config Class Initialized
INFO - 2016-10-17 15:34:16 --> Loader Class Initialized
INFO - 2016-10-17 15:34:16 --> Helper loaded: common_helper
INFO - 2016-10-17 15:34:16 --> Helper loaded: url_helper
INFO - 2016-10-17 15:34:16 --> Database Driver Class Initialized
INFO - 2016-10-17 15:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:34:16 --> Parser Class Initialized
INFO - 2016-10-17 15:34:16 --> Controller Class Initialized
DEBUG - 2016-10-17 15:34:16 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:34:16 --> Model Class Initialized
DEBUG - 2016-10-17 15:34:16 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:34:16 --> Model Class Initialized
DEBUG - 2016-10-17 15:34:16 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:34:44 --> Config Class Initialized
INFO - 2016-10-17 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:34:44 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:34:44 --> Utf8 Class Initialized
INFO - 2016-10-17 15:34:44 --> URI Class Initialized
INFO - 2016-10-17 15:34:44 --> Router Class Initialized
INFO - 2016-10-17 15:34:44 --> Output Class Initialized
INFO - 2016-10-17 15:34:44 --> Security Class Initialized
DEBUG - 2016-10-17 15:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:34:44 --> Input Class Initialized
INFO - 2016-10-17 15:34:44 --> Language Class Initialized
INFO - 2016-10-17 15:34:44 --> Language Class Initialized
INFO - 2016-10-17 15:34:44 --> Config Class Initialized
INFO - 2016-10-17 15:34:44 --> Loader Class Initialized
INFO - 2016-10-17 15:34:44 --> Helper loaded: common_helper
INFO - 2016-10-17 15:34:44 --> Helper loaded: url_helper
INFO - 2016-10-17 15:34:44 --> Database Driver Class Initialized
INFO - 2016-10-17 15:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:34:44 --> Parser Class Initialized
INFO - 2016-10-17 15:34:44 --> Controller Class Initialized
DEBUG - 2016-10-17 15:34:44 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:34:44 --> Model Class Initialized
DEBUG - 2016-10-17 15:34:44 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:34:44 --> Model Class Initialized
DEBUG - 2016-10-17 15:34:44 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:37:05 --> Config Class Initialized
INFO - 2016-10-17 15:37:05 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:37:05 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:37:05 --> Utf8 Class Initialized
INFO - 2016-10-17 15:37:05 --> URI Class Initialized
INFO - 2016-10-17 15:37:05 --> Router Class Initialized
INFO - 2016-10-17 15:37:05 --> Output Class Initialized
INFO - 2016-10-17 15:37:05 --> Security Class Initialized
DEBUG - 2016-10-17 15:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:37:05 --> Input Class Initialized
INFO - 2016-10-17 15:37:05 --> Language Class Initialized
INFO - 2016-10-17 15:37:05 --> Language Class Initialized
INFO - 2016-10-17 15:37:05 --> Config Class Initialized
INFO - 2016-10-17 15:37:05 --> Loader Class Initialized
INFO - 2016-10-17 15:37:05 --> Helper loaded: common_helper
INFO - 2016-10-17 15:37:05 --> Helper loaded: url_helper
INFO - 2016-10-17 15:37:05 --> Database Driver Class Initialized
INFO - 2016-10-17 15:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:37:05 --> Parser Class Initialized
INFO - 2016-10-17 15:37:05 --> Controller Class Initialized
DEBUG - 2016-10-17 15:37:05 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:37:05 --> Model Class Initialized
DEBUG - 2016-10-17 15:37:05 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:37:05 --> Model Class Initialized
DEBUG - 2016-10-17 15:37:05 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:37:05 --> Final output sent to browser
DEBUG - 2016-10-17 15:37:05 --> Total execution time: 0.0417
INFO - 2016-10-17 15:38:40 --> Config Class Initialized
INFO - 2016-10-17 15:38:40 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:38:40 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:38:40 --> Utf8 Class Initialized
INFO - 2016-10-17 15:38:40 --> URI Class Initialized
INFO - 2016-10-17 15:38:40 --> Router Class Initialized
INFO - 2016-10-17 15:38:40 --> Output Class Initialized
INFO - 2016-10-17 15:38:40 --> Security Class Initialized
DEBUG - 2016-10-17 15:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:38:40 --> Input Class Initialized
INFO - 2016-10-17 15:38:40 --> Language Class Initialized
INFO - 2016-10-17 15:38:40 --> Language Class Initialized
INFO - 2016-10-17 15:38:40 --> Config Class Initialized
INFO - 2016-10-17 15:38:40 --> Loader Class Initialized
INFO - 2016-10-17 15:38:40 --> Helper loaded: common_helper
INFO - 2016-10-17 15:38:40 --> Helper loaded: url_helper
INFO - 2016-10-17 15:38:40 --> Database Driver Class Initialized
INFO - 2016-10-17 15:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:38:40 --> Parser Class Initialized
INFO - 2016-10-17 15:38:40 --> Controller Class Initialized
DEBUG - 2016-10-17 15:38:40 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:38:40 --> Model Class Initialized
DEBUG - 2016-10-17 15:38:40 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:38:40 --> Model Class Initialized
DEBUG - 2016-10-17 15:38:40 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:39:32 --> Config Class Initialized
INFO - 2016-10-17 15:39:32 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:39:32 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:39:32 --> Utf8 Class Initialized
INFO - 2016-10-17 15:39:32 --> URI Class Initialized
INFO - 2016-10-17 15:39:32 --> Router Class Initialized
INFO - 2016-10-17 15:39:32 --> Output Class Initialized
INFO - 2016-10-17 15:39:32 --> Security Class Initialized
DEBUG - 2016-10-17 15:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:39:32 --> Input Class Initialized
INFO - 2016-10-17 15:39:32 --> Language Class Initialized
INFO - 2016-10-17 15:39:32 --> Language Class Initialized
INFO - 2016-10-17 15:39:32 --> Config Class Initialized
INFO - 2016-10-17 15:39:32 --> Loader Class Initialized
INFO - 2016-10-17 15:39:32 --> Helper loaded: common_helper
INFO - 2016-10-17 15:39:32 --> Helper loaded: url_helper
INFO - 2016-10-17 15:39:32 --> Database Driver Class Initialized
INFO - 2016-10-17 15:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:39:32 --> Parser Class Initialized
INFO - 2016-10-17 15:39:32 --> Controller Class Initialized
DEBUG - 2016-10-17 15:39:32 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:39:32 --> Model Class Initialized
DEBUG - 2016-10-17 15:39:32 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:39:32 --> Model Class Initialized
DEBUG - 2016-10-17 15:39:32 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:39:32 --> Final output sent to browser
DEBUG - 2016-10-17 15:39:32 --> Total execution time: 0.0420
INFO - 2016-10-17 15:39:34 --> Config Class Initialized
INFO - 2016-10-17 15:39:34 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:39:34 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:39:34 --> Utf8 Class Initialized
INFO - 2016-10-17 15:39:34 --> URI Class Initialized
INFO - 2016-10-17 15:39:34 --> Router Class Initialized
INFO - 2016-10-17 15:39:34 --> Output Class Initialized
INFO - 2016-10-17 15:39:34 --> Security Class Initialized
DEBUG - 2016-10-17 15:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:39:34 --> Input Class Initialized
INFO - 2016-10-17 15:39:34 --> Language Class Initialized
INFO - 2016-10-17 15:39:34 --> Language Class Initialized
INFO - 2016-10-17 15:39:34 --> Config Class Initialized
INFO - 2016-10-17 15:39:34 --> Loader Class Initialized
INFO - 2016-10-17 15:39:34 --> Helper loaded: common_helper
INFO - 2016-10-17 15:39:34 --> Helper loaded: url_helper
INFO - 2016-10-17 15:39:34 --> Database Driver Class Initialized
INFO - 2016-10-17 15:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:39:34 --> Parser Class Initialized
INFO - 2016-10-17 15:39:34 --> Controller Class Initialized
DEBUG - 2016-10-17 15:39:34 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:39:34 --> Model Class Initialized
DEBUG - 2016-10-17 15:39:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:39:34 --> Model Class Initialized
DEBUG - 2016-10-17 15:39:34 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:39:34 --> Final output sent to browser
DEBUG - 2016-10-17 15:39:34 --> Total execution time: 0.0391
INFO - 2016-10-17 15:40:31 --> Config Class Initialized
INFO - 2016-10-17 15:40:31 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:40:31 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:40:31 --> Utf8 Class Initialized
INFO - 2016-10-17 15:40:31 --> URI Class Initialized
INFO - 2016-10-17 15:40:31 --> Router Class Initialized
INFO - 2016-10-17 15:40:31 --> Output Class Initialized
INFO - 2016-10-17 15:40:31 --> Security Class Initialized
DEBUG - 2016-10-17 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:40:31 --> Input Class Initialized
INFO - 2016-10-17 15:40:31 --> Language Class Initialized
INFO - 2016-10-17 15:40:31 --> Language Class Initialized
INFO - 2016-10-17 15:40:31 --> Config Class Initialized
INFO - 2016-10-17 15:40:31 --> Loader Class Initialized
INFO - 2016-10-17 15:40:31 --> Helper loaded: common_helper
INFO - 2016-10-17 15:40:31 --> Helper loaded: url_helper
INFO - 2016-10-17 15:40:31 --> Database Driver Class Initialized
INFO - 2016-10-17 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:40:31 --> Parser Class Initialized
INFO - 2016-10-17 15:40:31 --> Controller Class Initialized
DEBUG - 2016-10-17 15:40:31 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:40:31 --> Model Class Initialized
DEBUG - 2016-10-17 15:40:31 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:40:31 --> Model Class Initialized
DEBUG - 2016-10-17 15:40:31 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
ERROR - 2016-10-17 15:40:31 --> Severity: Notice --> Undefined variable: content /home/dolongpk/public_html/application/modules/home/controllers/Home.php 110
INFO - 2016-10-17 15:40:31 --> Final output sent to browser
DEBUG - 2016-10-17 15:40:31 --> Total execution time: 0.0378
INFO - 2016-10-17 15:40:42 --> Config Class Initialized
INFO - 2016-10-17 15:40:42 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:40:42 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:40:42 --> Utf8 Class Initialized
INFO - 2016-10-17 15:40:42 --> URI Class Initialized
INFO - 2016-10-17 15:40:42 --> Router Class Initialized
INFO - 2016-10-17 15:40:42 --> Output Class Initialized
INFO - 2016-10-17 15:40:42 --> Security Class Initialized
DEBUG - 2016-10-17 15:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:40:42 --> Input Class Initialized
INFO - 2016-10-17 15:40:42 --> Language Class Initialized
INFO - 2016-10-17 15:40:42 --> Language Class Initialized
INFO - 2016-10-17 15:40:42 --> Config Class Initialized
INFO - 2016-10-17 15:40:42 --> Loader Class Initialized
INFO - 2016-10-17 15:40:42 --> Helper loaded: common_helper
INFO - 2016-10-17 15:40:42 --> Helper loaded: url_helper
INFO - 2016-10-17 15:40:42 --> Database Driver Class Initialized
INFO - 2016-10-17 15:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:40:42 --> Parser Class Initialized
INFO - 2016-10-17 15:40:42 --> Controller Class Initialized
DEBUG - 2016-10-17 15:40:42 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:40:42 --> Model Class Initialized
DEBUG - 2016-10-17 15:40:42 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:40:42 --> Model Class Initialized
DEBUG - 2016-10-17 15:40:42 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:40:42 --> Final output sent to browser
DEBUG - 2016-10-17 15:40:42 --> Total execution time: 0.0403
INFO - 2016-10-17 15:41:07 --> Config Class Initialized
INFO - 2016-10-17 15:41:07 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:41:07 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:41:07 --> Utf8 Class Initialized
INFO - 2016-10-17 15:41:07 --> URI Class Initialized
INFO - 2016-10-17 15:41:07 --> Router Class Initialized
INFO - 2016-10-17 15:41:07 --> Output Class Initialized
INFO - 2016-10-17 15:41:07 --> Security Class Initialized
DEBUG - 2016-10-17 15:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:41:07 --> Input Class Initialized
INFO - 2016-10-17 15:41:07 --> Language Class Initialized
INFO - 2016-10-17 15:41:07 --> Language Class Initialized
INFO - 2016-10-17 15:41:07 --> Config Class Initialized
INFO - 2016-10-17 15:41:07 --> Loader Class Initialized
INFO - 2016-10-17 15:41:07 --> Helper loaded: common_helper
INFO - 2016-10-17 15:41:07 --> Helper loaded: url_helper
INFO - 2016-10-17 15:41:07 --> Database Driver Class Initialized
INFO - 2016-10-17 15:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:41:07 --> Parser Class Initialized
INFO - 2016-10-17 15:41:07 --> Controller Class Initialized
DEBUG - 2016-10-17 15:41:07 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:41:07 --> Model Class Initialized
DEBUG - 2016-10-17 15:41:07 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:41:07 --> Model Class Initialized
DEBUG - 2016-10-17 15:41:07 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:41:07 --> Final output sent to browser
DEBUG - 2016-10-17 15:41:07 --> Total execution time: 0.0494
INFO - 2016-10-17 15:42:58 --> Config Class Initialized
INFO - 2016-10-17 15:42:58 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:42:58 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:42:58 --> Utf8 Class Initialized
INFO - 2016-10-17 15:42:58 --> URI Class Initialized
INFO - 2016-10-17 15:42:58 --> Router Class Initialized
INFO - 2016-10-17 15:42:58 --> Output Class Initialized
INFO - 2016-10-17 15:42:58 --> Security Class Initialized
DEBUG - 2016-10-17 15:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:42:58 --> Input Class Initialized
INFO - 2016-10-17 15:42:58 --> Language Class Initialized
INFO - 2016-10-17 15:42:58 --> Language Class Initialized
INFO - 2016-10-17 15:42:58 --> Config Class Initialized
INFO - 2016-10-17 15:42:58 --> Loader Class Initialized
INFO - 2016-10-17 15:42:58 --> Helper loaded: common_helper
INFO - 2016-10-17 15:42:58 --> Helper loaded: url_helper
INFO - 2016-10-17 15:42:58 --> Database Driver Class Initialized
INFO - 2016-10-17 15:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:42:58 --> Parser Class Initialized
INFO - 2016-10-17 15:42:58 --> Controller Class Initialized
DEBUG - 2016-10-17 15:42:58 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:42:58 --> Model Class Initialized
DEBUG - 2016-10-17 15:42:58 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:42:58 --> Model Class Initialized
DEBUG - 2016-10-17 15:42:58 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:42:58 --> Final output sent to browser
DEBUG - 2016-10-17 15:42:58 --> Total execution time: 0.0391
INFO - 2016-10-17 15:42:59 --> Config Class Initialized
INFO - 2016-10-17 15:42:59 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:42:59 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:42:59 --> Utf8 Class Initialized
INFO - 2016-10-17 15:42:59 --> URI Class Initialized
INFO - 2016-10-17 15:42:59 --> Router Class Initialized
INFO - 2016-10-17 15:42:59 --> Output Class Initialized
INFO - 2016-10-17 15:42:59 --> Security Class Initialized
DEBUG - 2016-10-17 15:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:42:59 --> Input Class Initialized
INFO - 2016-10-17 15:42:59 --> Language Class Initialized
INFO - 2016-10-17 15:42:59 --> Language Class Initialized
INFO - 2016-10-17 15:42:59 --> Config Class Initialized
INFO - 2016-10-17 15:42:59 --> Loader Class Initialized
INFO - 2016-10-17 15:42:59 --> Helper loaded: common_helper
INFO - 2016-10-17 15:42:59 --> Helper loaded: url_helper
INFO - 2016-10-17 15:42:59 --> Database Driver Class Initialized
INFO - 2016-10-17 15:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:42:59 --> Parser Class Initialized
INFO - 2016-10-17 15:42:59 --> Controller Class Initialized
DEBUG - 2016-10-17 15:42:59 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:42:59 --> Model Class Initialized
DEBUG - 2016-10-17 15:42:59 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:42:59 --> Model Class Initialized
DEBUG - 2016-10-17 15:42:59 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:42:59 --> Final output sent to browser
DEBUG - 2016-10-17 15:42:59 --> Total execution time: 0.0411
INFO - 2016-10-17 15:43:00 --> Config Class Initialized
INFO - 2016-10-17 15:43:00 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:43:00 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:43:00 --> Utf8 Class Initialized
INFO - 2016-10-17 15:43:00 --> URI Class Initialized
INFO - 2016-10-17 15:43:00 --> Router Class Initialized
INFO - 2016-10-17 15:43:00 --> Output Class Initialized
INFO - 2016-10-17 15:43:00 --> Security Class Initialized
DEBUG - 2016-10-17 15:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:43:00 --> Input Class Initialized
INFO - 2016-10-17 15:43:00 --> Language Class Initialized
INFO - 2016-10-17 15:43:00 --> Language Class Initialized
INFO - 2016-10-17 15:43:00 --> Config Class Initialized
INFO - 2016-10-17 15:43:00 --> Loader Class Initialized
INFO - 2016-10-17 15:43:00 --> Helper loaded: common_helper
INFO - 2016-10-17 15:43:00 --> Helper loaded: url_helper
INFO - 2016-10-17 15:43:00 --> Database Driver Class Initialized
INFO - 2016-10-17 15:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:43:00 --> Parser Class Initialized
INFO - 2016-10-17 15:43:00 --> Controller Class Initialized
DEBUG - 2016-10-17 15:43:00 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:43:00 --> Model Class Initialized
DEBUG - 2016-10-17 15:43:00 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:43:00 --> Model Class Initialized
DEBUG - 2016-10-17 15:43:00 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:43:00 --> Final output sent to browser
DEBUG - 2016-10-17 15:43:00 --> Total execution time: 0.0354
INFO - 2016-10-17 15:43:01 --> Config Class Initialized
INFO - 2016-10-17 15:43:01 --> Hooks Class Initialized
DEBUG - 2016-10-17 15:43:01 --> UTF-8 Support Enabled
INFO - 2016-10-17 15:43:01 --> Utf8 Class Initialized
INFO - 2016-10-17 15:43:01 --> URI Class Initialized
INFO - 2016-10-17 15:43:01 --> Router Class Initialized
INFO - 2016-10-17 15:43:01 --> Output Class Initialized
INFO - 2016-10-17 15:43:01 --> Security Class Initialized
DEBUG - 2016-10-17 15:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 15:43:01 --> Input Class Initialized
INFO - 2016-10-17 15:43:01 --> Language Class Initialized
INFO - 2016-10-17 15:43:01 --> Language Class Initialized
INFO - 2016-10-17 15:43:01 --> Config Class Initialized
INFO - 2016-10-17 15:43:01 --> Loader Class Initialized
INFO - 2016-10-17 15:43:01 --> Helper loaded: common_helper
INFO - 2016-10-17 15:43:01 --> Helper loaded: url_helper
INFO - 2016-10-17 15:43:01 --> Database Driver Class Initialized
INFO - 2016-10-17 15:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 15:43:01 --> Parser Class Initialized
INFO - 2016-10-17 15:43:01 --> Controller Class Initialized
DEBUG - 2016-10-17 15:43:01 --> Home MX_Controller Initialized
INFO - 2016-10-17 15:43:01 --> Model Class Initialized
DEBUG - 2016-10-17 15:43:01 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 15:43:01 --> Model Class Initialized
DEBUG - 2016-10-17 15:43:01 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 15:43:01 --> Final output sent to browser
DEBUG - 2016-10-17 15:43:01 --> Total execution time: 0.0346
INFO - 2016-10-17 17:21:15 --> Config Class Initialized
INFO - 2016-10-17 17:21:15 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:21:15 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:21:15 --> Utf8 Class Initialized
INFO - 2016-10-17 17:21:15 --> URI Class Initialized
INFO - 2016-10-17 17:21:15 --> Router Class Initialized
INFO - 2016-10-17 17:21:15 --> Output Class Initialized
INFO - 2016-10-17 17:21:15 --> Security Class Initialized
DEBUG - 2016-10-17 17:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:21:15 --> Input Class Initialized
INFO - 2016-10-17 17:21:15 --> Language Class Initialized
INFO - 2016-10-17 17:21:15 --> Language Class Initialized
INFO - 2016-10-17 17:21:15 --> Config Class Initialized
INFO - 2016-10-17 17:21:15 --> Loader Class Initialized
INFO - 2016-10-17 17:21:15 --> Helper loaded: common_helper
INFO - 2016-10-17 17:21:15 --> Helper loaded: url_helper
INFO - 2016-10-17 17:21:15 --> Database Driver Class Initialized
INFO - 2016-10-17 17:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:21:15 --> Parser Class Initialized
INFO - 2016-10-17 17:21:15 --> Controller Class Initialized
DEBUG - 2016-10-17 17:21:15 --> Home MX_Controller Initialized
INFO - 2016-10-17 17:21:15 --> Model Class Initialized
DEBUG - 2016-10-17 17:21:15 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 17:21:15 --> Model Class Initialized
DEBUG - 2016-10-17 17:21:15 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 17:21:15 --> Final output sent to browser
DEBUG - 2016-10-17 17:21:15 --> Total execution time: 0.0544
INFO - 2016-10-17 17:25:20 --> Config Class Initialized
INFO - 2016-10-17 17:25:20 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:25:20 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:25:20 --> Utf8 Class Initialized
INFO - 2016-10-17 17:25:20 --> URI Class Initialized
INFO - 2016-10-17 17:25:20 --> Router Class Initialized
INFO - 2016-10-17 17:25:20 --> Output Class Initialized
INFO - 2016-10-17 17:25:20 --> Security Class Initialized
DEBUG - 2016-10-17 17:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:25:20 --> Input Class Initialized
INFO - 2016-10-17 17:25:20 --> Language Class Initialized
INFO - 2016-10-17 17:25:20 --> Language Class Initialized
INFO - 2016-10-17 17:25:20 --> Config Class Initialized
INFO - 2016-10-17 17:25:20 --> Loader Class Initialized
INFO - 2016-10-17 17:25:20 --> Helper loaded: common_helper
INFO - 2016-10-17 17:25:20 --> Helper loaded: url_helper
INFO - 2016-10-17 17:25:20 --> Database Driver Class Initialized
INFO - 2016-10-17 17:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:25:20 --> Parser Class Initialized
INFO - 2016-10-17 17:25:20 --> Controller Class Initialized
DEBUG - 2016-10-17 17:25:20 --> Home MX_Controller Initialized
INFO - 2016-10-17 17:25:20 --> Model Class Initialized
DEBUG - 2016-10-17 17:25:20 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 17:25:20 --> Model Class Initialized
DEBUG - 2016-10-17 17:25:20 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 17:25:20 --> Final output sent to browser
DEBUG - 2016-10-17 17:25:20 --> Total execution time: 0.0394
INFO - 2016-10-17 17:26:18 --> Config Class Initialized
INFO - 2016-10-17 17:26:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:26:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:26:18 --> Utf8 Class Initialized
INFO - 2016-10-17 17:26:18 --> URI Class Initialized
INFO - 2016-10-17 17:26:18 --> Router Class Initialized
INFO - 2016-10-17 17:26:18 --> Output Class Initialized
INFO - 2016-10-17 17:26:18 --> Security Class Initialized
DEBUG - 2016-10-17 17:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:26:18 --> Input Class Initialized
INFO - 2016-10-17 17:26:18 --> Language Class Initialized
INFO - 2016-10-17 17:26:18 --> Language Class Initialized
INFO - 2016-10-17 17:26:18 --> Config Class Initialized
INFO - 2016-10-17 17:26:18 --> Loader Class Initialized
INFO - 2016-10-17 17:26:18 --> Helper loaded: common_helper
INFO - 2016-10-17 17:26:18 --> Helper loaded: url_helper
INFO - 2016-10-17 17:26:18 --> Database Driver Class Initialized
INFO - 2016-10-17 17:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:26:18 --> Parser Class Initialized
INFO - 2016-10-17 17:26:18 --> Controller Class Initialized
DEBUG - 2016-10-17 17:26:18 --> Home MX_Controller Initialized
INFO - 2016-10-17 17:26:18 --> Model Class Initialized
DEBUG - 2016-10-17 17:26:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 17:26:18 --> Model Class Initialized
DEBUG - 2016-10-17 17:26:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 17:26:18 --> Final output sent to browser
DEBUG - 2016-10-17 17:26:18 --> Total execution time: 0.0399
INFO - 2016-10-17 17:32:05 --> Config Class Initialized
INFO - 2016-10-17 17:32:05 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:32:05 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:32:05 --> Utf8 Class Initialized
INFO - 2016-10-17 17:32:05 --> URI Class Initialized
INFO - 2016-10-17 17:32:05 --> Router Class Initialized
INFO - 2016-10-17 17:32:05 --> Output Class Initialized
INFO - 2016-10-17 17:32:05 --> Security Class Initialized
DEBUG - 2016-10-17 17:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:32:05 --> Input Class Initialized
INFO - 2016-10-17 17:32:05 --> Language Class Initialized
INFO - 2016-10-17 17:32:05 --> Language Class Initialized
INFO - 2016-10-17 17:32:05 --> Config Class Initialized
INFO - 2016-10-17 17:32:05 --> Loader Class Initialized
INFO - 2016-10-17 17:32:05 --> Helper loaded: common_helper
INFO - 2016-10-17 17:32:05 --> Helper loaded: url_helper
INFO - 2016-10-17 17:32:05 --> Database Driver Class Initialized
INFO - 2016-10-17 17:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:32:05 --> Parser Class Initialized
INFO - 2016-10-17 17:32:05 --> Controller Class Initialized
DEBUG - 2016-10-17 17:32:05 --> Home MX_Controller Initialized
INFO - 2016-10-17 17:32:05 --> Model Class Initialized
DEBUG - 2016-10-17 17:32:05 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 17:32:05 --> Model Class Initialized
DEBUG - 2016-10-17 17:32:05 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 17:32:05 --> Final output sent to browser
DEBUG - 2016-10-17 17:32:05 --> Total execution time: 0.0400
INFO - 2016-10-17 17:33:27 --> Config Class Initialized
INFO - 2016-10-17 17:33:27 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:33:27 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:33:27 --> Utf8 Class Initialized
INFO - 2016-10-17 17:33:27 --> URI Class Initialized
INFO - 2016-10-17 17:33:27 --> Router Class Initialized
INFO - 2016-10-17 17:33:27 --> Output Class Initialized
INFO - 2016-10-17 17:33:27 --> Security Class Initialized
DEBUG - 2016-10-17 17:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:33:27 --> Input Class Initialized
INFO - 2016-10-17 17:33:27 --> Language Class Initialized
INFO - 2016-10-17 17:33:27 --> Language Class Initialized
INFO - 2016-10-17 17:33:27 --> Config Class Initialized
INFO - 2016-10-17 17:33:27 --> Loader Class Initialized
INFO - 2016-10-17 17:33:27 --> Helper loaded: common_helper
INFO - 2016-10-17 17:33:27 --> Helper loaded: url_helper
INFO - 2016-10-17 17:33:27 --> Database Driver Class Initialized
INFO - 2016-10-17 17:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:33:27 --> Parser Class Initialized
INFO - 2016-10-17 17:33:27 --> Controller Class Initialized
DEBUG - 2016-10-17 17:33:27 --> Home MX_Controller Initialized
INFO - 2016-10-17 17:33:27 --> Model Class Initialized
DEBUG - 2016-10-17 17:33:27 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 17:33:27 --> Model Class Initialized
DEBUG - 2016-10-17 17:33:27 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 17:33:56 --> Config Class Initialized
INFO - 2016-10-17 17:33:56 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:33:56 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:33:56 --> Utf8 Class Initialized
INFO - 2016-10-17 17:33:56 --> URI Class Initialized
INFO - 2016-10-17 17:33:56 --> Router Class Initialized
INFO - 2016-10-17 17:33:56 --> Output Class Initialized
INFO - 2016-10-17 17:33:56 --> Security Class Initialized
DEBUG - 2016-10-17 17:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:33:56 --> Input Class Initialized
INFO - 2016-10-17 17:33:56 --> Language Class Initialized
INFO - 2016-10-17 17:33:56 --> Language Class Initialized
INFO - 2016-10-17 17:33:56 --> Config Class Initialized
INFO - 2016-10-17 17:33:56 --> Loader Class Initialized
INFO - 2016-10-17 17:33:56 --> Helper loaded: common_helper
INFO - 2016-10-17 17:33:56 --> Helper loaded: url_helper
INFO - 2016-10-17 17:33:56 --> Database Driver Class Initialized
INFO - 2016-10-17 17:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:33:56 --> Parser Class Initialized
INFO - 2016-10-17 17:33:56 --> Controller Class Initialized
DEBUG - 2016-10-17 17:33:56 --> Home MX_Controller Initialized
INFO - 2016-10-17 17:33:56 --> Model Class Initialized
DEBUG - 2016-10-17 17:33:56 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 17:33:56 --> Model Class Initialized
DEBUG - 2016-10-17 17:33:56 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 17:34:18 --> Config Class Initialized
INFO - 2016-10-17 17:34:18 --> Hooks Class Initialized
DEBUG - 2016-10-17 17:34:18 --> UTF-8 Support Enabled
INFO - 2016-10-17 17:34:18 --> Utf8 Class Initialized
INFO - 2016-10-17 17:34:18 --> URI Class Initialized
INFO - 2016-10-17 17:34:18 --> Router Class Initialized
INFO - 2016-10-17 17:34:18 --> Output Class Initialized
INFO - 2016-10-17 17:34:18 --> Security Class Initialized
DEBUG - 2016-10-17 17:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 17:34:18 --> Input Class Initialized
INFO - 2016-10-17 17:34:18 --> Language Class Initialized
INFO - 2016-10-17 17:34:18 --> Language Class Initialized
INFO - 2016-10-17 17:34:18 --> Config Class Initialized
INFO - 2016-10-17 17:34:18 --> Loader Class Initialized
INFO - 2016-10-17 17:34:18 --> Helper loaded: common_helper
INFO - 2016-10-17 17:34:18 --> Helper loaded: url_helper
INFO - 2016-10-17 17:34:18 --> Database Driver Class Initialized
INFO - 2016-10-17 17:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 17:34:18 --> Parser Class Initialized
INFO - 2016-10-17 17:34:18 --> Controller Class Initialized
DEBUG - 2016-10-17 17:34:18 --> Home MX_Controller Initialized
INFO - 2016-10-17 17:34:18 --> Model Class Initialized
DEBUG - 2016-10-17 17:34:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 17:34:18 --> Model Class Initialized
DEBUG - 2016-10-17 17:34:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/api_view.php
INFO - 2016-10-17 23:18:36 --> Config Class Initialized
INFO - 2016-10-17 23:18:36 --> Hooks Class Initialized
DEBUG - 2016-10-17 23:18:36 --> UTF-8 Support Enabled
INFO - 2016-10-17 23:18:36 --> Utf8 Class Initialized
INFO - 2016-10-17 23:18:36 --> URI Class Initialized
INFO - 2016-10-17 23:18:36 --> Router Class Initialized
INFO - 2016-10-17 23:18:36 --> Output Class Initialized
INFO - 2016-10-17 23:18:36 --> Security Class Initialized
DEBUG - 2016-10-17 23:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 23:18:36 --> Input Class Initialized
INFO - 2016-10-17 23:18:36 --> Language Class Initialized
ERROR - 2016-10-17 23:18:36 --> 404 Page Not Found: /index
INFO - 2016-10-17 23:18:37 --> Config Class Initialized
INFO - 2016-10-17 23:18:37 --> Hooks Class Initialized
DEBUG - 2016-10-17 23:18:37 --> UTF-8 Support Enabled
INFO - 2016-10-17 23:18:37 --> Utf8 Class Initialized
INFO - 2016-10-17 23:18:37 --> URI Class Initialized
DEBUG - 2016-10-17 23:18:37 --> No URI present. Default controller set.
INFO - 2016-10-17 23:18:37 --> Router Class Initialized
INFO - 2016-10-17 23:18:37 --> Output Class Initialized
INFO - 2016-10-17 23:18:37 --> Security Class Initialized
DEBUG - 2016-10-17 23:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 23:18:37 --> Input Class Initialized
INFO - 2016-10-17 23:18:37 --> Language Class Initialized
INFO - 2016-10-17 23:18:37 --> Language Class Initialized
INFO - 2016-10-17 23:18:37 --> Config Class Initialized
INFO - 2016-10-17 23:18:37 --> Loader Class Initialized
INFO - 2016-10-17 23:18:37 --> Helper loaded: common_helper
INFO - 2016-10-17 23:18:37 --> Helper loaded: url_helper
INFO - 2016-10-17 23:18:37 --> Database Driver Class Initialized
INFO - 2016-10-17 23:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 23:18:37 --> Parser Class Initialized
INFO - 2016-10-17 23:18:37 --> Controller Class Initialized
DEBUG - 2016-10-17 23:18:37 --> Home MX_Controller Initialized
INFO - 2016-10-17 23:18:37 --> Model Class Initialized
DEBUG - 2016-10-17 23:18:37 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 23:18:37 --> Model Class Initialized
ERROR - 2016-10-17 23:18:37 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 23:18:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 23:18:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 23:18:37 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-17 23:18:37 --> Final output sent to browser
DEBUG - 2016-10-17 23:18:37 --> Total execution time: 0.0448
INFO - 2016-10-17 23:20:35 --> Config Class Initialized
INFO - 2016-10-17 23:20:35 --> Hooks Class Initialized
DEBUG - 2016-10-17 23:20:35 --> UTF-8 Support Enabled
INFO - 2016-10-17 23:20:35 --> Utf8 Class Initialized
INFO - 2016-10-17 23:20:35 --> URI Class Initialized
INFO - 2016-10-17 23:20:35 --> Router Class Initialized
INFO - 2016-10-17 23:20:35 --> Output Class Initialized
INFO - 2016-10-17 23:20:35 --> Security Class Initialized
DEBUG - 2016-10-17 23:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 23:20:35 --> Input Class Initialized
INFO - 2016-10-17 23:20:35 --> Language Class Initialized
ERROR - 2016-10-17 23:20:35 --> 404 Page Not Found: /index
INFO - 2016-10-17 23:20:35 --> Config Class Initialized
INFO - 2016-10-17 23:20:35 --> Hooks Class Initialized
DEBUG - 2016-10-17 23:20:35 --> UTF-8 Support Enabled
INFO - 2016-10-17 23:20:35 --> Utf8 Class Initialized
INFO - 2016-10-17 23:20:35 --> URI Class Initialized
DEBUG - 2016-10-17 23:20:35 --> No URI present. Default controller set.
INFO - 2016-10-17 23:20:35 --> Router Class Initialized
INFO - 2016-10-17 23:20:35 --> Output Class Initialized
INFO - 2016-10-17 23:20:35 --> Security Class Initialized
DEBUG - 2016-10-17 23:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-17 23:20:35 --> Input Class Initialized
INFO - 2016-10-17 23:20:35 --> Language Class Initialized
INFO - 2016-10-17 23:20:35 --> Language Class Initialized
INFO - 2016-10-17 23:20:35 --> Config Class Initialized
INFO - 2016-10-17 23:20:35 --> Loader Class Initialized
INFO - 2016-10-17 23:20:35 --> Helper loaded: common_helper
INFO - 2016-10-17 23:20:35 --> Helper loaded: url_helper
INFO - 2016-10-17 23:20:35 --> Database Driver Class Initialized
INFO - 2016-10-17 23:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-17 23:20:35 --> Parser Class Initialized
INFO - 2016-10-17 23:20:35 --> Controller Class Initialized
DEBUG - 2016-10-17 23:20:35 --> Home MX_Controller Initialized
INFO - 2016-10-17 23:20:35 --> Model Class Initialized
DEBUG - 2016-10-17 23:20:35 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-17 23:20:35 --> Model Class Initialized
ERROR - 2016-10-17 23:20:35 --> Module controller failed to run: banner/index
DEBUG - 2016-10-17 23:20:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-17 23:20:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-17 23:20:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-17 23:20:35 --> Final output sent to browser
DEBUG - 2016-10-17 23:20:35 --> Total execution time: 0.0423
