<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-19 01:25:21 --> Config Class Initialized
INFO - 2016-10-19 01:25:21 --> Hooks Class Initialized
DEBUG - 2016-10-19 01:25:21 --> UTF-8 Support Enabled
INFO - 2016-10-19 01:25:21 --> Utf8 Class Initialized
INFO - 2016-10-19 01:25:21 --> URI Class Initialized
DEBUG - 2016-10-19 01:25:21 --> No URI present. Default controller set.
INFO - 2016-10-19 01:25:21 --> Router Class Initialized
INFO - 2016-10-19 01:25:21 --> Output Class Initialized
INFO - 2016-10-19 01:25:21 --> Security Class Initialized
DEBUG - 2016-10-19 01:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 01:25:21 --> Input Class Initialized
INFO - 2016-10-19 01:25:21 --> Language Class Initialized
INFO - 2016-10-19 01:25:21 --> Language Class Initialized
INFO - 2016-10-19 01:25:21 --> Config Class Initialized
INFO - 2016-10-19 01:25:21 --> Loader Class Initialized
INFO - 2016-10-19 01:25:21 --> Helper loaded: common_helper
INFO - 2016-10-19 01:25:21 --> Helper loaded: url_helper
INFO - 2016-10-19 01:25:21 --> Database Driver Class Initialized
INFO - 2016-10-19 01:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 01:25:21 --> Parser Class Initialized
INFO - 2016-10-19 01:25:21 --> Controller Class Initialized
DEBUG - 2016-10-19 01:25:21 --> Home MX_Controller Initialized
INFO - 2016-10-19 01:25:21 --> Model Class Initialized
DEBUG - 2016-10-19 01:25:21 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 01:25:21 --> Model Class Initialized
ERROR - 2016-10-19 01:25:21 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 01:25:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 01:25:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 01:25:21 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 01:25:21 --> Final output sent to browser
DEBUG - 2016-10-19 01:25:21 --> Total execution time: 0.0784
INFO - 2016-10-19 01:27:23 --> Config Class Initialized
INFO - 2016-10-19 01:27:23 --> Hooks Class Initialized
DEBUG - 2016-10-19 01:27:23 --> UTF-8 Support Enabled
INFO - 2016-10-19 01:27:23 --> Utf8 Class Initialized
INFO - 2016-10-19 01:27:23 --> URI Class Initialized
DEBUG - 2016-10-19 01:27:23 --> No URI present. Default controller set.
INFO - 2016-10-19 01:27:23 --> Router Class Initialized
INFO - 2016-10-19 01:27:23 --> Output Class Initialized
INFO - 2016-10-19 01:27:23 --> Security Class Initialized
DEBUG - 2016-10-19 01:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 01:27:23 --> Input Class Initialized
INFO - 2016-10-19 01:27:23 --> Language Class Initialized
INFO - 2016-10-19 01:27:23 --> Language Class Initialized
INFO - 2016-10-19 01:27:23 --> Config Class Initialized
INFO - 2016-10-19 01:27:23 --> Loader Class Initialized
INFO - 2016-10-19 01:27:23 --> Helper loaded: common_helper
INFO - 2016-10-19 01:27:23 --> Helper loaded: url_helper
INFO - 2016-10-19 01:27:23 --> Database Driver Class Initialized
INFO - 2016-10-19 01:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 01:27:23 --> Parser Class Initialized
INFO - 2016-10-19 01:27:23 --> Controller Class Initialized
DEBUG - 2016-10-19 01:27:23 --> Home MX_Controller Initialized
INFO - 2016-10-19 01:27:23 --> Model Class Initialized
DEBUG - 2016-10-19 01:27:23 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 01:27:23 --> Model Class Initialized
ERROR - 2016-10-19 01:27:23 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 01:27:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 01:27:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 01:27:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 01:27:23 --> Final output sent to browser
DEBUG - 2016-10-19 01:27:23 --> Total execution time: 0.0456
INFO - 2016-10-19 02:33:03 --> Config Class Initialized
INFO - 2016-10-19 02:33:03 --> Hooks Class Initialized
DEBUG - 2016-10-19 02:33:03 --> UTF-8 Support Enabled
INFO - 2016-10-19 02:33:03 --> Utf8 Class Initialized
INFO - 2016-10-19 02:33:03 --> URI Class Initialized
INFO - 2016-10-19 02:33:03 --> Router Class Initialized
INFO - 2016-10-19 02:33:03 --> Output Class Initialized
INFO - 2016-10-19 02:33:03 --> Security Class Initialized
DEBUG - 2016-10-19 02:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 02:33:03 --> Input Class Initialized
INFO - 2016-10-19 02:33:03 --> Language Class Initialized
ERROR - 2016-10-19 02:33:03 --> 404 Page Not Found: /index
INFO - 2016-10-19 02:33:05 --> Config Class Initialized
INFO - 2016-10-19 02:33:05 --> Hooks Class Initialized
DEBUG - 2016-10-19 02:33:05 --> UTF-8 Support Enabled
INFO - 2016-10-19 02:33:05 --> Utf8 Class Initialized
INFO - 2016-10-19 02:33:05 --> URI Class Initialized
INFO - 2016-10-19 02:33:05 --> Router Class Initialized
INFO - 2016-10-19 02:33:05 --> Output Class Initialized
INFO - 2016-10-19 02:33:05 --> Security Class Initialized
DEBUG - 2016-10-19 02:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 02:33:05 --> Input Class Initialized
INFO - 2016-10-19 02:33:05 --> Language Class Initialized
ERROR - 2016-10-19 02:33:05 --> 404 Page Not Found: /index
INFO - 2016-10-19 03:04:41 --> Config Class Initialized
INFO - 2016-10-19 03:04:41 --> Hooks Class Initialized
DEBUG - 2016-10-19 03:04:41 --> UTF-8 Support Enabled
INFO - 2016-10-19 03:04:41 --> Utf8 Class Initialized
INFO - 2016-10-19 03:04:41 --> URI Class Initialized
DEBUG - 2016-10-19 03:04:41 --> No URI present. Default controller set.
INFO - 2016-10-19 03:04:41 --> Router Class Initialized
INFO - 2016-10-19 03:04:41 --> Output Class Initialized
INFO - 2016-10-19 03:04:41 --> Security Class Initialized
DEBUG - 2016-10-19 03:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 03:04:41 --> Input Class Initialized
INFO - 2016-10-19 03:04:41 --> Language Class Initialized
INFO - 2016-10-19 03:04:41 --> Language Class Initialized
INFO - 2016-10-19 03:04:41 --> Config Class Initialized
INFO - 2016-10-19 03:04:41 --> Loader Class Initialized
INFO - 2016-10-19 03:04:41 --> Helper loaded: common_helper
INFO - 2016-10-19 03:04:41 --> Helper loaded: url_helper
INFO - 2016-10-19 03:04:41 --> Database Driver Class Initialized
INFO - 2016-10-19 03:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 03:04:41 --> Parser Class Initialized
INFO - 2016-10-19 03:04:41 --> Controller Class Initialized
DEBUG - 2016-10-19 03:04:41 --> Home MX_Controller Initialized
INFO - 2016-10-19 03:04:41 --> Model Class Initialized
DEBUG - 2016-10-19 03:04:41 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 03:04:41 --> Model Class Initialized
ERROR - 2016-10-19 03:04:41 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 03:04:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 03:04:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 03:04:41 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 03:04:41 --> Final output sent to browser
DEBUG - 2016-10-19 03:04:41 --> Total execution time: 0.0696
INFO - 2016-10-19 05:23:50 --> Config Class Initialized
INFO - 2016-10-19 05:23:50 --> Hooks Class Initialized
DEBUG - 2016-10-19 05:23:50 --> UTF-8 Support Enabled
INFO - 2016-10-19 05:23:50 --> Utf8 Class Initialized
INFO - 2016-10-19 05:23:50 --> URI Class Initialized
INFO - 2016-10-19 05:23:50 --> Router Class Initialized
INFO - 2016-10-19 05:23:50 --> Output Class Initialized
INFO - 2016-10-19 05:23:50 --> Security Class Initialized
DEBUG - 2016-10-19 05:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 05:23:50 --> Input Class Initialized
INFO - 2016-10-19 05:23:50 --> Language Class Initialized
INFO - 2016-10-19 05:23:50 --> Language Class Initialized
INFO - 2016-10-19 05:23:50 --> Config Class Initialized
INFO - 2016-10-19 05:23:50 --> Loader Class Initialized
INFO - 2016-10-19 05:23:50 --> Helper loaded: common_helper
INFO - 2016-10-19 05:23:50 --> Helper loaded: url_helper
INFO - 2016-10-19 05:23:50 --> Database Driver Class Initialized
INFO - 2016-10-19 05:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 05:23:50 --> Parser Class Initialized
INFO - 2016-10-19 05:23:50 --> Controller Class Initialized
DEBUG - 2016-10-19 05:23:50 --> Content MX_Controller Initialized
INFO - 2016-10-19 05:23:50 --> Model Class Initialized
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-19 05:23:50 --> Model Class Initialized
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 05:23:50 --> Model Class Initialized
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 05:23:50 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 05:23:50 --> Model Class Initialized
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 05:23:50 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 05:23:50 --> Model Class Initialized
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-19 05:23:50 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 05:23:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 05:23:50 --> Final output sent to browser
DEBUG - 2016-10-19 05:23:50 --> Total execution time: 0.4437
INFO - 2016-10-19 09:21:39 --> Config Class Initialized
INFO - 2016-10-19 09:21:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:21:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:21:39 --> Utf8 Class Initialized
INFO - 2016-10-19 09:21:39 --> URI Class Initialized
DEBUG - 2016-10-19 09:21:39 --> No URI present. Default controller set.
INFO - 2016-10-19 09:21:39 --> Router Class Initialized
INFO - 2016-10-19 09:21:39 --> Output Class Initialized
INFO - 2016-10-19 09:21:39 --> Security Class Initialized
DEBUG - 2016-10-19 09:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:21:39 --> Input Class Initialized
INFO - 2016-10-19 09:21:39 --> Language Class Initialized
INFO - 2016-10-19 09:21:39 --> Language Class Initialized
INFO - 2016-10-19 09:21:39 --> Config Class Initialized
INFO - 2016-10-19 09:21:39 --> Loader Class Initialized
INFO - 2016-10-19 09:21:39 --> Helper loaded: common_helper
INFO - 2016-10-19 09:21:39 --> Helper loaded: url_helper
INFO - 2016-10-19 09:21:39 --> Database Driver Class Initialized
INFO - 2016-10-19 09:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:21:39 --> Parser Class Initialized
INFO - 2016-10-19 09:21:39 --> Controller Class Initialized
DEBUG - 2016-10-19 09:21:39 --> Home MX_Controller Initialized
INFO - 2016-10-19 09:21:39 --> Model Class Initialized
DEBUG - 2016-10-19 09:21:39 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 09:21:39 --> Model Class Initialized
ERROR - 2016-10-19 09:21:39 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 09:21:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 09:21:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 09:21:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 09:21:39 --> Final output sent to browser
DEBUG - 2016-10-19 09:21:39 --> Total execution time: 0.0459
INFO - 2016-10-19 09:23:53 --> Config Class Initialized
INFO - 2016-10-19 09:23:53 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:23:53 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:23:53 --> Utf8 Class Initialized
INFO - 2016-10-19 09:23:53 --> URI Class Initialized
INFO - 2016-10-19 09:23:53 --> Router Class Initialized
INFO - 2016-10-19 09:23:53 --> Output Class Initialized
INFO - 2016-10-19 09:23:53 --> Security Class Initialized
DEBUG - 2016-10-19 09:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:23:53 --> Input Class Initialized
INFO - 2016-10-19 09:23:53 --> Language Class Initialized
ERROR - 2016-10-19 09:23:53 --> 404 Page Not Found: /index
INFO - 2016-10-19 09:23:54 --> Config Class Initialized
INFO - 2016-10-19 09:23:54 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:23:54 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:23:54 --> Utf8 Class Initialized
INFO - 2016-10-19 09:23:54 --> URI Class Initialized
INFO - 2016-10-19 09:23:54 --> Router Class Initialized
INFO - 2016-10-19 09:23:54 --> Output Class Initialized
INFO - 2016-10-19 09:23:54 --> Security Class Initialized
DEBUG - 2016-10-19 09:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:23:54 --> Input Class Initialized
INFO - 2016-10-19 09:23:54 --> Language Class Initialized
ERROR - 2016-10-19 09:23:54 --> 404 Page Not Found: /index
INFO - 2016-10-19 09:23:54 --> Config Class Initialized
INFO - 2016-10-19 09:23:54 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:23:54 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:23:54 --> Utf8 Class Initialized
INFO - 2016-10-19 09:23:54 --> URI Class Initialized
INFO - 2016-10-19 09:23:54 --> Router Class Initialized
INFO - 2016-10-19 09:23:54 --> Output Class Initialized
INFO - 2016-10-19 09:23:54 --> Security Class Initialized
DEBUG - 2016-10-19 09:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:23:54 --> Input Class Initialized
INFO - 2016-10-19 09:23:54 --> Language Class Initialized
ERROR - 2016-10-19 09:23:54 --> 404 Page Not Found: /index
INFO - 2016-10-19 09:31:35 --> Config Class Initialized
INFO - 2016-10-19 09:31:35 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:31:35 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:31:35 --> Utf8 Class Initialized
INFO - 2016-10-19 09:31:35 --> URI Class Initialized
INFO - 2016-10-19 09:31:35 --> Router Class Initialized
INFO - 2016-10-19 09:31:35 --> Output Class Initialized
INFO - 2016-10-19 09:31:35 --> Security Class Initialized
DEBUG - 2016-10-19 09:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:31:35 --> Input Class Initialized
INFO - 2016-10-19 09:31:35 --> Language Class Initialized
ERROR - 2016-10-19 09:31:35 --> 404 Page Not Found: /index
INFO - 2016-10-19 09:31:40 --> Config Class Initialized
INFO - 2016-10-19 09:31:40 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:31:40 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:31:40 --> Utf8 Class Initialized
INFO - 2016-10-19 09:31:40 --> URI Class Initialized
INFO - 2016-10-19 09:31:40 --> Router Class Initialized
INFO - 2016-10-19 09:31:40 --> Output Class Initialized
INFO - 2016-10-19 09:31:40 --> Security Class Initialized
DEBUG - 2016-10-19 09:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:31:40 --> Input Class Initialized
INFO - 2016-10-19 09:31:40 --> Language Class Initialized
INFO - 2016-10-19 09:31:40 --> Language Class Initialized
INFO - 2016-10-19 09:31:40 --> Config Class Initialized
INFO - 2016-10-19 09:31:40 --> Loader Class Initialized
INFO - 2016-10-19 09:31:40 --> Helper loaded: common_helper
INFO - 2016-10-19 09:31:40 --> Helper loaded: url_helper
INFO - 2016-10-19 09:31:40 --> Database Driver Class Initialized
INFO - 2016-10-19 09:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:31:40 --> Parser Class Initialized
INFO - 2016-10-19 09:31:40 --> Controller Class Initialized
DEBUG - 2016-10-19 09:31:40 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 09:31:40 --> Config Class Initialized
INFO - 2016-10-19 09:31:40 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:31:40 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:31:40 --> Utf8 Class Initialized
INFO - 2016-10-19 09:31:40 --> URI Class Initialized
INFO - 2016-10-19 09:31:40 --> Router Class Initialized
INFO - 2016-10-19 09:31:40 --> Output Class Initialized
INFO - 2016-10-19 09:31:40 --> Security Class Initialized
DEBUG - 2016-10-19 09:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:31:40 --> Input Class Initialized
INFO - 2016-10-19 09:31:40 --> Language Class Initialized
INFO - 2016-10-19 09:31:40 --> Language Class Initialized
INFO - 2016-10-19 09:31:40 --> Config Class Initialized
INFO - 2016-10-19 09:31:40 --> Loader Class Initialized
INFO - 2016-10-19 09:31:40 --> Helper loaded: common_helper
INFO - 2016-10-19 09:31:40 --> Helper loaded: url_helper
INFO - 2016-10-19 09:31:40 --> Database Driver Class Initialized
INFO - 2016-10-19 09:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:31:40 --> Parser Class Initialized
INFO - 2016-10-19 09:31:40 --> Controller Class Initialized
DEBUG - 2016-10-19 09:31:40 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 09:31:40 --> Model Class Initialized
DEBUG - 2016-10-19 09:31:40 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 09:31:40 --> Model Class Initialized
DEBUG - 2016-10-19 09:31:40 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-19 09:31:40 --> Final output sent to browser
DEBUG - 2016-10-19 09:31:40 --> Total execution time: 0.0402
INFO - 2016-10-19 09:32:38 --> Config Class Initialized
INFO - 2016-10-19 09:32:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:32:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:32:38 --> Utf8 Class Initialized
INFO - 2016-10-19 09:32:38 --> URI Class Initialized
INFO - 2016-10-19 09:32:38 --> Router Class Initialized
INFO - 2016-10-19 09:32:38 --> Output Class Initialized
INFO - 2016-10-19 09:32:38 --> Security Class Initialized
DEBUG - 2016-10-19 09:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:32:38 --> Input Class Initialized
INFO - 2016-10-19 09:32:38 --> Language Class Initialized
INFO - 2016-10-19 09:32:38 --> Language Class Initialized
INFO - 2016-10-19 09:32:38 --> Config Class Initialized
INFO - 2016-10-19 09:32:38 --> Loader Class Initialized
INFO - 2016-10-19 09:32:38 --> Helper loaded: common_helper
INFO - 2016-10-19 09:32:38 --> Helper loaded: url_helper
INFO - 2016-10-19 09:32:38 --> Database Driver Class Initialized
INFO - 2016-10-19 09:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:32:38 --> Parser Class Initialized
INFO - 2016-10-19 09:32:38 --> Controller Class Initialized
DEBUG - 2016-10-19 09:32:38 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 09:32:38 --> Model Class Initialized
DEBUG - 2016-10-19 09:32:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 09:32:38 --> Model Class Initialized
INFO - 2016-10-19 09:32:38 --> Final output sent to browser
DEBUG - 2016-10-19 09:32:38 --> Total execution time: 0.0437
INFO - 2016-10-19 09:39:57 --> Config Class Initialized
INFO - 2016-10-19 09:39:57 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:39:57 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:39:57 --> Utf8 Class Initialized
INFO - 2016-10-19 09:39:57 --> URI Class Initialized
INFO - 2016-10-19 09:39:57 --> Router Class Initialized
INFO - 2016-10-19 09:39:57 --> Output Class Initialized
INFO - 2016-10-19 09:39:57 --> Security Class Initialized
DEBUG - 2016-10-19 09:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:39:57 --> Input Class Initialized
INFO - 2016-10-19 09:39:57 --> Language Class Initialized
ERROR - 2016-10-19 09:39:57 --> 404 Page Not Found: /index
INFO - 2016-10-19 09:49:06 --> Config Class Initialized
INFO - 2016-10-19 09:49:06 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:49:06 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:49:06 --> Utf8 Class Initialized
INFO - 2016-10-19 09:49:06 --> URI Class Initialized
INFO - 2016-10-19 09:49:06 --> Router Class Initialized
INFO - 2016-10-19 09:49:06 --> Output Class Initialized
INFO - 2016-10-19 09:49:06 --> Security Class Initialized
DEBUG - 2016-10-19 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:49:06 --> Input Class Initialized
INFO - 2016-10-19 09:49:06 --> Language Class Initialized
INFO - 2016-10-19 09:49:06 --> Language Class Initialized
INFO - 2016-10-19 09:49:06 --> Config Class Initialized
INFO - 2016-10-19 09:49:06 --> Loader Class Initialized
INFO - 2016-10-19 09:49:06 --> Helper loaded: common_helper
INFO - 2016-10-19 09:49:06 --> Helper loaded: url_helper
INFO - 2016-10-19 09:49:06 --> Database Driver Class Initialized
INFO - 2016-10-19 09:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:49:06 --> Parser Class Initialized
INFO - 2016-10-19 09:49:06 --> Controller Class Initialized
ERROR - 2016-10-19 09:49:06 --> 404 Page Not Found: ../modules/mobile_card/controllers/Mobile_card/index
INFO - 2016-10-19 09:49:09 --> Config Class Initialized
INFO - 2016-10-19 09:49:09 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:49:09 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:49:09 --> Utf8 Class Initialized
INFO - 2016-10-19 09:49:09 --> URI Class Initialized
INFO - 2016-10-19 09:49:09 --> Router Class Initialized
INFO - 2016-10-19 09:49:09 --> Output Class Initialized
INFO - 2016-10-19 09:49:09 --> Security Class Initialized
DEBUG - 2016-10-19 09:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:49:09 --> Input Class Initialized
INFO - 2016-10-19 09:49:09 --> Language Class Initialized
INFO - 2016-10-19 09:49:09 --> Language Class Initialized
INFO - 2016-10-19 09:49:09 --> Config Class Initialized
INFO - 2016-10-19 09:49:09 --> Loader Class Initialized
INFO - 2016-10-19 09:49:09 --> Helper loaded: common_helper
INFO - 2016-10-19 09:49:09 --> Helper loaded: url_helper
INFO - 2016-10-19 09:49:09 --> Database Driver Class Initialized
INFO - 2016-10-19 09:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:49:09 --> Parser Class Initialized
INFO - 2016-10-19 09:49:09 --> Controller Class Initialized
ERROR - 2016-10-19 09:49:09 --> 404 Page Not Found: ../modules/mobile_card/controllers/Mobile_card/index
INFO - 2016-10-19 09:54:41 --> Config Class Initialized
INFO - 2016-10-19 09:54:41 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:54:41 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:54:41 --> Utf8 Class Initialized
INFO - 2016-10-19 09:54:41 --> URI Class Initialized
INFO - 2016-10-19 09:54:41 --> Router Class Initialized
INFO - 2016-10-19 09:54:41 --> Output Class Initialized
INFO - 2016-10-19 09:54:41 --> Security Class Initialized
DEBUG - 2016-10-19 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:54:41 --> Input Class Initialized
INFO - 2016-10-19 09:54:41 --> Language Class Initialized
INFO - 2016-10-19 09:54:41 --> Language Class Initialized
INFO - 2016-10-19 09:54:41 --> Config Class Initialized
INFO - 2016-10-19 09:54:41 --> Loader Class Initialized
INFO - 2016-10-19 09:54:41 --> Helper loaded: common_helper
INFO - 2016-10-19 09:54:41 --> Helper loaded: url_helper
INFO - 2016-10-19 09:54:41 --> Database Driver Class Initialized
INFO - 2016-10-19 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:54:41 --> Parser Class Initialized
INFO - 2016-10-19 09:54:41 --> Controller Class Initialized
ERROR - 2016-10-19 09:54:41 --> 404 Page Not Found: ../modules/mobile_card/controllers/Mobile_card/index
INFO - 2016-10-19 09:54:45 --> Config Class Initialized
INFO - 2016-10-19 09:54:45 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:54:45 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:54:45 --> Utf8 Class Initialized
INFO - 2016-10-19 09:54:45 --> URI Class Initialized
INFO - 2016-10-19 09:54:45 --> Router Class Initialized
INFO - 2016-10-19 09:54:45 --> Output Class Initialized
INFO - 2016-10-19 09:54:45 --> Security Class Initialized
DEBUG - 2016-10-19 09:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:54:45 --> Input Class Initialized
INFO - 2016-10-19 09:54:45 --> Language Class Initialized
INFO - 2016-10-19 09:54:45 --> Language Class Initialized
INFO - 2016-10-19 09:54:45 --> Config Class Initialized
INFO - 2016-10-19 09:54:45 --> Loader Class Initialized
INFO - 2016-10-19 09:54:45 --> Helper loaded: common_helper
INFO - 2016-10-19 09:54:45 --> Helper loaded: url_helper
INFO - 2016-10-19 09:54:45 --> Database Driver Class Initialized
INFO - 2016-10-19 09:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:54:45 --> Parser Class Initialized
INFO - 2016-10-19 09:54:45 --> Controller Class Initialized
DEBUG - 2016-10-19 09:54:45 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 09:54:45 --> Model Class Initialized
DEBUG - 2016-10-19 09:54:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 09:54:45 --> Model Class Initialized
DEBUG - 2016-10-19 09:54:45 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-19 09:54:45 --> Final output sent to browser
DEBUG - 2016-10-19 09:54:45 --> Total execution time: 0.0524
INFO - 2016-10-19 09:54:53 --> Config Class Initialized
INFO - 2016-10-19 09:54:53 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:54:53 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:54:53 --> Utf8 Class Initialized
INFO - 2016-10-19 09:54:53 --> URI Class Initialized
INFO - 2016-10-19 09:54:53 --> Router Class Initialized
INFO - 2016-10-19 09:54:53 --> Output Class Initialized
INFO - 2016-10-19 09:54:53 --> Security Class Initialized
DEBUG - 2016-10-19 09:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:54:53 --> Input Class Initialized
INFO - 2016-10-19 09:54:53 --> Language Class Initialized
INFO - 2016-10-19 09:54:53 --> Language Class Initialized
INFO - 2016-10-19 09:54:53 --> Config Class Initialized
INFO - 2016-10-19 09:54:53 --> Loader Class Initialized
INFO - 2016-10-19 09:54:53 --> Helper loaded: common_helper
INFO - 2016-10-19 09:54:53 --> Helper loaded: url_helper
INFO - 2016-10-19 09:54:53 --> Database Driver Class Initialized
INFO - 2016-10-19 09:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:54:53 --> Parser Class Initialized
INFO - 2016-10-19 09:54:53 --> Controller Class Initialized
DEBUG - 2016-10-19 09:54:53 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 09:54:53 --> Model Class Initialized
DEBUG - 2016-10-19 09:54:53 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 09:54:53 --> Model Class Initialized
INFO - 2016-10-19 09:54:53 --> Final output sent to browser
DEBUG - 2016-10-19 09:54:53 --> Total execution time: 0.0416
INFO - 2016-10-19 09:54:55 --> Config Class Initialized
INFO - 2016-10-19 09:54:55 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:54:55 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:54:55 --> Utf8 Class Initialized
INFO - 2016-10-19 09:54:55 --> URI Class Initialized
INFO - 2016-10-19 09:54:55 --> Router Class Initialized
INFO - 2016-10-19 09:54:55 --> Output Class Initialized
INFO - 2016-10-19 09:54:55 --> Security Class Initialized
DEBUG - 2016-10-19 09:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:54:55 --> Input Class Initialized
INFO - 2016-10-19 09:54:55 --> Language Class Initialized
INFO - 2016-10-19 09:54:55 --> Language Class Initialized
INFO - 2016-10-19 09:54:55 --> Config Class Initialized
INFO - 2016-10-19 09:54:55 --> Loader Class Initialized
INFO - 2016-10-19 09:54:55 --> Helper loaded: common_helper
INFO - 2016-10-19 09:54:55 --> Helper loaded: url_helper
INFO - 2016-10-19 09:54:55 --> Database Driver Class Initialized
INFO - 2016-10-19 09:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:54:55 --> Parser Class Initialized
INFO - 2016-10-19 09:54:55 --> Controller Class Initialized
DEBUG - 2016-10-19 09:54:55 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 09:54:55 --> Model Class Initialized
DEBUG - 2016-10-19 09:54:55 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 09:54:55 --> Model Class Initialized
INFO - 2016-10-19 09:54:55 --> Final output sent to browser
DEBUG - 2016-10-19 09:54:55 --> Total execution time: 0.0337
INFO - 2016-10-19 09:54:57 --> Config Class Initialized
INFO - 2016-10-19 09:54:57 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:54:57 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:54:57 --> Utf8 Class Initialized
INFO - 2016-10-19 09:54:57 --> URI Class Initialized
INFO - 2016-10-19 09:54:57 --> Router Class Initialized
INFO - 2016-10-19 09:54:57 --> Output Class Initialized
INFO - 2016-10-19 09:54:57 --> Security Class Initialized
DEBUG - 2016-10-19 09:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:54:57 --> Input Class Initialized
INFO - 2016-10-19 09:54:57 --> Language Class Initialized
INFO - 2016-10-19 09:54:57 --> Language Class Initialized
INFO - 2016-10-19 09:54:57 --> Config Class Initialized
INFO - 2016-10-19 09:54:57 --> Loader Class Initialized
INFO - 2016-10-19 09:54:57 --> Helper loaded: common_helper
INFO - 2016-10-19 09:54:57 --> Helper loaded: url_helper
INFO - 2016-10-19 09:54:57 --> Database Driver Class Initialized
INFO - 2016-10-19 09:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:54:57 --> Parser Class Initialized
INFO - 2016-10-19 09:54:57 --> Controller Class Initialized
DEBUG - 2016-10-19 09:54:57 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 09:54:57 --> Model Class Initialized
DEBUG - 2016-10-19 09:54:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 09:54:57 --> Model Class Initialized
INFO - 2016-10-19 09:54:57 --> Final output sent to browser
DEBUG - 2016-10-19 09:54:57 --> Total execution time: 0.0337
INFO - 2016-10-19 09:55:02 --> Config Class Initialized
INFO - 2016-10-19 09:55:02 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:55:02 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:55:02 --> Utf8 Class Initialized
INFO - 2016-10-19 09:55:02 --> URI Class Initialized
INFO - 2016-10-19 09:55:02 --> Router Class Initialized
INFO - 2016-10-19 09:55:02 --> Output Class Initialized
INFO - 2016-10-19 09:55:02 --> Security Class Initialized
DEBUG - 2016-10-19 09:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:55:02 --> Input Class Initialized
INFO - 2016-10-19 09:55:02 --> Language Class Initialized
INFO - 2016-10-19 09:55:02 --> Language Class Initialized
INFO - 2016-10-19 09:55:02 --> Config Class Initialized
INFO - 2016-10-19 09:55:02 --> Loader Class Initialized
INFO - 2016-10-19 09:55:02 --> Helper loaded: common_helper
INFO - 2016-10-19 09:55:02 --> Helper loaded: url_helper
INFO - 2016-10-19 09:55:02 --> Database Driver Class Initialized
INFO - 2016-10-19 09:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:55:02 --> Parser Class Initialized
INFO - 2016-10-19 09:55:02 --> Controller Class Initialized
DEBUG - 2016-10-19 09:55:02 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 09:55:02 --> Config Class Initialized
INFO - 2016-10-19 09:55:02 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:55:02 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:55:02 --> Utf8 Class Initialized
INFO - 2016-10-19 09:55:02 --> URI Class Initialized
INFO - 2016-10-19 09:55:02 --> Router Class Initialized
INFO - 2016-10-19 09:55:02 --> Output Class Initialized
INFO - 2016-10-19 09:55:02 --> Security Class Initialized
DEBUG - 2016-10-19 09:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:55:02 --> Input Class Initialized
INFO - 2016-10-19 09:55:02 --> Language Class Initialized
INFO - 2016-10-19 09:55:02 --> Language Class Initialized
INFO - 2016-10-19 09:55:02 --> Config Class Initialized
INFO - 2016-10-19 09:55:02 --> Loader Class Initialized
INFO - 2016-10-19 09:55:02 --> Helper loaded: common_helper
INFO - 2016-10-19 09:55:02 --> Helper loaded: url_helper
INFO - 2016-10-19 09:55:02 --> Database Driver Class Initialized
INFO - 2016-10-19 09:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:55:02 --> Parser Class Initialized
INFO - 2016-10-19 09:55:02 --> Controller Class Initialized
DEBUG - 2016-10-19 09:55:02 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 09:55:02 --> Model Class Initialized
DEBUG - 2016-10-19 09:55:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 09:55:02 --> Model Class Initialized
DEBUG - 2016-10-19 09:55:02 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-19 09:55:02 --> Final output sent to browser
DEBUG - 2016-10-19 09:55:02 --> Total execution time: 0.0509
INFO - 2016-10-19 09:59:42 --> Config Class Initialized
INFO - 2016-10-19 09:59:42 --> Hooks Class Initialized
DEBUG - 2016-10-19 09:59:42 --> UTF-8 Support Enabled
INFO - 2016-10-19 09:59:42 --> Utf8 Class Initialized
INFO - 2016-10-19 09:59:42 --> URI Class Initialized
DEBUG - 2016-10-19 09:59:42 --> No URI present. Default controller set.
INFO - 2016-10-19 09:59:42 --> Router Class Initialized
INFO - 2016-10-19 09:59:42 --> Output Class Initialized
INFO - 2016-10-19 09:59:42 --> Security Class Initialized
DEBUG - 2016-10-19 09:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 09:59:42 --> Input Class Initialized
INFO - 2016-10-19 09:59:42 --> Language Class Initialized
INFO - 2016-10-19 09:59:42 --> Language Class Initialized
INFO - 2016-10-19 09:59:42 --> Config Class Initialized
INFO - 2016-10-19 09:59:42 --> Loader Class Initialized
INFO - 2016-10-19 09:59:42 --> Helper loaded: common_helper
INFO - 2016-10-19 09:59:42 --> Helper loaded: url_helper
INFO - 2016-10-19 09:59:42 --> Database Driver Class Initialized
INFO - 2016-10-19 09:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 09:59:42 --> Parser Class Initialized
INFO - 2016-10-19 09:59:42 --> Controller Class Initialized
DEBUG - 2016-10-19 09:59:42 --> Home MX_Controller Initialized
INFO - 2016-10-19 09:59:42 --> Model Class Initialized
DEBUG - 2016-10-19 09:59:42 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 09:59:42 --> Model Class Initialized
ERROR - 2016-10-19 09:59:42 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 09:59:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 09:59:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 09:59:42 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 09:59:42 --> Final output sent to browser
DEBUG - 2016-10-19 09:59:42 --> Total execution time: 0.0433
INFO - 2016-10-19 10:02:22 --> Config Class Initialized
INFO - 2016-10-19 10:02:22 --> Hooks Class Initialized
DEBUG - 2016-10-19 10:02:22 --> UTF-8 Support Enabled
INFO - 2016-10-19 10:02:22 --> Utf8 Class Initialized
INFO - 2016-10-19 10:02:22 --> URI Class Initialized
INFO - 2016-10-19 10:02:22 --> Router Class Initialized
INFO - 2016-10-19 10:02:22 --> Output Class Initialized
INFO - 2016-10-19 10:02:22 --> Security Class Initialized
DEBUG - 2016-10-19 10:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 10:02:22 --> Input Class Initialized
INFO - 2016-10-19 10:02:22 --> Language Class Initialized
INFO - 2016-10-19 10:02:22 --> Language Class Initialized
INFO - 2016-10-19 10:02:22 --> Config Class Initialized
INFO - 2016-10-19 10:02:22 --> Loader Class Initialized
INFO - 2016-10-19 10:02:22 --> Helper loaded: common_helper
INFO - 2016-10-19 10:02:22 --> Helper loaded: url_helper
INFO - 2016-10-19 10:02:22 --> Database Driver Class Initialized
INFO - 2016-10-19 10:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 10:02:22 --> Parser Class Initialized
INFO - 2016-10-19 10:02:22 --> Controller Class Initialized
DEBUG - 2016-10-19 10:02:22 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 10:02:22 --> Model Class Initialized
DEBUG - 2016-10-19 10:02:22 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 10:02:22 --> Model Class Initialized
DEBUG - 2016-10-19 10:02:22 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-19 10:02:22 --> Final output sent to browser
DEBUG - 2016-10-19 10:02:22 --> Total execution time: 0.0430
INFO - 2016-10-19 13:41:34 --> Config Class Initialized
INFO - 2016-10-19 13:41:34 --> Hooks Class Initialized
DEBUG - 2016-10-19 13:41:34 --> UTF-8 Support Enabled
INFO - 2016-10-19 13:41:34 --> Utf8 Class Initialized
INFO - 2016-10-19 13:41:34 --> URI Class Initialized
INFO - 2016-10-19 13:41:34 --> Router Class Initialized
INFO - 2016-10-19 13:41:34 --> Output Class Initialized
INFO - 2016-10-19 13:41:34 --> Security Class Initialized
DEBUG - 2016-10-19 13:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 13:41:34 --> Input Class Initialized
INFO - 2016-10-19 13:41:34 --> Language Class Initialized
INFO - 2016-10-19 13:41:34 --> Language Class Initialized
INFO - 2016-10-19 13:41:34 --> Config Class Initialized
INFO - 2016-10-19 13:41:34 --> Loader Class Initialized
INFO - 2016-10-19 13:41:34 --> Helper loaded: common_helper
INFO - 2016-10-19 13:41:34 --> Helper loaded: url_helper
INFO - 2016-10-19 13:41:34 --> Database Driver Class Initialized
INFO - 2016-10-19 13:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 13:41:34 --> Parser Class Initialized
INFO - 2016-10-19 13:41:34 --> Controller Class Initialized
DEBUG - 2016-10-19 13:41:34 --> Content MX_Controller Initialized
INFO - 2016-10-19 13:41:34 --> Model Class Initialized
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-19 13:41:34 --> Model Class Initialized
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 13:41:34 --> Model Class Initialized
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 13:41:34 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 13:41:34 --> Model Class Initialized
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 13:41:34 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 13:41:34 --> Model Class Initialized
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-19 13:41:34 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 13:41:34 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 13:41:34 --> Final output sent to browser
DEBUG - 2016-10-19 13:41:34 --> Total execution time: 0.0571
INFO - 2016-10-19 14:28:30 --> Config Class Initialized
INFO - 2016-10-19 14:28:30 --> Hooks Class Initialized
DEBUG - 2016-10-19 14:28:30 --> UTF-8 Support Enabled
INFO - 2016-10-19 14:28:30 --> Utf8 Class Initialized
INFO - 2016-10-19 14:28:30 --> URI Class Initialized
INFO - 2016-10-19 14:28:30 --> Router Class Initialized
INFO - 2016-10-19 14:28:30 --> Output Class Initialized
INFO - 2016-10-19 14:28:30 --> Security Class Initialized
DEBUG - 2016-10-19 14:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 14:28:30 --> Input Class Initialized
INFO - 2016-10-19 14:28:30 --> Language Class Initialized
INFO - 2016-10-19 14:28:30 --> Language Class Initialized
INFO - 2016-10-19 14:28:30 --> Config Class Initialized
INFO - 2016-10-19 14:28:30 --> Loader Class Initialized
INFO - 2016-10-19 14:28:30 --> Helper loaded: common_helper
INFO - 2016-10-19 14:28:30 --> Helper loaded: url_helper
INFO - 2016-10-19 14:28:30 --> Database Driver Class Initialized
INFO - 2016-10-19 14:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 14:28:30 --> Parser Class Initialized
INFO - 2016-10-19 14:28:30 --> Controller Class Initialized
DEBUG - 2016-10-19 14:28:30 --> Content MX_Controller Initialized
INFO - 2016-10-19 14:28:30 --> Model Class Initialized
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/models/Content_model.php
INFO - 2016-10-19 14:28:30 --> Model Class Initialized
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 14:28:30 --> Model Class Initialized
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/detail.php
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 14:28:30 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 14:28:30 --> Model Class Initialized
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 14:28:30 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 14:28:30 --> Model Class Initialized
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-19 14:28:30 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 14:28:30 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 14:28:30 --> Final output sent to browser
DEBUG - 2016-10-19 14:28:30 --> Total execution time: 0.0581
INFO - 2016-10-19 15:04:22 --> Config Class Initialized
INFO - 2016-10-19 15:04:22 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:22 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:22 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:22 --> URI Class Initialized
DEBUG - 2016-10-19 15:04:22 --> No URI present. Default controller set.
INFO - 2016-10-19 15:04:22 --> Router Class Initialized
INFO - 2016-10-19 15:04:22 --> Output Class Initialized
INFO - 2016-10-19 15:04:22 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:22 --> Input Class Initialized
INFO - 2016-10-19 15:04:22 --> Language Class Initialized
INFO - 2016-10-19 15:04:22 --> Language Class Initialized
INFO - 2016-10-19 15:04:22 --> Config Class Initialized
INFO - 2016-10-19 15:04:22 --> Loader Class Initialized
INFO - 2016-10-19 15:04:22 --> Helper loaded: common_helper
INFO - 2016-10-19 15:04:22 --> Helper loaded: url_helper
INFO - 2016-10-19 15:04:22 --> Database Driver Class Initialized
INFO - 2016-10-19 15:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 15:04:22 --> Parser Class Initialized
INFO - 2016-10-19 15:04:22 --> Controller Class Initialized
DEBUG - 2016-10-19 15:04:22 --> Home MX_Controller Initialized
INFO - 2016-10-19 15:04:22 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:22 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 15:04:22 --> Model Class Initialized
ERROR - 2016-10-19 15:04:22 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 15:04:22 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 15:04:22 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 15:04:22 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 15:04:22 --> Final output sent to browser
DEBUG - 2016-10-19 15:04:22 --> Total execution time: 0.0460
INFO - 2016-10-19 15:04:25 --> Config Class Initialized
INFO - 2016-10-19 15:04:25 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:25 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:25 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:25 --> URI Class Initialized
INFO - 2016-10-19 15:04:25 --> Router Class Initialized
INFO - 2016-10-19 15:04:25 --> Output Class Initialized
INFO - 2016-10-19 15:04:25 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:25 --> Input Class Initialized
INFO - 2016-10-19 15:04:25 --> Language Class Initialized
INFO - 2016-10-19 15:04:25 --> Language Class Initialized
INFO - 2016-10-19 15:04:25 --> Config Class Initialized
INFO - 2016-10-19 15:04:25 --> Loader Class Initialized
INFO - 2016-10-19 15:04:25 --> Helper loaded: common_helper
INFO - 2016-10-19 15:04:25 --> Helper loaded: url_helper
INFO - 2016-10-19 15:04:25 --> Database Driver Class Initialized
INFO - 2016-10-19 15:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 15:04:25 --> Parser Class Initialized
INFO - 2016-10-19 15:04:25 --> Controller Class Initialized
DEBUG - 2016-10-19 15:04:25 --> Home MX_Controller Initialized
INFO - 2016-10-19 15:04:25 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 15:04:25 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-19 15:04:25 --> Content MX_Controller Initialized
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 15:04:25 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 15:04:25 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 15:04:25 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 15:04:25 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 15:04:25 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-19 15:04:25 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 15:04:25 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 15:04:25 --> Final output sent to browser
DEBUG - 2016-10-19 15:04:25 --> Total execution time: 0.0747
INFO - 2016-10-19 15:04:26 --> Config Class Initialized
INFO - 2016-10-19 15:04:27 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:27 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:27 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:27 --> URI Class Initialized
INFO - 2016-10-19 15:04:27 --> Router Class Initialized
INFO - 2016-10-19 15:04:27 --> Output Class Initialized
INFO - 2016-10-19 15:04:27 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:27 --> Input Class Initialized
INFO - 2016-10-19 15:04:27 --> Language Class Initialized
ERROR - 2016-10-19 15:04:27 --> 404 Page Not Found: /index
INFO - 2016-10-19 15:04:28 --> Config Class Initialized
INFO - 2016-10-19 15:04:28 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:28 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:28 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:28 --> URI Class Initialized
INFO - 2016-10-19 15:04:28 --> Router Class Initialized
INFO - 2016-10-19 15:04:28 --> Output Class Initialized
INFO - 2016-10-19 15:04:28 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:28 --> Input Class Initialized
INFO - 2016-10-19 15:04:28 --> Language Class Initialized
ERROR - 2016-10-19 15:04:28 --> 404 Page Not Found: /index
INFO - 2016-10-19 15:04:28 --> Config Class Initialized
INFO - 2016-10-19 15:04:28 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:28 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:28 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:28 --> URI Class Initialized
DEBUG - 2016-10-19 15:04:28 --> No URI present. Default controller set.
INFO - 2016-10-19 15:04:28 --> Router Class Initialized
INFO - 2016-10-19 15:04:28 --> Output Class Initialized
INFO - 2016-10-19 15:04:28 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:28 --> Input Class Initialized
INFO - 2016-10-19 15:04:28 --> Language Class Initialized
INFO - 2016-10-19 15:04:28 --> Language Class Initialized
INFO - 2016-10-19 15:04:28 --> Config Class Initialized
INFO - 2016-10-19 15:04:28 --> Loader Class Initialized
INFO - 2016-10-19 15:04:28 --> Helper loaded: common_helper
INFO - 2016-10-19 15:04:28 --> Helper loaded: url_helper
INFO - 2016-10-19 15:04:28 --> Database Driver Class Initialized
INFO - 2016-10-19 15:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 15:04:28 --> Parser Class Initialized
INFO - 2016-10-19 15:04:28 --> Controller Class Initialized
DEBUG - 2016-10-19 15:04:28 --> Home MX_Controller Initialized
INFO - 2016-10-19 15:04:28 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:28 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 15:04:28 --> Model Class Initialized
ERROR - 2016-10-19 15:04:28 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 15:04:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 15:04:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 15:04:28 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 15:04:28 --> Final output sent to browser
DEBUG - 2016-10-19 15:04:28 --> Total execution time: 0.0412
INFO - 2016-10-19 15:04:41 --> Config Class Initialized
INFO - 2016-10-19 15:04:41 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:41 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:41 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:41 --> URI Class Initialized
INFO - 2016-10-19 15:04:41 --> Router Class Initialized
INFO - 2016-10-19 15:04:41 --> Output Class Initialized
INFO - 2016-10-19 15:04:41 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:41 --> Input Class Initialized
INFO - 2016-10-19 15:04:41 --> Language Class Initialized
INFO - 2016-10-19 15:04:41 --> Language Class Initialized
INFO - 2016-10-19 15:04:41 --> Config Class Initialized
INFO - 2016-10-19 15:04:41 --> Loader Class Initialized
INFO - 2016-10-19 15:04:41 --> Helper loaded: common_helper
INFO - 2016-10-19 15:04:41 --> Helper loaded: url_helper
INFO - 2016-10-19 15:04:41 --> Database Driver Class Initialized
INFO - 2016-10-19 15:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 15:04:41 --> Parser Class Initialized
INFO - 2016-10-19 15:04:41 --> Controller Class Initialized
DEBUG - 2016-10-19 15:04:41 --> User MX_Controller Initialized
INFO - 2016-10-19 15:04:41 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:41 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-19 15:04:41 --> Model Class Initialized
INFO - 2016-10-19 15:04:41 --> Helper loaded: cookie_helper
INFO - 2016-10-19 15:04:41 --> Helper loaded: form_helper
DEBUG - 2016-10-19 15:04:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 15:04:41 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:41 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 15:04:41 --> Model Class Initialized
INFO - 2016-10-19 15:04:41 --> Final output sent to browser
DEBUG - 2016-10-19 15:04:41 --> Total execution time: 0.0553
INFO - 2016-10-19 15:04:43 --> Config Class Initialized
INFO - 2016-10-19 15:04:43 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:43 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:43 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:43 --> URI Class Initialized
DEBUG - 2016-10-19 15:04:43 --> No URI present. Default controller set.
INFO - 2016-10-19 15:04:43 --> Router Class Initialized
INFO - 2016-10-19 15:04:43 --> Output Class Initialized
INFO - 2016-10-19 15:04:43 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:43 --> Input Class Initialized
INFO - 2016-10-19 15:04:43 --> Language Class Initialized
INFO - 2016-10-19 15:04:43 --> Language Class Initialized
INFO - 2016-10-19 15:04:43 --> Config Class Initialized
INFO - 2016-10-19 15:04:43 --> Loader Class Initialized
INFO - 2016-10-19 15:04:43 --> Helper loaded: common_helper
INFO - 2016-10-19 15:04:43 --> Helper loaded: url_helper
INFO - 2016-10-19 15:04:43 --> Database Driver Class Initialized
INFO - 2016-10-19 15:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 15:04:43 --> Parser Class Initialized
INFO - 2016-10-19 15:04:43 --> Controller Class Initialized
DEBUG - 2016-10-19 15:04:43 --> Home MX_Controller Initialized
INFO - 2016-10-19 15:04:43 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:43 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 15:04:43 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-19 15:04:43 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 15:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 15:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 15:04:43 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 15:04:43 --> Final output sent to browser
DEBUG - 2016-10-19 15:04:43 --> Total execution time: 0.0619
INFO - 2016-10-19 15:04:49 --> Config Class Initialized
INFO - 2016-10-19 15:04:49 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:49 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:49 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:49 --> URI Class Initialized
INFO - 2016-10-19 15:04:49 --> Router Class Initialized
INFO - 2016-10-19 15:04:49 --> Output Class Initialized
INFO - 2016-10-19 15:04:49 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:49 --> Input Class Initialized
INFO - 2016-10-19 15:04:49 --> Language Class Initialized
INFO - 2016-10-19 15:04:49 --> Language Class Initialized
INFO - 2016-10-19 15:04:49 --> Config Class Initialized
INFO - 2016-10-19 15:04:49 --> Loader Class Initialized
INFO - 2016-10-19 15:04:49 --> Helper loaded: common_helper
INFO - 2016-10-19 15:04:49 --> Helper loaded: url_helper
INFO - 2016-10-19 15:04:49 --> Database Driver Class Initialized
INFO - 2016-10-19 15:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 15:04:49 --> Parser Class Initialized
INFO - 2016-10-19 15:04:49 --> Controller Class Initialized
DEBUG - 2016-10-19 15:04:49 --> Home MX_Controller Initialized
INFO - 2016-10-19 15:04:49 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 15:04:49 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-19 15:04:49 --> Content MX_Controller Initialized
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 15:04:49 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 15:04:49 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 15:04:49 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 15:04:49 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 15:04:49 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-19 15:04:49 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 15:04:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 15:04:49 --> Final output sent to browser
DEBUG - 2016-10-19 15:04:49 --> Total execution time: 0.0636
INFO - 2016-10-19 15:04:50 --> Config Class Initialized
INFO - 2016-10-19 15:04:50 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:50 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:50 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:50 --> URI Class Initialized
INFO - 2016-10-19 15:04:50 --> Router Class Initialized
INFO - 2016-10-19 15:04:50 --> Output Class Initialized
INFO - 2016-10-19 15:04:50 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:50 --> Input Class Initialized
INFO - 2016-10-19 15:04:50 --> Language Class Initialized
ERROR - 2016-10-19 15:04:50 --> 404 Page Not Found: /index
INFO - 2016-10-19 15:04:57 --> Config Class Initialized
INFO - 2016-10-19 15:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:57 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:57 --> URI Class Initialized
INFO - 2016-10-19 15:04:57 --> Router Class Initialized
INFO - 2016-10-19 15:04:57 --> Output Class Initialized
INFO - 2016-10-19 15:04:57 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:57 --> Input Class Initialized
INFO - 2016-10-19 15:04:57 --> Language Class Initialized
INFO - 2016-10-19 15:04:57 --> Language Class Initialized
INFO - 2016-10-19 15:04:57 --> Config Class Initialized
INFO - 2016-10-19 15:04:57 --> Loader Class Initialized
INFO - 2016-10-19 15:04:57 --> Helper loaded: common_helper
INFO - 2016-10-19 15:04:57 --> Helper loaded: url_helper
INFO - 2016-10-19 15:04:57 --> Database Driver Class Initialized
INFO - 2016-10-19 15:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 15:04:57 --> Parser Class Initialized
INFO - 2016-10-19 15:04:57 --> Controller Class Initialized
DEBUG - 2016-10-19 15:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:57 --> File already loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
INFO - 2016-10-19 15:04:57 --> Config Class Initialized
INFO - 2016-10-19 15:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:57 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:57 --> URI Class Initialized
INFO - 2016-10-19 15:04:57 --> Router Class Initialized
INFO - 2016-10-19 15:04:57 --> Output Class Initialized
INFO - 2016-10-19 15:04:57 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:57 --> Input Class Initialized
INFO - 2016-10-19 15:04:57 --> Language Class Initialized
INFO - 2016-10-19 15:04:57 --> Language Class Initialized
INFO - 2016-10-19 15:04:57 --> Config Class Initialized
INFO - 2016-10-19 15:04:57 --> Loader Class Initialized
INFO - 2016-10-19 15:04:57 --> Helper loaded: common_helper
INFO - 2016-10-19 15:04:57 --> Helper loaded: url_helper
INFO - 2016-10-19 15:04:57 --> Database Driver Class Initialized
INFO - 2016-10-19 15:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 15:04:57 --> Parser Class Initialized
INFO - 2016-10-19 15:04:57 --> Controller Class Initialized
DEBUG - 2016-10-19 15:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 15:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 15:04:57 --> Final output sent to browser
DEBUG - 2016-10-19 15:04:57 --> Total execution time: 0.0392
INFO - 2016-10-19 15:04:57 --> Config Class Initialized
INFO - 2016-10-19 15:04:57 --> Hooks Class Initialized
DEBUG - 2016-10-19 15:04:57 --> UTF-8 Support Enabled
INFO - 2016-10-19 15:04:57 --> Utf8 Class Initialized
INFO - 2016-10-19 15:04:57 --> URI Class Initialized
INFO - 2016-10-19 15:04:57 --> Router Class Initialized
INFO - 2016-10-19 15:04:57 --> Output Class Initialized
INFO - 2016-10-19 15:04:57 --> Security Class Initialized
DEBUG - 2016-10-19 15:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 15:04:57 --> Input Class Initialized
INFO - 2016-10-19 15:04:57 --> Language Class Initialized
INFO - 2016-10-19 15:04:57 --> Language Class Initialized
INFO - 2016-10-19 15:04:57 --> Config Class Initialized
INFO - 2016-10-19 15:04:57 --> Loader Class Initialized
INFO - 2016-10-19 15:04:57 --> Helper loaded: common_helper
INFO - 2016-10-19 15:04:57 --> Helper loaded: url_helper
INFO - 2016-10-19 15:04:57 --> Database Driver Class Initialized
INFO - 2016-10-19 15:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 15:04:57 --> Parser Class Initialized
INFO - 2016-10-19 15:04:57 --> Controller Class Initialized
DEBUG - 2016-10-19 15:04:57 --> Servers MX_Controller Initialized
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
DEBUG - 2016-10-19 15:04:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 15:04:57 --> Model Class Initialized
INFO - 2016-10-19 16:29:55 --> Config Class Initialized
INFO - 2016-10-19 16:29:55 --> Hooks Class Initialized
DEBUG - 2016-10-19 16:29:55 --> UTF-8 Support Enabled
INFO - 2016-10-19 16:29:55 --> Utf8 Class Initialized
INFO - 2016-10-19 16:29:55 --> URI Class Initialized
DEBUG - 2016-10-19 16:29:55 --> No URI present. Default controller set.
INFO - 2016-10-19 16:29:55 --> Router Class Initialized
INFO - 2016-10-19 16:29:55 --> Output Class Initialized
INFO - 2016-10-19 16:29:55 --> Security Class Initialized
DEBUG - 2016-10-19 16:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 16:29:55 --> Input Class Initialized
INFO - 2016-10-19 16:29:55 --> Language Class Initialized
INFO - 2016-10-19 16:29:55 --> Language Class Initialized
INFO - 2016-10-19 16:29:55 --> Config Class Initialized
INFO - 2016-10-19 16:29:55 --> Loader Class Initialized
INFO - 2016-10-19 16:29:55 --> Helper loaded: common_helper
INFO - 2016-10-19 16:29:55 --> Helper loaded: url_helper
INFO - 2016-10-19 16:29:55 --> Database Driver Class Initialized
INFO - 2016-10-19 16:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 16:29:55 --> Parser Class Initialized
INFO - 2016-10-19 16:29:55 --> Controller Class Initialized
DEBUG - 2016-10-19 16:29:55 --> Home MX_Controller Initialized
INFO - 2016-10-19 16:29:55 --> Model Class Initialized
DEBUG - 2016-10-19 16:29:55 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 16:29:55 --> Model Class Initialized
ERROR - 2016-10-19 16:29:55 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 16:29:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 16:29:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 16:29:55 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 16:29:55 --> Final output sent to browser
DEBUG - 2016-10-19 16:29:55 --> Total execution time: 0.0423
INFO - 2016-10-19 16:30:18 --> Config Class Initialized
INFO - 2016-10-19 16:30:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 16:30:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 16:30:18 --> Utf8 Class Initialized
INFO - 2016-10-19 16:30:18 --> URI Class Initialized
INFO - 2016-10-19 16:30:18 --> Router Class Initialized
INFO - 2016-10-19 16:30:18 --> Output Class Initialized
INFO - 2016-10-19 16:30:18 --> Security Class Initialized
DEBUG - 2016-10-19 16:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 16:30:18 --> Input Class Initialized
INFO - 2016-10-19 16:30:18 --> Language Class Initialized
INFO - 2016-10-19 16:30:18 --> Language Class Initialized
INFO - 2016-10-19 16:30:18 --> Config Class Initialized
INFO - 2016-10-19 16:30:18 --> Loader Class Initialized
INFO - 2016-10-19 16:30:18 --> Helper loaded: common_helper
INFO - 2016-10-19 16:30:18 --> Helper loaded: url_helper
INFO - 2016-10-19 16:30:18 --> Database Driver Class Initialized
INFO - 2016-10-19 16:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 16:30:18 --> Parser Class Initialized
INFO - 2016-10-19 16:30:18 --> Controller Class Initialized
DEBUG - 2016-10-19 16:30:18 --> Home MX_Controller Initialized
INFO - 2016-10-19 16:30:18 --> Model Class Initialized
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 16:30:18 --> Model Class Initialized
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-19 16:30:18 --> Content MX_Controller Initialized
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 16:30:18 --> Model Class Initialized
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 16:30:18 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 16:30:18 --> Model Class Initialized
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 16:30:18 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 16:30:18 --> Model Class Initialized
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-19 16:30:18 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 16:30:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 16:30:18 --> Final output sent to browser
DEBUG - 2016-10-19 16:30:18 --> Total execution time: 0.0596
INFO - 2016-10-19 16:30:19 --> Config Class Initialized
INFO - 2016-10-19 16:30:19 --> Hooks Class Initialized
DEBUG - 2016-10-19 16:30:19 --> UTF-8 Support Enabled
INFO - 2016-10-19 16:30:19 --> Utf8 Class Initialized
INFO - 2016-10-19 16:30:19 --> URI Class Initialized
INFO - 2016-10-19 16:30:19 --> Router Class Initialized
INFO - 2016-10-19 16:30:19 --> Output Class Initialized
INFO - 2016-10-19 16:30:19 --> Security Class Initialized
DEBUG - 2016-10-19 16:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 16:30:19 --> Input Class Initialized
INFO - 2016-10-19 16:30:19 --> Language Class Initialized
ERROR - 2016-10-19 16:30:19 --> 404 Page Not Found: /index
INFO - 2016-10-19 18:52:50 --> Config Class Initialized
INFO - 2016-10-19 18:52:50 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:52:50 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:52:50 --> Utf8 Class Initialized
INFO - 2016-10-19 18:52:50 --> URI Class Initialized
DEBUG - 2016-10-19 18:52:50 --> No URI present. Default controller set.
INFO - 2016-10-19 18:52:50 --> Router Class Initialized
INFO - 2016-10-19 18:52:50 --> Output Class Initialized
INFO - 2016-10-19 18:52:50 --> Security Class Initialized
DEBUG - 2016-10-19 18:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:52:50 --> Input Class Initialized
INFO - 2016-10-19 18:52:50 --> Language Class Initialized
INFO - 2016-10-19 18:52:50 --> Language Class Initialized
INFO - 2016-10-19 18:52:50 --> Config Class Initialized
INFO - 2016-10-19 18:52:50 --> Loader Class Initialized
INFO - 2016-10-19 18:52:50 --> Helper loaded: common_helper
INFO - 2016-10-19 18:52:50 --> Helper loaded: url_helper
INFO - 2016-10-19 18:52:50 --> Database Driver Class Initialized
INFO - 2016-10-19 18:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:52:50 --> Parser Class Initialized
INFO - 2016-10-19 18:52:50 --> Controller Class Initialized
DEBUG - 2016-10-19 18:52:50 --> Home MX_Controller Initialized
INFO - 2016-10-19 18:52:50 --> Model Class Initialized
DEBUG - 2016-10-19 18:52:50 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 18:52:50 --> Model Class Initialized
ERROR - 2016-10-19 18:52:50 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 18:52:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 18:52:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 18:52:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 18:52:50 --> Final output sent to browser
DEBUG - 2016-10-19 18:52:50 --> Total execution time: 0.0443
INFO - 2016-10-19 18:53:08 --> Config Class Initialized
INFO - 2016-10-19 18:53:08 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:53:08 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:53:08 --> Utf8 Class Initialized
INFO - 2016-10-19 18:53:08 --> URI Class Initialized
INFO - 2016-10-19 18:53:08 --> Router Class Initialized
INFO - 2016-10-19 18:53:08 --> Output Class Initialized
INFO - 2016-10-19 18:53:08 --> Security Class Initialized
DEBUG - 2016-10-19 18:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:53:08 --> Input Class Initialized
INFO - 2016-10-19 18:53:08 --> Language Class Initialized
INFO - 2016-10-19 18:53:08 --> Language Class Initialized
INFO - 2016-10-19 18:53:08 --> Config Class Initialized
INFO - 2016-10-19 18:53:08 --> Loader Class Initialized
INFO - 2016-10-19 18:53:08 --> Helper loaded: common_helper
INFO - 2016-10-19 18:53:08 --> Helper loaded: url_helper
INFO - 2016-10-19 18:53:08 --> Database Driver Class Initialized
INFO - 2016-10-19 18:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:53:08 --> Parser Class Initialized
INFO - 2016-10-19 18:53:08 --> Controller Class Initialized
DEBUG - 2016-10-19 18:53:08 --> User MX_Controller Initialized
INFO - 2016-10-19 18:53:08 --> Model Class Initialized
DEBUG - 2016-10-19 18:53:08 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-19 18:53:08 --> Model Class Initialized
INFO - 2016-10-19 18:53:08 --> Helper loaded: cookie_helper
INFO - 2016-10-19 18:53:08 --> Helper loaded: form_helper
DEBUG - 2016-10-19 18:53:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:53:08 --> Model Class Initialized
DEBUG - 2016-10-19 18:53:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 18:53:08 --> Model Class Initialized
INFO - 2016-10-19 18:53:08 --> Final output sent to browser
DEBUG - 2016-10-19 18:53:08 --> Total execution time: 0.0506
INFO - 2016-10-19 18:53:10 --> Config Class Initialized
INFO - 2016-10-19 18:53:10 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:53:10 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:53:10 --> Utf8 Class Initialized
INFO - 2016-10-19 18:53:10 --> URI Class Initialized
DEBUG - 2016-10-19 18:53:10 --> No URI present. Default controller set.
INFO - 2016-10-19 18:53:10 --> Router Class Initialized
INFO - 2016-10-19 18:53:10 --> Output Class Initialized
INFO - 2016-10-19 18:53:10 --> Security Class Initialized
DEBUG - 2016-10-19 18:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:53:10 --> Input Class Initialized
INFO - 2016-10-19 18:53:10 --> Language Class Initialized
INFO - 2016-10-19 18:53:10 --> Language Class Initialized
INFO - 2016-10-19 18:53:10 --> Config Class Initialized
INFO - 2016-10-19 18:53:10 --> Loader Class Initialized
INFO - 2016-10-19 18:53:10 --> Helper loaded: common_helper
INFO - 2016-10-19 18:53:10 --> Helper loaded: url_helper
INFO - 2016-10-19 18:53:10 --> Database Driver Class Initialized
INFO - 2016-10-19 18:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:53:10 --> Parser Class Initialized
INFO - 2016-10-19 18:53:10 --> Controller Class Initialized
DEBUG - 2016-10-19 18:53:10 --> Home MX_Controller Initialized
INFO - 2016-10-19 18:53:10 --> Model Class Initialized
DEBUG - 2016-10-19 18:53:10 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 18:53:10 --> Model Class Initialized
DEBUG - 2016-10-19 18:53:10 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-19 18:53:10 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 18:53:10 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 18:53:10 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 18:53:10 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 18:53:10 --> Final output sent to browser
DEBUG - 2016-10-19 18:53:10 --> Total execution time: 0.0499
INFO - 2016-10-19 18:53:15 --> Config Class Initialized
INFO - 2016-10-19 18:53:15 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:53:15 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:53:15 --> Utf8 Class Initialized
INFO - 2016-10-19 18:53:15 --> URI Class Initialized
INFO - 2016-10-19 18:53:15 --> Router Class Initialized
INFO - 2016-10-19 18:53:15 --> Output Class Initialized
INFO - 2016-10-19 18:53:15 --> Security Class Initialized
DEBUG - 2016-10-19 18:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:53:15 --> Input Class Initialized
INFO - 2016-10-19 18:53:15 --> Language Class Initialized
INFO - 2016-10-19 18:53:15 --> Language Class Initialized
INFO - 2016-10-19 18:53:15 --> Config Class Initialized
INFO - 2016-10-19 18:53:15 --> Loader Class Initialized
INFO - 2016-10-19 18:53:15 --> Helper loaded: common_helper
INFO - 2016-10-19 18:53:15 --> Helper loaded: url_helper
INFO - 2016-10-19 18:53:15 --> Database Driver Class Initialized
INFO - 2016-10-19 18:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:53:15 --> Parser Class Initialized
INFO - 2016-10-19 18:53:15 --> Controller Class Initialized
DEBUG - 2016-10-19 18:53:15 --> Servers MX_Controller Initialized
INFO - 2016-10-19 18:53:15 --> Model Class Initialized
DEBUG - 2016-10-19 18:53:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 18:53:15 --> Model Class Initialized
DEBUG - 2016-10-19 18:53:15 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 18:53:15 --> Model Class Initialized
DEBUG - 2016-10-19 18:53:15 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 18:53:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 18:53:15 --> Final output sent to browser
DEBUG - 2016-10-19 18:53:15 --> Total execution time: 0.0381
INFO - 2016-10-19 18:53:15 --> Config Class Initialized
INFO - 2016-10-19 18:53:15 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:53:15 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:53:15 --> Utf8 Class Initialized
INFO - 2016-10-19 18:53:15 --> URI Class Initialized
INFO - 2016-10-19 18:53:15 --> Router Class Initialized
INFO - 2016-10-19 18:53:15 --> Output Class Initialized
INFO - 2016-10-19 18:53:15 --> Security Class Initialized
DEBUG - 2016-10-19 18:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:53:15 --> Input Class Initialized
INFO - 2016-10-19 18:53:15 --> Language Class Initialized
INFO - 2016-10-19 18:53:15 --> Language Class Initialized
INFO - 2016-10-19 18:53:15 --> Config Class Initialized
INFO - 2016-10-19 18:53:15 --> Loader Class Initialized
INFO - 2016-10-19 18:53:15 --> Helper loaded: common_helper
INFO - 2016-10-19 18:53:15 --> Helper loaded: url_helper
INFO - 2016-10-19 18:53:15 --> Database Driver Class Initialized
INFO - 2016-10-19 18:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:53:15 --> Parser Class Initialized
INFO - 2016-10-19 18:53:15 --> Controller Class Initialized
DEBUG - 2016-10-19 18:53:15 --> Servers MX_Controller Initialized
INFO - 2016-10-19 18:53:15 --> Model Class Initialized
DEBUG - 2016-10-19 18:53:15 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 18:53:15 --> Model Class Initialized
DEBUG - 2016-10-19 18:53:15 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 18:53:15 --> Model Class Initialized
INFO - 2016-10-19 18:54:48 --> Config Class Initialized
INFO - 2016-10-19 18:54:48 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:54:48 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:54:48 --> Utf8 Class Initialized
INFO - 2016-10-19 18:54:48 --> URI Class Initialized
INFO - 2016-10-19 18:54:48 --> Router Class Initialized
INFO - 2016-10-19 18:54:48 --> Output Class Initialized
INFO - 2016-10-19 18:54:48 --> Security Class Initialized
DEBUG - 2016-10-19 18:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:54:48 --> Input Class Initialized
INFO - 2016-10-19 18:54:48 --> Language Class Initialized
INFO - 2016-10-19 18:54:48 --> Language Class Initialized
INFO - 2016-10-19 18:54:48 --> Config Class Initialized
INFO - 2016-10-19 18:54:48 --> Loader Class Initialized
INFO - 2016-10-19 18:54:49 --> Helper loaded: common_helper
INFO - 2016-10-19 18:54:49 --> Helper loaded: url_helper
INFO - 2016-10-19 18:54:49 --> Database Driver Class Initialized
INFO - 2016-10-19 18:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:54:49 --> Parser Class Initialized
INFO - 2016-10-19 18:54:49 --> Controller Class Initialized
DEBUG - 2016-10-19 18:54:49 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 18:54:49 --> Config Class Initialized
INFO - 2016-10-19 18:54:49 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:54:49 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:54:49 --> Utf8 Class Initialized
INFO - 2016-10-19 18:54:49 --> URI Class Initialized
INFO - 2016-10-19 18:54:49 --> Router Class Initialized
INFO - 2016-10-19 18:54:49 --> Output Class Initialized
INFO - 2016-10-19 18:54:49 --> Security Class Initialized
DEBUG - 2016-10-19 18:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:54:49 --> Input Class Initialized
INFO - 2016-10-19 18:54:49 --> Language Class Initialized
INFO - 2016-10-19 18:54:49 --> Language Class Initialized
INFO - 2016-10-19 18:54:49 --> Config Class Initialized
INFO - 2016-10-19 18:54:49 --> Loader Class Initialized
INFO - 2016-10-19 18:54:49 --> Helper loaded: common_helper
INFO - 2016-10-19 18:54:49 --> Helper loaded: url_helper
INFO - 2016-10-19 18:54:49 --> Database Driver Class Initialized
INFO - 2016-10-19 18:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:54:49 --> Parser Class Initialized
INFO - 2016-10-19 18:54:49 --> Controller Class Initialized
DEBUG - 2016-10-19 18:54:49 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 18:54:49 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:54:49 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:49 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-19 18:54:49 --> Final output sent to browser
DEBUG - 2016-10-19 18:54:49 --> Total execution time: 0.0380
INFO - 2016-10-19 18:54:54 --> Config Class Initialized
INFO - 2016-10-19 18:54:54 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:54:54 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:54:54 --> Utf8 Class Initialized
INFO - 2016-10-19 18:54:54 --> URI Class Initialized
INFO - 2016-10-19 18:54:54 --> Router Class Initialized
INFO - 2016-10-19 18:54:54 --> Output Class Initialized
INFO - 2016-10-19 18:54:54 --> Security Class Initialized
DEBUG - 2016-10-19 18:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:54:54 --> Input Class Initialized
INFO - 2016-10-19 18:54:54 --> Language Class Initialized
INFO - 2016-10-19 18:54:54 --> Language Class Initialized
INFO - 2016-10-19 18:54:54 --> Config Class Initialized
INFO - 2016-10-19 18:54:54 --> Loader Class Initialized
INFO - 2016-10-19 18:54:54 --> Helper loaded: common_helper
INFO - 2016-10-19 18:54:54 --> Helper loaded: url_helper
INFO - 2016-10-19 18:54:54 --> Database Driver Class Initialized
INFO - 2016-10-19 18:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:54:54 --> Parser Class Initialized
INFO - 2016-10-19 18:54:54 --> Controller Class Initialized
DEBUG - 2016-10-19 18:54:54 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 18:54:54 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:54:54 --> Model Class Initialized
INFO - 2016-10-19 18:54:54 --> Final output sent to browser
DEBUG - 2016-10-19 18:54:54 --> Total execution time: 0.0420
INFO - 2016-10-19 18:54:54 --> Config Class Initialized
INFO - 2016-10-19 18:54:54 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:54:54 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:54:54 --> Utf8 Class Initialized
INFO - 2016-10-19 18:54:54 --> URI Class Initialized
INFO - 2016-10-19 18:54:54 --> Router Class Initialized
INFO - 2016-10-19 18:54:54 --> Output Class Initialized
INFO - 2016-10-19 18:54:54 --> Security Class Initialized
DEBUG - 2016-10-19 18:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:54:54 --> Input Class Initialized
INFO - 2016-10-19 18:54:54 --> Language Class Initialized
INFO - 2016-10-19 18:54:54 --> Language Class Initialized
INFO - 2016-10-19 18:54:54 --> Config Class Initialized
INFO - 2016-10-19 18:54:54 --> Loader Class Initialized
INFO - 2016-10-19 18:54:54 --> Helper loaded: common_helper
INFO - 2016-10-19 18:54:54 --> Helper loaded: url_helper
INFO - 2016-10-19 18:54:54 --> Database Driver Class Initialized
INFO - 2016-10-19 18:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:54:54 --> Parser Class Initialized
INFO - 2016-10-19 18:54:54 --> Controller Class Initialized
DEBUG - 2016-10-19 18:54:54 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 18:54:54 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:54:54 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-19 18:54:54 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:54:54 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-19 18:54:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 18:54:54 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-19 18:54:54 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:54 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-19 18:54:54 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-19 18:54:54 --> Final output sent to browser
DEBUG - 2016-10-19 18:54:54 --> Total execution time: 0.0547
INFO - 2016-10-19 18:54:55 --> Config Class Initialized
INFO - 2016-10-19 18:54:55 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:54:55 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:54:55 --> Utf8 Class Initialized
INFO - 2016-10-19 18:54:55 --> URI Class Initialized
INFO - 2016-10-19 18:54:55 --> Router Class Initialized
INFO - 2016-10-19 18:54:55 --> Output Class Initialized
INFO - 2016-10-19 18:54:55 --> Security Class Initialized
DEBUG - 2016-10-19 18:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:54:55 --> Input Class Initialized
INFO - 2016-10-19 18:54:55 --> Language Class Initialized
ERROR - 2016-10-19 18:54:55 --> 404 Page Not Found: /index
INFO - 2016-10-19 18:54:56 --> Config Class Initialized
INFO - 2016-10-19 18:54:56 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:54:56 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:54:56 --> Utf8 Class Initialized
INFO - 2016-10-19 18:54:56 --> URI Class Initialized
INFO - 2016-10-19 18:54:56 --> Router Class Initialized
INFO - 2016-10-19 18:54:56 --> Output Class Initialized
INFO - 2016-10-19 18:54:56 --> Security Class Initialized
DEBUG - 2016-10-19 18:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:54:56 --> Input Class Initialized
INFO - 2016-10-19 18:54:56 --> Language Class Initialized
INFO - 2016-10-19 18:54:56 --> Language Class Initialized
INFO - 2016-10-19 18:54:56 --> Config Class Initialized
INFO - 2016-10-19 18:54:56 --> Loader Class Initialized
INFO - 2016-10-19 18:54:56 --> Helper loaded: common_helper
INFO - 2016-10-19 18:54:56 --> Helper loaded: url_helper
INFO - 2016-10-19 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-19 18:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:54:56 --> Parser Class Initialized
INFO - 2016-10-19 18:54:56 --> Controller Class Initialized
DEBUG - 2016-10-19 18:54:56 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 18:54:56 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:56 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 18:54:56 --> Model Class Initialized
INFO - 2016-10-19 18:54:56 --> Config Class Initialized
INFO - 2016-10-19 18:54:56 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:54:56 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:54:56 --> Utf8 Class Initialized
INFO - 2016-10-19 18:54:56 --> URI Class Initialized
INFO - 2016-10-19 18:54:56 --> Router Class Initialized
INFO - 2016-10-19 18:54:56 --> Output Class Initialized
INFO - 2016-10-19 18:54:56 --> Security Class Initialized
DEBUG - 2016-10-19 18:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:54:56 --> Input Class Initialized
INFO - 2016-10-19 18:54:56 --> Language Class Initialized
INFO - 2016-10-19 18:54:56 --> Language Class Initialized
INFO - 2016-10-19 18:54:56 --> Config Class Initialized
INFO - 2016-10-19 18:54:56 --> Loader Class Initialized
INFO - 2016-10-19 18:54:56 --> Helper loaded: common_helper
INFO - 2016-10-19 18:54:56 --> Helper loaded: url_helper
INFO - 2016-10-19 18:54:56 --> Database Driver Class Initialized
INFO - 2016-10-19 18:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:54:56 --> Parser Class Initialized
INFO - 2016-10-19 18:54:56 --> Controller Class Initialized
DEBUG - 2016-10-19 18:54:56 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 18:54:56 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:54:56 --> Model Class Initialized
DEBUG - 2016-10-19 18:54:56 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/security_gt.php
INFO - 2016-10-19 18:54:56 --> Final output sent to browser
DEBUG - 2016-10-19 18:54:56 --> Total execution time: 0.0558
INFO - 2016-10-19 18:54:56 --> Config Class Initialized
INFO - 2016-10-19 18:54:56 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:54:56 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:54:56 --> Utf8 Class Initialized
INFO - 2016-10-19 18:54:56 --> URI Class Initialized
INFO - 2016-10-19 18:54:56 --> Router Class Initialized
INFO - 2016-10-19 18:54:56 --> Output Class Initialized
INFO - 2016-10-19 18:54:56 --> Security Class Initialized
DEBUG - 2016-10-19 18:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:54:56 --> Input Class Initialized
INFO - 2016-10-19 18:54:56 --> Language Class Initialized
ERROR - 2016-10-19 18:54:56 --> 404 Page Not Found: /index
INFO - 2016-10-19 18:54:56 --> Config Class Initialized
INFO - 2016-10-19 18:54:56 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:54:56 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:54:56 --> Utf8 Class Initialized
INFO - 2016-10-19 18:54:56 --> URI Class Initialized
INFO - 2016-10-19 18:54:56 --> Router Class Initialized
INFO - 2016-10-19 18:54:56 --> Output Class Initialized
INFO - 2016-10-19 18:54:56 --> Security Class Initialized
DEBUG - 2016-10-19 18:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:54:56 --> Input Class Initialized
INFO - 2016-10-19 18:54:56 --> Language Class Initialized
ERROR - 2016-10-19 18:54:56 --> 404 Page Not Found: /index
INFO - 2016-10-19 18:55:02 --> Config Class Initialized
INFO - 2016-10-19 18:55:02 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:55:02 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:55:02 --> Utf8 Class Initialized
INFO - 2016-10-19 18:55:02 --> URI Class Initialized
INFO - 2016-10-19 18:55:02 --> Router Class Initialized
INFO - 2016-10-19 18:55:02 --> Output Class Initialized
INFO - 2016-10-19 18:55:02 --> Security Class Initialized
DEBUG - 2016-10-19 18:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:55:02 --> Input Class Initialized
INFO - 2016-10-19 18:55:02 --> Language Class Initialized
INFO - 2016-10-19 18:55:02 --> Language Class Initialized
INFO - 2016-10-19 18:55:02 --> Config Class Initialized
INFO - 2016-10-19 18:55:02 --> Loader Class Initialized
INFO - 2016-10-19 18:55:02 --> Helper loaded: common_helper
INFO - 2016-10-19 18:55:02 --> Helper loaded: url_helper
INFO - 2016-10-19 18:55:02 --> Database Driver Class Initialized
INFO - 2016-10-19 18:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:55:02 --> Parser Class Initialized
INFO - 2016-10-19 18:55:02 --> Controller Class Initialized
DEBUG - 2016-10-19 18:55:02 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 18:55:02 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:55:02 --> Model Class Initialized
INFO - 2016-10-19 18:55:02 --> Config Class Initialized
INFO - 2016-10-19 18:55:02 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:55:02 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:55:02 --> Utf8 Class Initialized
INFO - 2016-10-19 18:55:02 --> URI Class Initialized
INFO - 2016-10-19 18:55:02 --> Router Class Initialized
INFO - 2016-10-19 18:55:02 --> Output Class Initialized
INFO - 2016-10-19 18:55:02 --> Security Class Initialized
DEBUG - 2016-10-19 18:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:55:02 --> Input Class Initialized
INFO - 2016-10-19 18:55:02 --> Language Class Initialized
INFO - 2016-10-19 18:55:02 --> Language Class Initialized
INFO - 2016-10-19 18:55:02 --> Config Class Initialized
INFO - 2016-10-19 18:55:02 --> Loader Class Initialized
INFO - 2016-10-19 18:55:02 --> Helper loaded: common_helper
INFO - 2016-10-19 18:55:02 --> Helper loaded: url_helper
INFO - 2016-10-19 18:55:02 --> Database Driver Class Initialized
INFO - 2016-10-19 18:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:55:02 --> Parser Class Initialized
INFO - 2016-10-19 18:55:02 --> Controller Class Initialized
DEBUG - 2016-10-19 18:55:02 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 18:55:02 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:55:02 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/setting.php
ERROR - 2016-10-19 18:55:02 --> Severity: Notice --> Undefined variable: module /home/dolongpk/public_html/application/views/BACKEND/template.php 11
DEBUG - 2016-10-19 18:55:02 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:55:02 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-19 18:55:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 18:55:02 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-19 18:55:02 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:02 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-19 18:55:02 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-19 18:55:02 --> Final output sent to browser
DEBUG - 2016-10-19 18:55:02 --> Total execution time: 0.0439
INFO - 2016-10-19 18:55:03 --> Config Class Initialized
INFO - 2016-10-19 18:55:03 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:55:03 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:55:03 --> Utf8 Class Initialized
INFO - 2016-10-19 18:55:03 --> URI Class Initialized
INFO - 2016-10-19 18:55:03 --> Router Class Initialized
INFO - 2016-10-19 18:55:03 --> Output Class Initialized
INFO - 2016-10-19 18:55:03 --> Security Class Initialized
DEBUG - 2016-10-19 18:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:55:03 --> Input Class Initialized
INFO - 2016-10-19 18:55:03 --> Language Class Initialized
INFO - 2016-10-19 18:55:03 --> Language Class Initialized
INFO - 2016-10-19 18:55:03 --> Config Class Initialized
INFO - 2016-10-19 18:55:03 --> Loader Class Initialized
INFO - 2016-10-19 18:55:03 --> Helper loaded: common_helper
INFO - 2016-10-19 18:55:03 --> Helper loaded: url_helper
INFO - 2016-10-19 18:55:03 --> Database Driver Class Initialized
INFO - 2016-10-19 18:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:55:03 --> Parser Class Initialized
INFO - 2016-10-19 18:55:03 --> Controller Class Initialized
DEBUG - 2016-10-19 18:55:03 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 18:55:03 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:55:03 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-19 18:55:03 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 18:55:03 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-19 18:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 18:55:03 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-19 18:55:03 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:03 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-19 18:55:03 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-19 18:55:03 --> Final output sent to browser
DEBUG - 2016-10-19 18:55:03 --> Total execution time: 0.0420
INFO - 2016-10-19 18:55:03 --> Config Class Initialized
INFO - 2016-10-19 18:55:03 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:55:03 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:55:03 --> Utf8 Class Initialized
INFO - 2016-10-19 18:55:03 --> URI Class Initialized
INFO - 2016-10-19 18:55:03 --> Router Class Initialized
INFO - 2016-10-19 18:55:03 --> Output Class Initialized
INFO - 2016-10-19 18:55:03 --> Security Class Initialized
DEBUG - 2016-10-19 18:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:55:03 --> Input Class Initialized
INFO - 2016-10-19 18:55:03 --> Language Class Initialized
ERROR - 2016-10-19 18:55:03 --> 404 Page Not Found: /index
INFO - 2016-10-19 18:55:04 --> Config Class Initialized
INFO - 2016-10-19 18:55:04 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:55:04 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:55:04 --> Utf8 Class Initialized
INFO - 2016-10-19 18:55:04 --> URI Class Initialized
INFO - 2016-10-19 18:55:04 --> Router Class Initialized
INFO - 2016-10-19 18:55:04 --> Output Class Initialized
INFO - 2016-10-19 18:55:04 --> Security Class Initialized
DEBUG - 2016-10-19 18:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:55:04 --> Input Class Initialized
INFO - 2016-10-19 18:55:04 --> Language Class Initialized
INFO - 2016-10-19 18:55:04 --> Language Class Initialized
INFO - 2016-10-19 18:55:04 --> Config Class Initialized
INFO - 2016-10-19 18:55:04 --> Loader Class Initialized
INFO - 2016-10-19 18:55:04 --> Helper loaded: common_helper
INFO - 2016-10-19 18:55:04 --> Helper loaded: url_helper
INFO - 2016-10-19 18:55:04 --> Database Driver Class Initialized
INFO - 2016-10-19 18:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:55:04 --> Parser Class Initialized
INFO - 2016-10-19 18:55:04 --> Controller Class Initialized
DEBUG - 2016-10-19 18:55:04 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 18:55:04 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:04 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 18:55:04 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:04 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-19 18:55:04 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-19 18:55:04 --> Final output sent to browser
DEBUG - 2016-10-19 18:55:04 --> Total execution time: 0.0544
INFO - 2016-10-19 18:55:57 --> Config Class Initialized
INFO - 2016-10-19 18:55:57 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:55:57 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:55:57 --> Utf8 Class Initialized
INFO - 2016-10-19 18:55:57 --> URI Class Initialized
INFO - 2016-10-19 18:55:57 --> Router Class Initialized
INFO - 2016-10-19 18:55:57 --> Output Class Initialized
INFO - 2016-10-19 18:55:57 --> Security Class Initialized
DEBUG - 2016-10-19 18:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:55:57 --> Input Class Initialized
INFO - 2016-10-19 18:55:57 --> Language Class Initialized
INFO - 2016-10-19 18:55:57 --> Language Class Initialized
INFO - 2016-10-19 18:55:57 --> Config Class Initialized
INFO - 2016-10-19 18:55:57 --> Loader Class Initialized
INFO - 2016-10-19 18:55:57 --> Helper loaded: common_helper
INFO - 2016-10-19 18:55:57 --> Helper loaded: url_helper
INFO - 2016-10-19 18:55:57 --> Database Driver Class Initialized
INFO - 2016-10-19 18:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:55:57 --> Parser Class Initialized
INFO - 2016-10-19 18:55:57 --> Controller Class Initialized
DEBUG - 2016-10-19 18:55:57 --> Servers MX_Controller Initialized
INFO - 2016-10-19 18:55:57 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 18:55:57 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 18:55:57 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:57 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 18:55:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 18:55:57 --> Final output sent to browser
DEBUG - 2016-10-19 18:55:57 --> Total execution time: 0.0731
INFO - 2016-10-19 18:55:57 --> Config Class Initialized
INFO - 2016-10-19 18:55:57 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:55:57 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:55:57 --> Utf8 Class Initialized
INFO - 2016-10-19 18:55:57 --> URI Class Initialized
INFO - 2016-10-19 18:55:57 --> Router Class Initialized
INFO - 2016-10-19 18:55:57 --> Output Class Initialized
INFO - 2016-10-19 18:55:57 --> Security Class Initialized
DEBUG - 2016-10-19 18:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:55:57 --> Input Class Initialized
INFO - 2016-10-19 18:55:57 --> Language Class Initialized
INFO - 2016-10-19 18:55:57 --> Language Class Initialized
INFO - 2016-10-19 18:55:57 --> Config Class Initialized
INFO - 2016-10-19 18:55:57 --> Loader Class Initialized
INFO - 2016-10-19 18:55:57 --> Helper loaded: common_helper
INFO - 2016-10-19 18:55:57 --> Helper loaded: url_helper
INFO - 2016-10-19 18:55:57 --> Database Driver Class Initialized
INFO - 2016-10-19 18:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:55:57 --> Parser Class Initialized
INFO - 2016-10-19 18:55:57 --> Controller Class Initialized
DEBUG - 2016-10-19 18:55:57 --> Servers MX_Controller Initialized
INFO - 2016-10-19 18:55:57 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:57 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 18:55:57 --> Model Class Initialized
DEBUG - 2016-10-19 18:55:57 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 18:55:57 --> Model Class Initialized
INFO - 2016-10-19 18:59:17 --> Config Class Initialized
INFO - 2016-10-19 18:59:17 --> Hooks Class Initialized
DEBUG - 2016-10-19 18:59:17 --> UTF-8 Support Enabled
INFO - 2016-10-19 18:59:17 --> Utf8 Class Initialized
INFO - 2016-10-19 18:59:17 --> URI Class Initialized
INFO - 2016-10-19 18:59:17 --> Router Class Initialized
INFO - 2016-10-19 18:59:17 --> Output Class Initialized
INFO - 2016-10-19 18:59:17 --> Security Class Initialized
DEBUG - 2016-10-19 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 18:59:17 --> Input Class Initialized
INFO - 2016-10-19 18:59:17 --> Language Class Initialized
INFO - 2016-10-19 18:59:17 --> Language Class Initialized
INFO - 2016-10-19 18:59:17 --> Config Class Initialized
INFO - 2016-10-19 18:59:17 --> Loader Class Initialized
INFO - 2016-10-19 18:59:17 --> Helper loaded: common_helper
INFO - 2016-10-19 18:59:17 --> Helper loaded: url_helper
INFO - 2016-10-19 18:59:17 --> Database Driver Class Initialized
INFO - 2016-10-19 18:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 18:59:17 --> Parser Class Initialized
INFO - 2016-10-19 18:59:17 --> Controller Class Initialized
DEBUG - 2016-10-19 18:59:17 --> Servers MX_Controller Initialized
INFO - 2016-10-19 18:59:17 --> Model Class Initialized
DEBUG - 2016-10-19 18:59:17 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 18:59:17 --> Model Class Initialized
DEBUG - 2016-10-19 18:59:17 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 18:59:17 --> Model Class Initialized
INFO - 2016-10-19 19:00:27 --> Config Class Initialized
INFO - 2016-10-19 19:00:27 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:00:27 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:00:27 --> Utf8 Class Initialized
INFO - 2016-10-19 19:00:27 --> URI Class Initialized
INFO - 2016-10-19 19:00:27 --> Router Class Initialized
INFO - 2016-10-19 19:00:27 --> Output Class Initialized
INFO - 2016-10-19 19:00:27 --> Security Class Initialized
DEBUG - 2016-10-19 19:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:00:27 --> Input Class Initialized
INFO - 2016-10-19 19:00:27 --> Language Class Initialized
INFO - 2016-10-19 19:00:27 --> Language Class Initialized
INFO - 2016-10-19 19:00:27 --> Config Class Initialized
INFO - 2016-10-19 19:00:27 --> Loader Class Initialized
INFO - 2016-10-19 19:00:27 --> Helper loaded: common_helper
INFO - 2016-10-19 19:00:27 --> Helper loaded: url_helper
INFO - 2016-10-19 19:00:27 --> Database Driver Class Initialized
INFO - 2016-10-19 19:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:00:27 --> Parser Class Initialized
INFO - 2016-10-19 19:00:27 --> Controller Class Initialized
DEBUG - 2016-10-19 19:00:27 --> Servers MX_Controller Initialized
INFO - 2016-10-19 19:00:27 --> Model Class Initialized
DEBUG - 2016-10-19 19:00:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 19:00:27 --> Model Class Initialized
DEBUG - 2016-10-19 19:00:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 19:00:27 --> Model Class Initialized
DEBUG - 2016-10-19 19:00:27 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 19:00:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 19:00:27 --> Final output sent to browser
DEBUG - 2016-10-19 19:00:27 --> Total execution time: 0.0487
INFO - 2016-10-19 19:00:27 --> Config Class Initialized
INFO - 2016-10-19 19:00:27 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:00:27 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:00:27 --> Utf8 Class Initialized
INFO - 2016-10-19 19:00:27 --> URI Class Initialized
INFO - 2016-10-19 19:00:27 --> Router Class Initialized
INFO - 2016-10-19 19:00:27 --> Output Class Initialized
INFO - 2016-10-19 19:00:27 --> Security Class Initialized
DEBUG - 2016-10-19 19:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:00:27 --> Input Class Initialized
INFO - 2016-10-19 19:00:27 --> Language Class Initialized
INFO - 2016-10-19 19:00:27 --> Language Class Initialized
INFO - 2016-10-19 19:00:27 --> Config Class Initialized
INFO - 2016-10-19 19:00:27 --> Loader Class Initialized
INFO - 2016-10-19 19:00:27 --> Helper loaded: common_helper
INFO - 2016-10-19 19:00:27 --> Helper loaded: url_helper
INFO - 2016-10-19 19:00:27 --> Database Driver Class Initialized
INFO - 2016-10-19 19:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:00:27 --> Parser Class Initialized
INFO - 2016-10-19 19:00:27 --> Controller Class Initialized
DEBUG - 2016-10-19 19:00:27 --> Servers MX_Controller Initialized
INFO - 2016-10-19 19:00:27 --> Model Class Initialized
DEBUG - 2016-10-19 19:00:27 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 19:00:27 --> Model Class Initialized
DEBUG - 2016-10-19 19:00:27 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 19:00:27 --> Model Class Initialized
INFO - 2016-10-19 19:03:47 --> Config Class Initialized
INFO - 2016-10-19 19:03:47 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:03:47 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:03:47 --> Utf8 Class Initialized
INFO - 2016-10-19 19:03:47 --> URI Class Initialized
INFO - 2016-10-19 19:03:47 --> Router Class Initialized
INFO - 2016-10-19 19:03:47 --> Output Class Initialized
INFO - 2016-10-19 19:03:47 --> Security Class Initialized
DEBUG - 2016-10-19 19:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:03:47 --> Input Class Initialized
INFO - 2016-10-19 19:03:47 --> Language Class Initialized
INFO - 2016-10-19 19:03:47 --> Language Class Initialized
INFO - 2016-10-19 19:03:47 --> Config Class Initialized
INFO - 2016-10-19 19:03:47 --> Loader Class Initialized
INFO - 2016-10-19 19:03:47 --> Helper loaded: common_helper
INFO - 2016-10-19 19:03:47 --> Helper loaded: url_helper
INFO - 2016-10-19 19:03:47 --> Database Driver Class Initialized
INFO - 2016-10-19 19:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:03:47 --> Parser Class Initialized
INFO - 2016-10-19 19:03:47 --> Controller Class Initialized
DEBUG - 2016-10-19 19:03:47 --> Servers MX_Controller Initialized
INFO - 2016-10-19 19:03:47 --> Model Class Initialized
DEBUG - 2016-10-19 19:03:47 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 19:03:47 --> Model Class Initialized
DEBUG - 2016-10-19 19:03:47 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 19:03:47 --> Model Class Initialized
INFO - 2016-10-19 19:07:08 --> Config Class Initialized
INFO - 2016-10-19 19:07:08 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:07:08 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:07:08 --> Utf8 Class Initialized
INFO - 2016-10-19 19:07:08 --> URI Class Initialized
INFO - 2016-10-19 19:07:08 --> Router Class Initialized
INFO - 2016-10-19 19:07:08 --> Output Class Initialized
INFO - 2016-10-19 19:07:08 --> Security Class Initialized
DEBUG - 2016-10-19 19:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:07:08 --> Input Class Initialized
INFO - 2016-10-19 19:07:08 --> Language Class Initialized
INFO - 2016-10-19 19:07:08 --> Language Class Initialized
INFO - 2016-10-19 19:07:08 --> Config Class Initialized
INFO - 2016-10-19 19:07:08 --> Loader Class Initialized
INFO - 2016-10-19 19:07:08 --> Helper loaded: common_helper
INFO - 2016-10-19 19:07:08 --> Helper loaded: url_helper
INFO - 2016-10-19 19:07:08 --> Database Driver Class Initialized
INFO - 2016-10-19 19:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:07:08 --> Parser Class Initialized
INFO - 2016-10-19 19:07:08 --> Controller Class Initialized
DEBUG - 2016-10-19 19:07:08 --> Servers MX_Controller Initialized
INFO - 2016-10-19 19:07:08 --> Model Class Initialized
DEBUG - 2016-10-19 19:07:08 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 19:07:08 --> Model Class Initialized
DEBUG - 2016-10-19 19:07:08 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 19:07:08 --> Model Class Initialized
INFO - 2016-10-19 19:10:28 --> Config Class Initialized
INFO - 2016-10-19 19:10:28 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:10:28 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:10:28 --> Utf8 Class Initialized
INFO - 2016-10-19 19:10:28 --> URI Class Initialized
INFO - 2016-10-19 19:10:28 --> Router Class Initialized
INFO - 2016-10-19 19:10:28 --> Output Class Initialized
INFO - 2016-10-19 19:10:28 --> Security Class Initialized
DEBUG - 2016-10-19 19:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:10:28 --> Input Class Initialized
INFO - 2016-10-19 19:10:28 --> Language Class Initialized
INFO - 2016-10-19 19:10:28 --> Language Class Initialized
INFO - 2016-10-19 19:10:28 --> Config Class Initialized
INFO - 2016-10-19 19:10:28 --> Loader Class Initialized
INFO - 2016-10-19 19:10:28 --> Helper loaded: common_helper
INFO - 2016-10-19 19:10:28 --> Helper loaded: url_helper
INFO - 2016-10-19 19:10:28 --> Database Driver Class Initialized
INFO - 2016-10-19 19:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:10:28 --> Parser Class Initialized
INFO - 2016-10-19 19:10:28 --> Controller Class Initialized
DEBUG - 2016-10-19 19:10:28 --> Servers MX_Controller Initialized
INFO - 2016-10-19 19:10:28 --> Model Class Initialized
DEBUG - 2016-10-19 19:10:28 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 19:10:28 --> Model Class Initialized
DEBUG - 2016-10-19 19:10:28 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 19:10:28 --> Model Class Initialized
INFO - 2016-10-19 19:11:56 --> Config Class Initialized
INFO - 2016-10-19 19:11:56 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:11:56 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:11:56 --> Utf8 Class Initialized
INFO - 2016-10-19 19:11:56 --> URI Class Initialized
INFO - 2016-10-19 19:11:56 --> Router Class Initialized
INFO - 2016-10-19 19:11:56 --> Output Class Initialized
INFO - 2016-10-19 19:11:56 --> Security Class Initialized
DEBUG - 2016-10-19 19:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:11:56 --> Input Class Initialized
INFO - 2016-10-19 19:11:56 --> Language Class Initialized
INFO - 2016-10-19 19:11:56 --> Language Class Initialized
INFO - 2016-10-19 19:11:56 --> Config Class Initialized
INFO - 2016-10-19 19:11:56 --> Loader Class Initialized
INFO - 2016-10-19 19:11:56 --> Helper loaded: common_helper
INFO - 2016-10-19 19:11:56 --> Helper loaded: url_helper
INFO - 2016-10-19 19:11:56 --> Database Driver Class Initialized
INFO - 2016-10-19 19:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:11:56 --> Parser Class Initialized
INFO - 2016-10-19 19:11:56 --> Controller Class Initialized
DEBUG - 2016-10-19 19:11:56 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 19:11:56 --> Model Class Initialized
DEBUG - 2016-10-19 19:11:56 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 19:11:56 --> Model Class Initialized
DEBUG - 2016-10-19 19:11:56 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-19 19:11:56 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-19 19:11:56 --> Final output sent to browser
DEBUG - 2016-10-19 19:11:56 --> Total execution time: 0.0467
INFO - 2016-10-19 19:12:06 --> Config Class Initialized
INFO - 2016-10-19 19:12:06 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:12:06 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:12:06 --> Utf8 Class Initialized
INFO - 2016-10-19 19:12:06 --> URI Class Initialized
INFO - 2016-10-19 19:12:06 --> Router Class Initialized
INFO - 2016-10-19 19:12:06 --> Output Class Initialized
INFO - 2016-10-19 19:12:06 --> Security Class Initialized
DEBUG - 2016-10-19 19:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:12:06 --> Input Class Initialized
INFO - 2016-10-19 19:12:06 --> Language Class Initialized
INFO - 2016-10-19 19:12:06 --> Language Class Initialized
INFO - 2016-10-19 19:12:06 --> Config Class Initialized
INFO - 2016-10-19 19:12:06 --> Loader Class Initialized
INFO - 2016-10-19 19:12:06 --> Helper loaded: common_helper
INFO - 2016-10-19 19:12:06 --> Helper loaded: url_helper
INFO - 2016-10-19 19:12:06 --> Database Driver Class Initialized
INFO - 2016-10-19 19:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:12:06 --> Parser Class Initialized
INFO - 2016-10-19 19:12:06 --> Controller Class Initialized
DEBUG - 2016-10-19 19:12:06 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 19:12:06 --> Model Class Initialized
DEBUG - 2016-10-19 19:12:06 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 19:12:06 --> Model Class Initialized
INFO - 2016-10-19 19:12:10 --> Config Class Initialized
INFO - 2016-10-19 19:12:10 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:12:10 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:12:10 --> Utf8 Class Initialized
INFO - 2016-10-19 19:12:10 --> URI Class Initialized
INFO - 2016-10-19 19:12:10 --> Router Class Initialized
INFO - 2016-10-19 19:12:10 --> Output Class Initialized
INFO - 2016-10-19 19:12:10 --> Security Class Initialized
DEBUG - 2016-10-19 19:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:12:10 --> Input Class Initialized
INFO - 2016-10-19 19:12:10 --> Language Class Initialized
INFO - 2016-10-19 19:12:10 --> Language Class Initialized
INFO - 2016-10-19 19:12:10 --> Config Class Initialized
INFO - 2016-10-19 19:12:10 --> Loader Class Initialized
INFO - 2016-10-19 19:12:10 --> Helper loaded: common_helper
INFO - 2016-10-19 19:12:10 --> Helper loaded: url_helper
INFO - 2016-10-19 19:12:10 --> Database Driver Class Initialized
INFO - 2016-10-19 19:12:32 --> Config Class Initialized
INFO - 2016-10-19 19:12:32 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:12:32 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:12:32 --> Utf8 Class Initialized
INFO - 2016-10-19 19:12:32 --> URI Class Initialized
INFO - 2016-10-19 19:12:32 --> Router Class Initialized
INFO - 2016-10-19 19:12:32 --> Output Class Initialized
INFO - 2016-10-19 19:12:32 --> Security Class Initialized
DEBUG - 2016-10-19 19:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:12:32 --> Input Class Initialized
INFO - 2016-10-19 19:12:32 --> Language Class Initialized
INFO - 2016-10-19 19:12:32 --> Language Class Initialized
INFO - 2016-10-19 19:12:32 --> Config Class Initialized
INFO - 2016-10-19 19:12:32 --> Loader Class Initialized
INFO - 2016-10-19 19:12:32 --> Helper loaded: common_helper
INFO - 2016-10-19 19:12:32 --> Helper loaded: url_helper
INFO - 2016-10-19 19:12:32 --> Database Driver Class Initialized
INFO - 2016-10-19 19:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:13:09 --> Parser Class Initialized
INFO - 2016-10-19 19:13:09 --> Controller Class Initialized
DEBUG - 2016-10-19 19:13:09 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 19:13:09 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:09 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 19:13:09 --> Model Class Initialized
ERROR - 2016-10-19 19:13:09 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `cli_servers`
WHERE `id` = 1
INFO - 2016-10-19 19:13:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-19 19:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:13:09 --> Parser Class Initialized
INFO - 2016-10-19 19:13:09 --> Controller Class Initialized
DEBUG - 2016-10-19 19:13:09 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 19:13:09 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:09 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 19:13:09 --> Model Class Initialized
ERROR - 2016-10-19 19:13:09 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `cli_log_gmt_money`
INFO - 2016-10-19 19:13:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-10-19 19:13:16 --> Config Class Initialized
INFO - 2016-10-19 19:13:16 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:13:16 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:13:16 --> Utf8 Class Initialized
INFO - 2016-10-19 19:13:16 --> URI Class Initialized
INFO - 2016-10-19 19:13:16 --> Router Class Initialized
INFO - 2016-10-19 19:13:16 --> Output Class Initialized
INFO - 2016-10-19 19:13:16 --> Security Class Initialized
DEBUG - 2016-10-19 19:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:13:16 --> Input Class Initialized
INFO - 2016-10-19 19:13:16 --> Language Class Initialized
INFO - 2016-10-19 19:13:16 --> Language Class Initialized
INFO - 2016-10-19 19:13:16 --> Config Class Initialized
INFO - 2016-10-19 19:13:16 --> Loader Class Initialized
INFO - 2016-10-19 19:13:16 --> Helper loaded: common_helper
INFO - 2016-10-19 19:13:16 --> Helper loaded: url_helper
INFO - 2016-10-19 19:13:16 --> Database Driver Class Initialized
INFO - 2016-10-19 19:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:13:16 --> Parser Class Initialized
INFO - 2016-10-19 19:13:16 --> Controller Class Initialized
DEBUG - 2016-10-19 19:13:16 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 19:13:16 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:16 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 19:13:16 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:16 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-19 19:13:16 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-19 19:13:16 --> Final output sent to browser
DEBUG - 2016-10-19 19:13:16 --> Total execution time: 0.0466
INFO - 2016-10-19 19:13:26 --> Config Class Initialized
INFO - 2016-10-19 19:13:26 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:13:26 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:13:26 --> Utf8 Class Initialized
INFO - 2016-10-19 19:13:26 --> URI Class Initialized
INFO - 2016-10-19 19:13:26 --> Router Class Initialized
INFO - 2016-10-19 19:13:26 --> Output Class Initialized
INFO - 2016-10-19 19:13:26 --> Security Class Initialized
DEBUG - 2016-10-19 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:13:26 --> Input Class Initialized
INFO - 2016-10-19 19:13:26 --> Language Class Initialized
INFO - 2016-10-19 19:13:26 --> Language Class Initialized
INFO - 2016-10-19 19:13:26 --> Config Class Initialized
INFO - 2016-10-19 19:13:26 --> Loader Class Initialized
INFO - 2016-10-19 19:13:26 --> Helper loaded: common_helper
INFO - 2016-10-19 19:13:26 --> Helper loaded: url_helper
INFO - 2016-10-19 19:13:26 --> Database Driver Class Initialized
INFO - 2016-10-19 19:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:13:26 --> Parser Class Initialized
INFO - 2016-10-19 19:13:26 --> Controller Class Initialized
DEBUG - 2016-10-19 19:13:26 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 19:13:26 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:26 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 19:13:26 --> Model Class Initialized
INFO - 2016-10-19 19:13:36 --> Config Class Initialized
INFO - 2016-10-19 19:13:36 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:13:36 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:13:36 --> Utf8 Class Initialized
INFO - 2016-10-19 19:13:36 --> URI Class Initialized
INFO - 2016-10-19 19:13:36 --> Router Class Initialized
INFO - 2016-10-19 19:13:36 --> Output Class Initialized
INFO - 2016-10-19 19:13:36 --> Security Class Initialized
DEBUG - 2016-10-19 19:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:13:36 --> Input Class Initialized
INFO - 2016-10-19 19:13:36 --> Language Class Initialized
INFO - 2016-10-19 19:13:36 --> Language Class Initialized
INFO - 2016-10-19 19:13:36 --> Config Class Initialized
INFO - 2016-10-19 19:13:36 --> Loader Class Initialized
INFO - 2016-10-19 19:13:36 --> Helper loaded: common_helper
INFO - 2016-10-19 19:13:36 --> Helper loaded: url_helper
INFO - 2016-10-19 19:13:36 --> Database Driver Class Initialized
INFO - 2016-10-19 19:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:13:36 --> Parser Class Initialized
INFO - 2016-10-19 19:13:36 --> Controller Class Initialized
DEBUG - 2016-10-19 19:13:36 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 19:13:36 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:36 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 19:13:36 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:36 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-19 19:13:36 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-19 19:13:36 --> Final output sent to browser
DEBUG - 2016-10-19 19:13:36 --> Total execution time: 0.0459
INFO - 2016-10-19 19:13:41 --> Config Class Initialized
INFO - 2016-10-19 19:13:41 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:13:41 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:13:41 --> Utf8 Class Initialized
INFO - 2016-10-19 19:13:41 --> URI Class Initialized
INFO - 2016-10-19 19:13:41 --> Router Class Initialized
INFO - 2016-10-19 19:13:41 --> Output Class Initialized
INFO - 2016-10-19 19:13:41 --> Security Class Initialized
DEBUG - 2016-10-19 19:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:13:41 --> Input Class Initialized
INFO - 2016-10-19 19:13:41 --> Language Class Initialized
INFO - 2016-10-19 19:13:41 --> Language Class Initialized
INFO - 2016-10-19 19:13:41 --> Config Class Initialized
INFO - 2016-10-19 19:13:41 --> Loader Class Initialized
INFO - 2016-10-19 19:13:41 --> Helper loaded: common_helper
INFO - 2016-10-19 19:13:41 --> Helper loaded: url_helper
INFO - 2016-10-19 19:13:41 --> Database Driver Class Initialized
INFO - 2016-10-19 19:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:13:41 --> Parser Class Initialized
INFO - 2016-10-19 19:13:41 --> Controller Class Initialized
DEBUG - 2016-10-19 19:13:41 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 19:13:41 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:41 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 19:13:41 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:41 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/api_view.php
INFO - 2016-10-19 19:13:48 --> Config Class Initialized
INFO - 2016-10-19 19:13:48 --> Hooks Class Initialized
DEBUG - 2016-10-19 19:13:48 --> UTF-8 Support Enabled
INFO - 2016-10-19 19:13:48 --> Utf8 Class Initialized
INFO - 2016-10-19 19:13:48 --> URI Class Initialized
INFO - 2016-10-19 19:13:48 --> Router Class Initialized
INFO - 2016-10-19 19:13:48 --> Output Class Initialized
INFO - 2016-10-19 19:13:48 --> Security Class Initialized
DEBUG - 2016-10-19 19:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 19:13:48 --> Input Class Initialized
INFO - 2016-10-19 19:13:48 --> Language Class Initialized
INFO - 2016-10-19 19:13:48 --> Language Class Initialized
INFO - 2016-10-19 19:13:48 --> Config Class Initialized
INFO - 2016-10-19 19:13:48 --> Loader Class Initialized
INFO - 2016-10-19 19:13:48 --> Helper loaded: common_helper
INFO - 2016-10-19 19:13:48 --> Helper loaded: url_helper
INFO - 2016-10-19 19:13:48 --> Database Driver Class Initialized
INFO - 2016-10-19 19:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 19:13:48 --> Parser Class Initialized
INFO - 2016-10-19 19:13:48 --> Controller Class Initialized
DEBUG - 2016-10-19 19:13:48 --> Servers MX_Controller Initialized
INFO - 2016-10-19 19:13:48 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:48 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 19:13:48 --> Model Class Initialized
DEBUG - 2016-10-19 19:13:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 19:13:48 --> Model Class Initialized
INFO - 2016-10-19 20:30:32 --> Config Class Initialized
INFO - 2016-10-19 20:30:32 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:30:32 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:30:32 --> Utf8 Class Initialized
INFO - 2016-10-19 20:30:32 --> URI Class Initialized
DEBUG - 2016-10-19 20:30:32 --> No URI present. Default controller set.
INFO - 2016-10-19 20:30:32 --> Router Class Initialized
INFO - 2016-10-19 20:30:32 --> Output Class Initialized
INFO - 2016-10-19 20:30:32 --> Security Class Initialized
DEBUG - 2016-10-19 20:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:30:32 --> Input Class Initialized
INFO - 2016-10-19 20:30:32 --> Language Class Initialized
INFO - 2016-10-19 20:30:32 --> Language Class Initialized
INFO - 2016-10-19 20:30:32 --> Config Class Initialized
INFO - 2016-10-19 20:30:32 --> Loader Class Initialized
INFO - 2016-10-19 20:30:32 --> Helper loaded: common_helper
INFO - 2016-10-19 20:30:32 --> Helper loaded: url_helper
INFO - 2016-10-19 20:30:32 --> Database Driver Class Initialized
INFO - 2016-10-19 20:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:30:32 --> Parser Class Initialized
INFO - 2016-10-19 20:30:32 --> Controller Class Initialized
DEBUG - 2016-10-19 20:30:32 --> Home MX_Controller Initialized
INFO - 2016-10-19 20:30:32 --> Model Class Initialized
DEBUG - 2016-10-19 20:30:32 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 20:30:32 --> Model Class Initialized
ERROR - 2016-10-19 20:30:32 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 20:30:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 20:30:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:30:32 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 20:30:32 --> Final output sent to browser
DEBUG - 2016-10-19 20:30:32 --> Total execution time: 0.0425
INFO - 2016-10-19 20:30:49 --> Config Class Initialized
INFO - 2016-10-19 20:30:49 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:30:49 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:30:49 --> Utf8 Class Initialized
INFO - 2016-10-19 20:30:49 --> URI Class Initialized
INFO - 2016-10-19 20:30:49 --> Router Class Initialized
INFO - 2016-10-19 20:30:49 --> Output Class Initialized
INFO - 2016-10-19 20:30:49 --> Security Class Initialized
DEBUG - 2016-10-19 20:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:30:49 --> Input Class Initialized
INFO - 2016-10-19 20:30:49 --> Language Class Initialized
INFO - 2016-10-19 20:30:49 --> Language Class Initialized
INFO - 2016-10-19 20:30:49 --> Config Class Initialized
INFO - 2016-10-19 20:30:49 --> Loader Class Initialized
INFO - 2016-10-19 20:30:49 --> Helper loaded: common_helper
INFO - 2016-10-19 20:30:49 --> Helper loaded: url_helper
INFO - 2016-10-19 20:30:49 --> Database Driver Class Initialized
INFO - 2016-10-19 20:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:30:49 --> Parser Class Initialized
INFO - 2016-10-19 20:30:49 --> Controller Class Initialized
DEBUG - 2016-10-19 20:30:49 --> Home MX_Controller Initialized
INFO - 2016-10-19 20:30:49 --> Model Class Initialized
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 20:30:49 --> Model Class Initialized
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-19 20:30:49 --> Content MX_Controller Initialized
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:30:49 --> Model Class Initialized
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 20:30:49 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 20:30:49 --> Model Class Initialized
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 20:30:49 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:30:49 --> Model Class Initialized
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-19 20:30:49 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:30:49 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 20:30:49 --> Final output sent to browser
DEBUG - 2016-10-19 20:30:49 --> Total execution time: 0.0579
INFO - 2016-10-19 20:30:49 --> Config Class Initialized
INFO - 2016-10-19 20:30:49 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:30:49 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:30:49 --> Utf8 Class Initialized
INFO - 2016-10-19 20:30:49 --> URI Class Initialized
INFO - 2016-10-19 20:30:49 --> Router Class Initialized
INFO - 2016-10-19 20:30:49 --> Output Class Initialized
INFO - 2016-10-19 20:30:49 --> Security Class Initialized
DEBUG - 2016-10-19 20:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:30:49 --> Input Class Initialized
INFO - 2016-10-19 20:30:49 --> Language Class Initialized
ERROR - 2016-10-19 20:30:49 --> 404 Page Not Found: /index
INFO - 2016-10-19 20:31:00 --> Config Class Initialized
INFO - 2016-10-19 20:31:00 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:31:00 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:31:00 --> Utf8 Class Initialized
INFO - 2016-10-19 20:31:00 --> URI Class Initialized
INFO - 2016-10-19 20:31:00 --> Router Class Initialized
INFO - 2016-10-19 20:31:00 --> Output Class Initialized
INFO - 2016-10-19 20:31:00 --> Security Class Initialized
DEBUG - 2016-10-19 20:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:31:00 --> Input Class Initialized
INFO - 2016-10-19 20:31:00 --> Language Class Initialized
INFO - 2016-10-19 20:31:00 --> Language Class Initialized
INFO - 2016-10-19 20:31:00 --> Config Class Initialized
INFO - 2016-10-19 20:31:00 --> Loader Class Initialized
INFO - 2016-10-19 20:31:00 --> Helper loaded: common_helper
INFO - 2016-10-19 20:31:00 --> Helper loaded: url_helper
INFO - 2016-10-19 20:31:00 --> Database Driver Class Initialized
INFO - 2016-10-19 20:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:31:00 --> Parser Class Initialized
INFO - 2016-10-19 20:31:00 --> Controller Class Initialized
DEBUG - 2016-10-19 20:31:00 --> User MX_Controller Initialized
INFO - 2016-10-19 20:31:00 --> Model Class Initialized
DEBUG - 2016-10-19 20:31:00 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-19 20:31:00 --> Model Class Initialized
INFO - 2016-10-19 20:31:00 --> Helper loaded: cookie_helper
INFO - 2016-10-19 20:31:00 --> Helper loaded: form_helper
DEBUG - 2016-10-19 20:31:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:31:00 --> Model Class Initialized
DEBUG - 2016-10-19 20:31:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:31:00 --> Model Class Initialized
INFO - 2016-10-19 20:31:00 --> Final output sent to browser
DEBUG - 2016-10-19 20:31:00 --> Total execution time: 0.0539
INFO - 2016-10-19 20:31:02 --> Config Class Initialized
INFO - 2016-10-19 20:31:02 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:31:02 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:31:02 --> Utf8 Class Initialized
INFO - 2016-10-19 20:31:02 --> URI Class Initialized
DEBUG - 2016-10-19 20:31:02 --> No URI present. Default controller set.
INFO - 2016-10-19 20:31:02 --> Router Class Initialized
INFO - 2016-10-19 20:31:02 --> Output Class Initialized
INFO - 2016-10-19 20:31:02 --> Security Class Initialized
DEBUG - 2016-10-19 20:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:31:02 --> Input Class Initialized
INFO - 2016-10-19 20:31:02 --> Language Class Initialized
INFO - 2016-10-19 20:31:02 --> Language Class Initialized
INFO - 2016-10-19 20:31:02 --> Config Class Initialized
INFO - 2016-10-19 20:31:02 --> Loader Class Initialized
INFO - 2016-10-19 20:31:02 --> Helper loaded: common_helper
INFO - 2016-10-19 20:31:02 --> Helper loaded: url_helper
INFO - 2016-10-19 20:31:02 --> Database Driver Class Initialized
INFO - 2016-10-19 20:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:31:02 --> Parser Class Initialized
INFO - 2016-10-19 20:31:02 --> Controller Class Initialized
DEBUG - 2016-10-19 20:31:02 --> Home MX_Controller Initialized
INFO - 2016-10-19 20:31:02 --> Model Class Initialized
DEBUG - 2016-10-19 20:31:02 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 20:31:02 --> Model Class Initialized
DEBUG - 2016-10-19 20:31:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-19 20:31:02 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 20:31:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 20:31:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:31:02 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 20:31:02 --> Final output sent to browser
DEBUG - 2016-10-19 20:31:02 --> Total execution time: 0.0439
INFO - 2016-10-19 20:31:06 --> Config Class Initialized
INFO - 2016-10-19 20:31:06 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:31:06 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:31:06 --> Utf8 Class Initialized
INFO - 2016-10-19 20:31:06 --> URI Class Initialized
INFO - 2016-10-19 20:31:06 --> Router Class Initialized
INFO - 2016-10-19 20:31:06 --> Output Class Initialized
INFO - 2016-10-19 20:31:06 --> Security Class Initialized
DEBUG - 2016-10-19 20:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:31:06 --> Input Class Initialized
INFO - 2016-10-19 20:31:06 --> Language Class Initialized
INFO - 2016-10-19 20:31:06 --> Language Class Initialized
INFO - 2016-10-19 20:31:06 --> Config Class Initialized
INFO - 2016-10-19 20:31:06 --> Loader Class Initialized
INFO - 2016-10-19 20:31:06 --> Helper loaded: common_helper
INFO - 2016-10-19 20:31:06 --> Helper loaded: url_helper
INFO - 2016-10-19 20:31:06 --> Database Driver Class Initialized
INFO - 2016-10-19 20:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:31:06 --> Parser Class Initialized
INFO - 2016-10-19 20:31:06 --> Controller Class Initialized
DEBUG - 2016-10-19 20:31:06 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:31:06 --> Model Class Initialized
DEBUG - 2016-10-19 20:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:31:06 --> Model Class Initialized
DEBUG - 2016-10-19 20:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:31:06 --> Model Class Initialized
DEBUG - 2016-10-19 20:31:06 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 20:31:06 --> Final output sent to browser
DEBUG - 2016-10-19 20:31:06 --> Total execution time: 0.0439
INFO - 2016-10-19 20:31:06 --> Config Class Initialized
INFO - 2016-10-19 20:31:06 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:31:06 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:31:06 --> Utf8 Class Initialized
INFO - 2016-10-19 20:31:06 --> URI Class Initialized
INFO - 2016-10-19 20:31:06 --> Router Class Initialized
INFO - 2016-10-19 20:31:06 --> Output Class Initialized
INFO - 2016-10-19 20:31:06 --> Security Class Initialized
DEBUG - 2016-10-19 20:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:31:06 --> Input Class Initialized
INFO - 2016-10-19 20:31:06 --> Language Class Initialized
INFO - 2016-10-19 20:31:06 --> Language Class Initialized
INFO - 2016-10-19 20:31:06 --> Config Class Initialized
INFO - 2016-10-19 20:31:06 --> Loader Class Initialized
INFO - 2016-10-19 20:31:06 --> Helper loaded: common_helper
INFO - 2016-10-19 20:31:06 --> Helper loaded: url_helper
INFO - 2016-10-19 20:31:06 --> Database Driver Class Initialized
INFO - 2016-10-19 20:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:31:06 --> Parser Class Initialized
INFO - 2016-10-19 20:31:06 --> Controller Class Initialized
DEBUG - 2016-10-19 20:31:06 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:31:06 --> Model Class Initialized
DEBUG - 2016-10-19 20:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:31:06 --> Model Class Initialized
DEBUG - 2016-10-19 20:31:06 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:31:06 --> Model Class Initialized
INFO - 2016-10-19 20:33:23 --> Config Class Initialized
INFO - 2016-10-19 20:33:23 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:23 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:23 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:23 --> URI Class Initialized
INFO - 2016-10-19 20:33:23 --> Router Class Initialized
INFO - 2016-10-19 20:33:23 --> Output Class Initialized
INFO - 2016-10-19 20:33:23 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:23 --> Input Class Initialized
INFO - 2016-10-19 20:33:23 --> Language Class Initialized
INFO - 2016-10-19 20:33:23 --> Language Class Initialized
INFO - 2016-10-19 20:33:23 --> Config Class Initialized
INFO - 2016-10-19 20:33:23 --> Loader Class Initialized
INFO - 2016-10-19 20:33:23 --> Helper loaded: common_helper
INFO - 2016-10-19 20:33:23 --> Helper loaded: url_helper
INFO - 2016-10-19 20:33:23 --> Database Driver Class Initialized
INFO - 2016-10-19 20:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:33:23 --> Parser Class Initialized
INFO - 2016-10-19 20:33:23 --> Controller Class Initialized
DEBUG - 2016-10-19 20:33:23 --> Home MX_Controller Initialized
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-19 20:33:23 --> Content MX_Controller Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 20:33:23 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 20:33:23 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-19 20:33:23 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 20:33:23 --> Final output sent to browser
DEBUG - 2016-10-19 20:33:23 --> Total execution time: 0.0571
INFO - 2016-10-19 20:33:23 --> Config Class Initialized
INFO - 2016-10-19 20:33:23 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:23 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:23 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:23 --> URI Class Initialized
INFO - 2016-10-19 20:33:23 --> Router Class Initialized
INFO - 2016-10-19 20:33:23 --> Output Class Initialized
INFO - 2016-10-19 20:33:23 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:23 --> Input Class Initialized
INFO - 2016-10-19 20:33:23 --> Language Class Initialized
INFO - 2016-10-19 20:33:23 --> Language Class Initialized
INFO - 2016-10-19 20:33:23 --> Config Class Initialized
INFO - 2016-10-19 20:33:23 --> Loader Class Initialized
INFO - 2016-10-19 20:33:23 --> Helper loaded: common_helper
INFO - 2016-10-19 20:33:23 --> Helper loaded: url_helper
INFO - 2016-10-19 20:33:23 --> Database Driver Class Initialized
INFO - 2016-10-19 20:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:33:23 --> Parser Class Initialized
INFO - 2016-10-19 20:33:23 --> Controller Class Initialized
DEBUG - 2016-10-19 20:33:23 --> Home MX_Controller Initialized
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-19 20:33:23 --> Content MX_Controller Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 20:33:23 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 20:33:23 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:33:23 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
ERROR - 2016-10-19 20:33:23 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:33:23 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 20:33:23 --> Final output sent to browser
DEBUG - 2016-10-19 20:33:23 --> Total execution time: 0.0567
INFO - 2016-10-19 20:33:23 --> Config Class Initialized
INFO - 2016-10-19 20:33:23 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:23 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:23 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:23 --> URI Class Initialized
INFO - 2016-10-19 20:33:23 --> Router Class Initialized
INFO - 2016-10-19 20:33:23 --> Output Class Initialized
INFO - 2016-10-19 20:33:23 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:23 --> Input Class Initialized
INFO - 2016-10-19 20:33:23 --> Language Class Initialized
ERROR - 2016-10-19 20:33:23 --> 404 Page Not Found: /index
INFO - 2016-10-19 20:33:33 --> Config Class Initialized
INFO - 2016-10-19 20:33:33 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:33 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:33 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:33 --> URI Class Initialized
INFO - 2016-10-19 20:33:33 --> Router Class Initialized
INFO - 2016-10-19 20:33:33 --> Output Class Initialized
INFO - 2016-10-19 20:33:33 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:33 --> Input Class Initialized
INFO - 2016-10-19 20:33:33 --> Language Class Initialized
INFO - 2016-10-19 20:33:33 --> Language Class Initialized
INFO - 2016-10-19 20:33:33 --> Config Class Initialized
INFO - 2016-10-19 20:33:33 --> Loader Class Initialized
INFO - 2016-10-19 20:33:33 --> Helper loaded: common_helper
INFO - 2016-10-19 20:33:33 --> Helper loaded: url_helper
INFO - 2016-10-19 20:33:33 --> Database Driver Class Initialized
INFO - 2016-10-19 20:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:33:33 --> Parser Class Initialized
INFO - 2016-10-19 20:33:33 --> Controller Class Initialized
DEBUG - 2016-10-19 20:33:33 --> User MX_Controller Initialized
INFO - 2016-10-19 20:33:33 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:33 --> File loaded: /home/dolongpk/public_html/application/modules/user/models/User_model.php
INFO - 2016-10-19 20:33:33 --> Model Class Initialized
INFO - 2016-10-19 20:33:33 --> Helper loaded: cookie_helper
INFO - 2016-10-19 20:33:33 --> Helper loaded: form_helper
DEBUG - 2016-10-19 20:33:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:33:33 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:33 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:33:33 --> Model Class Initialized
INFO - 2016-10-19 20:33:33 --> Final output sent to browser
DEBUG - 2016-10-19 20:33:33 --> Total execution time: 0.0479
INFO - 2016-10-19 20:33:35 --> Config Class Initialized
INFO - 2016-10-19 20:33:35 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:35 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:35 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:35 --> URI Class Initialized
DEBUG - 2016-10-19 20:33:35 --> No URI present. Default controller set.
INFO - 2016-10-19 20:33:35 --> Router Class Initialized
INFO - 2016-10-19 20:33:35 --> Output Class Initialized
INFO - 2016-10-19 20:33:35 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:35 --> Input Class Initialized
INFO - 2016-10-19 20:33:35 --> Language Class Initialized
INFO - 2016-10-19 20:33:35 --> Language Class Initialized
INFO - 2016-10-19 20:33:35 --> Config Class Initialized
INFO - 2016-10-19 20:33:35 --> Loader Class Initialized
INFO - 2016-10-19 20:33:35 --> Helper loaded: common_helper
INFO - 2016-10-19 20:33:35 --> Helper loaded: url_helper
INFO - 2016-10-19 20:33:35 --> Database Driver Class Initialized
INFO - 2016-10-19 20:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:33:35 --> Parser Class Initialized
INFO - 2016-10-19 20:33:35 --> Controller Class Initialized
DEBUG - 2016-10-19 20:33:35 --> Home MX_Controller Initialized
INFO - 2016-10-19 20:33:35 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:35 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 20:33:35 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-19 20:33:35 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 20:33:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 20:33:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:33:35 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 20:33:35 --> Final output sent to browser
DEBUG - 2016-10-19 20:33:35 --> Total execution time: 0.0562
INFO - 2016-10-19 20:33:45 --> Config Class Initialized
INFO - 2016-10-19 20:33:45 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:45 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:45 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:45 --> URI Class Initialized
INFO - 2016-10-19 20:33:45 --> Router Class Initialized
INFO - 2016-10-19 20:33:45 --> Output Class Initialized
INFO - 2016-10-19 20:33:45 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:45 --> Input Class Initialized
INFO - 2016-10-19 20:33:45 --> Language Class Initialized
INFO - 2016-10-19 20:33:45 --> Language Class Initialized
INFO - 2016-10-19 20:33:45 --> Config Class Initialized
INFO - 2016-10-19 20:33:45 --> Loader Class Initialized
INFO - 2016-10-19 20:33:45 --> Helper loaded: common_helper
INFO - 2016-10-19 20:33:45 --> Helper loaded: url_helper
INFO - 2016-10-19 20:33:45 --> Database Driver Class Initialized
INFO - 2016-10-19 20:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:33:45 --> Parser Class Initialized
INFO - 2016-10-19 20:33:45 --> Controller Class Initialized
DEBUG - 2016-10-19 20:33:45 --> Home MX_Controller Initialized
INFO - 2016-10-19 20:33:45 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 20:33:45 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/content/controllers/Content.php
DEBUG - 2016-10-19 20:33:45 --> Content MX_Controller Initialized
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:33:45 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/modules/content/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/modules/home/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/slider/controllers/Slider.php
DEBUG - 2016-10-19 20:33:45 --> Slider MX_Controller Initialized
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/modules/slider/models/Slider_model.php
INFO - 2016-10-19 20:33:45 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/modules/slider/views/FRONTEND/index.php
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/controllers/../modules/servers/controllers/Servers.php
DEBUG - 2016-10-19 20:33:45 --> Servers MX_Controller Initialized
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:33:45 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/listServer.php
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-19 20:33:45 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:33:45 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template.php
INFO - 2016-10-19 20:33:45 --> Final output sent to browser
DEBUG - 2016-10-19 20:33:45 --> Total execution time: 0.0581
INFO - 2016-10-19 20:33:45 --> Config Class Initialized
INFO - 2016-10-19 20:33:45 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:45 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:45 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:45 --> URI Class Initialized
INFO - 2016-10-19 20:33:45 --> Router Class Initialized
INFO - 2016-10-19 20:33:45 --> Output Class Initialized
INFO - 2016-10-19 20:33:45 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:45 --> Input Class Initialized
INFO - 2016-10-19 20:33:45 --> Language Class Initialized
ERROR - 2016-10-19 20:33:45 --> 404 Page Not Found: /index
INFO - 2016-10-19 20:33:58 --> Config Class Initialized
INFO - 2016-10-19 20:33:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:58 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:58 --> URI Class Initialized
INFO - 2016-10-19 20:33:58 --> Config Class Initialized
INFO - 2016-10-19 20:33:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:58 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:58 --> Router Class Initialized
INFO - 2016-10-19 20:33:58 --> Output Class Initialized
INFO - 2016-10-19 20:33:58 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:58 --> Input Class Initialized
INFO - 2016-10-19 20:33:58 --> Language Class Initialized
INFO - 2016-10-19 20:33:58 --> Language Class Initialized
INFO - 2016-10-19 20:33:58 --> URI Class Initialized
INFO - 2016-10-19 20:33:58 --> Router Class Initialized
INFO - 2016-10-19 20:33:58 --> Output Class Initialized
INFO - 2016-10-19 20:33:58 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:58 --> Input Class Initialized
INFO - 2016-10-19 20:33:58 --> Language Class Initialized
INFO - 2016-10-19 20:33:58 --> Config Class Initialized
INFO - 2016-10-19 20:33:58 --> Loader Class Initialized
INFO - 2016-10-19 20:33:58 --> Language Class Initialized
INFO - 2016-10-19 20:33:58 --> Config Class Initialized
INFO - 2016-10-19 20:33:58 --> Loader Class Initialized
INFO - 2016-10-19 20:33:58 --> Helper loaded: common_helper
INFO - 2016-10-19 20:33:58 --> Helper loaded: url_helper
INFO - 2016-10-19 20:33:58 --> Helper loaded: common_helper
INFO - 2016-10-19 20:33:58 --> Helper loaded: url_helper
INFO - 2016-10-19 20:33:58 --> Database Driver Class Initialized
INFO - 2016-10-19 20:33:58 --> Database Driver Class Initialized
INFO - 2016-10-19 20:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:33:58 --> Parser Class Initialized
INFO - 2016-10-19 20:33:58 --> Controller Class Initialized
DEBUG - 2016-10-19 20:33:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
INFO - 2016-10-19 20:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:33:58 --> Parser Class Initialized
INFO - 2016-10-19 20:33:58 --> Controller Class Initialized
DEBUG - 2016-10-19 20:33:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 20:33:58 --> Final output sent to browser
DEBUG - 2016-10-19 20:33:58 --> Total execution time: 0.1024
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 20:33:58 --> Final output sent to browser
DEBUG - 2016-10-19 20:33:58 --> Total execution time: 0.0929
INFO - 2016-10-19 20:33:58 --> Config Class Initialized
INFO - 2016-10-19 20:33:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:58 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:58 --> URI Class Initialized
INFO - 2016-10-19 20:33:58 --> Router Class Initialized
INFO - 2016-10-19 20:33:58 --> Output Class Initialized
INFO - 2016-10-19 20:33:58 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:58 --> Input Class Initialized
INFO - 2016-10-19 20:33:58 --> Language Class Initialized
INFO - 2016-10-19 20:33:58 --> Language Class Initialized
INFO - 2016-10-19 20:33:58 --> Config Class Initialized
INFO - 2016-10-19 20:33:58 --> Loader Class Initialized
INFO - 2016-10-19 20:33:58 --> Helper loaded: common_helper
INFO - 2016-10-19 20:33:58 --> Helper loaded: url_helper
INFO - 2016-10-19 20:33:58 --> Database Driver Class Initialized
INFO - 2016-10-19 20:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:33:58 --> Parser Class Initialized
INFO - 2016-10-19 20:33:58 --> Controller Class Initialized
DEBUG - 2016-10-19 20:33:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
INFO - 2016-10-19 20:33:58 --> Config Class Initialized
INFO - 2016-10-19 20:33:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:33:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:33:58 --> Utf8 Class Initialized
INFO - 2016-10-19 20:33:58 --> URI Class Initialized
INFO - 2016-10-19 20:33:58 --> Router Class Initialized
INFO - 2016-10-19 20:33:58 --> Output Class Initialized
INFO - 2016-10-19 20:33:58 --> Security Class Initialized
DEBUG - 2016-10-19 20:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:33:58 --> Input Class Initialized
INFO - 2016-10-19 20:33:58 --> Language Class Initialized
INFO - 2016-10-19 20:33:58 --> Language Class Initialized
INFO - 2016-10-19 20:33:58 --> Config Class Initialized
INFO - 2016-10-19 20:33:58 --> Loader Class Initialized
INFO - 2016-10-19 20:33:58 --> Helper loaded: common_helper
INFO - 2016-10-19 20:33:58 --> Helper loaded: url_helper
INFO - 2016-10-19 20:33:58 --> Database Driver Class Initialized
INFO - 2016-10-19 20:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:33:58 --> Parser Class Initialized
INFO - 2016-10-19 20:33:58 --> Controller Class Initialized
DEBUG - 2016-10-19 20:33:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:33:58 --> Model Class Initialized
INFO - 2016-10-19 20:37:05 --> Config Class Initialized
INFO - 2016-10-19 20:37:05 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:37:05 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:37:05 --> Utf8 Class Initialized
INFO - 2016-10-19 20:37:05 --> URI Class Initialized
INFO - 2016-10-19 20:37:05 --> Router Class Initialized
INFO - 2016-10-19 20:37:05 --> Output Class Initialized
INFO - 2016-10-19 20:37:05 --> Security Class Initialized
DEBUG - 2016-10-19 20:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:37:05 --> Input Class Initialized
INFO - 2016-10-19 20:37:05 --> Language Class Initialized
INFO - 2016-10-19 20:37:05 --> Language Class Initialized
INFO - 2016-10-19 20:37:05 --> Config Class Initialized
INFO - 2016-10-19 20:37:05 --> Loader Class Initialized
INFO - 2016-10-19 20:37:05 --> Helper loaded: common_helper
INFO - 2016-10-19 20:37:05 --> Helper loaded: url_helper
INFO - 2016-10-19 20:37:05 --> Database Driver Class Initialized
INFO - 2016-10-19 20:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:37:05 --> Parser Class Initialized
INFO - 2016-10-19 20:37:05 --> Controller Class Initialized
DEBUG - 2016-10-19 20:37:05 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:37:05 --> Model Class Initialized
DEBUG - 2016-10-19 20:37:05 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:37:05 --> Model Class Initialized
DEBUG - 2016-10-19 20:37:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:37:05 --> Model Class Initialized
DEBUG - 2016-10-19 20:37:05 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:37:05 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 20:37:05 --> Final output sent to browser
DEBUG - 2016-10-19 20:37:05 --> Total execution time: 0.0592
INFO - 2016-10-19 20:37:05 --> Config Class Initialized
INFO - 2016-10-19 20:37:05 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:37:05 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:37:05 --> Utf8 Class Initialized
INFO - 2016-10-19 20:37:05 --> URI Class Initialized
INFO - 2016-10-19 20:37:05 --> Router Class Initialized
INFO - 2016-10-19 20:37:05 --> Output Class Initialized
INFO - 2016-10-19 20:37:05 --> Security Class Initialized
DEBUG - 2016-10-19 20:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:37:05 --> Input Class Initialized
INFO - 2016-10-19 20:37:05 --> Language Class Initialized
INFO - 2016-10-19 20:37:05 --> Language Class Initialized
INFO - 2016-10-19 20:37:05 --> Config Class Initialized
INFO - 2016-10-19 20:37:05 --> Loader Class Initialized
INFO - 2016-10-19 20:37:05 --> Helper loaded: common_helper
INFO - 2016-10-19 20:37:05 --> Helper loaded: url_helper
INFO - 2016-10-19 20:37:05 --> Database Driver Class Initialized
INFO - 2016-10-19 20:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:37:05 --> Parser Class Initialized
INFO - 2016-10-19 20:37:05 --> Controller Class Initialized
DEBUG - 2016-10-19 20:37:05 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:37:05 --> Model Class Initialized
DEBUG - 2016-10-19 20:37:05 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:37:05 --> Model Class Initialized
DEBUG - 2016-10-19 20:37:05 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:37:05 --> Model Class Initialized
INFO - 2016-10-19 20:37:18 --> Config Class Initialized
INFO - 2016-10-19 20:37:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:37:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:37:18 --> Utf8 Class Initialized
INFO - 2016-10-19 20:37:18 --> URI Class Initialized
INFO - 2016-10-19 20:37:18 --> Router Class Initialized
INFO - 2016-10-19 20:37:18 --> Output Class Initialized
INFO - 2016-10-19 20:37:18 --> Security Class Initialized
DEBUG - 2016-10-19 20:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:37:18 --> Input Class Initialized
INFO - 2016-10-19 20:37:18 --> Language Class Initialized
INFO - 2016-10-19 20:37:18 --> Language Class Initialized
INFO - 2016-10-19 20:37:18 --> Config Class Initialized
INFO - 2016-10-19 20:37:18 --> Loader Class Initialized
INFO - 2016-10-19 20:37:18 --> Helper loaded: common_helper
INFO - 2016-10-19 20:37:18 --> Helper loaded: url_helper
INFO - 2016-10-19 20:37:18 --> Database Driver Class Initialized
INFO - 2016-10-19 20:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:37:18 --> Parser Class Initialized
INFO - 2016-10-19 20:37:18 --> Controller Class Initialized
DEBUG - 2016-10-19 20:37:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:37:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:37:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:37:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:37:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:37:18 --> Model Class Initialized
INFO - 2016-10-19 20:40:25 --> Config Class Initialized
INFO - 2016-10-19 20:40:25 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:40:25 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:40:25 --> Utf8 Class Initialized
INFO - 2016-10-19 20:40:25 --> URI Class Initialized
INFO - 2016-10-19 20:40:25 --> Router Class Initialized
INFO - 2016-10-19 20:40:25 --> Output Class Initialized
INFO - 2016-10-19 20:40:25 --> Security Class Initialized
DEBUG - 2016-10-19 20:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:40:25 --> Input Class Initialized
INFO - 2016-10-19 20:40:25 --> Language Class Initialized
INFO - 2016-10-19 20:40:25 --> Language Class Initialized
INFO - 2016-10-19 20:40:25 --> Config Class Initialized
INFO - 2016-10-19 20:40:25 --> Loader Class Initialized
INFO - 2016-10-19 20:40:25 --> Helper loaded: common_helper
INFO - 2016-10-19 20:40:25 --> Helper loaded: url_helper
INFO - 2016-10-19 20:40:25 --> Database Driver Class Initialized
INFO - 2016-10-19 20:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:40:25 --> Parser Class Initialized
INFO - 2016-10-19 20:40:25 --> Controller Class Initialized
DEBUG - 2016-10-19 20:40:25 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:40:25 --> Model Class Initialized
DEBUG - 2016-10-19 20:40:25 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:40:25 --> Model Class Initialized
DEBUG - 2016-10-19 20:40:25 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:40:25 --> Model Class Initialized
INFO - 2016-10-19 20:40:38 --> Config Class Initialized
INFO - 2016-10-19 20:40:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:40:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:40:38 --> Utf8 Class Initialized
INFO - 2016-10-19 20:40:38 --> URI Class Initialized
INFO - 2016-10-19 20:40:38 --> Router Class Initialized
INFO - 2016-10-19 20:40:38 --> Output Class Initialized
INFO - 2016-10-19 20:40:38 --> Security Class Initialized
DEBUG - 2016-10-19 20:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:40:38 --> Input Class Initialized
INFO - 2016-10-19 20:40:38 --> Language Class Initialized
INFO - 2016-10-19 20:40:38 --> Language Class Initialized
INFO - 2016-10-19 20:40:38 --> Config Class Initialized
INFO - 2016-10-19 20:40:38 --> Loader Class Initialized
INFO - 2016-10-19 20:40:38 --> Helper loaded: common_helper
INFO - 2016-10-19 20:40:38 --> Helper loaded: url_helper
INFO - 2016-10-19 20:40:38 --> Database Driver Class Initialized
INFO - 2016-10-19 20:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:40:38 --> Parser Class Initialized
INFO - 2016-10-19 20:40:38 --> Controller Class Initialized
DEBUG - 2016-10-19 20:40:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:40:38 --> Model Class Initialized
DEBUG - 2016-10-19 20:40:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:40:38 --> Model Class Initialized
DEBUG - 2016-10-19 20:40:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:40:38 --> Model Class Initialized
INFO - 2016-10-19 20:43:45 --> Config Class Initialized
INFO - 2016-10-19 20:43:45 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:43:45 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:43:45 --> Utf8 Class Initialized
INFO - 2016-10-19 20:43:45 --> URI Class Initialized
INFO - 2016-10-19 20:43:45 --> Router Class Initialized
INFO - 2016-10-19 20:43:45 --> Output Class Initialized
INFO - 2016-10-19 20:43:45 --> Security Class Initialized
DEBUG - 2016-10-19 20:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:43:45 --> Input Class Initialized
INFO - 2016-10-19 20:43:45 --> Language Class Initialized
INFO - 2016-10-19 20:43:45 --> Language Class Initialized
INFO - 2016-10-19 20:43:45 --> Config Class Initialized
INFO - 2016-10-19 20:43:45 --> Loader Class Initialized
INFO - 2016-10-19 20:43:45 --> Helper loaded: common_helper
INFO - 2016-10-19 20:43:45 --> Helper loaded: url_helper
INFO - 2016-10-19 20:43:45 --> Database Driver Class Initialized
INFO - 2016-10-19 20:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:43:45 --> Parser Class Initialized
INFO - 2016-10-19 20:43:45 --> Controller Class Initialized
DEBUG - 2016-10-19 20:43:45 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:43:45 --> Model Class Initialized
DEBUG - 2016-10-19 20:43:45 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:43:45 --> Model Class Initialized
DEBUG - 2016-10-19 20:43:45 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:43:45 --> Model Class Initialized
INFO - 2016-10-19 20:43:58 --> Config Class Initialized
INFO - 2016-10-19 20:43:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:43:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:43:58 --> Utf8 Class Initialized
INFO - 2016-10-19 20:43:58 --> URI Class Initialized
INFO - 2016-10-19 20:43:58 --> Router Class Initialized
INFO - 2016-10-19 20:43:58 --> Output Class Initialized
INFO - 2016-10-19 20:43:58 --> Security Class Initialized
DEBUG - 2016-10-19 20:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:43:58 --> Input Class Initialized
INFO - 2016-10-19 20:43:58 --> Language Class Initialized
INFO - 2016-10-19 20:43:58 --> Language Class Initialized
INFO - 2016-10-19 20:43:58 --> Config Class Initialized
INFO - 2016-10-19 20:43:58 --> Loader Class Initialized
INFO - 2016-10-19 20:43:58 --> Helper loaded: common_helper
INFO - 2016-10-19 20:43:58 --> Helper loaded: url_helper
INFO - 2016-10-19 20:43:58 --> Database Driver Class Initialized
INFO - 2016-10-19 20:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:43:58 --> Parser Class Initialized
INFO - 2016-10-19 20:43:58 --> Controller Class Initialized
DEBUG - 2016-10-19 20:43:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:43:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:43:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:43:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:43:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:43:58 --> Model Class Initialized
INFO - 2016-10-19 20:44:39 --> Config Class Initialized
INFO - 2016-10-19 20:44:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:44:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:44:39 --> Utf8 Class Initialized
INFO - 2016-10-19 20:44:39 --> URI Class Initialized
INFO - 2016-10-19 20:44:39 --> Router Class Initialized
INFO - 2016-10-19 20:44:39 --> Output Class Initialized
INFO - 2016-10-19 20:44:39 --> Security Class Initialized
DEBUG - 2016-10-19 20:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:44:39 --> Input Class Initialized
INFO - 2016-10-19 20:44:39 --> Language Class Initialized
INFO - 2016-10-19 20:44:39 --> Language Class Initialized
INFO - 2016-10-19 20:44:39 --> Config Class Initialized
INFO - 2016-10-19 20:44:39 --> Loader Class Initialized
INFO - 2016-10-19 20:44:39 --> Helper loaded: common_helper
INFO - 2016-10-19 20:44:39 --> Helper loaded: url_helper
INFO - 2016-10-19 20:44:39 --> Database Driver Class Initialized
INFO - 2016-10-19 20:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:44:39 --> Parser Class Initialized
INFO - 2016-10-19 20:44:39 --> Controller Class Initialized
DEBUG - 2016-10-19 20:44:39 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:44:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:44:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:44:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:44:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:44:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:44:39 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:44:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 20:44:39 --> Final output sent to browser
DEBUG - 2016-10-19 20:44:39 --> Total execution time: 0.0467
INFO - 2016-10-19 20:44:39 --> Config Class Initialized
INFO - 2016-10-19 20:44:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:44:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:44:39 --> Utf8 Class Initialized
INFO - 2016-10-19 20:44:39 --> URI Class Initialized
INFO - 2016-10-19 20:44:39 --> Router Class Initialized
INFO - 2016-10-19 20:44:39 --> Output Class Initialized
INFO - 2016-10-19 20:44:39 --> Security Class Initialized
DEBUG - 2016-10-19 20:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:44:39 --> Input Class Initialized
INFO - 2016-10-19 20:44:39 --> Language Class Initialized
INFO - 2016-10-19 20:44:39 --> Language Class Initialized
INFO - 2016-10-19 20:44:39 --> Config Class Initialized
INFO - 2016-10-19 20:44:39 --> Loader Class Initialized
INFO - 2016-10-19 20:44:39 --> Helper loaded: common_helper
INFO - 2016-10-19 20:44:39 --> Helper loaded: url_helper
INFO - 2016-10-19 20:44:39 --> Database Driver Class Initialized
INFO - 2016-10-19 20:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:44:39 --> Parser Class Initialized
INFO - 2016-10-19 20:44:39 --> Controller Class Initialized
DEBUG - 2016-10-19 20:44:39 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:44:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:44:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:44:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:44:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:44:39 --> Model Class Initialized
INFO - 2016-10-19 20:47:18 --> Config Class Initialized
INFO - 2016-10-19 20:47:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:47:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:47:18 --> Utf8 Class Initialized
INFO - 2016-10-19 20:47:18 --> URI Class Initialized
INFO - 2016-10-19 20:47:18 --> Router Class Initialized
INFO - 2016-10-19 20:47:18 --> Output Class Initialized
INFO - 2016-10-19 20:47:18 --> Security Class Initialized
DEBUG - 2016-10-19 20:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:47:18 --> Input Class Initialized
INFO - 2016-10-19 20:47:18 --> Language Class Initialized
INFO - 2016-10-19 20:47:18 --> Language Class Initialized
INFO - 2016-10-19 20:47:18 --> Config Class Initialized
INFO - 2016-10-19 20:47:18 --> Loader Class Initialized
INFO - 2016-10-19 20:47:18 --> Helper loaded: common_helper
INFO - 2016-10-19 20:47:18 --> Helper loaded: url_helper
INFO - 2016-10-19 20:47:18 --> Database Driver Class Initialized
INFO - 2016-10-19 20:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:47:18 --> Parser Class Initialized
INFO - 2016-10-19 20:47:18 --> Controller Class Initialized
DEBUG - 2016-10-19 20:47:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:47:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:47:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:47:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:47:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:47:18 --> Model Class Initialized
INFO - 2016-10-19 20:48:00 --> Config Class Initialized
INFO - 2016-10-19 20:48:00 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:48:00 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:48:00 --> Utf8 Class Initialized
INFO - 2016-10-19 20:48:00 --> URI Class Initialized
INFO - 2016-10-19 20:48:00 --> Router Class Initialized
INFO - 2016-10-19 20:48:00 --> Output Class Initialized
INFO - 2016-10-19 20:48:00 --> Security Class Initialized
DEBUG - 2016-10-19 20:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:48:00 --> Input Class Initialized
INFO - 2016-10-19 20:48:00 --> Language Class Initialized
INFO - 2016-10-19 20:48:00 --> Language Class Initialized
INFO - 2016-10-19 20:48:00 --> Config Class Initialized
INFO - 2016-10-19 20:48:00 --> Loader Class Initialized
INFO - 2016-10-19 20:48:00 --> Helper loaded: common_helper
INFO - 2016-10-19 20:48:00 --> Helper loaded: url_helper
INFO - 2016-10-19 20:48:00 --> Database Driver Class Initialized
INFO - 2016-10-19 20:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:48:00 --> Parser Class Initialized
INFO - 2016-10-19 20:48:00 --> Controller Class Initialized
DEBUG - 2016-10-19 20:48:00 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:48:00 --> Model Class Initialized
DEBUG - 2016-10-19 20:48:00 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:48:00 --> Model Class Initialized
DEBUG - 2016-10-19 20:48:00 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:48:00 --> Model Class Initialized
INFO - 2016-10-19 20:50:39 --> Config Class Initialized
INFO - 2016-10-19 20:50:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:50:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:50:39 --> Utf8 Class Initialized
INFO - 2016-10-19 20:50:39 --> URI Class Initialized
INFO - 2016-10-19 20:50:39 --> Router Class Initialized
INFO - 2016-10-19 20:50:39 --> Output Class Initialized
INFO - 2016-10-19 20:50:39 --> Security Class Initialized
DEBUG - 2016-10-19 20:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:50:39 --> Input Class Initialized
INFO - 2016-10-19 20:50:39 --> Language Class Initialized
INFO - 2016-10-19 20:50:39 --> Language Class Initialized
INFO - 2016-10-19 20:50:39 --> Config Class Initialized
INFO - 2016-10-19 20:50:39 --> Loader Class Initialized
INFO - 2016-10-19 20:50:39 --> Helper loaded: common_helper
INFO - 2016-10-19 20:50:39 --> Helper loaded: url_helper
INFO - 2016-10-19 20:50:39 --> Database Driver Class Initialized
INFO - 2016-10-19 20:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:50:39 --> Parser Class Initialized
INFO - 2016-10-19 20:50:39 --> Controller Class Initialized
DEBUG - 2016-10-19 20:50:39 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:50:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:50:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:50:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:50:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:50:39 --> Model Class Initialized
INFO - 2016-10-19 20:51:20 --> Config Class Initialized
INFO - 2016-10-19 20:51:20 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:51:20 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:51:20 --> Utf8 Class Initialized
INFO - 2016-10-19 20:51:20 --> URI Class Initialized
INFO - 2016-10-19 20:51:20 --> Router Class Initialized
INFO - 2016-10-19 20:51:20 --> Output Class Initialized
INFO - 2016-10-19 20:51:20 --> Security Class Initialized
DEBUG - 2016-10-19 20:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:51:20 --> Input Class Initialized
INFO - 2016-10-19 20:51:20 --> Language Class Initialized
INFO - 2016-10-19 20:51:20 --> Language Class Initialized
INFO - 2016-10-19 20:51:20 --> Config Class Initialized
INFO - 2016-10-19 20:51:20 --> Loader Class Initialized
INFO - 2016-10-19 20:51:20 --> Helper loaded: common_helper
INFO - 2016-10-19 20:51:20 --> Helper loaded: url_helper
INFO - 2016-10-19 20:51:20 --> Database Driver Class Initialized
INFO - 2016-10-19 20:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:51:20 --> Parser Class Initialized
INFO - 2016-10-19 20:51:20 --> Controller Class Initialized
DEBUG - 2016-10-19 20:51:20 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:51:20 --> Model Class Initialized
DEBUG - 2016-10-19 20:51:20 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:51:20 --> Model Class Initialized
DEBUG - 2016-10-19 20:51:20 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:51:20 --> Model Class Initialized
INFO - 2016-10-19 20:51:25 --> Config Class Initialized
INFO - 2016-10-19 20:51:25 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:51:25 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:51:25 --> Utf8 Class Initialized
INFO - 2016-10-19 20:51:25 --> URI Class Initialized
INFO - 2016-10-19 20:51:25 --> Router Class Initialized
INFO - 2016-10-19 20:51:25 --> Output Class Initialized
INFO - 2016-10-19 20:51:25 --> Security Class Initialized
DEBUG - 2016-10-19 20:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:51:25 --> Input Class Initialized
INFO - 2016-10-19 20:51:25 --> Language Class Initialized
ERROR - 2016-10-19 20:51:25 --> 404 Page Not Found: /index
INFO - 2016-10-19 20:52:31 --> Config Class Initialized
INFO - 2016-10-19 20:52:31 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:31 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:31 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:31 --> URI Class Initialized
INFO - 2016-10-19 20:52:31 --> Router Class Initialized
INFO - 2016-10-19 20:52:31 --> Output Class Initialized
INFO - 2016-10-19 20:52:31 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:31 --> Input Class Initialized
INFO - 2016-10-19 20:52:31 --> Language Class Initialized
INFO - 2016-10-19 20:52:31 --> Language Class Initialized
INFO - 2016-10-19 20:52:31 --> Config Class Initialized
INFO - 2016-10-19 20:52:31 --> Loader Class Initialized
INFO - 2016-10-19 20:52:31 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:31 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:31 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:31 --> Parser Class Initialized
INFO - 2016-10-19 20:52:31 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:31 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 20:52:31 --> Config Class Initialized
INFO - 2016-10-19 20:52:31 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:31 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:31 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:31 --> URI Class Initialized
INFO - 2016-10-19 20:52:31 --> Router Class Initialized
INFO - 2016-10-19 20:52:31 --> Output Class Initialized
INFO - 2016-10-19 20:52:31 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:31 --> Input Class Initialized
INFO - 2016-10-19 20:52:31 --> Language Class Initialized
INFO - 2016-10-19 20:52:31 --> Language Class Initialized
INFO - 2016-10-19 20:52:31 --> Config Class Initialized
INFO - 2016-10-19 20:52:31 --> Loader Class Initialized
INFO - 2016-10-19 20:52:31 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:31 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:31 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:31 --> Parser Class Initialized
INFO - 2016-10-19 20:52:31 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:31 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 20:52:31 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:31 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:52:31 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:31 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/login.php
INFO - 2016-10-19 20:52:31 --> Final output sent to browser
DEBUG - 2016-10-19 20:52:31 --> Total execution time: 0.0332
INFO - 2016-10-19 20:52:32 --> Config Class Initialized
INFO - 2016-10-19 20:52:32 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:32 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:32 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:32 --> URI Class Initialized
INFO - 2016-10-19 20:52:32 --> Router Class Initialized
INFO - 2016-10-19 20:52:32 --> Output Class Initialized
INFO - 2016-10-19 20:52:32 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:32 --> Input Class Initialized
INFO - 2016-10-19 20:52:32 --> Language Class Initialized
INFO - 2016-10-19 20:52:32 --> Language Class Initialized
INFO - 2016-10-19 20:52:32 --> Config Class Initialized
INFO - 2016-10-19 20:52:32 --> Loader Class Initialized
INFO - 2016-10-19 20:52:32 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:32 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:32 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:32 --> Parser Class Initialized
INFO - 2016-10-19 20:52:32 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:32 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 20:52:32 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:52:32 --> Model Class Initialized
INFO - 2016-10-19 20:52:32 --> Final output sent to browser
DEBUG - 2016-10-19 20:52:32 --> Total execution time: 0.0363
INFO - 2016-10-19 20:52:32 --> Config Class Initialized
INFO - 2016-10-19 20:52:32 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:32 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:32 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:32 --> URI Class Initialized
INFO - 2016-10-19 20:52:32 --> Router Class Initialized
INFO - 2016-10-19 20:52:32 --> Output Class Initialized
INFO - 2016-10-19 20:52:32 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:32 --> Input Class Initialized
INFO - 2016-10-19 20:52:32 --> Language Class Initialized
INFO - 2016-10-19 20:52:32 --> Language Class Initialized
INFO - 2016-10-19 20:52:32 --> Config Class Initialized
INFO - 2016-10-19 20:52:32 --> Loader Class Initialized
INFO - 2016-10-19 20:52:32 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:32 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:32 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:32 --> Parser Class Initialized
INFO - 2016-10-19 20:52:32 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:32 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 20:52:32 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:52:32 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/index.php
DEBUG - 2016-10-19 20:52:32 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:52:32 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-19 20:52:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:52:32 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-19 20:52:32 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:32 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-19 20:52:32 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-19 20:52:32 --> Final output sent to browser
DEBUG - 2016-10-19 20:52:32 --> Total execution time: 0.0560
INFO - 2016-10-19 20:52:33 --> Config Class Initialized
INFO - 2016-10-19 20:52:33 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:33 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:33 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:33 --> URI Class Initialized
INFO - 2016-10-19 20:52:33 --> Router Class Initialized
INFO - 2016-10-19 20:52:33 --> Output Class Initialized
INFO - 2016-10-19 20:52:33 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:33 --> Input Class Initialized
INFO - 2016-10-19 20:52:33 --> Language Class Initialized
ERROR - 2016-10-19 20:52:33 --> 404 Page Not Found: /index
INFO - 2016-10-19 20:52:35 --> Config Class Initialized
INFO - 2016-10-19 20:52:35 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:35 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:35 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:35 --> URI Class Initialized
INFO - 2016-10-19 20:52:35 --> Router Class Initialized
INFO - 2016-10-19 20:52:35 --> Output Class Initialized
INFO - 2016-10-19 20:52:35 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:35 --> Input Class Initialized
INFO - 2016-10-19 20:52:35 --> Language Class Initialized
INFO - 2016-10-19 20:52:35 --> Language Class Initialized
INFO - 2016-10-19 20:52:35 --> Config Class Initialized
INFO - 2016-10-19 20:52:35 --> Loader Class Initialized
INFO - 2016-10-19 20:52:35 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:35 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:35 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:35 --> Parser Class Initialized
INFO - 2016-10-19 20:52:35 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:35 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 20:52:35 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:35 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 20:52:35 --> Model Class Initialized
INFO - 2016-10-19 20:52:35 --> Config Class Initialized
INFO - 2016-10-19 20:52:35 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:35 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:35 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:35 --> URI Class Initialized
INFO - 2016-10-19 20:52:35 --> Router Class Initialized
INFO - 2016-10-19 20:52:35 --> Output Class Initialized
INFO - 2016-10-19 20:52:35 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:35 --> Input Class Initialized
INFO - 2016-10-19 20:52:35 --> Language Class Initialized
INFO - 2016-10-19 20:52:35 --> Language Class Initialized
INFO - 2016-10-19 20:52:35 --> Config Class Initialized
INFO - 2016-10-19 20:52:35 --> Loader Class Initialized
INFO - 2016-10-19 20:52:35 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:35 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:35 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:35 --> Parser Class Initialized
INFO - 2016-10-19 20:52:35 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:35 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 20:52:35 --> Config Class Initialized
INFO - 2016-10-19 20:52:35 --> Hooks Class Initialized
INFO - 2016-10-19 20:52:35 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:52:35 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:35 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/security_gt.php
INFO - 2016-10-19 20:52:35 --> Final output sent to browser
DEBUG - 2016-10-19 20:52:35 --> Total execution time: 0.0689
DEBUG - 2016-10-19 20:52:35 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:35 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:35 --> URI Class Initialized
INFO - 2016-10-19 20:52:35 --> Router Class Initialized
INFO - 2016-10-19 20:52:35 --> Output Class Initialized
INFO - 2016-10-19 20:52:35 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:35 --> Input Class Initialized
INFO - 2016-10-19 20:52:35 --> Language Class Initialized
ERROR - 2016-10-19 20:52:35 --> 404 Page Not Found: /index
INFO - 2016-10-19 20:52:35 --> Config Class Initialized
INFO - 2016-10-19 20:52:35 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:35 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:35 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:35 --> URI Class Initialized
INFO - 2016-10-19 20:52:35 --> Router Class Initialized
INFO - 2016-10-19 20:52:35 --> Output Class Initialized
INFO - 2016-10-19 20:52:35 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:35 --> Input Class Initialized
INFO - 2016-10-19 20:52:35 --> Language Class Initialized
ERROR - 2016-10-19 20:52:35 --> 404 Page Not Found: /index
INFO - 2016-10-19 20:52:39 --> Config Class Initialized
INFO - 2016-10-19 20:52:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:39 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:39 --> URI Class Initialized
INFO - 2016-10-19 20:52:39 --> Router Class Initialized
INFO - 2016-10-19 20:52:39 --> Output Class Initialized
INFO - 2016-10-19 20:52:39 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:39 --> Input Class Initialized
INFO - 2016-10-19 20:52:39 --> Language Class Initialized
INFO - 2016-10-19 20:52:39 --> Language Class Initialized
INFO - 2016-10-19 20:52:39 --> Config Class Initialized
INFO - 2016-10-19 20:52:39 --> Loader Class Initialized
INFO - 2016-10-19 20:52:39 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:39 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:39 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:39 --> Parser Class Initialized
INFO - 2016-10-19 20:52:39 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:39 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 20:52:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:52:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/security_gt.php
INFO - 2016-10-19 20:52:39 --> Final output sent to browser
DEBUG - 2016-10-19 20:52:39 --> Total execution time: 0.0421
INFO - 2016-10-19 20:52:48 --> Config Class Initialized
INFO - 2016-10-19 20:52:48 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:48 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:48 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:48 --> URI Class Initialized
INFO - 2016-10-19 20:52:48 --> Router Class Initialized
INFO - 2016-10-19 20:52:48 --> Output Class Initialized
INFO - 2016-10-19 20:52:48 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:48 --> Input Class Initialized
INFO - 2016-10-19 20:52:48 --> Language Class Initialized
INFO - 2016-10-19 20:52:48 --> Language Class Initialized
INFO - 2016-10-19 20:52:48 --> Config Class Initialized
INFO - 2016-10-19 20:52:48 --> Loader Class Initialized
INFO - 2016-10-19 20:52:48 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:48 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:48 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:48 --> Parser Class Initialized
INFO - 2016-10-19 20:52:48 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:48 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 20:52:48 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:52:48 --> Model Class Initialized
INFO - 2016-10-19 20:52:48 --> Config Class Initialized
INFO - 2016-10-19 20:52:48 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:48 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:48 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:48 --> URI Class Initialized
INFO - 2016-10-19 20:52:48 --> Router Class Initialized
INFO - 2016-10-19 20:52:48 --> Output Class Initialized
INFO - 2016-10-19 20:52:48 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:48 --> Input Class Initialized
INFO - 2016-10-19 20:52:48 --> Language Class Initialized
INFO - 2016-10-19 20:52:48 --> Language Class Initialized
INFO - 2016-10-19 20:52:48 --> Config Class Initialized
INFO - 2016-10-19 20:52:48 --> Loader Class Initialized
INFO - 2016-10-19 20:52:48 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:48 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:48 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:48 --> Parser Class Initialized
INFO - 2016-10-19 20:52:48 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:48 --> Admincp MX_Controller Initialized
INFO - 2016-10-19 20:52:48 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:52:48 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/setting.php
ERROR - 2016-10-19 20:52:48 --> Severity: Notice --> Undefined variable: module /home/dolongpk/public_html/application/views/BACKEND/template.php 11
DEBUG - 2016-10-19 20:52:48 --> File already loaded: /home/dolongpk/public_html/application/modules/admincp/models/Admincp_model.php
INFO - 2016-10-19 20:52:48 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/getSetting.php
DEBUG - 2016-10-19 20:52:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:52:48 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_accounts/models/Admincp_accounts_model.php
INFO - 2016-10-19 20:52:48 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:48 --> File loaded: /home/dolongpk/public_html/application/modules/admincp/views/menu.php
DEBUG - 2016-10-19 20:52:48 --> File loaded: /home/dolongpk/public_html/application/views/BACKEND/template.php
INFO - 2016-10-19 20:52:48 --> Final output sent to browser
DEBUG - 2016-10-19 20:52:48 --> Total execution time: 0.0395
INFO - 2016-10-19 20:52:50 --> Config Class Initialized
INFO - 2016-10-19 20:52:50 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:50 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:50 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:50 --> URI Class Initialized
INFO - 2016-10-19 20:52:50 --> Router Class Initialized
INFO - 2016-10-19 20:52:50 --> Output Class Initialized
INFO - 2016-10-19 20:52:50 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:50 --> Input Class Initialized
INFO - 2016-10-19 20:52:50 --> Language Class Initialized
INFO - 2016-10-19 20:52:50 --> Language Class Initialized
INFO - 2016-10-19 20:52:50 --> Config Class Initialized
INFO - 2016-10-19 20:52:50 --> Loader Class Initialized
INFO - 2016-10-19 20:52:50 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:50 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:50 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:50 --> Parser Class Initialized
INFO - 2016-10-19 20:52:50 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:50 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 20:52:50 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:50 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 20:52:50 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:50 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-19 20:52:50 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-19 20:52:50 --> Final output sent to browser
DEBUG - 2016-10-19 20:52:50 --> Total execution time: 0.0463
INFO - 2016-10-19 20:52:52 --> Config Class Initialized
INFO - 2016-10-19 20:52:52 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:52:52 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:52:52 --> Utf8 Class Initialized
INFO - 2016-10-19 20:52:52 --> URI Class Initialized
INFO - 2016-10-19 20:52:52 --> Router Class Initialized
INFO - 2016-10-19 20:52:52 --> Output Class Initialized
INFO - 2016-10-19 20:52:52 --> Security Class Initialized
DEBUG - 2016-10-19 20:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:52:52 --> Input Class Initialized
INFO - 2016-10-19 20:52:52 --> Language Class Initialized
INFO - 2016-10-19 20:52:52 --> Language Class Initialized
INFO - 2016-10-19 20:52:52 --> Config Class Initialized
INFO - 2016-10-19 20:52:52 --> Loader Class Initialized
INFO - 2016-10-19 20:52:52 --> Helper loaded: common_helper
INFO - 2016-10-19 20:52:52 --> Helper loaded: url_helper
INFO - 2016-10-19 20:52:52 --> Database Driver Class Initialized
INFO - 2016-10-19 20:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:52:52 --> Parser Class Initialized
INFO - 2016-10-19 20:52:52 --> Controller Class Initialized
DEBUG - 2016-10-19 20:52:52 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 20:52:52 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:52 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 20:52:52 --> Model Class Initialized
DEBUG - 2016-10-19 20:52:52 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/naptien.php
DEBUG - 2016-10-19 20:52:52 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-19 20:52:52 --> Final output sent to browser
DEBUG - 2016-10-19 20:52:52 --> Total execution time: 0.0454
INFO - 2016-10-19 20:53:06 --> Config Class Initialized
INFO - 2016-10-19 20:53:06 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:53:06 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:53:06 --> Utf8 Class Initialized
INFO - 2016-10-19 20:53:06 --> URI Class Initialized
INFO - 2016-10-19 20:53:06 --> Router Class Initialized
INFO - 2016-10-19 20:53:06 --> Output Class Initialized
INFO - 2016-10-19 20:53:06 --> Security Class Initialized
DEBUG - 2016-10-19 20:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:53:06 --> Input Class Initialized
INFO - 2016-10-19 20:53:06 --> Language Class Initialized
INFO - 2016-10-19 20:53:06 --> Language Class Initialized
INFO - 2016-10-19 20:53:06 --> Config Class Initialized
INFO - 2016-10-19 20:53:06 --> Loader Class Initialized
INFO - 2016-10-19 20:53:06 --> Helper loaded: common_helper
INFO - 2016-10-19 20:53:06 --> Helper loaded: url_helper
INFO - 2016-10-19 20:53:06 --> Database Driver Class Initialized
INFO - 2016-10-19 20:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:53:06 --> Parser Class Initialized
INFO - 2016-10-19 20:53:06 --> Controller Class Initialized
DEBUG - 2016-10-19 20:53:06 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 20:53:06 --> Model Class Initialized
DEBUG - 2016-10-19 20:53:06 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 20:53:06 --> Model Class Initialized
DEBUG - 2016-10-19 20:53:06 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/api_view.php
INFO - 2016-10-19 20:53:19 --> Config Class Initialized
INFO - 2016-10-19 20:53:19 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:53:19 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:53:19 --> Utf8 Class Initialized
INFO - 2016-10-19 20:53:19 --> URI Class Initialized
INFO - 2016-10-19 20:53:19 --> Router Class Initialized
INFO - 2016-10-19 20:53:19 --> Output Class Initialized
INFO - 2016-10-19 20:53:19 --> Security Class Initialized
DEBUG - 2016-10-19 20:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:53:19 --> Input Class Initialized
INFO - 2016-10-19 20:53:19 --> Language Class Initialized
INFO - 2016-10-19 20:53:19 --> Language Class Initialized
INFO - 2016-10-19 20:53:19 --> Config Class Initialized
INFO - 2016-10-19 20:53:19 --> Loader Class Initialized
INFO - 2016-10-19 20:53:19 --> Helper loaded: common_helper
INFO - 2016-10-19 20:53:19 --> Helper loaded: url_helper
INFO - 2016-10-19 20:53:19 --> Database Driver Class Initialized
INFO - 2016-10-19 20:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:53:20 --> Parser Class Initialized
INFO - 2016-10-19 20:53:20 --> Controller Class Initialized
DEBUG - 2016-10-19 20:53:20 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 20:53:20 --> Model Class Initialized
DEBUG - 2016-10-19 20:53:20 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 20:53:20 --> Model Class Initialized
DEBUG - 2016-10-19 20:53:20 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/api_view.php
INFO - 2016-10-19 20:53:31 --> Config Class Initialized
INFO - 2016-10-19 20:53:31 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:53:31 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:53:31 --> Utf8 Class Initialized
INFO - 2016-10-19 20:53:31 --> URI Class Initialized
INFO - 2016-10-19 20:53:31 --> Router Class Initialized
INFO - 2016-10-19 20:53:31 --> Output Class Initialized
INFO - 2016-10-19 20:53:31 --> Security Class Initialized
DEBUG - 2016-10-19 20:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:53:31 --> Input Class Initialized
INFO - 2016-10-19 20:53:31 --> Language Class Initialized
INFO - 2016-10-19 20:53:31 --> Language Class Initialized
INFO - 2016-10-19 20:53:31 --> Config Class Initialized
INFO - 2016-10-19 20:53:31 --> Loader Class Initialized
INFO - 2016-10-19 20:53:31 --> Helper loaded: common_helper
INFO - 2016-10-19 20:53:31 --> Helper loaded: url_helper
INFO - 2016-10-19 20:53:31 --> Database Driver Class Initialized
INFO - 2016-10-19 20:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:53:31 --> Parser Class Initialized
INFO - 2016-10-19 20:53:31 --> Controller Class Initialized
DEBUG - 2016-10-19 20:53:31 --> Gametool MX_Controller Initialized
INFO - 2016-10-19 20:53:31 --> Model Class Initialized
DEBUG - 2016-10-19 20:53:31 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/models/Gametool_model.php
INFO - 2016-10-19 20:53:31 --> Model Class Initialized
DEBUG - 2016-10-19 20:53:31 --> File loaded: /home/dolongpk/public_html/application/modules/gametool/views/FRONTEND/themvatpham.php
DEBUG - 2016-10-19 20:53:31 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template-thongke.php
INFO - 2016-10-19 20:53:31 --> Final output sent to browser
DEBUG - 2016-10-19 20:53:31 --> Total execution time: 0.0796
INFO - 2016-10-19 20:53:58 --> Config Class Initialized
INFO - 2016-10-19 20:53:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:53:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:53:58 --> Utf8 Class Initialized
INFO - 2016-10-19 20:53:58 --> URI Class Initialized
INFO - 2016-10-19 20:53:58 --> Router Class Initialized
INFO - 2016-10-19 20:53:58 --> Output Class Initialized
INFO - 2016-10-19 20:53:58 --> Security Class Initialized
DEBUG - 2016-10-19 20:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:53:58 --> Input Class Initialized
INFO - 2016-10-19 20:53:58 --> Language Class Initialized
INFO - 2016-10-19 20:53:58 --> Language Class Initialized
INFO - 2016-10-19 20:53:58 --> Config Class Initialized
INFO - 2016-10-19 20:53:58 --> Loader Class Initialized
INFO - 2016-10-19 20:53:58 --> Helper loaded: common_helper
INFO - 2016-10-19 20:53:58 --> Helper loaded: url_helper
INFO - 2016-10-19 20:53:58 --> Database Driver Class Initialized
INFO - 2016-10-19 20:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:53:58 --> Parser Class Initialized
INFO - 2016-10-19 20:53:58 --> Controller Class Initialized
DEBUG - 2016-10-19 20:53:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:53:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:53:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:53:58 --> Model Class Initialized
DEBUG - 2016-10-19 20:53:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:53:58 --> Model Class Initialized
INFO - 2016-10-19 20:54:00 --> Config Class Initialized
INFO - 2016-10-19 20:54:00 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:54:00 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:54:00 --> Utf8 Class Initialized
INFO - 2016-10-19 20:54:00 --> URI Class Initialized
DEBUG - 2016-10-19 20:54:00 --> No URI present. Default controller set.
INFO - 2016-10-19 20:54:00 --> Router Class Initialized
INFO - 2016-10-19 20:54:00 --> Output Class Initialized
INFO - 2016-10-19 20:54:00 --> Security Class Initialized
DEBUG - 2016-10-19 20:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:54:00 --> Input Class Initialized
INFO - 2016-10-19 20:54:00 --> Language Class Initialized
INFO - 2016-10-19 20:54:00 --> Language Class Initialized
INFO - 2016-10-19 20:54:00 --> Config Class Initialized
INFO - 2016-10-19 20:54:00 --> Loader Class Initialized
INFO - 2016-10-19 20:54:00 --> Helper loaded: common_helper
INFO - 2016-10-19 20:54:00 --> Helper loaded: url_helper
INFO - 2016-10-19 20:54:00 --> Database Driver Class Initialized
INFO - 2016-10-19 20:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:54:00 --> Parser Class Initialized
INFO - 2016-10-19 20:54:00 --> Controller Class Initialized
DEBUG - 2016-10-19 20:54:00 --> Home MX_Controller Initialized
INFO - 2016-10-19 20:54:00 --> Model Class Initialized
DEBUG - 2016-10-19 20:54:00 --> File loaded: /home/dolongpk/public_html/application/modules/home/models/Home_model.php
INFO - 2016-10-19 20:54:00 --> Model Class Initialized
DEBUG - 2016-10-19 20:54:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup_giftcode.php
ERROR - 2016-10-19 20:54:00 --> Module controller failed to run: banner/index
DEBUG - 2016-10-19 20:54:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/popup/account.php
DEBUG - 2016-10-19 20:54:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:54:00 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/template_landingpage.php
INFO - 2016-10-19 20:54:00 --> Final output sent to browser
DEBUG - 2016-10-19 20:54:00 --> Total execution time: 0.0382
INFO - 2016-10-19 20:54:18 --> Config Class Initialized
INFO - 2016-10-19 20:54:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:54:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:54:18 --> Utf8 Class Initialized
INFO - 2016-10-19 20:54:18 --> URI Class Initialized
INFO - 2016-10-19 20:54:18 --> Router Class Initialized
INFO - 2016-10-19 20:54:18 --> Output Class Initialized
INFO - 2016-10-19 20:54:18 --> Security Class Initialized
DEBUG - 2016-10-19 20:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:54:18 --> Input Class Initialized
INFO - 2016-10-19 20:54:18 --> Language Class Initialized
INFO - 2016-10-19 20:54:18 --> Language Class Initialized
INFO - 2016-10-19 20:54:18 --> Config Class Initialized
INFO - 2016-10-19 20:54:18 --> Loader Class Initialized
INFO - 2016-10-19 20:54:18 --> Helper loaded: common_helper
INFO - 2016-10-19 20:54:18 --> Helper loaded: url_helper
INFO - 2016-10-19 20:54:18 --> Database Driver Class Initialized
INFO - 2016-10-19 20:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:54:18 --> Parser Class Initialized
INFO - 2016-10-19 20:54:18 --> Controller Class Initialized
DEBUG - 2016-10-19 20:54:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:54:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:54:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:54:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:54:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:54:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:54:18 --> File loaded: /home/dolongpk/public_html/application/views/FRONTEND/modules/tracking.php
DEBUG - 2016-10-19 20:54:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/views/FRONTEND/skin_playgame_leftbar.php
INFO - 2016-10-19 20:54:18 --> Final output sent to browser
DEBUG - 2016-10-19 20:54:18 --> Total execution time: 0.0529
INFO - 2016-10-19 20:54:18 --> Config Class Initialized
INFO - 2016-10-19 20:54:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:54:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:54:18 --> Utf8 Class Initialized
INFO - 2016-10-19 20:54:18 --> URI Class Initialized
INFO - 2016-10-19 20:54:18 --> Router Class Initialized
INFO - 2016-10-19 20:54:18 --> Output Class Initialized
INFO - 2016-10-19 20:54:18 --> Security Class Initialized
DEBUG - 2016-10-19 20:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:54:18 --> Input Class Initialized
INFO - 2016-10-19 20:54:18 --> Language Class Initialized
INFO - 2016-10-19 20:54:18 --> Language Class Initialized
INFO - 2016-10-19 20:54:18 --> Config Class Initialized
INFO - 2016-10-19 20:54:18 --> Loader Class Initialized
INFO - 2016-10-19 20:54:18 --> Helper loaded: common_helper
INFO - 2016-10-19 20:54:18 --> Helper loaded: url_helper
INFO - 2016-10-19 20:54:18 --> Database Driver Class Initialized
INFO - 2016-10-19 20:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:54:18 --> Parser Class Initialized
INFO - 2016-10-19 20:54:18 --> Controller Class Initialized
DEBUG - 2016-10-19 20:54:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:54:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:54:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:54:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:54:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:54:18 --> Model Class Initialized
INFO - 2016-10-19 20:57:18 --> Config Class Initialized
INFO - 2016-10-19 20:57:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:57:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:57:18 --> Utf8 Class Initialized
INFO - 2016-10-19 20:57:18 --> URI Class Initialized
INFO - 2016-10-19 20:57:18 --> Router Class Initialized
INFO - 2016-10-19 20:57:18 --> Output Class Initialized
INFO - 2016-10-19 20:57:18 --> Security Class Initialized
DEBUG - 2016-10-19 20:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:57:18 --> Input Class Initialized
INFO - 2016-10-19 20:57:18 --> Language Class Initialized
INFO - 2016-10-19 20:57:18 --> Language Class Initialized
INFO - 2016-10-19 20:57:18 --> Config Class Initialized
INFO - 2016-10-19 20:57:18 --> Loader Class Initialized
INFO - 2016-10-19 20:57:18 --> Helper loaded: common_helper
INFO - 2016-10-19 20:57:18 --> Helper loaded: url_helper
INFO - 2016-10-19 20:57:18 --> Database Driver Class Initialized
INFO - 2016-10-19 20:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:57:18 --> Parser Class Initialized
INFO - 2016-10-19 20:57:18 --> Controller Class Initialized
DEBUG - 2016-10-19 20:57:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:57:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:57:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:57:18 --> Model Class Initialized
DEBUG - 2016-10-19 20:57:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:57:18 --> Model Class Initialized
INFO - 2016-10-19 20:57:39 --> Config Class Initialized
INFO - 2016-10-19 20:57:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 20:57:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 20:57:39 --> Utf8 Class Initialized
INFO - 2016-10-19 20:57:39 --> URI Class Initialized
INFO - 2016-10-19 20:57:39 --> Router Class Initialized
INFO - 2016-10-19 20:57:39 --> Output Class Initialized
INFO - 2016-10-19 20:57:39 --> Security Class Initialized
DEBUG - 2016-10-19 20:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 20:57:39 --> Input Class Initialized
INFO - 2016-10-19 20:57:39 --> Language Class Initialized
INFO - 2016-10-19 20:57:39 --> Language Class Initialized
INFO - 2016-10-19 20:57:39 --> Config Class Initialized
INFO - 2016-10-19 20:57:39 --> Loader Class Initialized
INFO - 2016-10-19 20:57:39 --> Helper loaded: common_helper
INFO - 2016-10-19 20:57:39 --> Helper loaded: url_helper
INFO - 2016-10-19 20:57:39 --> Database Driver Class Initialized
INFO - 2016-10-19 20:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 20:57:39 --> Parser Class Initialized
INFO - 2016-10-19 20:57:39 --> Controller Class Initialized
DEBUG - 2016-10-19 20:57:39 --> Servers MX_Controller Initialized
INFO - 2016-10-19 20:57:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:57:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 20:57:39 --> Model Class Initialized
DEBUG - 2016-10-19 20:57:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 20:57:39 --> Model Class Initialized
INFO - 2016-10-19 21:00:38 --> Config Class Initialized
INFO - 2016-10-19 21:00:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:00:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:00:38 --> Utf8 Class Initialized
INFO - 2016-10-19 21:00:38 --> URI Class Initialized
INFO - 2016-10-19 21:00:38 --> Router Class Initialized
INFO - 2016-10-19 21:00:38 --> Output Class Initialized
INFO - 2016-10-19 21:00:38 --> Security Class Initialized
DEBUG - 2016-10-19 21:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:00:38 --> Input Class Initialized
INFO - 2016-10-19 21:00:38 --> Language Class Initialized
INFO - 2016-10-19 21:00:38 --> Language Class Initialized
INFO - 2016-10-19 21:00:38 --> Config Class Initialized
INFO - 2016-10-19 21:00:38 --> Loader Class Initialized
INFO - 2016-10-19 21:00:38 --> Helper loaded: common_helper
INFO - 2016-10-19 21:00:38 --> Helper loaded: url_helper
INFO - 2016-10-19 21:00:38 --> Database Driver Class Initialized
INFO - 2016-10-19 21:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:00:38 --> Parser Class Initialized
INFO - 2016-10-19 21:00:38 --> Controller Class Initialized
DEBUG - 2016-10-19 21:00:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:00:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:00:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:00:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:00:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:00:38 --> Model Class Initialized
INFO - 2016-10-19 21:00:59 --> Config Class Initialized
INFO - 2016-10-19 21:00:59 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:00:59 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:00:59 --> Utf8 Class Initialized
INFO - 2016-10-19 21:00:59 --> URI Class Initialized
INFO - 2016-10-19 21:00:59 --> Router Class Initialized
INFO - 2016-10-19 21:00:59 --> Output Class Initialized
INFO - 2016-10-19 21:00:59 --> Security Class Initialized
DEBUG - 2016-10-19 21:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:00:59 --> Input Class Initialized
INFO - 2016-10-19 21:00:59 --> Language Class Initialized
INFO - 2016-10-19 21:00:59 --> Language Class Initialized
INFO - 2016-10-19 21:00:59 --> Config Class Initialized
INFO - 2016-10-19 21:00:59 --> Loader Class Initialized
INFO - 2016-10-19 21:00:59 --> Helper loaded: common_helper
INFO - 2016-10-19 21:00:59 --> Helper loaded: url_helper
INFO - 2016-10-19 21:00:59 --> Database Driver Class Initialized
INFO - 2016-10-19 21:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:00:59 --> Parser Class Initialized
INFO - 2016-10-19 21:00:59 --> Controller Class Initialized
DEBUG - 2016-10-19 21:00:59 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:00:59 --> Model Class Initialized
DEBUG - 2016-10-19 21:00:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:00:59 --> Model Class Initialized
DEBUG - 2016-10-19 21:00:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:00:59 --> Model Class Initialized
INFO - 2016-10-19 21:03:58 --> Config Class Initialized
INFO - 2016-10-19 21:03:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:03:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:03:58 --> Utf8 Class Initialized
INFO - 2016-10-19 21:03:58 --> URI Class Initialized
INFO - 2016-10-19 21:03:58 --> Router Class Initialized
INFO - 2016-10-19 21:03:58 --> Output Class Initialized
INFO - 2016-10-19 21:03:58 --> Security Class Initialized
DEBUG - 2016-10-19 21:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:03:58 --> Input Class Initialized
INFO - 2016-10-19 21:03:58 --> Language Class Initialized
INFO - 2016-10-19 21:03:58 --> Language Class Initialized
INFO - 2016-10-19 21:03:58 --> Config Class Initialized
INFO - 2016-10-19 21:03:58 --> Loader Class Initialized
INFO - 2016-10-19 21:03:58 --> Helper loaded: common_helper
INFO - 2016-10-19 21:03:58 --> Helper loaded: url_helper
INFO - 2016-10-19 21:03:58 --> Database Driver Class Initialized
INFO - 2016-10-19 21:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:03:58 --> Parser Class Initialized
INFO - 2016-10-19 21:03:58 --> Controller Class Initialized
DEBUG - 2016-10-19 21:03:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:03:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:03:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:03:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:03:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:03:58 --> Model Class Initialized
INFO - 2016-10-19 21:04:19 --> Config Class Initialized
INFO - 2016-10-19 21:04:19 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:04:19 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:04:19 --> Utf8 Class Initialized
INFO - 2016-10-19 21:04:19 --> URI Class Initialized
INFO - 2016-10-19 21:04:19 --> Router Class Initialized
INFO - 2016-10-19 21:04:19 --> Output Class Initialized
INFO - 2016-10-19 21:04:19 --> Security Class Initialized
DEBUG - 2016-10-19 21:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:04:19 --> Input Class Initialized
INFO - 2016-10-19 21:04:19 --> Language Class Initialized
INFO - 2016-10-19 21:04:19 --> Language Class Initialized
INFO - 2016-10-19 21:04:19 --> Config Class Initialized
INFO - 2016-10-19 21:04:19 --> Loader Class Initialized
INFO - 2016-10-19 21:04:19 --> Helper loaded: common_helper
INFO - 2016-10-19 21:04:19 --> Helper loaded: url_helper
INFO - 2016-10-19 21:04:19 --> Database Driver Class Initialized
INFO - 2016-10-19 21:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:04:19 --> Parser Class Initialized
INFO - 2016-10-19 21:04:19 --> Controller Class Initialized
DEBUG - 2016-10-19 21:04:19 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:04:19 --> Model Class Initialized
DEBUG - 2016-10-19 21:04:19 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:04:19 --> Model Class Initialized
DEBUG - 2016-10-19 21:04:19 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:04:19 --> Model Class Initialized
INFO - 2016-10-19 21:07:18 --> Config Class Initialized
INFO - 2016-10-19 21:07:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:07:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:07:18 --> Utf8 Class Initialized
INFO - 2016-10-19 21:07:18 --> URI Class Initialized
INFO - 2016-10-19 21:07:18 --> Router Class Initialized
INFO - 2016-10-19 21:07:18 --> Output Class Initialized
INFO - 2016-10-19 21:07:18 --> Security Class Initialized
DEBUG - 2016-10-19 21:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:07:18 --> Input Class Initialized
INFO - 2016-10-19 21:07:18 --> Language Class Initialized
INFO - 2016-10-19 21:07:18 --> Language Class Initialized
INFO - 2016-10-19 21:07:18 --> Config Class Initialized
INFO - 2016-10-19 21:07:18 --> Loader Class Initialized
INFO - 2016-10-19 21:07:18 --> Helper loaded: common_helper
INFO - 2016-10-19 21:07:18 --> Helper loaded: url_helper
INFO - 2016-10-19 21:07:18 --> Database Driver Class Initialized
INFO - 2016-10-19 21:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:07:18 --> Parser Class Initialized
INFO - 2016-10-19 21:07:18 --> Controller Class Initialized
DEBUG - 2016-10-19 21:07:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:07:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:07:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:07:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:07:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:07:18 --> Model Class Initialized
INFO - 2016-10-19 21:07:39 --> Config Class Initialized
INFO - 2016-10-19 21:07:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:07:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:07:39 --> Utf8 Class Initialized
INFO - 2016-10-19 21:07:39 --> URI Class Initialized
INFO - 2016-10-19 21:07:39 --> Router Class Initialized
INFO - 2016-10-19 21:07:39 --> Output Class Initialized
INFO - 2016-10-19 21:07:39 --> Security Class Initialized
DEBUG - 2016-10-19 21:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:07:39 --> Input Class Initialized
INFO - 2016-10-19 21:07:39 --> Language Class Initialized
INFO - 2016-10-19 21:07:39 --> Language Class Initialized
INFO - 2016-10-19 21:07:39 --> Config Class Initialized
INFO - 2016-10-19 21:07:39 --> Loader Class Initialized
INFO - 2016-10-19 21:07:39 --> Helper loaded: common_helper
INFO - 2016-10-19 21:07:39 --> Helper loaded: url_helper
INFO - 2016-10-19 21:07:39 --> Database Driver Class Initialized
INFO - 2016-10-19 21:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:07:39 --> Parser Class Initialized
INFO - 2016-10-19 21:07:39 --> Controller Class Initialized
DEBUG - 2016-10-19 21:07:39 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:07:39 --> Model Class Initialized
DEBUG - 2016-10-19 21:07:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:07:39 --> Model Class Initialized
DEBUG - 2016-10-19 21:07:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:07:39 --> Model Class Initialized
INFO - 2016-10-19 21:10:38 --> Config Class Initialized
INFO - 2016-10-19 21:10:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:10:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:10:38 --> Utf8 Class Initialized
INFO - 2016-10-19 21:10:38 --> URI Class Initialized
INFO - 2016-10-19 21:10:38 --> Router Class Initialized
INFO - 2016-10-19 21:10:38 --> Output Class Initialized
INFO - 2016-10-19 21:10:38 --> Security Class Initialized
DEBUG - 2016-10-19 21:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:10:38 --> Input Class Initialized
INFO - 2016-10-19 21:10:38 --> Language Class Initialized
INFO - 2016-10-19 21:10:38 --> Language Class Initialized
INFO - 2016-10-19 21:10:38 --> Config Class Initialized
INFO - 2016-10-19 21:10:38 --> Loader Class Initialized
INFO - 2016-10-19 21:10:38 --> Helper loaded: common_helper
INFO - 2016-10-19 21:10:38 --> Helper loaded: url_helper
INFO - 2016-10-19 21:10:38 --> Database Driver Class Initialized
INFO - 2016-10-19 21:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:10:38 --> Parser Class Initialized
INFO - 2016-10-19 21:10:38 --> Controller Class Initialized
DEBUG - 2016-10-19 21:10:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:10:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:10:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:10:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:10:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:10:38 --> Model Class Initialized
INFO - 2016-10-19 21:10:59 --> Config Class Initialized
INFO - 2016-10-19 21:10:59 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:10:59 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:10:59 --> Utf8 Class Initialized
INFO - 2016-10-19 21:10:59 --> URI Class Initialized
INFO - 2016-10-19 21:10:59 --> Router Class Initialized
INFO - 2016-10-19 21:10:59 --> Output Class Initialized
INFO - 2016-10-19 21:10:59 --> Security Class Initialized
DEBUG - 2016-10-19 21:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:10:59 --> Input Class Initialized
INFO - 2016-10-19 21:10:59 --> Language Class Initialized
INFO - 2016-10-19 21:10:59 --> Language Class Initialized
INFO - 2016-10-19 21:10:59 --> Config Class Initialized
INFO - 2016-10-19 21:10:59 --> Loader Class Initialized
INFO - 2016-10-19 21:10:59 --> Helper loaded: common_helper
INFO - 2016-10-19 21:10:59 --> Helper loaded: url_helper
INFO - 2016-10-19 21:10:59 --> Database Driver Class Initialized
INFO - 2016-10-19 21:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:10:59 --> Parser Class Initialized
INFO - 2016-10-19 21:10:59 --> Controller Class Initialized
DEBUG - 2016-10-19 21:10:59 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:10:59 --> Model Class Initialized
DEBUG - 2016-10-19 21:10:59 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:10:59 --> Model Class Initialized
DEBUG - 2016-10-19 21:10:59 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:10:59 --> Model Class Initialized
INFO - 2016-10-19 21:13:58 --> Config Class Initialized
INFO - 2016-10-19 21:13:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:13:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:13:58 --> Utf8 Class Initialized
INFO - 2016-10-19 21:13:58 --> URI Class Initialized
INFO - 2016-10-19 21:13:58 --> Router Class Initialized
INFO - 2016-10-19 21:13:58 --> Output Class Initialized
INFO - 2016-10-19 21:13:58 --> Security Class Initialized
DEBUG - 2016-10-19 21:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:13:58 --> Input Class Initialized
INFO - 2016-10-19 21:13:58 --> Language Class Initialized
INFO - 2016-10-19 21:13:58 --> Language Class Initialized
INFO - 2016-10-19 21:13:58 --> Config Class Initialized
INFO - 2016-10-19 21:13:58 --> Loader Class Initialized
INFO - 2016-10-19 21:13:58 --> Helper loaded: common_helper
INFO - 2016-10-19 21:13:58 --> Helper loaded: url_helper
INFO - 2016-10-19 21:13:58 --> Database Driver Class Initialized
INFO - 2016-10-19 21:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:13:58 --> Parser Class Initialized
INFO - 2016-10-19 21:13:58 --> Controller Class Initialized
DEBUG - 2016-10-19 21:13:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:13:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:13:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:13:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:13:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:13:58 --> Model Class Initialized
INFO - 2016-10-19 21:17:18 --> Config Class Initialized
INFO - 2016-10-19 21:17:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:17:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:17:18 --> Utf8 Class Initialized
INFO - 2016-10-19 21:17:18 --> URI Class Initialized
INFO - 2016-10-19 21:17:18 --> Router Class Initialized
INFO - 2016-10-19 21:17:18 --> Output Class Initialized
INFO - 2016-10-19 21:17:18 --> Security Class Initialized
DEBUG - 2016-10-19 21:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:17:18 --> Input Class Initialized
INFO - 2016-10-19 21:17:18 --> Language Class Initialized
INFO - 2016-10-19 21:17:18 --> Language Class Initialized
INFO - 2016-10-19 21:17:18 --> Config Class Initialized
INFO - 2016-10-19 21:17:18 --> Loader Class Initialized
INFO - 2016-10-19 21:17:18 --> Helper loaded: common_helper
INFO - 2016-10-19 21:17:18 --> Helper loaded: url_helper
INFO - 2016-10-19 21:17:18 --> Database Driver Class Initialized
INFO - 2016-10-19 21:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:17:18 --> Parser Class Initialized
INFO - 2016-10-19 21:17:18 --> Controller Class Initialized
DEBUG - 2016-10-19 21:17:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:17:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:17:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:17:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:17:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:17:18 --> Model Class Initialized
INFO - 2016-10-19 21:20:38 --> Config Class Initialized
INFO - 2016-10-19 21:20:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:20:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:20:38 --> Utf8 Class Initialized
INFO - 2016-10-19 21:20:38 --> URI Class Initialized
INFO - 2016-10-19 21:20:38 --> Router Class Initialized
INFO - 2016-10-19 21:20:38 --> Output Class Initialized
INFO - 2016-10-19 21:20:38 --> Security Class Initialized
DEBUG - 2016-10-19 21:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:20:38 --> Input Class Initialized
INFO - 2016-10-19 21:20:38 --> Language Class Initialized
INFO - 2016-10-19 21:20:38 --> Language Class Initialized
INFO - 2016-10-19 21:20:38 --> Config Class Initialized
INFO - 2016-10-19 21:20:38 --> Loader Class Initialized
INFO - 2016-10-19 21:20:38 --> Helper loaded: common_helper
INFO - 2016-10-19 21:20:38 --> Helper loaded: url_helper
INFO - 2016-10-19 21:20:38 --> Database Driver Class Initialized
INFO - 2016-10-19 21:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:20:38 --> Parser Class Initialized
INFO - 2016-10-19 21:20:38 --> Controller Class Initialized
DEBUG - 2016-10-19 21:20:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:20:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:20:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:20:38 --> Model Class Initialized
INFO - 2016-10-19 21:23:58 --> Config Class Initialized
INFO - 2016-10-19 21:23:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:23:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:23:58 --> Utf8 Class Initialized
INFO - 2016-10-19 21:23:58 --> URI Class Initialized
INFO - 2016-10-19 21:23:58 --> Router Class Initialized
INFO - 2016-10-19 21:23:58 --> Output Class Initialized
INFO - 2016-10-19 21:23:58 --> Security Class Initialized
DEBUG - 2016-10-19 21:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:23:58 --> Input Class Initialized
INFO - 2016-10-19 21:23:58 --> Language Class Initialized
INFO - 2016-10-19 21:23:58 --> Language Class Initialized
INFO - 2016-10-19 21:23:58 --> Config Class Initialized
INFO - 2016-10-19 21:23:58 --> Loader Class Initialized
INFO - 2016-10-19 21:23:58 --> Helper loaded: common_helper
INFO - 2016-10-19 21:23:58 --> Helper loaded: url_helper
INFO - 2016-10-19 21:23:58 --> Database Driver Class Initialized
INFO - 2016-10-19 21:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:23:58 --> Parser Class Initialized
INFO - 2016-10-19 21:23:58 --> Controller Class Initialized
DEBUG - 2016-10-19 21:23:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:23:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:23:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:23:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:23:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:23:58 --> Model Class Initialized
INFO - 2016-10-19 21:27:18 --> Config Class Initialized
INFO - 2016-10-19 21:27:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:27:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:27:18 --> Utf8 Class Initialized
INFO - 2016-10-19 21:27:18 --> URI Class Initialized
INFO - 2016-10-19 21:27:18 --> Router Class Initialized
INFO - 2016-10-19 21:27:18 --> Output Class Initialized
INFO - 2016-10-19 21:27:18 --> Security Class Initialized
DEBUG - 2016-10-19 21:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:27:18 --> Input Class Initialized
INFO - 2016-10-19 21:27:18 --> Language Class Initialized
INFO - 2016-10-19 21:27:18 --> Language Class Initialized
INFO - 2016-10-19 21:27:18 --> Config Class Initialized
INFO - 2016-10-19 21:27:18 --> Loader Class Initialized
INFO - 2016-10-19 21:27:18 --> Helper loaded: common_helper
INFO - 2016-10-19 21:27:18 --> Helper loaded: url_helper
INFO - 2016-10-19 21:27:18 --> Database Driver Class Initialized
INFO - 2016-10-19 21:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:27:18 --> Parser Class Initialized
INFO - 2016-10-19 21:27:18 --> Controller Class Initialized
DEBUG - 2016-10-19 21:27:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:27:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:27:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:27:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:27:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:27:18 --> Model Class Initialized
INFO - 2016-10-19 21:30:38 --> Config Class Initialized
INFO - 2016-10-19 21:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:30:38 --> Utf8 Class Initialized
INFO - 2016-10-19 21:30:38 --> URI Class Initialized
INFO - 2016-10-19 21:30:38 --> Router Class Initialized
INFO - 2016-10-19 21:30:38 --> Output Class Initialized
INFO - 2016-10-19 21:30:38 --> Security Class Initialized
DEBUG - 2016-10-19 21:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:30:38 --> Input Class Initialized
INFO - 2016-10-19 21:30:38 --> Language Class Initialized
INFO - 2016-10-19 21:30:38 --> Language Class Initialized
INFO - 2016-10-19 21:30:38 --> Config Class Initialized
INFO - 2016-10-19 21:30:38 --> Loader Class Initialized
INFO - 2016-10-19 21:30:38 --> Helper loaded: common_helper
INFO - 2016-10-19 21:30:38 --> Helper loaded: url_helper
INFO - 2016-10-19 21:30:38 --> Database Driver Class Initialized
INFO - 2016-10-19 21:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:30:38 --> Parser Class Initialized
INFO - 2016-10-19 21:30:38 --> Controller Class Initialized
DEBUG - 2016-10-19 21:30:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:30:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:30:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:30:38 --> Model Class Initialized
INFO - 2016-10-19 21:33:58 --> Config Class Initialized
INFO - 2016-10-19 21:33:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:33:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:33:58 --> Utf8 Class Initialized
INFO - 2016-10-19 21:33:58 --> URI Class Initialized
INFO - 2016-10-19 21:33:58 --> Router Class Initialized
INFO - 2016-10-19 21:33:58 --> Output Class Initialized
INFO - 2016-10-19 21:33:58 --> Security Class Initialized
DEBUG - 2016-10-19 21:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:33:58 --> Input Class Initialized
INFO - 2016-10-19 21:33:58 --> Language Class Initialized
INFO - 2016-10-19 21:33:58 --> Language Class Initialized
INFO - 2016-10-19 21:33:58 --> Config Class Initialized
INFO - 2016-10-19 21:33:58 --> Loader Class Initialized
INFO - 2016-10-19 21:33:58 --> Helper loaded: common_helper
INFO - 2016-10-19 21:33:58 --> Helper loaded: url_helper
INFO - 2016-10-19 21:33:58 --> Database Driver Class Initialized
INFO - 2016-10-19 21:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:33:58 --> Parser Class Initialized
INFO - 2016-10-19 21:33:58 --> Controller Class Initialized
DEBUG - 2016-10-19 21:33:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:33:58 --> Model Class Initialized
INFO - 2016-10-19 21:37:18 --> Config Class Initialized
INFO - 2016-10-19 21:37:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:37:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:37:18 --> Utf8 Class Initialized
INFO - 2016-10-19 21:37:18 --> URI Class Initialized
INFO - 2016-10-19 21:37:18 --> Router Class Initialized
INFO - 2016-10-19 21:37:18 --> Output Class Initialized
INFO - 2016-10-19 21:37:18 --> Security Class Initialized
DEBUG - 2016-10-19 21:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:37:18 --> Input Class Initialized
INFO - 2016-10-19 21:37:18 --> Language Class Initialized
INFO - 2016-10-19 21:37:18 --> Language Class Initialized
INFO - 2016-10-19 21:37:18 --> Config Class Initialized
INFO - 2016-10-19 21:37:18 --> Loader Class Initialized
INFO - 2016-10-19 21:37:18 --> Helper loaded: common_helper
INFO - 2016-10-19 21:37:18 --> Helper loaded: url_helper
INFO - 2016-10-19 21:37:18 --> Database Driver Class Initialized
INFO - 2016-10-19 21:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:37:18 --> Parser Class Initialized
INFO - 2016-10-19 21:37:18 --> Controller Class Initialized
DEBUG - 2016-10-19 21:37:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:37:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:37:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:37:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:37:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:37:18 --> Model Class Initialized
INFO - 2016-10-19 21:40:38 --> Config Class Initialized
INFO - 2016-10-19 21:40:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:40:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:40:38 --> Utf8 Class Initialized
INFO - 2016-10-19 21:40:38 --> URI Class Initialized
INFO - 2016-10-19 21:40:38 --> Router Class Initialized
INFO - 2016-10-19 21:40:38 --> Output Class Initialized
INFO - 2016-10-19 21:40:38 --> Security Class Initialized
DEBUG - 2016-10-19 21:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:40:38 --> Input Class Initialized
INFO - 2016-10-19 21:40:38 --> Language Class Initialized
INFO - 2016-10-19 21:40:38 --> Language Class Initialized
INFO - 2016-10-19 21:40:38 --> Config Class Initialized
INFO - 2016-10-19 21:40:38 --> Loader Class Initialized
INFO - 2016-10-19 21:40:38 --> Helper loaded: common_helper
INFO - 2016-10-19 21:40:38 --> Helper loaded: url_helper
INFO - 2016-10-19 21:40:38 --> Database Driver Class Initialized
INFO - 2016-10-19 21:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:40:38 --> Parser Class Initialized
INFO - 2016-10-19 21:40:38 --> Controller Class Initialized
DEBUG - 2016-10-19 21:40:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:40:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:40:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:40:38 --> Model Class Initialized
DEBUG - 2016-10-19 21:40:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:40:38 --> Model Class Initialized
INFO - 2016-10-19 21:43:58 --> Config Class Initialized
INFO - 2016-10-19 21:43:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:43:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:43:58 --> Utf8 Class Initialized
INFO - 2016-10-19 21:43:58 --> URI Class Initialized
INFO - 2016-10-19 21:43:58 --> Router Class Initialized
INFO - 2016-10-19 21:43:58 --> Output Class Initialized
INFO - 2016-10-19 21:43:58 --> Security Class Initialized
DEBUG - 2016-10-19 21:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:43:58 --> Input Class Initialized
INFO - 2016-10-19 21:43:58 --> Language Class Initialized
INFO - 2016-10-19 21:43:58 --> Language Class Initialized
INFO - 2016-10-19 21:43:58 --> Config Class Initialized
INFO - 2016-10-19 21:43:58 --> Loader Class Initialized
INFO - 2016-10-19 21:43:58 --> Helper loaded: common_helper
INFO - 2016-10-19 21:43:58 --> Helper loaded: url_helper
INFO - 2016-10-19 21:43:58 --> Database Driver Class Initialized
INFO - 2016-10-19 21:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:43:58 --> Parser Class Initialized
INFO - 2016-10-19 21:43:58 --> Controller Class Initialized
DEBUG - 2016-10-19 21:43:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:43:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:43:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:43:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:43:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:43:58 --> Model Class Initialized
INFO - 2016-10-19 21:47:18 --> Config Class Initialized
INFO - 2016-10-19 21:47:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:47:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:47:18 --> Utf8 Class Initialized
INFO - 2016-10-19 21:47:18 --> URI Class Initialized
INFO - 2016-10-19 21:47:18 --> Router Class Initialized
INFO - 2016-10-19 21:47:18 --> Output Class Initialized
INFO - 2016-10-19 21:47:18 --> Security Class Initialized
DEBUG - 2016-10-19 21:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:47:18 --> Input Class Initialized
INFO - 2016-10-19 21:47:18 --> Language Class Initialized
INFO - 2016-10-19 21:47:18 --> Language Class Initialized
INFO - 2016-10-19 21:47:18 --> Config Class Initialized
INFO - 2016-10-19 21:47:18 --> Loader Class Initialized
INFO - 2016-10-19 21:47:18 --> Helper loaded: common_helper
INFO - 2016-10-19 21:47:18 --> Helper loaded: url_helper
INFO - 2016-10-19 21:47:18 --> Database Driver Class Initialized
INFO - 2016-10-19 21:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:47:18 --> Parser Class Initialized
INFO - 2016-10-19 21:47:18 --> Controller Class Initialized
DEBUG - 2016-10-19 21:47:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:47:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:47:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:47:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:47:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:47:18 --> Model Class Initialized
INFO - 2016-10-19 21:50:39 --> Config Class Initialized
INFO - 2016-10-19 21:50:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:50:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:50:39 --> Utf8 Class Initialized
INFO - 2016-10-19 21:50:39 --> URI Class Initialized
INFO - 2016-10-19 21:50:39 --> Router Class Initialized
INFO - 2016-10-19 21:50:39 --> Output Class Initialized
INFO - 2016-10-19 21:50:39 --> Security Class Initialized
DEBUG - 2016-10-19 21:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:50:39 --> Input Class Initialized
INFO - 2016-10-19 21:50:39 --> Language Class Initialized
INFO - 2016-10-19 21:50:39 --> Language Class Initialized
INFO - 2016-10-19 21:50:39 --> Config Class Initialized
INFO - 2016-10-19 21:50:39 --> Loader Class Initialized
INFO - 2016-10-19 21:50:39 --> Helper loaded: common_helper
INFO - 2016-10-19 21:50:39 --> Helper loaded: url_helper
INFO - 2016-10-19 21:50:39 --> Database Driver Class Initialized
INFO - 2016-10-19 21:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:50:39 --> Parser Class Initialized
INFO - 2016-10-19 21:50:39 --> Controller Class Initialized
DEBUG - 2016-10-19 21:50:39 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:50:39 --> Model Class Initialized
DEBUG - 2016-10-19 21:50:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:50:39 --> Model Class Initialized
DEBUG - 2016-10-19 21:50:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:50:39 --> Model Class Initialized
INFO - 2016-10-19 21:53:58 --> Config Class Initialized
INFO - 2016-10-19 21:53:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:53:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:53:58 --> Utf8 Class Initialized
INFO - 2016-10-19 21:53:58 --> URI Class Initialized
INFO - 2016-10-19 21:53:58 --> Router Class Initialized
INFO - 2016-10-19 21:53:58 --> Output Class Initialized
INFO - 2016-10-19 21:53:58 --> Security Class Initialized
DEBUG - 2016-10-19 21:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:53:58 --> Input Class Initialized
INFO - 2016-10-19 21:53:58 --> Language Class Initialized
INFO - 2016-10-19 21:53:58 --> Language Class Initialized
INFO - 2016-10-19 21:53:58 --> Config Class Initialized
INFO - 2016-10-19 21:53:58 --> Loader Class Initialized
INFO - 2016-10-19 21:53:58 --> Helper loaded: common_helper
INFO - 2016-10-19 21:53:58 --> Helper loaded: url_helper
INFO - 2016-10-19 21:53:58 --> Database Driver Class Initialized
INFO - 2016-10-19 21:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:53:58 --> Parser Class Initialized
INFO - 2016-10-19 21:53:58 --> Controller Class Initialized
DEBUG - 2016-10-19 21:53:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:53:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:53:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:53:58 --> Model Class Initialized
DEBUG - 2016-10-19 21:53:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:53:58 --> Model Class Initialized
INFO - 2016-10-19 21:57:18 --> Config Class Initialized
INFO - 2016-10-19 21:57:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 21:57:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 21:57:18 --> Utf8 Class Initialized
INFO - 2016-10-19 21:57:18 --> URI Class Initialized
INFO - 2016-10-19 21:57:18 --> Router Class Initialized
INFO - 2016-10-19 21:57:18 --> Output Class Initialized
INFO - 2016-10-19 21:57:18 --> Security Class Initialized
DEBUG - 2016-10-19 21:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 21:57:18 --> Input Class Initialized
INFO - 2016-10-19 21:57:18 --> Language Class Initialized
INFO - 2016-10-19 21:57:18 --> Language Class Initialized
INFO - 2016-10-19 21:57:18 --> Config Class Initialized
INFO - 2016-10-19 21:57:18 --> Loader Class Initialized
INFO - 2016-10-19 21:57:18 --> Helper loaded: common_helper
INFO - 2016-10-19 21:57:18 --> Helper loaded: url_helper
INFO - 2016-10-19 21:57:18 --> Database Driver Class Initialized
INFO - 2016-10-19 21:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 21:57:18 --> Parser Class Initialized
INFO - 2016-10-19 21:57:18 --> Controller Class Initialized
DEBUG - 2016-10-19 21:57:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 21:57:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:57:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 21:57:18 --> Model Class Initialized
DEBUG - 2016-10-19 21:57:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 21:57:18 --> Model Class Initialized
INFO - 2016-10-19 22:00:38 --> Config Class Initialized
INFO - 2016-10-19 22:00:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:00:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:00:38 --> Utf8 Class Initialized
INFO - 2016-10-19 22:00:38 --> URI Class Initialized
INFO - 2016-10-19 22:00:38 --> Router Class Initialized
INFO - 2016-10-19 22:00:38 --> Output Class Initialized
INFO - 2016-10-19 22:00:38 --> Security Class Initialized
DEBUG - 2016-10-19 22:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:00:38 --> Input Class Initialized
INFO - 2016-10-19 22:00:38 --> Language Class Initialized
INFO - 2016-10-19 22:00:38 --> Language Class Initialized
INFO - 2016-10-19 22:00:38 --> Config Class Initialized
INFO - 2016-10-19 22:00:38 --> Loader Class Initialized
INFO - 2016-10-19 22:00:38 --> Helper loaded: common_helper
INFO - 2016-10-19 22:00:38 --> Helper loaded: url_helper
INFO - 2016-10-19 22:00:38 --> Database Driver Class Initialized
INFO - 2016-10-19 22:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:00:38 --> Parser Class Initialized
INFO - 2016-10-19 22:00:38 --> Controller Class Initialized
DEBUG - 2016-10-19 22:00:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:00:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:00:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:00:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:00:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:00:38 --> Model Class Initialized
INFO - 2016-10-19 22:03:58 --> Config Class Initialized
INFO - 2016-10-19 22:03:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:03:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:03:58 --> Utf8 Class Initialized
INFO - 2016-10-19 22:03:58 --> URI Class Initialized
INFO - 2016-10-19 22:03:58 --> Router Class Initialized
INFO - 2016-10-19 22:03:58 --> Output Class Initialized
INFO - 2016-10-19 22:03:58 --> Security Class Initialized
DEBUG - 2016-10-19 22:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:03:58 --> Input Class Initialized
INFO - 2016-10-19 22:03:58 --> Language Class Initialized
INFO - 2016-10-19 22:03:58 --> Language Class Initialized
INFO - 2016-10-19 22:03:58 --> Config Class Initialized
INFO - 2016-10-19 22:03:58 --> Loader Class Initialized
INFO - 2016-10-19 22:03:58 --> Helper loaded: common_helper
INFO - 2016-10-19 22:03:58 --> Helper loaded: url_helper
INFO - 2016-10-19 22:03:58 --> Database Driver Class Initialized
INFO - 2016-10-19 22:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:03:58 --> Parser Class Initialized
INFO - 2016-10-19 22:03:58 --> Controller Class Initialized
DEBUG - 2016-10-19 22:03:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:03:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:03:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:03:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:03:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:03:58 --> Model Class Initialized
INFO - 2016-10-19 22:07:18 --> Config Class Initialized
INFO - 2016-10-19 22:07:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:07:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:07:18 --> Utf8 Class Initialized
INFO - 2016-10-19 22:07:18 --> URI Class Initialized
INFO - 2016-10-19 22:07:18 --> Router Class Initialized
INFO - 2016-10-19 22:07:18 --> Output Class Initialized
INFO - 2016-10-19 22:07:18 --> Security Class Initialized
DEBUG - 2016-10-19 22:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:07:18 --> Input Class Initialized
INFO - 2016-10-19 22:07:18 --> Language Class Initialized
INFO - 2016-10-19 22:07:18 --> Language Class Initialized
INFO - 2016-10-19 22:07:18 --> Config Class Initialized
INFO - 2016-10-19 22:07:18 --> Loader Class Initialized
INFO - 2016-10-19 22:07:18 --> Helper loaded: common_helper
INFO - 2016-10-19 22:07:18 --> Helper loaded: url_helper
INFO - 2016-10-19 22:07:18 --> Database Driver Class Initialized
INFO - 2016-10-19 22:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:07:18 --> Parser Class Initialized
INFO - 2016-10-19 22:07:18 --> Controller Class Initialized
DEBUG - 2016-10-19 22:07:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:07:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:07:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:07:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:07:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:07:18 --> Model Class Initialized
INFO - 2016-10-19 22:10:38 --> Config Class Initialized
INFO - 2016-10-19 22:10:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:10:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:10:38 --> Utf8 Class Initialized
INFO - 2016-10-19 22:10:38 --> URI Class Initialized
INFO - 2016-10-19 22:10:38 --> Router Class Initialized
INFO - 2016-10-19 22:10:38 --> Output Class Initialized
INFO - 2016-10-19 22:10:38 --> Security Class Initialized
DEBUG - 2016-10-19 22:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:10:38 --> Input Class Initialized
INFO - 2016-10-19 22:10:38 --> Language Class Initialized
INFO - 2016-10-19 22:10:38 --> Language Class Initialized
INFO - 2016-10-19 22:10:38 --> Config Class Initialized
INFO - 2016-10-19 22:10:38 --> Loader Class Initialized
INFO - 2016-10-19 22:10:38 --> Helper loaded: common_helper
INFO - 2016-10-19 22:10:38 --> Helper loaded: url_helper
INFO - 2016-10-19 22:10:38 --> Database Driver Class Initialized
INFO - 2016-10-19 22:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:10:38 --> Parser Class Initialized
INFO - 2016-10-19 22:10:38 --> Controller Class Initialized
DEBUG - 2016-10-19 22:10:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:10:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:10:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:10:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:10:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:10:38 --> Model Class Initialized
INFO - 2016-10-19 22:13:58 --> Config Class Initialized
INFO - 2016-10-19 22:13:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:13:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:13:58 --> Utf8 Class Initialized
INFO - 2016-10-19 22:13:58 --> URI Class Initialized
INFO - 2016-10-19 22:13:58 --> Router Class Initialized
INFO - 2016-10-19 22:13:58 --> Output Class Initialized
INFO - 2016-10-19 22:13:58 --> Security Class Initialized
DEBUG - 2016-10-19 22:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:13:58 --> Input Class Initialized
INFO - 2016-10-19 22:13:58 --> Language Class Initialized
INFO - 2016-10-19 22:13:58 --> Language Class Initialized
INFO - 2016-10-19 22:13:58 --> Config Class Initialized
INFO - 2016-10-19 22:13:58 --> Loader Class Initialized
INFO - 2016-10-19 22:13:58 --> Helper loaded: common_helper
INFO - 2016-10-19 22:13:58 --> Helper loaded: url_helper
INFO - 2016-10-19 22:13:58 --> Database Driver Class Initialized
INFO - 2016-10-19 22:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:13:58 --> Parser Class Initialized
INFO - 2016-10-19 22:13:58 --> Controller Class Initialized
DEBUG - 2016-10-19 22:13:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:13:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:13:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:13:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:13:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:13:58 --> Model Class Initialized
INFO - 2016-10-19 22:17:18 --> Config Class Initialized
INFO - 2016-10-19 22:17:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:17:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:17:18 --> Utf8 Class Initialized
INFO - 2016-10-19 22:17:18 --> URI Class Initialized
INFO - 2016-10-19 22:17:18 --> Router Class Initialized
INFO - 2016-10-19 22:17:18 --> Output Class Initialized
INFO - 2016-10-19 22:17:18 --> Security Class Initialized
DEBUG - 2016-10-19 22:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:17:18 --> Input Class Initialized
INFO - 2016-10-19 22:17:18 --> Language Class Initialized
INFO - 2016-10-19 22:17:18 --> Language Class Initialized
INFO - 2016-10-19 22:17:18 --> Config Class Initialized
INFO - 2016-10-19 22:17:18 --> Loader Class Initialized
INFO - 2016-10-19 22:17:18 --> Helper loaded: common_helper
INFO - 2016-10-19 22:17:18 --> Helper loaded: url_helper
INFO - 2016-10-19 22:17:18 --> Database Driver Class Initialized
INFO - 2016-10-19 22:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:17:18 --> Parser Class Initialized
INFO - 2016-10-19 22:17:18 --> Controller Class Initialized
DEBUG - 2016-10-19 22:17:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:17:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:17:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:17:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:17:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:17:18 --> Model Class Initialized
INFO - 2016-10-19 22:20:38 --> Config Class Initialized
INFO - 2016-10-19 22:20:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:20:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:20:38 --> Utf8 Class Initialized
INFO - 2016-10-19 22:20:38 --> URI Class Initialized
INFO - 2016-10-19 22:20:38 --> Router Class Initialized
INFO - 2016-10-19 22:20:38 --> Output Class Initialized
INFO - 2016-10-19 22:20:38 --> Security Class Initialized
DEBUG - 2016-10-19 22:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:20:38 --> Input Class Initialized
INFO - 2016-10-19 22:20:38 --> Language Class Initialized
INFO - 2016-10-19 22:20:38 --> Language Class Initialized
INFO - 2016-10-19 22:20:38 --> Config Class Initialized
INFO - 2016-10-19 22:20:38 --> Loader Class Initialized
INFO - 2016-10-19 22:20:38 --> Helper loaded: common_helper
INFO - 2016-10-19 22:20:38 --> Helper loaded: url_helper
INFO - 2016-10-19 22:20:38 --> Database Driver Class Initialized
INFO - 2016-10-19 22:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:20:38 --> Parser Class Initialized
INFO - 2016-10-19 22:20:38 --> Controller Class Initialized
DEBUG - 2016-10-19 22:20:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:20:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:20:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:20:38 --> Model Class Initialized
INFO - 2016-10-19 22:23:58 --> Config Class Initialized
INFO - 2016-10-19 22:23:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:23:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:23:58 --> Utf8 Class Initialized
INFO - 2016-10-19 22:23:58 --> URI Class Initialized
INFO - 2016-10-19 22:23:58 --> Router Class Initialized
INFO - 2016-10-19 22:23:58 --> Output Class Initialized
INFO - 2016-10-19 22:23:58 --> Security Class Initialized
DEBUG - 2016-10-19 22:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:23:58 --> Input Class Initialized
INFO - 2016-10-19 22:23:58 --> Language Class Initialized
INFO - 2016-10-19 22:23:58 --> Language Class Initialized
INFO - 2016-10-19 22:23:58 --> Config Class Initialized
INFO - 2016-10-19 22:23:58 --> Loader Class Initialized
INFO - 2016-10-19 22:23:58 --> Helper loaded: common_helper
INFO - 2016-10-19 22:23:58 --> Helper loaded: url_helper
INFO - 2016-10-19 22:23:58 --> Database Driver Class Initialized
INFO - 2016-10-19 22:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:23:58 --> Parser Class Initialized
INFO - 2016-10-19 22:23:58 --> Controller Class Initialized
DEBUG - 2016-10-19 22:23:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:23:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:23:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:23:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:23:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:23:58 --> Model Class Initialized
INFO - 2016-10-19 22:27:18 --> Config Class Initialized
INFO - 2016-10-19 22:27:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:27:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:27:18 --> Utf8 Class Initialized
INFO - 2016-10-19 22:27:18 --> URI Class Initialized
INFO - 2016-10-19 22:27:18 --> Router Class Initialized
INFO - 2016-10-19 22:27:18 --> Output Class Initialized
INFO - 2016-10-19 22:27:18 --> Security Class Initialized
DEBUG - 2016-10-19 22:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:27:18 --> Input Class Initialized
INFO - 2016-10-19 22:27:18 --> Language Class Initialized
INFO - 2016-10-19 22:27:18 --> Language Class Initialized
INFO - 2016-10-19 22:27:18 --> Config Class Initialized
INFO - 2016-10-19 22:27:18 --> Loader Class Initialized
INFO - 2016-10-19 22:27:18 --> Helper loaded: common_helper
INFO - 2016-10-19 22:27:18 --> Helper loaded: url_helper
INFO - 2016-10-19 22:27:18 --> Database Driver Class Initialized
INFO - 2016-10-19 22:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:27:18 --> Parser Class Initialized
INFO - 2016-10-19 22:27:18 --> Controller Class Initialized
DEBUG - 2016-10-19 22:27:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:27:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:27:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:27:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:27:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:27:18 --> Model Class Initialized
INFO - 2016-10-19 22:30:38 --> Config Class Initialized
INFO - 2016-10-19 22:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:30:38 --> Utf8 Class Initialized
INFO - 2016-10-19 22:30:38 --> URI Class Initialized
INFO - 2016-10-19 22:30:38 --> Router Class Initialized
INFO - 2016-10-19 22:30:38 --> Output Class Initialized
INFO - 2016-10-19 22:30:38 --> Security Class Initialized
DEBUG - 2016-10-19 22:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:30:38 --> Input Class Initialized
INFO - 2016-10-19 22:30:38 --> Language Class Initialized
INFO - 2016-10-19 22:30:38 --> Language Class Initialized
INFO - 2016-10-19 22:30:38 --> Config Class Initialized
INFO - 2016-10-19 22:30:38 --> Loader Class Initialized
INFO - 2016-10-19 22:30:38 --> Helper loaded: common_helper
INFO - 2016-10-19 22:30:38 --> Helper loaded: url_helper
INFO - 2016-10-19 22:30:38 --> Database Driver Class Initialized
INFO - 2016-10-19 22:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:30:38 --> Parser Class Initialized
INFO - 2016-10-19 22:30:38 --> Controller Class Initialized
DEBUG - 2016-10-19 22:30:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:30:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:30:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:30:38 --> Model Class Initialized
INFO - 2016-10-19 22:33:58 --> Config Class Initialized
INFO - 2016-10-19 22:33:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:33:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:33:58 --> Utf8 Class Initialized
INFO - 2016-10-19 22:33:58 --> URI Class Initialized
INFO - 2016-10-19 22:33:58 --> Router Class Initialized
INFO - 2016-10-19 22:33:58 --> Output Class Initialized
INFO - 2016-10-19 22:33:58 --> Security Class Initialized
DEBUG - 2016-10-19 22:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:33:58 --> Input Class Initialized
INFO - 2016-10-19 22:33:58 --> Language Class Initialized
INFO - 2016-10-19 22:33:58 --> Language Class Initialized
INFO - 2016-10-19 22:33:58 --> Config Class Initialized
INFO - 2016-10-19 22:33:58 --> Loader Class Initialized
INFO - 2016-10-19 22:33:58 --> Helper loaded: common_helper
INFO - 2016-10-19 22:33:58 --> Helper loaded: url_helper
INFO - 2016-10-19 22:33:58 --> Database Driver Class Initialized
INFO - 2016-10-19 22:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:33:58 --> Parser Class Initialized
INFO - 2016-10-19 22:33:58 --> Controller Class Initialized
DEBUG - 2016-10-19 22:33:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:33:58 --> Model Class Initialized
INFO - 2016-10-19 22:37:18 --> Config Class Initialized
INFO - 2016-10-19 22:37:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:37:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:37:18 --> Utf8 Class Initialized
INFO - 2016-10-19 22:37:18 --> URI Class Initialized
INFO - 2016-10-19 22:37:18 --> Router Class Initialized
INFO - 2016-10-19 22:37:18 --> Output Class Initialized
INFO - 2016-10-19 22:37:18 --> Security Class Initialized
DEBUG - 2016-10-19 22:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:37:18 --> Input Class Initialized
INFO - 2016-10-19 22:37:18 --> Language Class Initialized
INFO - 2016-10-19 22:37:18 --> Language Class Initialized
INFO - 2016-10-19 22:37:18 --> Config Class Initialized
INFO - 2016-10-19 22:37:18 --> Loader Class Initialized
INFO - 2016-10-19 22:37:18 --> Helper loaded: common_helper
INFO - 2016-10-19 22:37:18 --> Helper loaded: url_helper
INFO - 2016-10-19 22:37:18 --> Database Driver Class Initialized
INFO - 2016-10-19 22:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:37:18 --> Parser Class Initialized
INFO - 2016-10-19 22:37:18 --> Controller Class Initialized
DEBUG - 2016-10-19 22:37:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:37:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:37:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:37:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:37:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:37:18 --> Model Class Initialized
INFO - 2016-10-19 22:40:38 --> Config Class Initialized
INFO - 2016-10-19 22:40:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:40:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:40:38 --> Utf8 Class Initialized
INFO - 2016-10-19 22:40:38 --> URI Class Initialized
INFO - 2016-10-19 22:40:38 --> Router Class Initialized
INFO - 2016-10-19 22:40:38 --> Output Class Initialized
INFO - 2016-10-19 22:40:38 --> Security Class Initialized
DEBUG - 2016-10-19 22:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:40:38 --> Input Class Initialized
INFO - 2016-10-19 22:40:38 --> Language Class Initialized
INFO - 2016-10-19 22:40:38 --> Language Class Initialized
INFO - 2016-10-19 22:40:38 --> Config Class Initialized
INFO - 2016-10-19 22:40:38 --> Loader Class Initialized
INFO - 2016-10-19 22:40:38 --> Helper loaded: common_helper
INFO - 2016-10-19 22:40:38 --> Helper loaded: url_helper
INFO - 2016-10-19 22:40:38 --> Database Driver Class Initialized
INFO - 2016-10-19 22:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:40:38 --> Parser Class Initialized
INFO - 2016-10-19 22:40:38 --> Controller Class Initialized
DEBUG - 2016-10-19 22:40:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:40:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:40:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:40:38 --> Model Class Initialized
DEBUG - 2016-10-19 22:40:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:40:38 --> Model Class Initialized
INFO - 2016-10-19 22:43:58 --> Config Class Initialized
INFO - 2016-10-19 22:43:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:43:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:43:58 --> Utf8 Class Initialized
INFO - 2016-10-19 22:43:58 --> URI Class Initialized
INFO - 2016-10-19 22:43:58 --> Router Class Initialized
INFO - 2016-10-19 22:43:58 --> Output Class Initialized
INFO - 2016-10-19 22:43:58 --> Security Class Initialized
DEBUG - 2016-10-19 22:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:43:58 --> Input Class Initialized
INFO - 2016-10-19 22:43:58 --> Language Class Initialized
INFO - 2016-10-19 22:43:58 --> Language Class Initialized
INFO - 2016-10-19 22:43:58 --> Config Class Initialized
INFO - 2016-10-19 22:43:58 --> Loader Class Initialized
INFO - 2016-10-19 22:43:58 --> Helper loaded: common_helper
INFO - 2016-10-19 22:43:58 --> Helper loaded: url_helper
INFO - 2016-10-19 22:43:58 --> Database Driver Class Initialized
INFO - 2016-10-19 22:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:43:58 --> Parser Class Initialized
INFO - 2016-10-19 22:43:58 --> Controller Class Initialized
DEBUG - 2016-10-19 22:43:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:43:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:43:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:43:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:43:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:43:58 --> Model Class Initialized
INFO - 2016-10-19 22:47:18 --> Config Class Initialized
INFO - 2016-10-19 22:47:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:47:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:47:18 --> Utf8 Class Initialized
INFO - 2016-10-19 22:47:18 --> URI Class Initialized
INFO - 2016-10-19 22:47:18 --> Router Class Initialized
INFO - 2016-10-19 22:47:18 --> Output Class Initialized
INFO - 2016-10-19 22:47:18 --> Security Class Initialized
DEBUG - 2016-10-19 22:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:47:18 --> Input Class Initialized
INFO - 2016-10-19 22:47:18 --> Language Class Initialized
INFO - 2016-10-19 22:47:18 --> Language Class Initialized
INFO - 2016-10-19 22:47:18 --> Config Class Initialized
INFO - 2016-10-19 22:47:18 --> Loader Class Initialized
INFO - 2016-10-19 22:47:18 --> Helper loaded: common_helper
INFO - 2016-10-19 22:47:18 --> Helper loaded: url_helper
INFO - 2016-10-19 22:47:18 --> Database Driver Class Initialized
INFO - 2016-10-19 22:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:47:18 --> Parser Class Initialized
INFO - 2016-10-19 22:47:18 --> Controller Class Initialized
DEBUG - 2016-10-19 22:47:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:47:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:47:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:47:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:47:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:47:18 --> Model Class Initialized
INFO - 2016-10-19 22:50:39 --> Config Class Initialized
INFO - 2016-10-19 22:50:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:50:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:50:39 --> Utf8 Class Initialized
INFO - 2016-10-19 22:50:39 --> URI Class Initialized
INFO - 2016-10-19 22:50:39 --> Router Class Initialized
INFO - 2016-10-19 22:50:39 --> Output Class Initialized
INFO - 2016-10-19 22:50:39 --> Security Class Initialized
DEBUG - 2016-10-19 22:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:50:39 --> Input Class Initialized
INFO - 2016-10-19 22:50:39 --> Language Class Initialized
INFO - 2016-10-19 22:50:39 --> Language Class Initialized
INFO - 2016-10-19 22:50:39 --> Config Class Initialized
INFO - 2016-10-19 22:50:39 --> Loader Class Initialized
INFO - 2016-10-19 22:50:39 --> Helper loaded: common_helper
INFO - 2016-10-19 22:50:39 --> Helper loaded: url_helper
INFO - 2016-10-19 22:50:39 --> Database Driver Class Initialized
INFO - 2016-10-19 22:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:50:39 --> Parser Class Initialized
INFO - 2016-10-19 22:50:39 --> Controller Class Initialized
DEBUG - 2016-10-19 22:50:39 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:50:39 --> Model Class Initialized
DEBUG - 2016-10-19 22:50:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:50:39 --> Model Class Initialized
DEBUG - 2016-10-19 22:50:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:50:39 --> Model Class Initialized
INFO - 2016-10-19 22:53:58 --> Config Class Initialized
INFO - 2016-10-19 22:53:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:53:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:53:58 --> Utf8 Class Initialized
INFO - 2016-10-19 22:53:58 --> URI Class Initialized
INFO - 2016-10-19 22:53:58 --> Router Class Initialized
INFO - 2016-10-19 22:53:58 --> Output Class Initialized
INFO - 2016-10-19 22:53:58 --> Security Class Initialized
DEBUG - 2016-10-19 22:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:53:58 --> Input Class Initialized
INFO - 2016-10-19 22:53:58 --> Language Class Initialized
INFO - 2016-10-19 22:53:58 --> Language Class Initialized
INFO - 2016-10-19 22:53:58 --> Config Class Initialized
INFO - 2016-10-19 22:53:58 --> Loader Class Initialized
INFO - 2016-10-19 22:53:58 --> Helper loaded: common_helper
INFO - 2016-10-19 22:53:58 --> Helper loaded: url_helper
INFO - 2016-10-19 22:53:58 --> Database Driver Class Initialized
INFO - 2016-10-19 22:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:53:58 --> Parser Class Initialized
INFO - 2016-10-19 22:53:58 --> Controller Class Initialized
DEBUG - 2016-10-19 22:53:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:53:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:53:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:53:58 --> Model Class Initialized
DEBUG - 2016-10-19 22:53:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:53:58 --> Model Class Initialized
INFO - 2016-10-19 22:57:18 --> Config Class Initialized
INFO - 2016-10-19 22:57:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 22:57:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 22:57:18 --> Utf8 Class Initialized
INFO - 2016-10-19 22:57:18 --> URI Class Initialized
INFO - 2016-10-19 22:57:18 --> Router Class Initialized
INFO - 2016-10-19 22:57:18 --> Output Class Initialized
INFO - 2016-10-19 22:57:18 --> Security Class Initialized
DEBUG - 2016-10-19 22:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 22:57:18 --> Input Class Initialized
INFO - 2016-10-19 22:57:18 --> Language Class Initialized
INFO - 2016-10-19 22:57:18 --> Language Class Initialized
INFO - 2016-10-19 22:57:18 --> Config Class Initialized
INFO - 2016-10-19 22:57:18 --> Loader Class Initialized
INFO - 2016-10-19 22:57:18 --> Helper loaded: common_helper
INFO - 2016-10-19 22:57:18 --> Helper loaded: url_helper
INFO - 2016-10-19 22:57:18 --> Database Driver Class Initialized
INFO - 2016-10-19 22:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 22:57:18 --> Parser Class Initialized
INFO - 2016-10-19 22:57:18 --> Controller Class Initialized
DEBUG - 2016-10-19 22:57:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 22:57:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:57:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 22:57:18 --> Model Class Initialized
DEBUG - 2016-10-19 22:57:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 22:57:18 --> Model Class Initialized
INFO - 2016-10-19 23:00:38 --> Config Class Initialized
INFO - 2016-10-19 23:00:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:00:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:00:38 --> Utf8 Class Initialized
INFO - 2016-10-19 23:00:38 --> URI Class Initialized
INFO - 2016-10-19 23:00:38 --> Router Class Initialized
INFO - 2016-10-19 23:00:38 --> Output Class Initialized
INFO - 2016-10-19 23:00:38 --> Security Class Initialized
DEBUG - 2016-10-19 23:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:00:38 --> Input Class Initialized
INFO - 2016-10-19 23:00:38 --> Language Class Initialized
INFO - 2016-10-19 23:00:38 --> Language Class Initialized
INFO - 2016-10-19 23:00:38 --> Config Class Initialized
INFO - 2016-10-19 23:00:38 --> Loader Class Initialized
INFO - 2016-10-19 23:00:38 --> Helper loaded: common_helper
INFO - 2016-10-19 23:00:38 --> Helper loaded: url_helper
INFO - 2016-10-19 23:00:38 --> Database Driver Class Initialized
INFO - 2016-10-19 23:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:00:38 --> Parser Class Initialized
INFO - 2016-10-19 23:00:38 --> Controller Class Initialized
DEBUG - 2016-10-19 23:00:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:00:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:00:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:00:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:00:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:00:38 --> Model Class Initialized
INFO - 2016-10-19 23:03:58 --> Config Class Initialized
INFO - 2016-10-19 23:03:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:03:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:03:58 --> Utf8 Class Initialized
INFO - 2016-10-19 23:03:58 --> URI Class Initialized
INFO - 2016-10-19 23:03:58 --> Router Class Initialized
INFO - 2016-10-19 23:03:58 --> Output Class Initialized
INFO - 2016-10-19 23:03:58 --> Security Class Initialized
DEBUG - 2016-10-19 23:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:03:58 --> Input Class Initialized
INFO - 2016-10-19 23:03:58 --> Language Class Initialized
INFO - 2016-10-19 23:03:58 --> Language Class Initialized
INFO - 2016-10-19 23:03:58 --> Config Class Initialized
INFO - 2016-10-19 23:03:58 --> Loader Class Initialized
INFO - 2016-10-19 23:03:58 --> Helper loaded: common_helper
INFO - 2016-10-19 23:03:58 --> Helper loaded: url_helper
INFO - 2016-10-19 23:03:58 --> Database Driver Class Initialized
INFO - 2016-10-19 23:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:03:58 --> Parser Class Initialized
INFO - 2016-10-19 23:03:58 --> Controller Class Initialized
DEBUG - 2016-10-19 23:03:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:03:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:03:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:03:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:03:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:03:58 --> Model Class Initialized
INFO - 2016-10-19 23:07:18 --> Config Class Initialized
INFO - 2016-10-19 23:07:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:07:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:07:18 --> Utf8 Class Initialized
INFO - 2016-10-19 23:07:18 --> URI Class Initialized
INFO - 2016-10-19 23:07:18 --> Router Class Initialized
INFO - 2016-10-19 23:07:18 --> Output Class Initialized
INFO - 2016-10-19 23:07:18 --> Security Class Initialized
DEBUG - 2016-10-19 23:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:07:18 --> Input Class Initialized
INFO - 2016-10-19 23:07:18 --> Language Class Initialized
INFO - 2016-10-19 23:07:18 --> Language Class Initialized
INFO - 2016-10-19 23:07:18 --> Config Class Initialized
INFO - 2016-10-19 23:07:18 --> Loader Class Initialized
INFO - 2016-10-19 23:07:18 --> Helper loaded: common_helper
INFO - 2016-10-19 23:07:18 --> Helper loaded: url_helper
INFO - 2016-10-19 23:07:18 --> Database Driver Class Initialized
INFO - 2016-10-19 23:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:07:18 --> Parser Class Initialized
INFO - 2016-10-19 23:07:18 --> Controller Class Initialized
DEBUG - 2016-10-19 23:07:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:07:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:07:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:07:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:07:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:07:18 --> Model Class Initialized
INFO - 2016-10-19 23:10:38 --> Config Class Initialized
INFO - 2016-10-19 23:10:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:10:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:10:38 --> Utf8 Class Initialized
INFO - 2016-10-19 23:10:38 --> URI Class Initialized
INFO - 2016-10-19 23:10:38 --> Router Class Initialized
INFO - 2016-10-19 23:10:38 --> Output Class Initialized
INFO - 2016-10-19 23:10:38 --> Security Class Initialized
DEBUG - 2016-10-19 23:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:10:38 --> Input Class Initialized
INFO - 2016-10-19 23:10:38 --> Language Class Initialized
INFO - 2016-10-19 23:10:38 --> Language Class Initialized
INFO - 2016-10-19 23:10:38 --> Config Class Initialized
INFO - 2016-10-19 23:10:38 --> Loader Class Initialized
INFO - 2016-10-19 23:10:38 --> Helper loaded: common_helper
INFO - 2016-10-19 23:10:38 --> Helper loaded: url_helper
INFO - 2016-10-19 23:10:38 --> Database Driver Class Initialized
INFO - 2016-10-19 23:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:10:38 --> Parser Class Initialized
INFO - 2016-10-19 23:10:38 --> Controller Class Initialized
DEBUG - 2016-10-19 23:10:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:10:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:10:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:10:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:10:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:10:38 --> Model Class Initialized
INFO - 2016-10-19 23:13:58 --> Config Class Initialized
INFO - 2016-10-19 23:13:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:13:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:13:58 --> Utf8 Class Initialized
INFO - 2016-10-19 23:13:58 --> URI Class Initialized
INFO - 2016-10-19 23:13:58 --> Router Class Initialized
INFO - 2016-10-19 23:13:58 --> Output Class Initialized
INFO - 2016-10-19 23:13:58 --> Security Class Initialized
DEBUG - 2016-10-19 23:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:13:58 --> Input Class Initialized
INFO - 2016-10-19 23:13:58 --> Language Class Initialized
INFO - 2016-10-19 23:13:58 --> Language Class Initialized
INFO - 2016-10-19 23:13:58 --> Config Class Initialized
INFO - 2016-10-19 23:13:58 --> Loader Class Initialized
INFO - 2016-10-19 23:13:58 --> Helper loaded: common_helper
INFO - 2016-10-19 23:13:58 --> Helper loaded: url_helper
INFO - 2016-10-19 23:13:58 --> Database Driver Class Initialized
INFO - 2016-10-19 23:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:13:58 --> Parser Class Initialized
INFO - 2016-10-19 23:13:58 --> Controller Class Initialized
DEBUG - 2016-10-19 23:13:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:13:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:13:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:13:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:13:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:13:58 --> Model Class Initialized
INFO - 2016-10-19 23:17:18 --> Config Class Initialized
INFO - 2016-10-19 23:17:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:17:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:17:18 --> Utf8 Class Initialized
INFO - 2016-10-19 23:17:18 --> URI Class Initialized
INFO - 2016-10-19 23:17:18 --> Router Class Initialized
INFO - 2016-10-19 23:17:18 --> Output Class Initialized
INFO - 2016-10-19 23:17:18 --> Security Class Initialized
DEBUG - 2016-10-19 23:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:17:18 --> Input Class Initialized
INFO - 2016-10-19 23:17:18 --> Language Class Initialized
INFO - 2016-10-19 23:17:18 --> Language Class Initialized
INFO - 2016-10-19 23:17:18 --> Config Class Initialized
INFO - 2016-10-19 23:17:18 --> Loader Class Initialized
INFO - 2016-10-19 23:17:18 --> Helper loaded: common_helper
INFO - 2016-10-19 23:17:18 --> Helper loaded: url_helper
INFO - 2016-10-19 23:17:18 --> Database Driver Class Initialized
INFO - 2016-10-19 23:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:17:18 --> Parser Class Initialized
INFO - 2016-10-19 23:17:18 --> Controller Class Initialized
DEBUG - 2016-10-19 23:17:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:17:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:17:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:17:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:17:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:17:18 --> Model Class Initialized
INFO - 2016-10-19 23:20:38 --> Config Class Initialized
INFO - 2016-10-19 23:20:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:20:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:20:38 --> Utf8 Class Initialized
INFO - 2016-10-19 23:20:38 --> URI Class Initialized
INFO - 2016-10-19 23:20:38 --> Router Class Initialized
INFO - 2016-10-19 23:20:38 --> Output Class Initialized
INFO - 2016-10-19 23:20:38 --> Security Class Initialized
DEBUG - 2016-10-19 23:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:20:38 --> Input Class Initialized
INFO - 2016-10-19 23:20:38 --> Language Class Initialized
INFO - 2016-10-19 23:20:38 --> Language Class Initialized
INFO - 2016-10-19 23:20:38 --> Config Class Initialized
INFO - 2016-10-19 23:20:38 --> Loader Class Initialized
INFO - 2016-10-19 23:20:38 --> Helper loaded: common_helper
INFO - 2016-10-19 23:20:38 --> Helper loaded: url_helper
INFO - 2016-10-19 23:20:38 --> Database Driver Class Initialized
INFO - 2016-10-19 23:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:20:38 --> Parser Class Initialized
INFO - 2016-10-19 23:20:38 --> Controller Class Initialized
DEBUG - 2016-10-19 23:20:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:20:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:20:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:20:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:20:38 --> Model Class Initialized
INFO - 2016-10-19 23:23:58 --> Config Class Initialized
INFO - 2016-10-19 23:23:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:23:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:23:58 --> Utf8 Class Initialized
INFO - 2016-10-19 23:23:58 --> URI Class Initialized
INFO - 2016-10-19 23:23:58 --> Router Class Initialized
INFO - 2016-10-19 23:23:58 --> Output Class Initialized
INFO - 2016-10-19 23:23:58 --> Security Class Initialized
DEBUG - 2016-10-19 23:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:23:58 --> Input Class Initialized
INFO - 2016-10-19 23:23:58 --> Language Class Initialized
INFO - 2016-10-19 23:23:58 --> Language Class Initialized
INFO - 2016-10-19 23:23:58 --> Config Class Initialized
INFO - 2016-10-19 23:23:58 --> Loader Class Initialized
INFO - 2016-10-19 23:23:58 --> Helper loaded: common_helper
INFO - 2016-10-19 23:23:58 --> Helper loaded: url_helper
INFO - 2016-10-19 23:23:58 --> Database Driver Class Initialized
INFO - 2016-10-19 23:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:23:58 --> Parser Class Initialized
INFO - 2016-10-19 23:23:58 --> Controller Class Initialized
DEBUG - 2016-10-19 23:23:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:23:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:23:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:23:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:23:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:23:58 --> Model Class Initialized
INFO - 2016-10-19 23:27:18 --> Config Class Initialized
INFO - 2016-10-19 23:27:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:27:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:27:18 --> Utf8 Class Initialized
INFO - 2016-10-19 23:27:18 --> URI Class Initialized
INFO - 2016-10-19 23:27:18 --> Router Class Initialized
INFO - 2016-10-19 23:27:18 --> Output Class Initialized
INFO - 2016-10-19 23:27:18 --> Security Class Initialized
DEBUG - 2016-10-19 23:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:27:18 --> Input Class Initialized
INFO - 2016-10-19 23:27:18 --> Language Class Initialized
INFO - 2016-10-19 23:27:18 --> Language Class Initialized
INFO - 2016-10-19 23:27:18 --> Config Class Initialized
INFO - 2016-10-19 23:27:18 --> Loader Class Initialized
INFO - 2016-10-19 23:27:18 --> Helper loaded: common_helper
INFO - 2016-10-19 23:27:18 --> Helper loaded: url_helper
INFO - 2016-10-19 23:27:18 --> Database Driver Class Initialized
INFO - 2016-10-19 23:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:27:18 --> Parser Class Initialized
INFO - 2016-10-19 23:27:18 --> Controller Class Initialized
DEBUG - 2016-10-19 23:27:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:27:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:27:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:27:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:27:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:27:18 --> Model Class Initialized
INFO - 2016-10-19 23:30:38 --> Config Class Initialized
INFO - 2016-10-19 23:30:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:30:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:30:38 --> Utf8 Class Initialized
INFO - 2016-10-19 23:30:38 --> URI Class Initialized
INFO - 2016-10-19 23:30:38 --> Router Class Initialized
INFO - 2016-10-19 23:30:38 --> Output Class Initialized
INFO - 2016-10-19 23:30:38 --> Security Class Initialized
DEBUG - 2016-10-19 23:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:30:38 --> Input Class Initialized
INFO - 2016-10-19 23:30:38 --> Language Class Initialized
INFO - 2016-10-19 23:30:38 --> Language Class Initialized
INFO - 2016-10-19 23:30:38 --> Config Class Initialized
INFO - 2016-10-19 23:30:38 --> Loader Class Initialized
INFO - 2016-10-19 23:30:38 --> Helper loaded: common_helper
INFO - 2016-10-19 23:30:38 --> Helper loaded: url_helper
INFO - 2016-10-19 23:30:38 --> Database Driver Class Initialized
INFO - 2016-10-19 23:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:30:38 --> Parser Class Initialized
INFO - 2016-10-19 23:30:38 --> Controller Class Initialized
DEBUG - 2016-10-19 23:30:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:30:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:30:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:30:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:30:38 --> Model Class Initialized
INFO - 2016-10-19 23:33:58 --> Config Class Initialized
INFO - 2016-10-19 23:33:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:33:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:33:58 --> Utf8 Class Initialized
INFO - 2016-10-19 23:33:58 --> URI Class Initialized
INFO - 2016-10-19 23:33:58 --> Router Class Initialized
INFO - 2016-10-19 23:33:58 --> Output Class Initialized
INFO - 2016-10-19 23:33:58 --> Security Class Initialized
DEBUG - 2016-10-19 23:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:33:58 --> Input Class Initialized
INFO - 2016-10-19 23:33:58 --> Language Class Initialized
INFO - 2016-10-19 23:33:58 --> Language Class Initialized
INFO - 2016-10-19 23:33:58 --> Config Class Initialized
INFO - 2016-10-19 23:33:58 --> Loader Class Initialized
INFO - 2016-10-19 23:33:58 --> Helper loaded: common_helper
INFO - 2016-10-19 23:33:58 --> Helper loaded: url_helper
INFO - 2016-10-19 23:33:58 --> Database Driver Class Initialized
INFO - 2016-10-19 23:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:33:58 --> Parser Class Initialized
INFO - 2016-10-19 23:33:58 --> Controller Class Initialized
DEBUG - 2016-10-19 23:33:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:33:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:33:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:33:58 --> Model Class Initialized
INFO - 2016-10-19 23:37:18 --> Config Class Initialized
INFO - 2016-10-19 23:37:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:37:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:37:18 --> Utf8 Class Initialized
INFO - 2016-10-19 23:37:18 --> URI Class Initialized
INFO - 2016-10-19 23:37:18 --> Router Class Initialized
INFO - 2016-10-19 23:37:18 --> Output Class Initialized
INFO - 2016-10-19 23:37:18 --> Security Class Initialized
DEBUG - 2016-10-19 23:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:37:18 --> Input Class Initialized
INFO - 2016-10-19 23:37:18 --> Language Class Initialized
INFO - 2016-10-19 23:37:18 --> Language Class Initialized
INFO - 2016-10-19 23:37:18 --> Config Class Initialized
INFO - 2016-10-19 23:37:18 --> Loader Class Initialized
INFO - 2016-10-19 23:37:18 --> Helper loaded: common_helper
INFO - 2016-10-19 23:37:18 --> Helper loaded: url_helper
INFO - 2016-10-19 23:37:18 --> Database Driver Class Initialized
INFO - 2016-10-19 23:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:37:18 --> Parser Class Initialized
INFO - 2016-10-19 23:37:18 --> Controller Class Initialized
DEBUG - 2016-10-19 23:37:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:37:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:37:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:37:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:37:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:37:18 --> Model Class Initialized
INFO - 2016-10-19 23:40:38 --> Config Class Initialized
INFO - 2016-10-19 23:40:38 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:40:38 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:40:38 --> Utf8 Class Initialized
INFO - 2016-10-19 23:40:38 --> URI Class Initialized
INFO - 2016-10-19 23:40:38 --> Router Class Initialized
INFO - 2016-10-19 23:40:38 --> Output Class Initialized
INFO - 2016-10-19 23:40:38 --> Security Class Initialized
DEBUG - 2016-10-19 23:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:40:38 --> Input Class Initialized
INFO - 2016-10-19 23:40:38 --> Language Class Initialized
INFO - 2016-10-19 23:40:38 --> Language Class Initialized
INFO - 2016-10-19 23:40:38 --> Config Class Initialized
INFO - 2016-10-19 23:40:38 --> Loader Class Initialized
INFO - 2016-10-19 23:40:38 --> Helper loaded: common_helper
INFO - 2016-10-19 23:40:38 --> Helper loaded: url_helper
INFO - 2016-10-19 23:40:38 --> Database Driver Class Initialized
INFO - 2016-10-19 23:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:40:38 --> Parser Class Initialized
INFO - 2016-10-19 23:40:38 --> Controller Class Initialized
DEBUG - 2016-10-19 23:40:38 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:40:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:40:38 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:40:38 --> Model Class Initialized
DEBUG - 2016-10-19 23:40:38 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:40:38 --> Model Class Initialized
INFO - 2016-10-19 23:43:58 --> Config Class Initialized
INFO - 2016-10-19 23:43:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:43:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:43:58 --> Utf8 Class Initialized
INFO - 2016-10-19 23:43:58 --> URI Class Initialized
INFO - 2016-10-19 23:43:58 --> Router Class Initialized
INFO - 2016-10-19 23:43:58 --> Output Class Initialized
INFO - 2016-10-19 23:43:58 --> Security Class Initialized
DEBUG - 2016-10-19 23:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:43:58 --> Input Class Initialized
INFO - 2016-10-19 23:43:58 --> Language Class Initialized
INFO - 2016-10-19 23:43:58 --> Language Class Initialized
INFO - 2016-10-19 23:43:58 --> Config Class Initialized
INFO - 2016-10-19 23:43:58 --> Loader Class Initialized
INFO - 2016-10-19 23:43:58 --> Helper loaded: common_helper
INFO - 2016-10-19 23:43:58 --> Helper loaded: url_helper
INFO - 2016-10-19 23:43:58 --> Database Driver Class Initialized
INFO - 2016-10-19 23:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:43:58 --> Parser Class Initialized
INFO - 2016-10-19 23:43:58 --> Controller Class Initialized
DEBUG - 2016-10-19 23:43:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:43:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:43:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:43:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:43:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:43:58 --> Model Class Initialized
INFO - 2016-10-19 23:47:18 --> Config Class Initialized
INFO - 2016-10-19 23:47:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:47:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:47:18 --> Utf8 Class Initialized
INFO - 2016-10-19 23:47:18 --> URI Class Initialized
INFO - 2016-10-19 23:47:18 --> Router Class Initialized
INFO - 2016-10-19 23:47:18 --> Output Class Initialized
INFO - 2016-10-19 23:47:18 --> Security Class Initialized
DEBUG - 2016-10-19 23:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:47:18 --> Input Class Initialized
INFO - 2016-10-19 23:47:18 --> Language Class Initialized
INFO - 2016-10-19 23:47:18 --> Language Class Initialized
INFO - 2016-10-19 23:47:18 --> Config Class Initialized
INFO - 2016-10-19 23:47:18 --> Loader Class Initialized
INFO - 2016-10-19 23:47:18 --> Helper loaded: common_helper
INFO - 2016-10-19 23:47:18 --> Helper loaded: url_helper
INFO - 2016-10-19 23:47:18 --> Database Driver Class Initialized
INFO - 2016-10-19 23:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:47:18 --> Parser Class Initialized
INFO - 2016-10-19 23:47:18 --> Controller Class Initialized
DEBUG - 2016-10-19 23:47:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:47:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:47:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:47:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:47:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:47:18 --> Model Class Initialized
INFO - 2016-10-19 23:50:39 --> Config Class Initialized
INFO - 2016-10-19 23:50:39 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:50:39 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:50:39 --> Utf8 Class Initialized
INFO - 2016-10-19 23:50:39 --> URI Class Initialized
INFO - 2016-10-19 23:50:39 --> Router Class Initialized
INFO - 2016-10-19 23:50:39 --> Output Class Initialized
INFO - 2016-10-19 23:50:39 --> Security Class Initialized
DEBUG - 2016-10-19 23:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:50:39 --> Input Class Initialized
INFO - 2016-10-19 23:50:39 --> Language Class Initialized
INFO - 2016-10-19 23:50:39 --> Language Class Initialized
INFO - 2016-10-19 23:50:39 --> Config Class Initialized
INFO - 2016-10-19 23:50:39 --> Loader Class Initialized
INFO - 2016-10-19 23:50:39 --> Helper loaded: common_helper
INFO - 2016-10-19 23:50:39 --> Helper loaded: url_helper
INFO - 2016-10-19 23:50:39 --> Database Driver Class Initialized
INFO - 2016-10-19 23:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:50:39 --> Parser Class Initialized
INFO - 2016-10-19 23:50:39 --> Controller Class Initialized
DEBUG - 2016-10-19 23:50:39 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:50:39 --> Model Class Initialized
DEBUG - 2016-10-19 23:50:39 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:50:39 --> Model Class Initialized
DEBUG - 2016-10-19 23:50:39 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:50:39 --> Model Class Initialized
INFO - 2016-10-19 23:53:58 --> Config Class Initialized
INFO - 2016-10-19 23:53:58 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:53:58 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:53:58 --> Utf8 Class Initialized
INFO - 2016-10-19 23:53:58 --> URI Class Initialized
INFO - 2016-10-19 23:53:58 --> Router Class Initialized
INFO - 2016-10-19 23:53:58 --> Output Class Initialized
INFO - 2016-10-19 23:53:58 --> Security Class Initialized
DEBUG - 2016-10-19 23:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:53:58 --> Input Class Initialized
INFO - 2016-10-19 23:53:58 --> Language Class Initialized
INFO - 2016-10-19 23:53:58 --> Language Class Initialized
INFO - 2016-10-19 23:53:58 --> Config Class Initialized
INFO - 2016-10-19 23:53:58 --> Loader Class Initialized
INFO - 2016-10-19 23:53:58 --> Helper loaded: common_helper
INFO - 2016-10-19 23:53:58 --> Helper loaded: url_helper
INFO - 2016-10-19 23:53:58 --> Database Driver Class Initialized
INFO - 2016-10-19 23:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:53:58 --> Parser Class Initialized
INFO - 2016-10-19 23:53:58 --> Controller Class Initialized
DEBUG - 2016-10-19 23:53:58 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:53:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:53:58 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:53:58 --> Model Class Initialized
DEBUG - 2016-10-19 23:53:58 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:53:58 --> Model Class Initialized
INFO - 2016-10-19 23:57:18 --> Config Class Initialized
INFO - 2016-10-19 23:57:18 --> Hooks Class Initialized
DEBUG - 2016-10-19 23:57:18 --> UTF-8 Support Enabled
INFO - 2016-10-19 23:57:18 --> Utf8 Class Initialized
INFO - 2016-10-19 23:57:18 --> URI Class Initialized
INFO - 2016-10-19 23:57:18 --> Router Class Initialized
INFO - 2016-10-19 23:57:18 --> Output Class Initialized
INFO - 2016-10-19 23:57:18 --> Security Class Initialized
DEBUG - 2016-10-19 23:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-19 23:57:18 --> Input Class Initialized
INFO - 2016-10-19 23:57:18 --> Language Class Initialized
INFO - 2016-10-19 23:57:18 --> Language Class Initialized
INFO - 2016-10-19 23:57:18 --> Config Class Initialized
INFO - 2016-10-19 23:57:18 --> Loader Class Initialized
INFO - 2016-10-19 23:57:18 --> Helper loaded: common_helper
INFO - 2016-10-19 23:57:18 --> Helper loaded: url_helper
INFO - 2016-10-19 23:57:18 --> Database Driver Class Initialized
INFO - 2016-10-19 23:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-10-19 23:57:18 --> Parser Class Initialized
INFO - 2016-10-19 23:57:18 --> Controller Class Initialized
DEBUG - 2016-10-19 23:57:18 --> Servers MX_Controller Initialized
INFO - 2016-10-19 23:57:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:57:18 --> File loaded: /home/dolongpk/public_html/application/modules/servers/models/Servers_model.php
INFO - 2016-10-19 23:57:18 --> Model Class Initialized
DEBUG - 2016-10-19 23:57:18 --> File loaded: /home/dolongpk/public_html/application/modules/admincp_modules/models/Admincp_modules_model.php
INFO - 2016-10-19 23:57:18 --> Model Class Initialized
