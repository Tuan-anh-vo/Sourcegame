<div class="right-content-listnv-heading">
    <div class="right-content-listnv-heading-stt">STT</div>
    <div class="right-content-listnv-heading-tennv">Tên NV</div>
    <div class="right-content-listnv-heading-idnv">ID Nhân vật</div>
    <div class="right-content-listnv-heading-server">Server</div>
    <div class="right-content-listnv-heading-email">Email</div>
    <div class="right-content-listnv-heading-trangthai">Trạng thái</div>
    <div class="right-content-listnv-heading-chon">Chọn</div>
    <div class="clear"></div>
</div>
<div class="right-content-listnv-rowle">
    <div class="right-content-listnv-row-stt"></div>
    <div class="right-content-listnv-row-tennv"></div>
    <div class="right-content-listnv-row-idnv"></div>
    <div class="right-content-listnv-row-server"></div>
    <div class="right-content-listnv-row-email"></div>
    <div class="right-content-listnv-row-trangthai"></div>
    <div class="right-content-listnv-row-chon"><input type="checkbox" /></div>
    <div class="clear"></div>
</div>
<div class="right-content-listnv-rowchan">
    <div class="right-content-listnv-row-stt"></div>
    <div class="right-content-listnv-row-tennv"></div>
    <div class="right-content-listnv-row-idnv"></div>
    <div class="right-content-listnv-row-server"></div>
    <div class="right-content-listnv-row-email"></div>
    <div class="right-content-listnv-row-trangthai"></div>
    <div class="right-content-listnv-row-chon"><input type="checkbox" /></div>
    <div class="clear"></div>
</div>
<div class="right-content-listnv-rowle">
    <div class="right-content-listnv-row-stt"></div>
    <div class="right-content-listnv-row-tennv"></div>
    <div class="right-content-listnv-row-idnv"></div>
    <div class="right-content-listnv-row-server"></div>
    <div class="right-content-listnv-row-email"></div>
    <div class="right-content-listnv-row-trangthai"></div>
    <div class="right-content-listnv-row-chon"><input type="checkbox" /></div>
    <div class="clear"></div>
</div>
<div class="right-content-listnv-rowchan">
    <div class="right-content-listnv-row-stt"></div>
    <div class="right-content-listnv-row-tennv"></div>
    <div class="right-content-listnv-row-idnv"></div>
    <div class="right-content-listnv-row-server"></div>
    <div class="right-content-listnv-row-email"></div>
    <div class="right-content-listnv-row-trangthai"></div>
    <div class="right-content-listnv-row-chon"><input type="checkbox" /></div>
    <div class="clear"></div>
</div>