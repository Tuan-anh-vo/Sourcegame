<!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Login Game Tool</title>
</head>
	<header>Login Game Tool</header>
	<body>
		<form action="" method="post">
		<div>
			<p><label for="">Mật khẩu cấp 2:</label><input type="password" name="pwgt"></p>
			<p><label for="">&nbsp;</label><input type="button" value="Login"></p>
		</div>
		</form>
	</body>
</html>