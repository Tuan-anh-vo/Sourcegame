<div id="content_detail">
    <h2 id="title_detail">Lỗi 404!!!</h2>

    <div id="goback"><a href="<?= site_url('trang-chu') ?>">Trở về Trang Chủ</a></div>
    <div id="content">
        <p style="text-align: center">Không tìm thấy trang bạn yêu cầu!</p>
        <img src="<?=PATH_URL.'static/'?>images/loi404.png" width="300"/>
    </div>
</div>
