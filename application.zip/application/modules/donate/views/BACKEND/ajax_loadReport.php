		<?=$list_charge?>
			<div class="clearAll"></div>
		<?=$list_charge_amount?>
