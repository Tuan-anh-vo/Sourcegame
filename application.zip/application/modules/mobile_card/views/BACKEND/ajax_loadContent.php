<input type="hidden" id="first_access" name='first_access' value='<?php if(isset($first_access)) { print $first_access; } else {print "1";} ?>' />
<div class="clearAll"></div>