<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="<?=PATH_URL?>static/css/reset.css">
<style type="text/css">
.tichluy-wrapper{width: 400px;}
.tichluy-wrapper h3{text-align: center;font-weight: bold;padding: 4px 0;}
.list-tichluy{margin: 10px 0 0;}
.list-tichluy table{border: 1px solid red;width: 100%;}
.list-tichluy table tr{border: 1px solid red;}
.list-tichluy table tr th, .list-tichluy table tr td{border: 1px solid red;padding: 6px 4px;text-align: center;}
.list-tichluy table tr th{font-weight: bold;}
</style>
<div class="tichluy-wrapper">
	<h1>Chào bạn, <font>tan.nguyen123</font></h1>
	<h2>Danh sách event tích lũy</h2>
	<div class="list-tichluy">
		<h3>Tích lũy tháng 3</h1>
		<table>
			<tr>
				<th>Mốc nạp</th>
				<th>Phần quà</th>
				<th>Trạng thái</th>
			</tr>
			<tr>
				<td>20.000</td>
				<td>KNB, Đá tăng cấp</td>
				<td>Chưa nhận</td>
			</tr>
			<tr>
				<td>20.000</td>
				<td>KNB, Đá tăng cấp</td>
				<td>Chưa nhận</td>
			</tr>
		</table>
	</div>

	<div class="list-tichluy">
		<h3>Tích lũy tháng 4</h1>
		<table>
			<tr>
				<th>Mốc nạp</th>
				<th>Phần quà</th>
				<th>Trạng thái</th>
			</tr>
			<tr>
				<td>20.000</td>
				<td>KNB, Đá tăng cấp</td>
				<td>Chưa nhận</td>
			</tr>
			<tr>
				<td>20.000</td>
				<td>KNB, Đá tăng cấp</td>
				<td>Chưa nhận</td>
			</tr>
		</table>
	</div>

</div>
