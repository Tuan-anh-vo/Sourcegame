
        <div class='leftbar'>

            <div class="bt-link width left">
                <a href="<?=PATH_URL?>nap-the" class="bt-link-napthe"></a>
                <a href="<?=PATH_URL?>tin-tuc/bo-5-giftcode-mung-ngay-ra-mat-trang-chu" class="bt-link-quatanthu"></a>
                <a href="<?=PATH_URL?>tin-tuc" class="bt-link-tangcapnhanh"></a>
            </div>

            <!-- <div class="list-servers-w">
                    <div class="servers-title">DANH SÁCH SERVER</div>
                    <ul>

                                    <li><a href="#"><span class="date-server">[07-04]</span><span class="name-server">S1 - Bá Võ Lâm</span></a></li>

                    </ul>
                    <a class="server-ct" href="<?=PATH_URL?>may-chu">Xem thêm</a>
                </div> -->

                <?=Modules::run("servers/loadviewleft")?>

            <div class="fanpage-w">
                    <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fbavolamvn&amp;width=150&amp;height=208&amp;colorscheme=dark&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false" scrolling="no" frameborder="0" style="border: none;overflow: hidden;width: 150px;height: 260px;margin: 0px 0 0 0;background: #000" allowtransparency="true"></iframe>
                  </div>

        </div>


