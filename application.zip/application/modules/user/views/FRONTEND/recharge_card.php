<div class="tab-naptien" style="float: left;">
	<div class="rc-row">
		<p class="rc-title">NẠP TIỀN</p>
	</div>
	<div class="rc-row">
		<p class="rc-tip"><img style="float:left;margin-right: 6px;" src="<?php echo PATH_URL;?>static/images/user/img_hot_larger.png" width="50">Giảm ngay 3% khi nạp từ <font color="#e7604a"><b>50.000VNĐ</b></font> trở lên qua thẻ <font color="#6d9dc4"><b>ATM.</b></font></p>
	</div>
	<div class="rc-row">
		<p class="rc-result">Nhập số Seri và Mật khẩu để nạp tiền vào tài khoản</p>
	</div>
	<div class="rc-row">
		<div class="frm-nap">
			<form action="" method="post">
				<p><span class="frm-label">Nhà mạng :</span><select class="frm-input" style="width: 160px;margin-left: 2px;">
					<option value="0">-- Chọn nhà mạng --</option>
				</select></p>
				<p><span class="frm-label">Số Seri :</span><input class="frm-input" type="text"></p>
				<p><span class="frm-label">Mật mã của thẻ :</span><input class="frm-input" type="text"></p>
				<p><input type="submit" value="NẠP THẺ" class="bt-nap"></p>
			</form>
		</div>
		<div class="menhgia">
			<img src="<?php echo PATH_URL;?>static/images/user/img_menhgia.png" width="372">
		</div>
	</div>
	<div class="rc-row">
		<p class="rc-note"><font style="color:#e7604a;"><u>Lưu ý :</u></font> Thẻ được nạp trực tiếp thành tiền lưu hành trong game</p>
	</div>
</div>