<input type="hidden" value="<?=$module?>" id="module" />
<div class="gr_perm_error">
	<p><strong>FAILURE: </strong>Permission Denied.</p>
</div>