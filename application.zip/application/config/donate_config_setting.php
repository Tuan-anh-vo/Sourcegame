<?php
$config['rate'] = 50;
$config['time_begin'] = '2016-10-30 11:30:00';
$config['time_end'] = '2016-11-09 23:59:00';
$config['server'] = '1|24|23|22';
 ?>