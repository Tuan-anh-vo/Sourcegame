<?php
$config['pay_method'] = 'paydirect';
 ?>