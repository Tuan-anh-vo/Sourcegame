<!-- Load tracking -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48343651-3', 'auto');
  ga('send', 'pageview');

</script>

 <script type="text/javascript">

function check_register_convertion(){
  console.log(20);
  ga('send', 'event', 'Register', 'Source', 'FULL');
  var img = new Image()
  img.src = "http://www.googleadservices.com/pagead/conversion/870862469/?label=iCAZCIqQ4moQhZ2hnwM&amp;guid=ON&amp;script=0";
  var fbimg = new Image()
  fbimg.src = "https://www.facebook.com/tr?ev=304323203284452&amp;cd[value]=0.00&amp;cd[currency]=VND&amp;noscript=1";
 }
 </script>
 
<!-- Facebook Pixel Code -->
<script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '304323203284452']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
<!-- End Facebook Pixel Code -->

<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/tr?id=304323203284452&amp;ev=PixelInitialized" /></noscript>

<script type="text/javascript">
var google_tag_params = {
dynx_itemid: 'REPLACE_WITH_VALUE',
dynx_itemid2: 'REPLACE_WITH_VALUE',
dynx_pagetype: 'REPLACE_WITH_VALUE',
dynx_totalvalue: 'REPLACE_WITH_VALUE',
};
</script>
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 870862469;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" style="display:none" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/870862469/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<!-- End Load tracking -->
